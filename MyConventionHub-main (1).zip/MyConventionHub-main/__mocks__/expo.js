// Stub for all expo-* packages in test environment
module.exports = {};
