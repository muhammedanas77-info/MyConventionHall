// Minimal React Native stub for Node/Jest environment
module.exports = {
  Platform: { OS: 'ios', select: (obj) => obj.ios ?? obj.default },
  AppState: { addEventListener: () => ({ remove: () => {} }) },
  Alert: { alert: () => {} },
};
