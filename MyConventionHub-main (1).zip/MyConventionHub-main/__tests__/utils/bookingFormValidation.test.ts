/**
 * Tests for service booking form validation rules.
 *
 * guest_count is required for wedding + corporate, optional for birthday + other.
 * Requirements: 6.1
 */
import type { EventType } from '@/types';

// Inline the validation logic (mirrors what service-booking/[id].tsx enforces)
function isGuestCountRequired(eventType: EventType): boolean {
  return eventType === 'wedding' || eventType === 'corporate';
}

function validateBookingForm(params: {
  eventDate: string;
  eventType: EventType;
  guestCount: number | null;
  specialRequests: string;
}): { valid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};

  if (!params.eventDate) {
    errors.eventDate = 'Event date is required';
  }

  if (isGuestCountRequired(params.eventType) && (params.guestCount === null || params.guestCount < 1)) {
    errors.guestCount = 'Guest count is required for this event type';
  }

  if (params.guestCount !== null && params.guestCount < 1) {
    errors.guestCount = 'Guest count must be at least 1';
  }

  if (params.specialRequests.length > 500) {
    errors.specialRequests = 'Special requests must be 500 characters or fewer';
  }

  return { valid: Object.keys(errors).length === 0, errors };
}

// ─── isGuestCountRequired ────────────────────────────────────────────────────

describe('isGuestCountRequired (Req 6.1)', () => {
  it('returns true for wedding', () => {
    expect(isGuestCountRequired('wedding')).toBe(true);
  });

  it('returns true for corporate', () => {
    expect(isGuestCountRequired('corporate')).toBe(true);
  });

  it('returns false for birthday', () => {
    expect(isGuestCountRequired('birthday')).toBe(false);
  });

  it('returns false for other', () => {
    expect(isGuestCountRequired('other')).toBe(false);
  });
});

// ─── validateBookingForm ─────────────────────────────────────────────────────

describe('validateBookingForm', () => {
  const base = {
    eventDate: '2026-09-15',
    eventType: 'wedding' as EventType,
    guestCount: 150,
    specialRequests: '',
  };

  it('passes with all required fields for wedding', () => {
    const r = validateBookingForm(base);
    expect(r.valid).toBe(true);
  });

  it('fails wedding without guest count', () => {
    const r = validateBookingForm({ ...base, guestCount: null });
    expect(r.valid).toBe(false);
    expect(r.errors.guestCount).toBeDefined();
  });

  it('fails corporate without guest count', () => {
    const r = validateBookingForm({ ...base, eventType: 'corporate', guestCount: null });
    expect(r.valid).toBe(false);
    expect(r.errors.guestCount).toBeDefined();
  });

  it('passes birthday without guest count (optional)', () => {
    const r = validateBookingForm({ ...base, eventType: 'birthday', guestCount: null });
    expect(r.valid).toBe(true);
  });

  it('passes other without guest count (optional)', () => {
    const r = validateBookingForm({ ...base, eventType: 'other', guestCount: null });
    expect(r.valid).toBe(true);
  });

  it('fails when guest count is provided but < 1', () => {
    const r = validateBookingForm({ ...base, guestCount: 0 });
    expect(r.valid).toBe(false);
    expect(r.errors.guestCount).toBeDefined();
  });

  it('fails when event date is missing', () => {
    const r = validateBookingForm({ ...base, eventDate: '' });
    expect(r.valid).toBe(false);
    expect(r.errors.eventDate).toBeDefined();
  });

  it('fails when special requests exceed 500 chars', () => {
    const r = validateBookingForm({ ...base, specialRequests: 'x'.repeat(501) });
    expect(r.valid).toBe(false);
    expect(r.errors.specialRequests).toBeDefined();
  });

  it('passes with exactly 500-char special requests', () => {
    const r = validateBookingForm({ ...base, specialRequests: 'x'.repeat(500) });
    expect(r.valid).toBe(true);
  });
});
