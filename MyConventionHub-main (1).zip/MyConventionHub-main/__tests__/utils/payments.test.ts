/**
 * Tests for utils/payments.ts
 *
 * Covers: verifyPayment, submitPaymentProof, rejectPayment
 * Supabase is mocked with a self-contained factory (required by jest.mock hoisting).
 */

// ─── Supabase mock — must be self-contained inside jest.mock factory ──────────
jest.mock('@/utils/supabase', () => {
  // Build a chainable mock builder
  function makeChain(resolvedValue: any) {
    const chain: any = {};
    const methods = ['select', 'update', 'insert', 'upsert', 'eq', 'in', 'order'];
    methods.forEach((m) => { chain[m] = jest.fn(() => chain); });
    chain.single = jest.fn(() => Promise.resolve(resolvedValue));
    return chain;
  }

  // We expose a mutable "responses" array so each test can push its own resolved values
  const responses: any[] = [];
  let callCount = 0;

  const fromMock = jest.fn(() => {
    const idx = callCount++;
    const resolved = responses[idx] ?? { data: null, error: null };
    return makeChain(resolved);
  });

  return {
    supabase: {
      from: fromMock,
      _responses: responses,
      _reset: () => { responses.length = 0; callCount = 0; fromMock.mockClear(); },
    },
  };
});

jest.mock('@/utils/notifications', () => ({
  sendBookingNotification: jest.fn().mockResolvedValue(undefined),
}));

import { supabase } from '@/utils/supabase';
import { verifyPayment, submitPaymentProof, rejectPayment } from '@/utils/payments';

const sb = supabase as any;

beforeEach(() => sb._reset());

// ─── verifyPayment ────────────────────────────────────────────────────────────
describe('verifyPayment', () => {
  it('returns error when payment is not found', async () => {
    sb._responses.push({ data: null, error: { message: 'Not found' } });

    const result = await verifyPayment('pay-1', 'admin-1');
    expect(result.success).toBe(false);
    expect(result.error).toBe('Not found');
  });

  it('returns success on happy path', async () => {
    // 1. Payment fetch
    sb._responses.push({ data: { id: 'pay-1', booking_id: 'book-1', amount: 320_000 }, error: null });
    // 2. Payment update (verified_at)
    sb._responses.push({ data: null, error: null });
    // 3. Booking fetch
    sb._responses.push({ data: { id: 'book-1', hall_id: 'hall-1', total_amount: 320_000, discount_amount: 5_000 }, error: null });
    // 4. Booking update payment_verified
    sb._responses.push({ data: null, error: null });
    // 5. Booking update status
    sb._responses.push({ data: null, error: null });
    // 6. Status history insert
    sb._responses.push({ data: null, error: null });
    // 7. Hall fetch for owner_id
    sb._responses.push({ data: { owner_id: 'owner-1' }, error: null });
    // 8. Commissions upsert
    sb._responses.push({ data: null, error: null });

    const result = await verifyPayment('pay-1', 'admin-1');
    expect(result.success).toBe(true);
  });
});

// ─── submitPaymentProof ───────────────────────────────────────────────────────
describe('submitPaymentProof', () => {
  it('returns data on success', async () => {
    sb._responses.push({ data: { id: 'pay-1', status: 'submitted' }, error: null });

    const result = await submitPaymentProof('pay-1', 'https://example.com/proof.jpg', 'Paid via GPay');
    expect(result.error).toBeNull();
    expect(result.data).toMatchObject({ id: 'pay-1', status: 'submitted' });
  });

  it('returns error on failure', async () => {
    sb._responses.push({ data: null, error: { message: 'Update failed' } });

    const result = await submitPaymentProof('pay-1', null);
    expect(result.error).toBeTruthy();
  });
});

// ─── rejectPayment ────────────────────────────────────────────────────────────
describe('rejectPayment', () => {
  it('returns data on success', async () => {
    sb._responses.push({ data: { id: 'pay-1', booking_id: 'book-1' }, error: null });

    const result = await rejectPayment('pay-1', 'admin-1', 'Screenshot unclear');
    expect(result.error).toBeNull();
  });

  it('returns error on failure', async () => {
    sb._responses.push({ data: null, error: { message: 'Reject failed' } });

    const result = await rejectPayment('pay-1', 'admin-1', 'reason');
    expect(result.error).toBeTruthy();
  });
});
