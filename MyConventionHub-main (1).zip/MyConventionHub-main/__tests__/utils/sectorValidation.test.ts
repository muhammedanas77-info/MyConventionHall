/**
 * Tests for utils/sectorValidation.ts
 *
 * Covers all 8 sector schemas (success + failure paths for field bounds).
 * Requirements: 2.1–2.8
 */
import { validateSectorData, getMandatoryFields } from '@/utils/sectorValidation';

// ─── Shared helpers ───────────────────────────────────────────────────────────

const VALID_URL = 'https://example.com/photo.jpg';
const VALID_RANGE = { start_date: '2026-01-01', end_date: '2026-01-05' };

function ok(sector: Parameters<typeof validateSectorData>[0], data: unknown) {
  const r = validateSectorData(sector, data);
  if (!r.success) throw new Error(JSON.stringify((r as any).error.flatten()));
  return r;
}

function fail(sector: Parameters<typeof validateSectorData>[0], data: unknown) {
  const r = validateSectorData(sector, data);
  expect(r.success).toBe(false);
  return r;
}

// ─── blockedDateRange ─────────────────────────────────────────────────────────

describe('blockedDateRange (shared)', () => {
  const base = {
    business_name: 'Test Venue',
    address: '1 Main St',
    city: 'Bangalore',
    capacity_min: 50,
    capacity_max: 200,
    price_per_day: 100_000,
    photos: [VALID_URL],
    amenities: [],
    blocked_dates: [],
  };

  it('accepts valid range where start equals end', () => {
    ok('venue', { ...base, blocked_dates: [{ start_date: '2026-06-01', end_date: '2026-06-01' }] });
  });

  it('rejects range where start > end', () => {
    fail('venue', { ...base, blocked_dates: [{ start_date: '2026-06-10', end_date: '2026-06-01' }] });
  });

  it('rejects non-ISO date string', () => {
    fail('venue', { ...base, blocked_dates: [{ start_date: 'not-a-date', end_date: '2026-06-01' }] });
  });
});

// ─── venue ────────────────────────────────────────────────────────────────────

describe('venue schema (Req 2.1)', () => {
  const valid = {
    business_name: 'Grand Hall',
    address: '123 Palace Road',
    city: 'Bangalore',
    capacity_min: 50,
    capacity_max: 500,
    price_per_day: 250_000,
    photos: [VALID_URL],
    amenities: ['AC', 'Parking'],
    blocked_dates: [VALID_RANGE],
  };

  it('accepts a fully valid payload', () => { ok('venue', valid); });

  it('rejects empty business_name', () => {
    fail('venue', { ...valid, business_name: '' });
  });

  it('rejects business_name > 100 chars', () => {
    fail('venue', { ...valid, business_name: 'x'.repeat(101) });
  });

  it('rejects capacity_min of 0', () => {
    fail('venue', { ...valid, capacity_min: 0 });
  });

  it('rejects capacity_max > 100 000', () => {
    fail('venue', { ...valid, capacity_max: 100_001 });
  });

  it('rejects capacity_max < capacity_min', () => {
    fail('venue', { ...valid, capacity_min: 300, capacity_max: 100 });
  });

  it('rejects photos array with 0 items', () => {
    fail('venue', { ...valid, photos: [] });
  });

  it('rejects photos array with > 20 items', () => {
    fail('venue', { ...valid, photos: Array(21).fill(VALID_URL) });
  });

  it('rejects price_per_day of 0', () => {
    fail('venue', { ...valid, price_per_day: 0 });
  });

  it('rejects price_per_day > 10 000 000', () => {
    fail('venue', { ...valid, price_per_day: 10_000_001 });
  });
});

// ─── florist ──────────────────────────────────────────────────────────────────

describe('florist schema (Req 2.2)', () => {
  const valid = {
    business_name: 'Petal Studio',
    city: 'Mumbai',
    service_area: 'Western Suburbs',
    specialty_styles: ['Romantic', 'Modern'],
    price_range_min: 5_000,
    price_range_max: 50_000,
    portfolio_photos: [],
    blocked_dates: [],
  };

  it('accepts a fully valid payload', () => { ok('florist', valid); });

  it('rejects empty specialty_styles', () => {
    fail('florist', { ...valid, specialty_styles: [] });
  });

  it('rejects specialty_styles with > 10 items', () => {
    fail('florist', { ...valid, specialty_styles: Array(11).fill('Style') });
  });

  it('rejects price_range_max < price_range_min', () => {
    fail('florist', { ...valid, price_range_min: 30_000, price_range_max: 10_000 });
  });

  it('rejects portfolio_photos with > 20 items', () => {
    fail('florist', { ...valid, portfolio_photos: Array(21).fill(VALID_URL) });
  });
});

// ─── musician ─────────────────────────────────────────────────────────────────

describe('musician schema (Req 2.3)', () => {
  const valid = {
    artist_name: 'Ravi Shankar Jr.',
    city: 'Delhi',
    genre_tags: ['Classical', 'Jazz'],
    performance_durations_min: [60, 120],
    price_per_event: 25_000,
    demo_links: [],
    blocked_dates: [],
  };

  it('accepts a fully valid payload', () => { ok('musician', valid); });

  it('rejects empty genre_tags', () => {
    fail('musician', { ...valid, genre_tags: [] });
  });

  it('rejects performance_duration < 15 min', () => {
    fail('musician', { ...valid, performance_durations_min: [14] });
  });

  it('rejects performance_duration > 480 min', () => {
    fail('musician', { ...valid, performance_durations_min: [481] });
  });

  it('rejects demo_links with > 5 items', () => {
    fail('musician', { ...valid, demo_links: Array(6).fill(VALID_URL) });
  });

  it('rejects price_per_event of 0', () => {
    fail('musician', { ...valid, price_per_event: 0 });
  });
});

// ─── photographer ─────────────────────────────────────────────────────────────

describe('photographer schema (Req 2.4)', () => {
  const valid = {
    studio_name: 'Lens & Light',
    city: 'Chennai',
    photography_styles: ['Candid', 'Cinematic'],
    packages: [{ name: 'Basic', price: 20_000 }, { name: 'Premium', price: 60_000 }],
    portfolio_media: [],
    blocked_dates: [],
  };

  it('accepts a fully valid payload', () => { ok('photographer', valid); });

  it('rejects empty photography_styles', () => {
    fail('photographer', { ...valid, photography_styles: [] });
  });

  it('rejects empty packages array', () => {
    fail('photographer', { ...valid, packages: [] });
  });

  it('rejects package with empty name', () => {
    fail('photographer', { ...valid, packages: [{ name: '', price: 10_000 }] });
  });

  it('rejects package with price 0', () => {
    fail('photographer', { ...valid, packages: [{ name: 'Pkg', price: 0 }] });
  });

  it('rejects > 20 packages', () => {
    fail('photographer', {
      ...valid,
      packages: Array(21).fill({ name: 'Pkg', price: 1_000 }),
    });
  });
});

// ─── caterer ──────────────────────────────────────────────────────────────────

describe('caterer schema (Req 2.5)', () => {
  const valid = {
    business_name: 'Spice Routes',
    city: 'Hyderabad',
    cuisine_types: ['South Indian', 'Mughal'],
    service_capacity_min: 50,
    service_capacity_max: 500,
    price_per_plate_min: 200,
    price_per_plate_max: 800,
    menu_highlights: 'Biryani, Paneer, Desserts',
    blocked_dates: [],
  };

  it('accepts a fully valid payload', () => { ok('caterer', valid); });

  it('rejects empty cuisine_types', () => {
    fail('caterer', { ...valid, cuisine_types: [] });
  });

  it('rejects service_capacity_max < service_capacity_min', () => {
    fail('caterer', { ...valid, service_capacity_min: 300, service_capacity_max: 100 });
  });

  it('rejects price_per_plate_max < price_per_plate_min', () => {
    fail('caterer', { ...valid, price_per_plate_min: 500, price_per_plate_max: 100 });
  });

  it('rejects menu_highlights > 500 chars', () => {
    fail('caterer', { ...valid, menu_highlights: 'x'.repeat(501) });
  });
});

// ─── decorator ────────────────────────────────────────────────────────────────

describe('decorator schema (Req 2.6)', () => {
  const valid = {
    business_name: 'Bloom Decor',
    city: 'Pune',
    decoration_themes: ['Rustic', 'Floral'],
    price_range_min: 10_000,
    price_range_max: 100_000,
    portfolio_photos: [],
    blocked_dates: [],
  };

  it('accepts a fully valid payload', () => { ok('decorator', valid); });

  it('rejects empty decoration_themes', () => {
    fail('decorator', { ...valid, decoration_themes: [] });
  });

  it('rejects price_range_max < price_range_min', () => {
    fail('decorator', { ...valid, price_range_min: 80_000, price_range_max: 10_000 });
  });
});

// ─── artist ───────────────────────────────────────────────────────────────────

describe('artist schema (Req 2.7)', () => {
  const valid = {
    artist_name: 'Ananya Arts',
    city: 'Kolkata',
    art_types: ['Mehendi', 'Rangoli'],
    price_per_event: 5_000,
    portfolio_photos: [],
    blocked_dates: [],
  };

  it('accepts a fully valid payload', () => { ok('artist', valid); });

  it('rejects empty art_types', () => {
    fail('artist', { ...valid, art_types: [] });
  });

  it('rejects art_types with > 10 items', () => {
    fail('artist', { ...valid, art_types: Array(11).fill('Art') });
  });

  it('rejects price_per_event of 0', () => {
    fail('artist', { ...valid, price_per_event: 0 });
  });
});

// ─── other ────────────────────────────────────────────────────────────────────

describe('other schema (Req 2.8)', () => {
  const valid = {
    business_name: 'Event Magic',
    city: 'Ahmedabad',
    service_description: 'Custom event coordination and logistics.',
    price_range_min: 5_000,
    price_range_max: 50_000,
    blocked_dates: [],
  };

  it('accepts a fully valid payload', () => { ok('other', valid); });

  it('rejects empty service_description', () => {
    fail('other', { ...valid, service_description: '' });
  });

  it('rejects service_description > 500 chars', () => {
    fail('other', { ...valid, service_description: 'x'.repeat(501) });
  });

  it('rejects price_range_max < price_range_min', () => {
    fail('other', { ...valid, price_range_min: 40_000, price_range_max: 5_000 });
  });
});

// ─── getMandatoryFields ───────────────────────────────────────────────────────

describe('getMandatoryFields', () => {
  it('returns non-empty array for every sector', () => {
    const sectors = ['venue', 'florist', 'musician', 'photographer', 'caterer', 'decorator', 'artist', 'other'] as const;
    for (const s of sectors) {
      expect(getMandatoryFields(s).length).toBeGreaterThan(0);
    }
  });
});
