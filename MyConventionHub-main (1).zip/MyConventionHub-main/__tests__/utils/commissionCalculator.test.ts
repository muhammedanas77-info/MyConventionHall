/**
 * Tests for utils/commissionCalculator.ts
 *
 * Covers: fixed fee only, percentage only, hybrid, cap at 50%, zero amount.
 * Requirements: 9.2, 9.3, 9.6
 */
import { calculateCommission } from '@/utils/commissionCalculator';
import type { SectorCommissionRate } from '@/types';

function rate(fixed_fee: number, percentage_rate: number): SectorCommissionRate {
  return {
    id: 'test-id',
    sector: 'venue',
    fixed_fee,
    percentage_rate,
    effective_from: '2026-01-01',
    created_at: '2026-01-01T00:00:00Z',
  } as SectorCommissionRate;
}

describe('calculateCommission', () => {
  it('fixed fee only (0% percentage)', () => {
    const r = calculateCommission(rate(2_000, 0), 100_000);
    expect(r.commission).toBe(2_000);
    expect(r.vendorPayout).toBe(98_000);
    expect(r.isCapped).toBe(false);
  });

  it('percentage only (0 fixed fee)', () => {
    const r = calculateCommission(rate(0, 10), 100_000);
    expect(r.commission).toBe(10_000);
    expect(r.vendorPayout).toBe(90_000);
    expect(r.isCapped).toBe(false);
  });

  it('hybrid: fixed + percentage (Req 9.2)', () => {
    const r = calculateCommission(rate(2_000, 8), 500_000);
    // 2000 + 0.08 * 500000 = 2000 + 40000 = 42000
    expect(r.commission).toBe(42_000);
    expect(r.vendorPayout).toBe(458_000);
    expect(r.isCapped).toBe(false);
  });

  it('caps commission at 50% of total (Req 9.6)', () => {
    // fixed_fee=0, percentage_rate=80 → would be 80000 on 100000, but cap is 50000
    const r = calculateCommission(rate(0, 80), 100_000);
    expect(r.commission).toBe(50_000);
    expect(r.vendorPayout).toBe(50_000);
    expect(r.isCapped).toBe(true);
  });

  it('sets isCapped=true when fixed fee alone exceeds 50%', () => {
    const r = calculateCommission(rate(60_000, 0), 100_000);
    expect(r.commission).toBe(50_000);
    expect(r.isCapped).toBe(true);
  });

  it('commission rounds to 2 decimal places', () => {
    // 0.08 * 333 = 26.64 — no rounding needed here but use an odd number
    const r = calculateCommission(rate(0, 8), 333);
    expect(r.commission).toBe(Math.round(0.08 * 333 * 100) / 100);
    expect(r.vendorPayout).toBe(Math.round((333 - r.commission) * 100) / 100);
  });

  it('returns zero commission and full payout for zero total amount', () => {
    const r = calculateCommission(rate(0, 10), 0);
    expect(r.commission).toBe(0);
    expect(r.vendorPayout).toBe(0);
    expect(r.isCapped).toBe(false);
  });

  it('vendorPayout = totalAmount - commission always (Req 9.3)', () => {
    const cases = [
      { fixed: 1_000, pct: 5, total: 200_000 },
      { fixed: 500, pct: 10, total: 50_000 },
      { fixed: 3_000, pct: 10, total: 2_000 }, // triggers cap
    ];
    for (const { fixed, pct, total } of cases) {
      const r = calculateCommission(rate(fixed, pct), total);
      expect(r.vendorPayout).toBeCloseTo(total - r.commission, 5);
    }
  });
});
