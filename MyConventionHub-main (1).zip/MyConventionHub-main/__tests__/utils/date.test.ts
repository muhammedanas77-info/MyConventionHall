/**
 * Tests for utils/date.ts — pure date utility functions
 */
import {
  formatDateDisplay,
  formatDateShort,
  isDateInPast,
  isDateInFuture,
  getDaysUntil,
  getRefundPercentage,
} from '@/utils/date';

// Pin "today" so tests are deterministic
const TODAY = '2026-05-15';
const YESTERDAY = '2026-05-14';
const TOMORROW = '2026-05-16';
const IN_30_DAYS = '2026-06-14';
const IN_14_DAYS = '2026-05-30'; // 15 days out — qualifies for 50% refund

// Mock Date so "today" is always 2026-05-15
const RealDate = Date;
beforeAll(() => {
  jest.useFakeTimers();
  jest.setSystemTime(new Date('2026-05-15T12:00:00Z'));
});
afterAll(() => {
  jest.useRealTimers();
});

describe('formatDateDisplay', () => {
  it('formats a date as "D Month YYYY"', () => {
    expect(formatDateDisplay('2026-01-05')).toBe('5 January 2026');
  });

  it('formats December correctly', () => {
    expect(formatDateDisplay('2026-12-25')).toBe('25 December 2026');
  });
});

describe('formatDateShort', () => {
  it('formats as "D Mon"', () => {
    expect(formatDateShort('2026-03-08')).toBe('8 Mar');
  });
});

describe('isDateInPast', () => {
  it('returns true for yesterday', () => {
    expect(isDateInPast(YESTERDAY)).toBe(true);
  });

  it('returns false for tomorrow', () => {
    expect(isDateInPast(TOMORROW)).toBe(false);
  });

  it('returns false for today', () => {
    expect(isDateInPast(TODAY)).toBe(false);
  });
});

describe('isDateInFuture', () => {
  it('returns true for tomorrow', () => {
    expect(isDateInFuture(TOMORROW)).toBe(true);
  });

  it('returns false for yesterday', () => {
    expect(isDateInFuture(YESTERDAY)).toBe(false);
  });

  it('returns false for today', () => {
    expect(isDateInFuture(TODAY)).toBe(false);
  });
});

describe('getDaysUntil', () => {
  it('returns 1 for tomorrow', () => {
    expect(getDaysUntil(TOMORROW)).toBe(1);
  });

  it('returns -1 for yesterday', () => {
    expect(getDaysUntil(YESTERDAY)).toBe(-1);
  });

  it('returns 0 for today', () => {
    expect(getDaysUntil(TODAY)).toBe(0);
  });
});

describe('getRefundPercentage', () => {
  it('returns 100% for 30+ days out', () => {
    expect(getRefundPercentage(IN_30_DAYS)).toBe(100);
  });

  it('returns 50% for 15 days out', () => {
    expect(getRefundPercentage(IN_14_DAYS)).toBe(50);
  });

  it('returns 0% for yesterday (past event)', () => {
    expect(getRefundPercentage(YESTERDAY)).toBe(0);
  });
});
