/**
 * Tests for utils/availabilityChecker.ts
 *
 * Covers: free date, booked date, blocked range boundaries, getUnavailableDates.
 * Requirements: 6.2, 6.3
 */
import { isDateAvailable, getUnavailableDates } from '@/utils/availabilityChecker';
import type { BlockedDateRange } from '@/types';

const NO_BLOCKS: BlockedDateRange[] = [];
const NO_BOOKINGS: { event_date: string }[] = [];

// ─── isDateAvailable ─────────────────────────────────────────────────────────

describe('isDateAvailable', () => {
  it('returns true when no blocks and no bookings', () => {
    expect(isDateAvailable(NO_BLOCKS, NO_BOOKINGS, '2026-08-15')).toBe(true);
  });

  it('returns false when date matches a confirmed booking', () => {
    expect(isDateAvailable(NO_BLOCKS, [{ event_date: '2026-08-15' }], '2026-08-15')).toBe(false);
  });

  it('returns true when confirmed bookings exist on different dates', () => {
    expect(isDateAvailable(NO_BLOCKS, [{ event_date: '2026-08-14' }], '2026-08-15')).toBe(true);
  });

  it('returns false for a date equal to blocked range start (inclusive)', () => {
    const range: BlockedDateRange = { start_date: '2026-06-01', end_date: '2026-06-05' };
    expect(isDateAvailable([range], NO_BOOKINGS, '2026-06-01')).toBe(false);
  });

  it('returns false for a date within a blocked range', () => {
    const range: BlockedDateRange = { start_date: '2026-06-01', end_date: '2026-06-05' };
    expect(isDateAvailable([range], NO_BOOKINGS, '2026-06-03')).toBe(false);
  });

  it('returns false for a date equal to blocked range end (inclusive)', () => {
    const range: BlockedDateRange = { start_date: '2026-06-01', end_date: '2026-06-05' };
    expect(isDateAvailable([range], NO_BOOKINGS, '2026-06-05')).toBe(false);
  });

  it('returns true for a date just before blocked range', () => {
    const range: BlockedDateRange = { start_date: '2026-06-01', end_date: '2026-06-05' };
    expect(isDateAvailable([range], NO_BOOKINGS, '2026-05-31')).toBe(true);
  });

  it('returns true for a date just after blocked range', () => {
    const range: BlockedDateRange = { start_date: '2026-06-01', end_date: '2026-06-05' };
    expect(isDateAvailable([range], NO_BOOKINGS, '2026-06-06')).toBe(true);
  });

  it('returns false when date is blocked by both a range and a booking', () => {
    const range: BlockedDateRange = { start_date: '2026-06-01', end_date: '2026-06-05' };
    expect(isDateAvailable([range], [{ event_date: '2026-06-03' }], '2026-06-03')).toBe(false);
  });

  it('handles single-day blocked range (start === end)', () => {
    const range: BlockedDateRange = { start_date: '2026-07-04', end_date: '2026-07-04' };
    expect(isDateAvailable([range], NO_BOOKINGS, '2026-07-04')).toBe(false);
    expect(isDateAvailable([range], NO_BOOKINGS, '2026-07-05')).toBe(true);
  });

  it('returns false when date is blocked by second of multiple ranges', () => {
    const ranges: BlockedDateRange[] = [
      { start_date: '2026-06-01', end_date: '2026-06-05' },
      { start_date: '2026-07-10', end_date: '2026-07-15' },
    ];
    expect(isDateAvailable(ranges, NO_BOOKINGS, '2026-07-12')).toBe(false);
    expect(isDateAvailable(ranges, NO_BOOKINGS, '2026-07-09')).toBe(true);
  });
});

// ─── getUnavailableDates ─────────────────────────────────────────────────────

describe('getUnavailableDates', () => {
  it('returns empty array when nothing is blocked', () => {
    const result = getUnavailableDates(NO_BLOCKS, NO_BOOKINGS, '2026-08-01', '2026-08-05');
    expect(result).toEqual([]);
  });

  it('returns all dates within a blocked range', () => {
    const range: BlockedDateRange = { start_date: '2026-08-02', end_date: '2026-08-04' };
    const result = getUnavailableDates([range], NO_BOOKINGS, '2026-08-01', '2026-08-05');
    expect(result).toEqual(['2026-08-02', '2026-08-03', '2026-08-04']);
  });

  it('includes confirmed booking dates', () => {
    const result = getUnavailableDates(NO_BLOCKS, [{ event_date: '2026-08-03' }], '2026-08-01', '2026-08-05');
    expect(result).toContain('2026-08-03');
    expect(result).not.toContain('2026-08-01');
  });

  it('does not include dates outside the query window', () => {
    const range: BlockedDateRange = { start_date: '2026-07-01', end_date: '2026-07-31' };
    const result = getUnavailableDates([range], NO_BOOKINGS, '2026-08-01', '2026-08-05');
    expect(result).toEqual([]);
  });

  it('returns single date when fromDate === toDate and that date is unavailable', () => {
    const range: BlockedDateRange = { start_date: '2026-09-10', end_date: '2026-09-10' };
    const result = getUnavailableDates([range], NO_BOOKINGS, '2026-09-10', '2026-09-10');
    expect(result).toEqual(['2026-09-10']);
  });

  it('returns empty when fromDate === toDate and date is available', () => {
    const result = getUnavailableDates(NO_BLOCKS, NO_BOOKINGS, '2026-09-10', '2026-09-10');
    expect(result).toEqual([]);
  });
});
