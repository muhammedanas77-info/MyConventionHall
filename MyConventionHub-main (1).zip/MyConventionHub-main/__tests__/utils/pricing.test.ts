/**
 * Tests for utils/pricing.ts
 *
 * These are pure functions — no mocking required.
 * Covers: getSlotPrice, getDiscount, calculatePriceBreakdown
 */
import { getSlotPrice, getDiscount, calculatePriceBreakdown } from '@/utils/pricing';
import { COMMISSION_RATE, ADVANCE_RATE } from '@/constants/pricing';

const BASE = 200_000; // ₹2L base price

// ─── getSlotPrice ────────────────────────────────────────────────────────────
describe('getSlotPrice', () => {
  it('applies off_season morning multiplier (1.0)', () => {
    expect(getSlotPrice(BASE, 'off_season', 'morning')).toBe(200_000);
  });

  it('applies off_season evening multiplier (1.2)', () => {
    expect(getSlotPrice(BASE, 'off_season', 'evening')).toBe(240_000);
  });

  it('applies off_season full_day multiplier (1.7)', () => {
    expect(getSlotPrice(BASE, 'off_season', 'full_day')).toBe(340_000);
  });

  it('applies peak morning multiplier (1.6)', () => {
    expect(getSlotPrice(BASE, 'peak', 'morning')).toBe(320_000);
  });

  it('applies peak evening multiplier (1.9)', () => {
    expect(getSlotPrice(BASE, 'peak', 'evening')).toBe(380_000);
  });

  it('applies peak full_day multiplier (2.8)', () => {
    expect(getSlotPrice(BASE, 'peak', 'full_day')).toBe(560_000);
  });

  it('applies shoulder full_day multiplier (2.1)', () => {
    expect(getSlotPrice(BASE, 'shoulder', 'full_day')).toBe(420_000);
  });

  it('rounds fractional results', () => {
    // 150000 * 1.9 = 285000 — exact
    expect(getSlotPrice(150_000, 'peak', 'evening')).toBe(285_000);
    // 100001 * 1.0 = 100001 — no rounding needed
    expect(getSlotPrice(100_001, 'off_season', 'morning')).toBe(100_001);
  });
});

// ─── getDiscount ─────────────────────────────────────────────────────────────
describe('getDiscount', () => {
  it('returns ₹2000 for prices at or below ₹1L', () => {
    expect(getDiscount(100_000)).toBe(2_000);
    expect(getDiscount(50_000)).toBe(2_000);
    expect(getDiscount(1)).toBe(2_000);
  });

  it('returns ₹5000 for prices between ₹1L and ₹2L', () => {
    expect(getDiscount(100_001)).toBe(5_000);
    expect(getDiscount(150_000)).toBe(5_000);
    expect(getDiscount(200_000)).toBe(5_000);
  });

  it('returns ₹10000 for prices above ₹2L', () => {
    expect(getDiscount(200_001)).toBe(10_000);
    expect(getDiscount(500_000)).toBe(10_000);
    expect(getDiscount(1_000_000)).toBe(10_000);
  });
});

// ─── calculatePriceBreakdown ─────────────────────────────────────────────────
describe('calculatePriceBreakdown', () => {
  it('returns correct shape', () => {
    const result = calculatePriceBreakdown(BASE, 'peak', 'evening');
    expect(result).toHaveProperty('basePrice');
    expect(result).toHaveProperty('slotPrice');
    expect(result).toHaveProperty('commission');
    expect(result).toHaveProperty('discount');
    expect(result).toHaveProperty('totalAmount');
    expect(result).toHaveProperty('advanceAmount');
    expect(result).toHaveProperty('ownerGets');
  });

  it('slotPrice = basePrice × multiplier', () => {
    const result = calculatePriceBreakdown(BASE, 'peak', 'evening'); // 1.9×
    expect(result.slotPrice).toBe(380_000);
  });

  it('commission = 8% of slotPrice (rounded)', () => {
    const result = calculatePriceBreakdown(BASE, 'peak', 'evening');
    expect(result.commission).toBe(Math.round(380_000 * COMMISSION_RATE));
  });

  it('totalAmount = slotPrice - discount', () => {
    const result = calculatePriceBreakdown(BASE, 'peak', 'evening');
    expect(result.totalAmount).toBe(result.slotPrice - result.discount);
  });

  it('advanceAmount = 30% of totalAmount (rounded)', () => {
    const result = calculatePriceBreakdown(BASE, 'peak', 'evening');
    expect(result.advanceAmount).toBe(Math.round(result.totalAmount * ADVANCE_RATE));
  });

  it('ownerGets = slotPrice (before commission deduction)', () => {
    const result = calculatePriceBreakdown(BASE, 'peak', 'evening');
    expect(result.ownerGets).toBe(result.slotPrice);
  });

  it('preserves season and slot in output', () => {
    const result = calculatePriceBreakdown(BASE, 'shoulder', 'morning');
    expect(result.season).toBe('shoulder');
    expect(result.slot).toBe('morning');
    expect(result.basePrice).toBe(BASE);
  });

  it('off_season morning has lowest price', () => {
    const off = calculatePriceBreakdown(BASE, 'off_season', 'morning');
    const peak = calculatePriceBreakdown(BASE, 'peak', 'full_day');
    expect(off.slotPrice).toBeLessThan(peak.slotPrice);
  });
});
