/**
 * Tests for utils/booking.ts
 *
 * Supabase is mocked so tests run offline and deterministically.
 * Tests cover: normalizeBooking, checkSlotAvailability, createBooking
 */

// ─── Mock Supabase ────────────────────────────────────────────────────────────
const mockSelect = jest.fn();
const mockInsert = jest.fn();
const mockUpdate = jest.fn();
const mockEq = jest.fn();
const mockIn = jest.fn();
const mockMaybeSingle = jest.fn();
const mockSingle = jest.fn();
const mockFrom = jest.fn();

// Chain builder — each method returns the chain so calls can be chained
const chain = {
  select: mockSelect,
  insert: mockInsert,
  update: mockUpdate,
  eq: mockEq,
  in: mockIn,
  maybeSingle: mockMaybeSingle,
  single: mockSingle,
};

// Make every chain method return the chain itself by default
Object.values(chain).forEach((fn) => (fn as jest.Mock).mockReturnValue(chain));

mockFrom.mockReturnValue(chain);

jest.mock('@/utils/supabase', () => ({
  supabase: { from: mockFrom },
}));

jest.mock('@/utils/notifications', () => ({
  sendBookingNotification: jest.fn().mockResolvedValue(undefined),
}));

import { normalizeBooking, checkSlotAvailability, createBooking } from '@/utils/booking';

// ─── normalizeBooking ─────────────────────────────────────────────────────────
describe('normalizeBooking', () => {
  it('maps event_date → date', () => {
    const raw = { event_date: '2026-03-15', slot_type: 'morning', status: 'pending', payment_verified: false };
    const result = normalizeBooking(raw);
    expect(result.date).toBe('2026-03-15');
  });

  it('maps slot_type → slot', () => {
    const raw = { event_date: '2026-03-15', slot_type: 'evening', status: 'pending', payment_verified: false };
    expect(normalizeBooking(raw).slot).toBe('evening');
  });

  it('falls back to date when event_date is absent', () => {
    const raw = { date: '2026-04-01', slot: 'full_day', status: 'confirmed', payment_verified: false };
    expect(normalizeBooking(raw).date).toBe('2026-04-01');
  });

  it('promotes status to confirmed when payment_verified=true and status=pending', () => {
    const raw = { event_date: '2026-03-15', slot_type: 'morning', status: 'pending', payment_verified: true };
    expect(normalizeBooking(raw).status).toBe('confirmed');
  });

  it('does not change status when payment_verified=false', () => {
    const raw = { event_date: '2026-03-15', slot_type: 'morning', status: 'pending', payment_verified: false };
    expect(normalizeBooking(raw).status).toBe('pending');
  });

  it('maps special_requests from notes fallback', () => {
    const raw = { event_date: '2026-03-15', slot_type: 'morning', status: 'pending', payment_verified: false, notes: 'Veg only' };
    expect(normalizeBooking(raw).special_requests).toBe('Veg only');
  });

  it('defaults commission_amount to 0 when absent', () => {
    const raw = { event_date: '2026-03-15', slot_type: 'morning', status: 'pending', payment_verified: false };
    expect(normalizeBooking(raw).commission_amount).toBe(0);
  });
});

// ─── checkSlotAvailability ────────────────────────────────────────────────────
describe('checkSlotAvailability', () => {
  beforeEach(() => jest.clearAllMocks());

  it('returns true when no conflicting booking exists', async () => {
    mockMaybeSingle.mockResolvedValueOnce({ data: null, error: null });
    const result = await checkSlotAvailability('hall-1', '2026-06-01', 'morning');
    expect(result).toBe(true);
  });

  it('returns false when new-schema query finds a conflict', async () => {
    // new-schema query finds a booking
    mockMaybeSingle.mockResolvedValueOnce({ data: { id: 'booking-123' }, error: null });
    const result = await checkSlotAvailability('hall-1', '2026-06-01', 'morning');
    expect(result).toBe(false);
  });

  it('returns false when old-schema fallback finds a conflict', async () => {
    // new-schema query returns nothing
    mockMaybeSingle.mockResolvedValueOnce({ data: null, error: null });
    // old-schema fallback finds a booking
    mockMaybeSingle.mockResolvedValueOnce({ data: { id: 'booking-old' }, error: null });
    const result = await checkSlotAvailability('hall-1', '2026-06-01', 'morning');
    expect(result).toBe(false);
  });

  it('returns true when both queries find no conflict', async () => {
    mockMaybeSingle.mockResolvedValueOnce({ data: null, error: null });
    mockMaybeSingle.mockResolvedValueOnce({ data: null, error: null });
    const result = await checkSlotAvailability('hall-1', '2026-06-01', 'morning');
    expect(result).toBe(true);
  });

  it('checks morning + full_day slots when slot is morning', async () => {
    mockMaybeSingle.mockResolvedValueOnce({ data: null, error: null });
    await checkSlotAvailability('hall-1', '2026-06-01', 'morning');
    expect(mockIn).toHaveBeenCalledWith('slot_type', ['morning', 'full_day']);
  });

  it('checks all slots when slot is full_day', async () => {
    mockMaybeSingle.mockResolvedValueOnce({ data: null, error: null });
    await checkSlotAvailability('hall-1', '2026-06-01', 'full_day');
    expect(mockIn).toHaveBeenCalledWith('slot_type', ['morning', 'evening', 'full_day']);
  });
});

// ─── createBooking ────────────────────────────────────────────────────────────
describe('createBooking', () => {
  const validParams = {
    hallId: 'hall-1',
    customerId: 'user-1',
    date: '2026-06-01',
    slot: 'morning' as const,
    customerName: 'Priya Sharma',
    customerEmail: 'priya@example.com',
    customerPhone: '+91 98765 43210',
    guestCount: 500,
    totalAmount: 320_000,
    advanceAmount: 96_000,
    commission: 25_600,
    discount: 5_000,
  };

  beforeEach(() => jest.clearAllMocks());

  it('returns error when slot is unavailable', async () => {
    // checkSlotAvailability returns false (slot taken)
    mockMaybeSingle.mockResolvedValueOnce({ data: { id: 'existing' }, error: null });

    const result = await createBooking(validParams);
    expect(result.success).toBe(false);
    expect(result.error).toMatch(/no longer available/i);
  });

  it('returns error when hall owner cannot be found', async () => {
    // Slot available
    mockMaybeSingle.mockResolvedValueOnce({ data: null, error: null });
    // Hall fetch fails
    mockSingle.mockResolvedValueOnce({ data: null, error: { message: 'Not found' } });

    const result = await createBooking(validParams);
    expect(result.success).toBe(false);
    expect(result.error).toMatch(/venue owner/i);
  });

  it('returns success with bookingId on happy path', async () => {
    // Slot available
    mockMaybeSingle.mockResolvedValueOnce({ data: null, error: null });
    // Hall fetch succeeds
    mockSingle
      .mockResolvedValueOnce({ data: { owner_id: 'owner-1' }, error: null })
      // Booking insert succeeds
      .mockResolvedValueOnce({ data: { id: 'booking-new-1' }, error: null });
    // Payment insert (fire-and-forget, chain returns)
    mockInsert.mockReturnValue({ ...chain, select: jest.fn().mockReturnValue(chain) });

    const result = await createBooking(validParams);
    expect(result.success).toBe(true);
    expect(result.bookingId).toBe('booking-new-1');
  });

  it('returns error when booking insert fails', async () => {
    // Slot available
    mockMaybeSingle.mockResolvedValueOnce({ data: null, error: null });
    // Hall fetch succeeds
    mockSingle
      .mockResolvedValueOnce({ data: { owner_id: 'owner-1' }, error: null })
      // Booking insert fails
      .mockResolvedValueOnce({ data: null, error: { message: 'Insert failed' } });

    const result = await createBooking(validParams);
    expect(result.success).toBe(false);
    expect(result.error).toBe('Insert failed');
  });
});
