/**
 * Tests for utils/currency.ts — pure formatting functions
 */
import { formatCurrency, formatCurrencyFull, formatCurrencyCompact } from '@/utils/currency';

describe('formatCurrency', () => {
  it('formats amounts below 1L with Indian locale', () => {
    expect(formatCurrency(50_000)).toBe('₹50,000');
  });

  it('formats 1L exactly as ₹1L', () => {
    expect(formatCurrency(100_000)).toBe('₹1L');
  });

  it('formats 2.5L as ₹2.5L', () => {
    expect(formatCurrency(250_000)).toBe('₹2.5L');
  });

  it('formats whole lakhs without decimal', () => {
    expect(formatCurrency(500_000)).toBe('₹5L');
  });
});

describe('formatCurrencyFull', () => {
  it('formats with ₹ prefix and Indian locale commas', () => {
    expect(formatCurrencyFull(100_000)).toBe('₹1,00,000');
  });

  it('formats zero', () => {
    expect(formatCurrencyFull(0)).toBe('₹0');
  });
});

describe('formatCurrencyCompact', () => {
  it('formats crores', () => {
    expect(formatCurrencyCompact(10_000_000)).toBe('₹1.0Cr');
  });

  it('formats lakhs', () => {
    expect(formatCurrencyCompact(500_000)).toBe('₹5.0L');
  });

  it('formats thousands', () => {
    expect(formatCurrencyCompact(5_000)).toBe('₹5K');
  });

  it('formats small amounts as-is', () => {
    expect(formatCurrencyCompact(500)).toBe('₹500');
  });
});
