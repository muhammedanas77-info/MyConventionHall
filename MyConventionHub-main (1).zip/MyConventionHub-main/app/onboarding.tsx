import React, { useState, useRef, useCallback } from 'react';
import { View, Text, StyleSheet, Dimensions, Animated, FlatList, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';
import { useApp } from '@/providers/AppProvider';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const SERIF_FONT = Platform.select({ ios: 'Georgia', android: 'serif', web: 'Georgia, serif', default: 'serif' });

const SLIDES = [
    { id: '1', emoji: '🏛️', title: "Discover Bangalore's Finest", subtitle: 'Browse 100+ verified venues across every neighbourhood' },
    { id: '2', emoji: '📅', title: 'Live Availability', subtitle: 'See real-time availability and book instantly. No phone calls, no back and forth.' },
    { id: '3', emoji: '🛡️', title: 'Secure & Transparent', subtitle: 'Pay advance online. Transparent pricing. 100% refundable if plans change.' },
];

export default function OnboardingScreen() {
    const router = useRouter();
    const { completeOnboarding } = useApp();
    const [currentIndex, setCurrentIndex] = useState(0);
    const flatListRef = useRef<FlatList>(null);
    const scrollX = useRef(new Animated.Value(0)).current;

    const handleDone = useCallback(() => {
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        completeOnboarding();
        router.replace('/role-select' as any);
    }, [completeOnboarding, router]);

    const handleNext = useCallback(() => {
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        if (currentIndex < SLIDES.length - 1) flatListRef.current?.scrollToIndex({ index: currentIndex + 1 });
        else handleDone();
    }, [currentIndex, handleDone]);

    const onViewableItemsChanged = useRef(({ viewableItems }: { viewableItems: Array<{ index?: number | null }> }) => {
        if (viewableItems[0]?.index != null) setCurrentIndex(viewableItems[0].index);
    }).current;

    const viewabilityConfig = useRef({ viewAreaCoveragePercentThreshold: 50 }).current;

    return (
        <View style={styles.container}>
            <SafeAreaView style={styles.safeArea}>
                <View style={styles.header}>
                    {currentIndex < SLIDES.length - 1 ? (
                        <AnimatedPressable onPress={handleDone} scaleValue={0.95}><Text style={styles.skipText}>Skip</Text></AnimatedPressable>
                    ) : <View />}
                </View>
                <FlatList
                    ref={flatListRef}
                    data={SLIDES}
                    renderItem={({ item }) => (
                        <View style={styles.slide}>
                            <Text style={styles.emoji}>{item.emoji}</Text>
                            <Text style={styles.slideTitle}>{item.title}</Text>
                            <Text style={styles.slideSubtitle}>{item.subtitle}</Text>
                        </View>
                    )}
                    keyExtractor={(item) => item.id}
                    horizontal pagingEnabled showsHorizontalScrollIndicator={false} bounces={false}
                    onScroll={Animated.event([{ nativeEvent: { contentOffset: { x: scrollX } } }], { useNativeDriver: false })}
                    onViewableItemsChanged={onViewableItemsChanged}
                    viewabilityConfig={viewabilityConfig}
                    scrollEventThrottle={16}
                />
                <View style={styles.footer}>
                    <View style={styles.pagination}>
                        {SLIDES.map((_, index) => {
                            const dotWidth = scrollX.interpolate({ inputRange: [(index - 1) * SCREEN_WIDTH, index * SCREEN_WIDTH, (index + 1) * SCREEN_WIDTH], outputRange: [8, 24, 8], extrapolate: 'clamp' });
                            const dotOpacity = scrollX.interpolate({ inputRange: [(index - 1) * SCREEN_WIDTH, index * SCREEN_WIDTH, (index + 1) * SCREEN_WIDTH], outputRange: [0.3, 1, 0.3], extrapolate: 'clamp' });
                            return <Animated.View key={index} style={[styles.dot, { width: dotWidth, opacity: dotOpacity }]} />;
                        })}
                    </View>
                    <AnimatedPressable onPress={handleNext} scaleValue={0.96}>
                        <View style={styles.nextButton}><Text style={styles.nextButtonText}>{currentIndex === SLIDES.length - 1 ? 'Get Started' : 'Next'}</Text></View>
                    </AnimatedPressable>
                </View>
            </SafeAreaView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#FFFFFF' },
    safeArea: { flex: 1 },
    header: { flexDirection: 'row', justifyContent: 'flex-end', paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md },
    skipText: { fontSize: FontSize.md, color: Colors.textTertiary, fontWeight: FontWeight.medium },
    slide: { width: SCREEN_WIDTH, paddingHorizontal: Spacing.xxxl, justifyContent: 'center', alignItems: 'center' },
    emoji: { fontSize: 72, marginBottom: Spacing.huge },
    slideTitle: { fontSize: 28, fontWeight: FontWeight.bold, color: Colors.text, textAlign: 'center', marginBottom: Spacing.lg, fontFamily: SERIF_FONT },
    slideSubtitle: { fontSize: FontSize.md, color: Colors.textSecondary, textAlign: 'center', lineHeight: 24, paddingHorizontal: Spacing.lg },
    footer: { paddingHorizontal: Spacing.xxl, paddingBottom: Spacing.xxl, gap: Spacing.xxl },
    pagination: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: Spacing.sm },
    dot: { height: 8, borderRadius: 4, backgroundColor: Colors.primary },
    nextButton: { backgroundColor: Colors.primary, paddingVertical: Spacing.lg, borderRadius: Radius.lg, alignItems: 'center' },
    nextButtonText: { color: '#FFFFFF', fontSize: FontSize.lg, fontWeight: FontWeight.bold },
});
