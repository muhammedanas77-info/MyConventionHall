import React, { useRef, useEffect, useState } from 'react';
import {
    View, Text, StyleSheet, TextInput, Animated, Platform, KeyboardAvoidingView, ScrollView,
} from 'react-native';
import { useRouter, Stack } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowLeft, Building2, Mail, ShieldCheck } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import * as LocalAuthentication from 'expo-local-authentication';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { useApp } from '@/providers/AppProvider';
import { supabase } from '@/utils/supabase';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

const SERIF_FONT = Platform.select({ ios: 'Georgia', android: 'serif', web: 'Georgia, serif', default: 'serif' });

export default function OwnerLoginScreen() {
    const router = useRouter();
    const { login } = useApp();
    const [isSignUp, setIsSignUp] = useState(false);
    const [email, setEmail] = useState('');
    const [name, setName] = useState('');
    const [hallName, setHallName] = useState('');
    const [otp, setOtp] = useState('');
    const [step, setStep] = useState<'email' | 'otp'>('email');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isBiometricSupported, setIsBiometricSupported] = useState(false);

    const fadeAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
        (async () => {
            const compatible = await LocalAuthentication.hasHardwareAsync();
            const enrolled = await LocalAuthentication.isEnrolledAsync();
            setIsBiometricSupported(compatible && enrolled);
        })();
    }, [fadeAnim]);

    const handleSendOTP = async () => {
        if (!email || (isSignUp && !name)) {
            setError('Please fill all required fields');
            return;
        }

        setIsLoading(true);
        setError(null);
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

        try {
            const { error: otpError } = await supabase.auth.signInWithOtp({
                email: email.trim(),
                options: {
                    data: {
                        full_name: name.trim(),
                        company_name: hallName.trim(),
                        role: 'owner',
                    }
                }
            });

            if (otpError) {
                setError(otpError.message || 'Failed to send OTP. Please try again.');
                setIsLoading(false);
                return;
            }

            setStep('otp');
        } catch (err) {
            setError('Network error. Please try again.');
            console.error('OTP send error:', err);
        } finally {
            setIsLoading(false);
        }
    };

    const handleVerifyOTP = async () => {
        if (!otp || otp.length < 6) {
            setError('Please enter a valid verification code');
            return;
        }

        setIsLoading(true);
        setError(null);
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

        try {
            const { data, error } = await supabase.auth.verifyOtp({
                email: email.trim(),
                token: otp.trim(),
                type: 'email',
            });

            if (error) {
                setError(error.message || 'Invalid code. Please try again.');
                setIsLoading(false);
                return;
            }

            // Only create profile if it doesn't exist — never overwrite existing role
            if (data?.session?.user) {
                const displayName = isSignUp ? name.trim() : email.trim().split('@')[0];

                const { data: existing } = await supabase
                    .from('profiles')
                    .select('id, full_name, role')
                    .eq('id', data.session.user.id)
                    .maybeSingle();

                if (!existing) {
                    // New user — create owner profile
                    await supabase.from('profiles').insert([{
                        id: data.session.user.id,
                        role: 'owner',
                        full_name: displayName,
                        email: email.trim(),
                    }]);
                } else if (existing.role !== 'owner') {
                    // Existing user with wrong role — update to owner
                    await supabase.from('profiles')
                        .update({ role: 'owner' })
                        .eq('id', data.session.user.id);
                }

                login('owner', existing?.full_name || displayName);
            }

            setIsLoading(false);
            router.replace('/(owner)/dashboard' as any);
        } catch (err) {
            setError('Verification failed. Please try again.');
            console.error('Owner OTP verify error:', err);
            setIsLoading(false);
        }
    };

    const handleBiometricAuth = async () => {
        try {
            const result = await LocalAuthentication.authenticateAsync({
                promptMessage: 'Authenticate to access Owner Portal',
                fallbackLabel: 'Use Email Instead',
                disableDeviceFallback: false,
            });

            if (result.success) {
                if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                login('owner', 'Venue Partner');
                router.replace('/(owner)/dashboard' as any);
            }
        } catch (error) {
            console.error('Biometric Auth Error:', error);
        }
    };

    return (
        <View style={styles.container}>
            <Stack.Screen options={{ headerShown: false }} />
            <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
                <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
                    <SafeAreaView style={styles.safeArea}>
                        <Animated.View style={[styles.main, { opacity: fadeAnim }]}>
                            <AnimatedPressable
                                onPress={() => router.back()}
                                style={styles.backButton}
                                scaleValue={0.9}
                            >
                                <ArrowLeft size={24} color={Colors.text} />
                            </AnimatedPressable>

                            <LinearGradient colors={[Colors.primaryDark, '#3A1014']} style={styles.heroPanel}>
                                <View style={styles.heroIcon}>
                                    <Building2 size={24} color="#FFFFFF" />
                                </View>
                                <View style={styles.heroCopy}>
                                    <Text style={styles.heroKicker}>ConventionHub</Text>
                                    <Text style={styles.heroTitle}>Venue Partner Console</Text>
                                    <Text style={styles.heroText}>Bookings, availability, pricing, and payment reviews in one secure workspace.</Text>
                                </View>
                            </LinearGradient>

                            <View style={styles.header}>
                                <Text style={styles.brandTitle}>OWNER PORTAL</Text>
                                <Text style={styles.welcomeTitle}>{isSignUp ? 'Partner with Us' : 'Welcome Back'}</Text>
                                <Text style={styles.subtitle}>
                                    {isSignUp
                                        ? 'List your venue and reach thousands of customers across India'
                                        : 'Sign in to manage your bookings and venue calendar'}
                                </Text>
                            </View>

                            <View style={styles.form}>
                                {error && (
                                    <View style={styles.errorBox}>
                                        <Text style={styles.errorText}>{error}</Text>
                                    </View>
                                )}

                                {step === 'email' ? (
                                    <>
                                        {isSignUp && (
                                            <>
                                                <View style={styles.inputGroup}>
                                                    <Text style={styles.label}>Full Name</Text>
                                                    <TextInput
                                                        style={styles.input}
                                                        placeholder="Enter your full name"
                                                        placeholderTextColor={Colors.textTertiary}
                                                        value={name}
                                                        onChangeText={setName}
                                                        autoCapitalize="words"
                                                    />
                                                </View>
                                                <View style={styles.inputGroup}>
                                                    <Text style={styles.label}>Venue name (Optional)</Text>
                                                    <TextInput
                                                        style={styles.input}
                                                        placeholder="e.g. Royal Palace Hall"
                                                        placeholderTextColor={Colors.textTertiary}
                                                        value={hallName}
                                                        onChangeText={setHallName}
                                                        autoCapitalize="words"
                                                    />
                                                </View>
                                            </>
                                        )}

                                        <View style={styles.inputGroup}>
                                            <Text style={styles.label}>Business Email</Text>
                                            <View style={styles.inputShell}>
                                                <Mail size={18} color={Colors.textTertiary} />
                                                <TextInput
                                                    style={styles.emailInput}
                                                    placeholder="owner@example.com"
                                                    placeholderTextColor={Colors.textTertiary}
                                                    value={email}
                                                    onChangeText={setEmail}
                                                    keyboardType="email-address"
                                                    autoCapitalize="none"
                                                    autoComplete="email"
                                                />
                                            </View>
                                            <Text style={styles.helperText}>
                                                We will send a verification code to your email.
                                            </Text>
                                        </View>

                        <AnimatedPressable onPress={handleSendOTP} scaleValue={0.96} disabled={isLoading}>
                                            <View style={[styles.primaryButton, isLoading && styles.buttonDisabled]}>
                                                <Text style={styles.primaryButtonText}>
                                                    {isLoading ? 'Sending Code...' : (isSignUp ? 'Join as Partner' : 'Continue')}
                                                </Text>
                                            </View>
                                        </AnimatedPressable>

                                        {isBiometricSupported && !isSignUp && (
                                            <>
                                                <Text style={styles.orText}>OR</Text>
                                                <AnimatedPressable onPress={handleBiometricAuth} scaleValue={0.96}>
                                                    <View style={styles.bioButton}>
                                                        <Text style={styles.bioButtonText}>Use Face ID / Touch ID</Text>
                                                    </View>
                                                </AnimatedPressable>
                                            </>
                                        )}

                                        <View style={styles.toggleRow}>
                                            <Text style={styles.toggleText}>
                                                {isSignUp ? 'Already have an account?' : "New to ConventionHub?"}
                                            </Text>
                                            <AnimatedPressable onPress={() => { setIsSignUp(!isSignUp); setError(null); }} scaleValue={0.98}>
                                                <Text style={styles.toggleLink}>
                                                    {isSignUp ? 'Sign In' : 'Sign Up'}
                                                </Text>
                                            </AnimatedPressable>
                                        </View>
                                    </>
                                ) : (
                                    <>
                                        <View style={styles.inputGroup}>
                                            <Text style={styles.label}>Enter Verification Code</Text>
                                            <TextInput
                                                style={styles.input}
                                                placeholder="00000000"
                                                placeholderTextColor={Colors.textTertiary}
                                                value={otp}
                                                onChangeText={setOtp}
                                                keyboardType="number-pad"
                                                maxLength={8}
                                            />
                                            <AnimatedPressable onPress={() => setStep('email')} scaleValue={0.98}>
                                                <Text style={styles.wrongEmailText}>Change Email?</Text>
                                            </AnimatedPressable>
                                        </View>

                                        <AnimatedPressable onPress={handleVerifyOTP} scaleValue={0.96} disabled={isLoading}>
                                            <View style={[styles.primaryButton, isLoading && styles.buttonDisabled]}>
                                                <Text style={styles.primaryButtonText}>
                                                    {isLoading ? 'Verifying...' : 'Verify & Login'}
                                                </Text>
                                            </View>
                                        </AnimatedPressable>
                                    </>
                                )}

                                <View style={styles.roleInfo}>
                                    <ShieldCheck size={18} color={Colors.primaryDark} />
                                    <Text style={styles.roleInfoText}>
                                        You will be able to manage availability, pricing, and bookings for your venue.
                                    </Text>
                                </View>
                            </View>
                        </Animated.View>
                    </SafeAreaView>
                </ScrollView>
            </KeyboardAvoidingView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: Colors.background },
    flex: { flex: 1 },
    scrollContent: { flexGrow: 1 },
    safeArea: { flex: 1, paddingHorizontal: Spacing.xl },
    main: { flex: 1, paddingTop: Spacing.md },
    backButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: Colors.surface,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: Spacing.lg,
        borderWidth: 1,
        borderColor: Colors.borderLight,
        ...Shadow.sm,
    },
    heroPanel: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.md,
        borderRadius: Radius.xl,
        padding: Spacing.lg,
        marginBottom: Spacing.xxl,
        ...Shadow.lg,
    },
    heroIcon: {
        width: 52,
        height: 52,
        borderRadius: Radius.lg,
        backgroundColor: 'rgba(255,255,255,0.14)',
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: 'rgba(255,255,255,0.16)',
    },
    heroCopy: { flex: 1 },
    heroKicker: { color: Colors.goldLight, fontSize: FontSize.xs, fontWeight: FontWeight.bold, textTransform: 'uppercase', letterSpacing: 1.5, marginBottom: 2 },
    heroTitle: { color: '#FFFFFF', fontSize: FontSize.lg, fontWeight: FontWeight.heavy },
    heroText: { color: 'rgba(255,255,255,0.7)', fontSize: FontSize.xs, lineHeight: 17, marginTop: Spacing.xs },
    header: { marginBottom: Spacing.xxl },
    brandTitle: {
        fontSize: 12,
        fontWeight: FontWeight.bold,
        color: Colors.gold,
        letterSpacing: 3,
        textTransform: 'uppercase',
        marginBottom: Spacing.md,
    },
    welcomeTitle: {
        fontSize: 38,
        fontWeight: FontWeight.heavy,
        color: Colors.text,
        fontFamily: SERIF_FONT,
        marginBottom: Spacing.xs,
    },
    subtitle: {
        fontSize: FontSize.md,
        color: Colors.textTertiary,
        lineHeight: 22,
        maxWidth: '92%',
    },
    form: { gap: Spacing.lg, backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.lg, borderWidth: 1, borderColor: Colors.borderLight, ...Shadow.md },
    inputGroup: { gap: Spacing.xs },
    labelRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    label: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textSecondary },
    forgotPassword: { fontSize: FontSize.sm, color: Colors.primary, fontWeight: FontWeight.medium },
    input: {
        backgroundColor: Colors.ivory,
        borderRadius: Radius.lg,
        paddingHorizontal: Spacing.lg,
        paddingVertical: Spacing.lg,
        fontSize: FontSize.md,
        color: Colors.text,
        borderWidth: 1,
        borderColor: Colors.borderLight,
    },
    inputShell: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.sm,
        backgroundColor: Colors.ivory,
        borderRadius: Radius.lg,
        paddingHorizontal: Spacing.lg,
        borderWidth: 1,
        borderColor: Colors.borderLight,
    },
    emailInput: {
        flex: 1,
        paddingVertical: Spacing.lg,
        fontSize: FontSize.md,
        color: Colors.text,
    },
    primaryButton: {
        backgroundColor: Colors.primaryDark,
        paddingVertical: Spacing.lg,
        borderRadius: Radius.lg,
        alignItems: 'center',
        marginTop: Spacing.sm,
        ...Shadow.md,
    },
    buttonDisabled: { opacity: 0.7 },
    primaryButtonText: { color: '#FFFFFF', fontSize: FontSize.lg, fontWeight: FontWeight.bold },
    orText: { textAlign: 'center', color: Colors.textTertiary, fontSize: FontSize.sm, fontWeight: FontWeight.bold, marginVertical: Spacing.xs },
    bioButton: { backgroundColor: Colors.ivory, paddingVertical: Spacing.md, borderRadius: Radius.lg, alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
    bioButtonText: { color: Colors.text, fontSize: FontSize.lg, fontWeight: FontWeight.bold },
    toggleRow: { flexDirection: 'row', justifyContent: 'center', gap: Spacing.xs, marginTop: Spacing.xs },
    toggleText: { fontSize: FontSize.sm, color: Colors.textTertiary },
    toggleLink: { fontSize: FontSize.sm, color: Colors.primary, fontWeight: FontWeight.bold },
    roleInfo: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.md,
        backgroundColor: Colors.ivory,
        padding: Spacing.md,
        borderRadius: Radius.lg,
        borderWidth: 1,
        borderColor: Colors.borderLight,
        marginTop: Spacing.sm
    },
    roleInfoText: { flex: 1, fontSize: FontSize.sm, color: Colors.textSecondary, lineHeight: 20 },
    helperText: { fontSize: FontSize.xs, color: Colors.textTertiary, marginTop: Spacing.xxs },
    wrongEmailText: { fontSize: FontSize.sm, color: Colors.gold, fontWeight: FontWeight.semibold, marginTop: Spacing.md, alignSelf: 'flex-start' },
    errorBox: { backgroundColor: Colors.errorLight, padding: Spacing.md, borderRadius: Radius.md, borderWidth: 1, borderColor: 'rgba(197, 48, 48, 0.2)' },
    errorText: { color: Colors.error, fontSize: FontSize.sm, fontWeight: FontWeight.medium },
    secondaryButton: { paddingVertical: Spacing.lg, borderRadius: Radius.lg, alignItems: 'center' },
    secondaryButtonText: { fontSize: FontSize.md, fontWeight: FontWeight.bold },
});
