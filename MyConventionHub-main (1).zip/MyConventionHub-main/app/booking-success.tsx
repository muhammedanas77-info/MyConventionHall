import React, { useRef, useEffect } from 'react';
import { View, Text, StyleSheet, Animated, Platform } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { CheckCircle2, Copy, Share2, CalendarDays } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

export default function BookingSuccessScreen() {
    const { bookingId, hallName } = useLocalSearchParams<{ bookingId: string; hallName: string }>();
    const router = useRouter();

    const checkScale = useRef(new Animated.Value(0)).current;
    const fadeAnim = useRef(new Animated.Value(0)).current;
    const slideAnim = useRef(new Animated.Value(40)).current;

    useEffect(() => {
        if (Platform.OS !== 'web') {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        }

        Animated.sequence([
            Animated.spring(checkScale, {
                toValue: 1,
                useNativeDriver: true,
                speed: 8,
                bounciness: 12,
            }),
            Animated.parallel([
                Animated.timing(fadeAnim, {
                    toValue: 1,
                    duration: 400,
                    useNativeDriver: true,
                }),
                Animated.spring(slideAnim, {
                    toValue: 0,
                    useNativeDriver: true,
                    speed: 12,
                }),
            ]),
        ]).start();
    }, []);

    return (
        <LinearGradient
            colors={[Colors.background, Colors.cream]}
            style={styles.screen}
        >
            <SafeAreaView style={styles.safeArea}>
                <View style={styles.content}>
                    <Animated.View style={[styles.checkContainer, { transform: [{ scale: checkScale }] }]}>
                        <LinearGradient
                            colors={[Colors.success, '#2D8B55']}
                            style={styles.checkCircle}
                        >
                            <CheckCircle2 size={48} color="#FFFFFF" />
                        </LinearGradient>
                    </Animated.View>

                    <Animated.View style={{
                        opacity: fadeAnim,
                        transform: [{ translateY: slideAnim }],
                        alignItems: 'center' as const,
                    }}>
                        <Text style={styles.title}>Booking Confirmed!</Text>
                        <Text style={styles.subtitle}>
                            Your celebration at {hallName} is all set
                        </Text>

                        <View style={styles.bookingIdCard}>
                            <Text style={styles.bookingIdLabel}>Booking ID</Text>
                            <View style={styles.bookingIdRow}>
                                <Text style={styles.bookingIdText}>{bookingId}</Text>
                                <AnimatedPressable onPress={() => { }} scaleValue={0.9}>
                                    <Copy size={16} color={Colors.primary} />
                                </AnimatedPressable>
                            </View>
                        </View>

                        <View style={styles.actions}>
                            <AnimatedPressable onPress={() => { }} scaleValue={0.95}>
                                <View style={styles.shareButton}>
                                    <Share2 size={18} color={Colors.primary} />
                                    <Text style={styles.shareButtonText}>Share on WhatsApp</Text>
                                </View>
                            </AnimatedPressable>

                            <AnimatedPressable
                                onPress={() => router.replace('/(tabs)/bookings' as any)}
                                scaleValue={0.95}
                            >
                                <LinearGradient
                                    colors={[Colors.primary, Colors.primaryDark]}
                                    style={styles.viewButton}
                                    start={{ x: 0, y: 0 }}
                                    end={{ x: 1, y: 0 }}
                                >
                                    <CalendarDays size={18} color="#FFFFFF" />
                                    <Text style={styles.viewButtonText}>View My Bookings</Text>
                                </LinearGradient>
                            </AnimatedPressable>

                            <AnimatedPressable
                                onPress={() => router.replace('/(tabs)/discover' as any)}
                                scaleValue={0.95}
                            >
                                <Text style={styles.homeLink}>Back to Home</Text>
                            </AnimatedPressable>
                        </View>
                    </Animated.View>
                </View>
            </SafeAreaView>
        </LinearGradient>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1 },
    safeArea: { flex: 1 },
    content: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: Spacing.xxl,
    },
    checkContainer: { marginBottom: Spacing.xxl },
    checkCircle: {
        width: 96, height: 96, borderRadius: 48,
        justifyContent: 'center', alignItems: 'center',
        ...Shadow.lg,
    },
    title: {
        fontSize: FontSize.xxxl, fontWeight: FontWeight.heavy,
        color: Colors.text, textAlign: 'center', marginBottom: Spacing.sm,
    },
    subtitle: {
        fontSize: FontSize.md, color: Colors.textSecondary,
        textAlign: 'center', marginBottom: Spacing.xxl, lineHeight: 22,
    },
    bookingIdCard: {
        backgroundColor: Colors.surface, borderRadius: Radius.xl,
        padding: Spacing.xl, width: '100%', marginBottom: Spacing.xxl, ...Shadow.md,
    },
    bookingIdLabel: {
        fontSize: FontSize.xs, color: Colors.textTertiary,
        fontWeight: FontWeight.semibold, textTransform: 'uppercase' as const,
        letterSpacing: 1, marginBottom: Spacing.sm,
    },
    bookingIdRow: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    },
    bookingIdText: {
        fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text,
        fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
    },
    actions: { width: '100%', gap: Spacing.md },
    shareButton: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
        gap: Spacing.sm, backgroundColor: Colors.surface,
        borderWidth: 1.5, borderColor: Colors.primary, borderRadius: Radius.lg,
        paddingVertical: Spacing.md,
    },
    shareButtonText: { color: Colors.primary, fontSize: FontSize.md, fontWeight: FontWeight.bold },
    viewButton: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
        gap: Spacing.sm, borderRadius: Radius.lg, paddingVertical: Spacing.md,
    },
    viewButtonText: { color: '#FFFFFF', fontSize: FontSize.md, fontWeight: FontWeight.bold },
    homeLink: {
        color: Colors.textTertiary, fontSize: FontSize.md, fontWeight: FontWeight.medium,
        textAlign: 'center', paddingVertical: Spacing.sm,
    },
});
