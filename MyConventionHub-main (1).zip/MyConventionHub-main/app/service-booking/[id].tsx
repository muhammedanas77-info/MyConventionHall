﻿/**
 * app/service-booking/[id].tsx
 *
 * Customer service booking flow.
 *
 * The `id` param is the service_listing id.
 * On mount, loads the listing + vendor profile to build the availability calendar.
 * Collects: event date, event type, guest count (required for wedding/corporate),
 * special requests (max 500 chars).
 * On submit: INSERTs into service_bookings; the DB trigger fn_set_booking_amounts
 * populates total_amount and advance_amount.
 *
 * Error surfacing:
 *   - unique_violation (23505) from partial UNIQUE index → "Vendor is unavailable on selected date"
 *   - P0001 from fn_set_booking_amounts (no base price) → shown verbatim
 *   - P0001 from fn_create_service_commission (no active rate) → shown verbatim
 *
 * Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.6, 6.7, 6.8, 6.9, 9.7
 */

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Animated,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  AlertTriangle,
  Calendar,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Info,
  Users,
} from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';

import { Colors, FontSize, FontWeight, Radius, Shadow, Spacing } from '@/constants/theme';
import { useAuth } from '@/providers/AuthProvider';
import { supabase } from '@/utils/supabase';
import { getUnavailableDates } from '@/utils/availabilityChecker';
import { formatCurrencyFull } from '@/utils/currency';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import type {
  BlockedDateRange,
  EventType,
  ServiceListing,
  VendorProfile,
} from '@/types';

// ─── Constants ────────────────────────────────────────────────────────────────

const SERIF_FONT = Platform.select({
  ios: 'Georgia',
  android: 'serif',
  web: 'Georgia, serif',
  default: 'serif',
});

const EVENT_TYPES: { value: EventType; label: string }[] = [
  { value: 'wedding', label: 'Wedding' },
  { value: 'birthday', label: 'Birthday' },
  { value: 'corporate', label: 'Corporate' },
  { value: 'other', label: 'Other' },
];

/** Event types that require guest count (Requirement 6.1) */
const GUEST_COUNT_REQUIRED: EventType[] = ['wedding', 'corporate'];

// ─── Types ────────────────────────────────────────────────────────────────────

interface ListingWithVendor extends ServiceListing {
  vendor: Pick<VendorProfile, 'id' | 'vendor_sector' | 'business_name' | 'sector_data'>;
}

interface BookingConfirmation {
  id: string;
  total_amount: number;
  advance_amount: number;
  event_date: string;
  event_type: EventType;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Parses a Postgres error and returns a user-friendly message. */
function parseDbError(error: { code?: string; message?: string }): string {
  // unique_violation from partial UNIQUE index on (listing_id, event_date)
  if (error.code === '23505') {
    return 'Vendor is unavailable on selected date.';
  }
  // P0001 raised by fn_set_booking_amounts or fn_create_service_commission
  if (error.code === 'P0001' && error.message) {
    return error.message;
  }
  return error.message ?? 'An unexpected error occurred. Please try again.';
}

/** Returns today's ISO date string (YYYY-MM-DD). */
function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

/** Adds `days` to an ISO date string and returns the new ISO date string. */
function addDays(isoDate: string, days: number): string {
  const d = new Date(isoDate);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

/** Formats an ISO date string for display (e.g. "15 Aug 2025"). */
function formatDisplayDate(isoDate: string): string {
  const d = new Date(isoDate + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

// --- Date Picker Component ---

interface DatePickerProps {
  unavailableDates: Set<string>;
  selectedDate: string;
  onSelectDate: (date: string) => void;
  isLoading: boolean;
}

function DatePicker({ unavailableDates, selectedDate, onSelectDate, isLoading }: DatePickerProps) {
  const today = todayISO();
  const endDate = addDays(today, 365);

  const dates = useMemo(() => {
    const result: { iso: string; day: string; num: string; month: string }[] = [];
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    let current = new Date(today + 'T00:00:00');
    const end = new Date(endDate + 'T00:00:00');
    while (current <= end) {
      result.push({
        iso: current.toISOString().slice(0, 10),
        day: dayNames[current.getDay()],
        num: String(current.getDate()),
        month: monthNames[current.getMonth()],
      });
      current.setDate(current.getDate() + 1);
    }
    return result;
  }, [today, endDate]);

  if (isLoading) {
    return (
      <View style={dpStyles.loadingBox}>
        <ActivityIndicator size="small" color={Colors.primary} />
        <Text style={dpStyles.loadingText}>Loading availability...</Text>
      </View>
    );
  }

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={dpStyles.scroll}
    >
      {dates.map((d) => {
        const isUnavailable = unavailableDates.has(d.iso);
        const isSelected = d.iso === selectedDate;
        return (
          <AnimatedPressable
            key={d.iso}
            onPress={() => !isUnavailable && onSelectDate(d.iso)}
            disabled={isUnavailable}
            scaleValue={0.92}
          >
            <View
              style={[
                dpStyles.dateBox,
                isSelected && dpStyles.dateBoxSelected,
                isUnavailable && dpStyles.dateBoxUnavailable,
              ]}
            >
              <Text style={[dpStyles.dayText, isSelected && dpStyles.dateTextSelected, isUnavailable && dpStyles.dateTextDisabled]}>{d.day}</Text>
              <Text style={[dpStyles.numText, isSelected && dpStyles.dateTextSelected, isUnavailable && dpStyles.dateTextDisabled]}>{d.num}</Text>
              <Text style={[dpStyles.monthText, isSelected && dpStyles.dateTextSelected, isUnavailable && dpStyles.dateTextDisabled]}>{d.month}</Text>
              {isUnavailable && (
                <View style={dpStyles.unavailableOverlay}>
                  <Text style={dpStyles.unavailableText}>N/A</Text>
                </View>
              )}
            </View>
          </AnimatedPressable>
        );
      })}
    </ScrollView>
  );
}

const dpStyles = StyleSheet.create({
  scroll: { paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm, gap: Spacing.sm },
  loadingBox: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: Spacing.xxl, gap: Spacing.sm },
  loadingText: { fontSize: FontSize.sm, color: Colors.textSecondary },
  dateBox: { width: 56, paddingVertical: Spacing.sm, borderRadius: Radius.md, backgroundColor: Colors.surface, borderWidth: 1.5, borderColor: Colors.border, alignItems: 'center', gap: 2 },
  dateBoxSelected: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  dateBoxUnavailable: { backgroundColor: Colors.cream, borderColor: Colors.borderLight, opacity: 0.6 },
  dayText: { fontSize: FontSize.xs, color: Colors.textTertiary, fontWeight: FontWeight.medium },
  numText: { fontSize: FontSize.lg, color: Colors.text, fontWeight: FontWeight.bold },
  monthText: { fontSize: FontSize.xs, color: Colors.textTertiary, fontWeight: FontWeight.medium },
  dateTextSelected: { color: Colors.textOnPrimary },
  dateTextDisabled: { color: Colors.textTertiary },
  unavailableOverlay: { position: 'absolute', bottom: 2, backgroundColor: Colors.errorLight, borderRadius: Radius.xs, paddingHorizontal: 3 },
  unavailableText: { fontSize: 8, color: Colors.error, fontWeight: FontWeight.bold },
});

// --- Confirmation Screen ---

interface ConfirmationProps {
  booking: BookingConfirmation;
  listingTitle: string;
  onViewBookings: () => void;
  onGoHome: () => void;
}

function ConfirmationScreen({ booking, listingTitle, onViewBookings, onGoHome }: ConfirmationProps) {
  const checkScale = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    if (Platform.OS !== 'web') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    Animated.sequence([
      Animated.spring(checkScale, { toValue: 1, useNativeDriver: true, speed: 8, bounciness: 12 }),
      Animated.parallel([
        Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }),
        Animated.spring(slideAnim, { toValue: 0, useNativeDriver: true, speed: 12 }),
      ]),
    ]).start();
  }, []);

  return (
    <LinearGradient colors={[Colors.background, Colors.cream]} style={confStyles.screen}>
      <SafeAreaView style={confStyles.safeArea}>
        <ScrollView contentContainerStyle={confStyles.content} showsVerticalScrollIndicator={false}>
          <Animated.View style={[confStyles.checkContainer, { transform: [{ scale: checkScale }] }]}>
            <LinearGradient colors={[Colors.success, '#2D8B55']} style={confStyles.checkCircle}>
              <CheckCircle2 size={48} color="#FFFFFF" />
            </LinearGradient>
          </Animated.View>

          <Animated.View style={{ opacity: fadeAnim, transform: [{ translateY: slideAnim }], alignItems: 'center' as const, width: '100%' }}>
            <Text style={confStyles.title}>Booking Submitted!</Text>
            <Text style={confStyles.subtitle}>
              Your booking for {listingTitle} is pending vendor confirmation.
            </Text>

            <View style={confStyles.card}>
              <Text style={confStyles.cardLabel}>Booking ID</Text>
              <Text style={confStyles.bookingId} numberOfLines={1} ellipsizeMode="middle">
                {booking.id}
              </Text>
            </View>

            <View style={confStyles.card}>
              <View style={confStyles.amountRow}>
                <View style={confStyles.amountItem}>
                  <Text style={confStyles.cardLabel}>Total Amount</Text>
                  <Text style={confStyles.amountValue}>{formatCurrencyFull(booking.total_amount)}</Text>
                </View>
                <View style={confStyles.amountDivider} />
                <View style={confStyles.amountItem}>
                  <Text style={confStyles.cardLabel}>Advance Due</Text>
                  <Text style={[confStyles.amountValue, { color: Colors.primary }]}>{formatCurrencyFull(booking.advance_amount)}</Text>
                </View>
              </View>
              <View style={confStyles.advanceNote}>
                <Info size={12} color={Colors.textTertiary} />
                <Text style={confStyles.advanceNoteText}>30% advance is due upon confirmation</Text>
              </View>
            </View>

            <View style={confStyles.card}>
              <View style={confStyles.detailRow}>
                <Calendar size={16} color={Colors.textSecondary} />
                <Text style={confStyles.detailText}>{formatDisplayDate(booking.event_date)}</Text>
              </View>
              <View style={confStyles.detailRow}>
                <Info size={16} color={Colors.textSecondary} />
                <Text style={confStyles.detailText}>
                  {EVENT_TYPES.find((e) => e.value === booking.event_type)?.label ?? booking.event_type}
                </Text>
              </View>
            </View>

            <View style={confStyles.actions}>
              <AnimatedPressable onPress={onViewBookings} scaleValue={0.96}>
                <LinearGradient colors={[Colors.primary, Colors.primaryDark]} style={confStyles.primaryBtn} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
                  <Text style={confStyles.primaryBtnText}>View My Bookings</Text>
                </LinearGradient>
              </AnimatedPressable>
              <AnimatedPressable onPress={onGoHome} scaleValue={0.96}>
                <Text style={confStyles.secondaryLink}>Back to Discover</Text>
              </AnimatedPressable>
            </View>
          </Animated.View>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const confStyles = StyleSheet.create({
  screen: { flex: 1 },
  safeArea: { flex: 1 },
  content: { flexGrow: 1, alignItems: 'center', paddingHorizontal: Spacing.xxl, paddingVertical: Spacing.xxxl },
  checkContainer: { marginBottom: Spacing.xxl },
  checkCircle: { width: 96, height: 96, borderRadius: 48, justifyContent: 'center', alignItems: 'center', ...Shadow.lg },
  title: { fontSize: FontSize.xxxl, fontWeight: FontWeight.heavy, color: Colors.text, textAlign: 'center', marginBottom: Spacing.sm, fontFamily: SERIF_FONT },
  subtitle: { fontSize: FontSize.md, color: Colors.textSecondary, textAlign: 'center', marginBottom: Spacing.xxl, lineHeight: 22 },
  card: { backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.xl, width: '100%', marginBottom: Spacing.md, ...Shadow.sm },
  cardLabel: { fontSize: FontSize.xs, color: Colors.textTertiary, fontWeight: FontWeight.semibold, textTransform: 'uppercase' as const, letterSpacing: 0.8, marginBottom: Spacing.xs },
  bookingId: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text, fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace' },
  amountRow: { flexDirection: 'row', alignItems: 'center' },
  amountItem: { flex: 1 },
  amountDivider: { width: 1, height: 40, backgroundColor: Colors.border, marginHorizontal: Spacing.md },
  amountValue: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
  advanceNote: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, marginTop: Spacing.sm, paddingTop: Spacing.sm, borderTopWidth: 1, borderTopColor: Colors.borderLight },
  advanceNoteText: { fontSize: FontSize.xs, color: Colors.textTertiary },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingVertical: Spacing.xs },
  detailText: { fontSize: FontSize.md, color: Colors.textSecondary },
  actions: { width: '100%', gap: Spacing.md, marginTop: Spacing.md },
  primaryBtn: { borderRadius: Radius.lg, paddingVertical: Spacing.md, alignItems: 'center' },
  primaryBtnText: { color: '#FFFFFF', fontSize: FontSize.md, fontWeight: FontWeight.bold },
  secondaryLink: { color: Colors.textTertiary, fontSize: FontSize.md, fontWeight: FontWeight.medium, textAlign: 'center', paddingVertical: Spacing.sm },
});

// --- Main Screen ---

export default function ServiceBookingScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { user } = useAuth();

  // Auth is checked lazily in handleSubmit — no mount-time redirect.
  // This avoids the race condition where React hasn't propagated the user
  // state yet right after OTP login, causing a false "not logged in" redirect.

  // Data loading
  const [listing, setListing] = useState<ListingWithVendor | null>(null);
  const [isLoadingListing, setIsLoadingListing] = useState(true);
  const [listingError, setListingError] = useState<string | null>(null);

  // Availability
  const [unavailableDates, setUnavailableDates] = useState<Set<string>>(new Set());
  const [isLoadingAvailability, setIsLoadingAvailability] = useState(true);
  const [availabilityError, setAvailabilityError] = useState<string | null>(null);

  // Form state
  const [selectedDate, setSelectedDate] = useState('');
  const [eventType, setEventType] = useState<EventType | null>(null);
  const [guestCount, setGuestCount] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');

  // Submission state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [confirmation, setConfirmation] = useState<BookingConfirmation | null>(null);

  // Validation errors
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  // Load listing
  useEffect(() => {
    if (!id) return;
    setIsLoadingListing(true);
    setListingError(null);

    supabase
      .from('service_listings')
      .select('*, vendor:vendor_profiles(id, vendor_sector, business_name, sector_data)')
      .eq('id', id)
      .eq('is_active', true)
      .single()
      .then(({ data, error }) => {
        if (error || !data) {
          setListingError('Service listing not found or is no longer available.');
          setListing(null);
        } else {
          setListing(data as ListingWithVendor);
        }
        setIsLoadingListing(false);
      });
  }, [id]);

  // Load availability (Requirement 6.2)
  const loadAvailability = useCallback(async () => {
    if (!id || !listing) return;
    setIsLoadingAvailability(true);
    setAvailabilityError(null);

    try {
      // Fetch all non-cancelled bookings for this listing
      const { data: bookings, error: bookingsError } = await supabase
        .from('service_bookings')
        .select('event_date')
        .eq('listing_id', id)
        .neq('status', 'cancelled');

      if (bookingsError) throw bookingsError;

      // Extract blocked dates from vendor sector_data
      const sectorData = listing.vendor?.sector_data as { blocked_dates?: BlockedDateRange[] } | null;
      const blockedRanges: BlockedDateRange[] = sectorData?.blocked_dates ?? [];

      const today = todayISO();
      const endDate = addDays(today, 365);

      const unavailable = getUnavailableDates(blockedRanges, bookings ?? [], today, endDate);
      setUnavailableDates(new Set(unavailable));
    } catch (err: any) {
      // Requirement 6.2: if availability query fails, display error and block date selection
      setAvailabilityError('Could not load availability. Please try again before selecting a date.');
    } finally {
      setIsLoadingAvailability(false);
    }
  }, [id, listing]);

  useEffect(() => {
    if (listing) {
      loadAvailability();
    }
  }, [listing]);

  // Derived: guest count required for wedding/corporate (Requirement 6.1)
  const guestCountRequired = useMemo(
    () => eventType !== null && GUEST_COUNT_REQUIRED.includes(eventType),
    [eventType]
  );

  // Validation
  const validate = useCallback((): boolean => {
    const errors: Record<string, string> = {};

    if (!selectedDate) {
      errors.date = 'Please select an event date.';
    } else if (unavailableDates.has(selectedDate)) {
      // Requirement 6.3: client-side guard before DB insert
      errors.date = 'Vendor is unavailable on selected date.';
    }

    if (!eventType) {
      errors.eventType = 'Please select an event type.';
    }

    if (guestCountRequired) {
      const count = parseInt(guestCount, 10);
      if (!guestCount.trim() || isNaN(count) || count < 1) {
        errors.guestCount = 'Guest count is required for this event type.';
      }
    }

    // Requirement 6.1: special requests max 500 chars
    if (specialRequests.length > 500) {
      errors.specialRequests = `Special requests must be 500 characters or fewer (currently ${specialRequests.length}).`;
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }, [selectedDate, eventType, guestCount, guestCountRequired, specialRequests, unavailableDates]);

  // Submit booking (Requirements 6.4, 6.5, 6.6, 6.8, 6.9, 9.7)
  const handleSubmit = useCallback(async () => {
    if (!validate()) return;
    if (!listing) return;

    // Resolve user id — context first, getSession() as fallback
    let customerId = user?.id ?? null;
    if (!customerId) {
      const { data: { session } } = await supabase.auth.getSession();
      customerId = session?.user?.id ?? null;
    }
    if (!customerId) {
      const redirectPath = `/service-booking/${id}`;
      router.push(`/customer-login?redirect=${encodeURIComponent(redirectPath)}` as any);
      return;
    }

    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }

    setIsSubmitting(true);
    setSubmitError(null);

    try {
      // Build insert payload. total_amount and advance_amount are set by
      // fn_set_booking_amounts BEFORE INSERT trigger (Requirement 6.8).
      // We pass 0 as placeholders; the trigger overwrites them.
      const insertPayload: Record<string, unknown> = {
        listing_id: listing.id,
        vendor_id: listing.vendor_id,
        customer_id: customerId,
        sector: listing.sector,
        event_date: selectedDate,
        event_type: eventType,
        total_amount: 0,
        advance_amount: 0,
        status: 'pending',
      };

      if (guestCountRequired && guestCount.trim()) {
        insertPayload.guest_count = parseInt(guestCount, 10);
      }

      if (specialRequests.trim()) {
        insertPayload.special_requests = specialRequests.trim();
      }

      const { data, error } = await supabase
        .from('service_bookings')
        .insert(insertPayload)
        .select('id, total_amount, advance_amount, event_date, event_type')
        .single();

      if (error) {
        // Surface DB errors per spec:
        // - 23505 (unique_violation) from partial UNIQUE index → Requirement 6.6
        // - P0001 from fn_set_booking_amounts (no base price) → Requirement 6.9
        // - P0001 from fn_create_service_commission (no active rate) → Requirement 9.7
        setSubmitError(parseDbError(error));
        return;
      }

      if (!data) {
        setSubmitError('Booking was created but confirmation could not be retrieved. Please check your bookings.');
        return;
      }

      // Show confirmation state (Requirement 6.4)
      setConfirmation(data as BookingConfirmation);
    } catch (err: any) {
      setSubmitError(err?.message ?? 'An unexpected error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  }, [user, validate, listing, selectedDate, eventType, guestCount, guestCountRequired, specialRequests, router, id]);

  // Render: loading listing
  if (isLoadingListing) {
    return (
      <View style={styles.centered}>
        <Stack.Screen options={{ title: 'Book Service', headerShown: true }} />
        <ActivityIndicator size="large" color={Colors.primary} />
        <Text style={styles.loadingText}>Loading service details...</Text>
      </View>
    );
  }

  // Render: listing error
  if (listingError || !listing) {
    return (
      <View style={styles.centered}>
        <Stack.Screen options={{ title: 'Book Service', headerShown: true }} />
        <AlertTriangle size={40} color={Colors.error} />
        <Text style={styles.errorHeading}>Service Not Found</Text>
        <Text style={styles.errorBody}>{listingError ?? 'This listing is no longer available.'}</Text>
        <AnimatedPressable onPress={() => router.back()} scaleValue={0.96}>
          <View style={styles.backBtn}>
            <Text style={styles.backBtnText}>Go Back</Text>
          </View>
        </AnimatedPressable>
      </View>
    );
  }

  // Render: confirmation success state (Requirement 6.4)
  if (confirmation) {
    return (
      <>
        <Stack.Screen options={{ headerShown: false }} />
        <ConfirmationScreen
          booking={confirmation}
          listingTitle={listing.title}
          onViewBookings={() => router.replace('/(tabs)/bookings' as any)}
          onGoHome={() => router.replace('/(tabs)/discover' as any)}
        />
      </>
    );
  }

  // Render: booking form
  const vendorName = listing.vendor?.business_name ?? 'Vendor';

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <Stack.Screen
        options={{
          title: 'Book Service',
          headerStyle: { backgroundColor: Colors.surface },
          headerTintColor: Colors.text,
          headerShadowVisible: false,
          headerLeft: () => (
            <AnimatedPressable onPress={() => router.back()} style={{ marginLeft: -Spacing.sm }}>
              <ChevronLeft size={24} color={Colors.text} />
            </AnimatedPressable>
          ),
        }}
      />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Listing header */}
        <View style={styles.listingHeader}>
          <View style={styles.listingInfo}>
            <Text style={styles.listingTitle} numberOfLines={2}>{listing.title}</Text>
            <Text style={styles.vendorName}>{vendorName}</Text>
          </View>
          <View style={styles.priceBox}>
            <Text style={styles.priceAmount}>{formatCurrencyFull(listing.base_price)}</Text>
            <Text style={styles.priceUnit}>{listing.price_unit.replace(/_/g, ' ')}</Text>
          </View>
        </View>

        {/* Step 1: Date picker (Requirement 6.2) */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Calendar size={18} color={Colors.primary} />
            <Text style={styles.sectionTitle}>Select Event Date</Text>
          </View>

          {availabilityError ? (
            <View style={styles.availabilityErrorBox}>
              <AlertTriangle size={16} color={Colors.error} />
              <Text style={styles.availabilityErrorText}>{availabilityError}</Text>
              <TouchableOpacity onPress={loadAvailability} style={styles.retryBtn}>
                <Text style={styles.retryBtnText}>Retry</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <DatePicker
              unavailableDates={unavailableDates}
              selectedDate={selectedDate}
              onSelectDate={(date) => {
                setSelectedDate(date);
                setFieldErrors((prev) => ({ ...prev, date: '' }));
              }}
              isLoading={isLoadingAvailability}
            />
          )}

          {selectedDate ? (
            <View style={styles.selectedDateBadge}>
              <CheckCircle2 size={14} color={Colors.success} />
              <Text style={styles.selectedDateText}>{formatDisplayDate(selectedDate)}</Text>
            </View>
          ) : null}

          {fieldErrors.date ? (
            <View style={styles.fieldError}>
              <AlertTriangle size={12} color={Colors.error} />
              <Text style={styles.fieldErrorText}>{fieldErrors.date}</Text>
            </View>
          ) : null}

          <View style={styles.legend}>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: Colors.primary }]} />
              <Text style={styles.legendText}>Selected</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: Colors.cream, borderWidth: 1, borderColor: Colors.border }]} />
              <Text style={styles.legendText}>Unavailable</Text>
            </View>
          </View>
        </View>

        {/* Step 2: Event type (Requirement 6.1) */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Info size={18} color={Colors.primary} />
            <Text style={styles.sectionTitle}>Event Type</Text>
          </View>

          <View style={styles.eventTypeGrid}>
            {EVENT_TYPES.map((et) => {
              const isSelected = eventType === et.value;
              return (
                <AnimatedPressable
                  key={et.value}
                  onPress={() => {
                    setEventType(et.value);
                    setFieldErrors((prev) => ({ ...prev, eventType: '', guestCount: '' }));
                  }}
                  scaleValue={0.95}
                  style={styles.eventTypeItem}
                >
                  <View style={[styles.eventTypeCard, isSelected && styles.eventTypeCardSelected]}>
                    <Text style={[styles.eventTypeLabel, isSelected && styles.eventTypeLabelSelected]}>
                      {et.label}
                    </Text>
                  </View>
                </AnimatedPressable>
              );
            })}
          </View>

          {fieldErrors.eventType ? (
            <View style={styles.fieldError}>
              <AlertTriangle size={12} color={Colors.error} />
              <Text style={styles.fieldErrorText}>{fieldErrors.eventType}</Text>
            </View>
          ) : null}
        </View>

        {/* Step 3: Guest count (Requirement 6.1 - required for wedding/corporate) */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Users size={18} color={Colors.primary} />
            <Text style={styles.sectionTitle}>
              Guest Count
              {guestCountRequired
                ? <Text style={styles.required}> *</Text>
                : <Text style={styles.optional}> (optional)</Text>
              }
            </Text>
          </View>

          <View style={[styles.inputWrapper, fieldErrors.guestCount ? styles.inputWrapperError : null]}>
            <Users size={16} color={Colors.textTertiary} style={styles.inputIcon} />
            <TextInput
              style={styles.textInput}
              placeholder={guestCountRequired ? 'Enter expected guest count' : 'Enter guest count (optional)'}
              placeholderTextColor={Colors.textTertiary}
              value={guestCount}
              onChangeText={(v) => {
                setGuestCount(v);
                setFieldErrors((prev) => ({ ...prev, guestCount: '' }));
              }}
              keyboardType="number-pad"
              returnKeyType="done"
            />
          </View>

          {fieldErrors.guestCount ? (
            <View style={styles.fieldError}>
              <AlertTriangle size={12} color={Colors.error} />
              <Text style={styles.fieldErrorText}>{fieldErrors.guestCount}</Text>
            </View>
          ) : null}
        </View>

        {/* Step 4: Special requests (Requirement 6.1 - max 500 chars) */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Info size={18} color={Colors.primary} />
            <Text style={styles.sectionTitle}>
              Special Requests <Text style={styles.optional}>(optional)</Text>
            </Text>
          </View>

          <View style={[styles.inputWrapper, styles.textAreaWrapper, fieldErrors.specialRequests ? styles.inputWrapperError : null]}>
            <TextInput
              style={[styles.textInput, styles.textArea]}
              placeholder="Any special requirements, setup preferences, or notes for the vendor..."
              placeholderTextColor={Colors.textTertiary}
              value={specialRequests}
              onChangeText={(v) => {
                setSpecialRequests(v);
                setFieldErrors((prev) => ({ ...prev, specialRequests: '' }));
              }}
              multiline
              numberOfLines={4}
              maxLength={520}
              textAlignVertical="top"
            />
          </View>

          <View style={styles.charCountRow}>
            {fieldErrors.specialRequests ? (
              <View style={[styles.fieldError, { flex: 1 }]}>
                <AlertTriangle size={12} color={Colors.error} />
                <Text style={styles.fieldErrorText}>{fieldErrors.specialRequests}</Text>
              </View>
            ) : <View style={{ flex: 1 }} />}
            <Text style={[styles.charCount, specialRequests.length > 500 && styles.charCountError]}>
              {specialRequests.length}/500
            </Text>
          </View>
        </View>

        {/* Submit error */}
        {submitError ? (
          <View style={styles.submitErrorBox}>
            <AlertTriangle size={16} color={Colors.error} />
            <Text style={styles.submitErrorText}>{submitError}</Text>
          </View>
        ) : null}

        {/* Submit button */}
        <View style={styles.submitSection}>
          <AnimatedPressable
            onPress={handleSubmit}
            disabled={isSubmitting || isLoadingAvailability || !!availabilityError}
            scaleValue={0.97}
          >
            <LinearGradient
              colors={
                isSubmitting || isLoadingAvailability || !!availabilityError
                  ? [Colors.warmGray, Colors.warmGray]
                  : [Colors.primary, Colors.primaryDark]
              }
              style={styles.submitBtn}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
            >
              {isSubmitting ? (
                <ActivityIndicator size="small" color="#FFFFFF" />
              ) : (
                <>
                  <Text style={styles.submitBtnText}>Confirm Booking</Text>
                  <ChevronRight size={18} color="#FFFFFF" />
                </>
              )}
            </LinearGradient>
          </AnimatedPressable>

          <Text style={styles.submitNote}>
            Your booking will be pending until the vendor confirms it.
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: Spacing.massive,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.xxl,
    backgroundColor: Colors.background,
    gap: Spacing.md,
  },
  loadingText: {
    fontSize: FontSize.md,
    color: Colors.textSecondary,
    marginTop: Spacing.sm,
  },
  errorHeading: {
    fontSize: FontSize.xl,
    fontWeight: FontWeight.bold,
    color: Colors.text,
    textAlign: 'center',
  },
  errorBody: {
    fontSize: FontSize.md,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
  },
  backBtn: {
    marginTop: Spacing.sm,
    paddingHorizontal: Spacing.xxl,
    paddingVertical: Spacing.md,
    backgroundColor: Colors.primary,
    borderRadius: Radius.lg,
  },
  backBtnText: {
    color: Colors.textOnPrimary,
    fontSize: FontSize.md,
    fontWeight: FontWeight.semibold,
  },

  // Listing header
  listingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: Spacing.xl,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
    ...Shadow.sm,
  },
  listingInfo: {
    flex: 1,
    marginRight: Spacing.md,
  },
  listingTitle: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.bold,
    color: Colors.text,
    marginBottom: Spacing.xs,
  },
  vendorName: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
  },
  priceBox: {
    alignItems: 'flex-end',
  },
  priceAmount: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.bold,
    color: Colors.primary,
  },
  priceUnit: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    textTransform: 'capitalize',
  },

  // Sections
  section: {
    backgroundColor: Colors.surface,
    marginTop: Spacing.sm,
    paddingVertical: Spacing.xl,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: Colors.borderLight,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.xl,
    marginBottom: Spacing.md,
  },
  sectionTitle: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.semibold,
    color: Colors.text,
  },
  required: {
    color: Colors.error,
    fontWeight: FontWeight.bold,
  },
  optional: {
    color: Colors.textTertiary,
    fontWeight: FontWeight.regular,
    fontSize: FontSize.sm,
  },

  // Availability error
  availabilityErrorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginHorizontal: Spacing.xl,
    padding: Spacing.md,
    backgroundColor: Colors.errorLight,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.error + '33',
    flexWrap: 'wrap',
  },
  availabilityErrorText: {
    flex: 1,
    fontSize: FontSize.sm,
    color: Colors.error,
    lineHeight: 18,
  },
  retryBtn: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    backgroundColor: Colors.error,
    borderRadius: Radius.sm,
  },
  retryBtnText: {
    color: '#FFFFFF',
    fontSize: FontSize.xs,
    fontWeight: FontWeight.semibold,
  },

  // Selected date badge
  selectedDateBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    marginHorizontal: Spacing.xl,
    marginTop: Spacing.sm,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    backgroundColor: Colors.successLight,
    borderRadius: Radius.full,
    alignSelf: 'flex-start',
  },
  selectedDateText: {
    fontSize: FontSize.sm,
    color: Colors.success,
    fontWeight: FontWeight.semibold,
  },

  // Legend
  legend: {
    flexDirection: 'row',
    gap: Spacing.xl,
    paddingHorizontal: Spacing.xl,
    marginTop: Spacing.md,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  legendDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  legendText: {
    fontSize: FontSize.xs,
    color: Colors.textSecondary,
  },

  // Event type grid
  eventTypeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: Spacing.xl,
    gap: Spacing.sm,
  },
  eventTypeItem: {
    width: '47%',
  },
  eventTypeCard: {
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: Colors.border,
    backgroundColor: Colors.surface,
    alignItems: 'center',
  },
  eventTypeCardSelected: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primaryFaded,
  },
  eventTypeLabel: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.medium,
    color: Colors.textSecondary,
  },
  eventTypeLabelSelected: {
    color: Colors.primary,
    fontWeight: FontWeight.semibold,
  },

  // Input fields
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: Spacing.xl,
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderRadius: Radius.md,
    backgroundColor: Colors.surface,
    paddingHorizontal: Spacing.md,
    minHeight: 48,
  },
  inputWrapperError: {
    borderColor: Colors.error,
  },
  textAreaWrapper: {
    alignItems: 'flex-start',
    paddingVertical: Spacing.sm,
    minHeight: 100,
  },
  inputIcon: {
    marginRight: Spacing.sm,
  },
  textInput: {
    flex: 1,
    fontSize: FontSize.md,
    color: Colors.text,
    paddingVertical: Spacing.sm,
  },
  textArea: {
    minHeight: 88,
    textAlignVertical: 'top',
  },

  // Char count
  charCountRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.xl,
    marginTop: Spacing.xs,
  },
  charCount: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
  },
  charCountError: {
    color: Colors.error,
    fontWeight: FontWeight.semibold,
  },

  // Field errors
  fieldError: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    paddingHorizontal: Spacing.xl,
    marginTop: Spacing.xs,
  },
  fieldErrorText: {
    fontSize: FontSize.xs,
    color: Colors.error,
    flex: 1,
  },

  // Submit error
  submitErrorBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.sm,
    marginHorizontal: Spacing.xl,
    marginTop: Spacing.sm,
    padding: Spacing.md,
    backgroundColor: Colors.errorLight,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.error + '33',
  },
  submitErrorText: {
    flex: 1,
    fontSize: FontSize.sm,
    color: Colors.error,
    lineHeight: 20,
  },

  // Submit section
  submitSection: {
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.xl,
    gap: Spacing.sm,
  },
  submitBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.md + 2,
    borderRadius: Radius.lg,
    ...Shadow.sm,
  },
  submitBtnText: {
    color: Colors.textOnPrimary,
    fontSize: FontSize.md,
    fontWeight: FontWeight.bold,
  },
  submitNote: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    textAlign: 'center',
    lineHeight: 18,
  },
});
