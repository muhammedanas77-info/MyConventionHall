import React, { useRef, useEffect } from 'react';
import { View, Text, StyleSheet, Animated, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Users, Building, Lock, ChevronRight } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { useApp } from '@/providers/AppProvider';
import { supabase } from '@/utils/supabase';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

const SERIF_FONT = Platform.select({
    ios: 'Georgia',
    android: 'serif',
    web: 'Georgia, serif',
    default: 'serif',
});

const SANS_FONT = Platform.select({
    ios: 'System',
    android: 'sans-serif',
    web: 'system-ui, sans-serif',
    default: 'sans-serif',
});

export default function RoleSelectScreen() {
    const router = useRouter();
    const { login, logout } = useApp();
    const fadeAnim = useRef(new Animated.Value(0)).current;
    const card1 = useRef(new Animated.Value(0)).current;
    const card2 = useRef(new Animated.Value(0)).current;
    const card3 = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        Animated.sequence([
            Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }),
            Animated.stagger(100, [
                Animated.spring(card1, { toValue: 1, useNativeDriver: true, speed: 14, bounciness: 4 }),
                Animated.spring(card2, { toValue: 1, useNativeDriver: true, speed: 14, bounciness: 4 }),
                Animated.spring(card3, { toValue: 1, useNativeDriver: true, speed: 14, bounciness: 4 }),
            ]),
        ]).start();
    }, [card1, card2, card3, fadeAnim]);

    const handleGuest = () => {
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        login('guest', 'Guest');
        router.replace('/(tabs)/discover' as any);
    };

    const handleCustomerLogin = async () => {
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        logout();
        await supabase.auth.signOut();
        router.push('/customer-login' as any);
    };

    const animStyle = (anim: Animated.Value) => ({
        opacity: anim,
        transform: [{ translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [30, 0] }) }],
    });

    return (
        <View style={styles.container}>
            <SafeAreaView style={styles.safeArea}>
                <Animated.View style={[styles.mainContent, { opacity: fadeAnim }]}>
                    <Text style={styles.welcomeIntro}>WELCOME TO</Text>
                    <Text style={styles.brandTitle}>ConventionHub</Text>
                    <Text style={styles.subtitle}>Let&apos;s find the perfect space for your next event</Text>
                </Animated.View>

                <View style={styles.cards}>
                    <Animated.View style={animStyle(card1)}>
                        <AnimatedPressable
                            onPress={handleCustomerLogin}
                            scaleValue={0.96}
                        >
                            <View style={styles.card}>
                                <View style={[styles.iconCircle, { backgroundColor: '#FDE8E8' }]}>
                                    <Users size={28} color="#C53030" />
                                </View>
                                <View style={styles.cardText}>
                                    <View style={styles.cardTitleRow}>
                                        <Text style={styles.cardTitle}>Book Services</Text>
                                        <ChevronRight size={18} color={Colors.textTertiary} />
                                    </View>
                                    <Text style={styles.cardSubtitle}>
                                        Venues, florists, musicians, photographers, caterers, decorators, artists & more
                                    </Text>
                                </View>
                            </View>
                        </AnimatedPressable>
                    </Animated.View>

                    <Animated.View style={animStyle(card2)}>
                        <AnimatedPressable
                            onPress={() => {
                                if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                                router.push('/vendor-login' as any);
                            }}
                            scaleValue={0.96}
                        >
                            <View style={styles.card}>
                                <View style={[styles.iconCircle, { backgroundColor: '#FEF3CD' }]}>
                                    <Building size={28} color="#D97706" />
                                </View>
                                <View style={styles.cardText}>
                                    <View style={styles.cardTitleRow}>
                                        <Text style={styles.cardTitle}>List Your Services</Text>
                                        <ChevronRight size={18} color={Colors.textTertiary} />
                                    </View>
                                    <Text style={styles.cardSubtitle}>
                                        Partner with us to manage bookings and reach 1000+ customers
                                    </Text>
                                </View>
                            </View>
                        </AnimatedPressable>
                    </Animated.View>

                    <Animated.View style={animStyle(card3)}>
                        <AnimatedPressable
                            onPress={() => {
                                if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                                router.push('/admin-login' as any);
                            }}
                            scaleValue={0.96}
                        >
                            <View style={styles.adminAccessRow}>
                                <Lock size={12} color={Colors.textTertiary} />
                                <Text style={styles.adminText}>ADMIN PORTAL ACCESS</Text>
                            </View>
                        </AnimatedPressable>
                    </Animated.View>
                </View>

                <Animated.View style={[styles.footer, { opacity: fadeAnim }]}>
                    <AnimatedPressable onPress={handleGuest} scaleValue={0.98}>
                        <View style={styles.guestButton}>
                            <Text style={styles.guestButtonText}>Continue as Guest</Text>
                        </View>
                    </AnimatedPressable>
                </Animated.View>
            </SafeAreaView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FFFFFF',
    },
    safeArea: {
        flex: 1,
        paddingHorizontal: Spacing.xl,
    },
    mainContent: {
        paddingTop: Spacing.huge * 2,
        marginBottom: Spacing.huge,
        alignItems: 'center',
    },
    welcomeIntro: {
        fontSize: 14,
        color: Colors.textTertiary,
        fontFamily: SERIF_FONT,
        letterSpacing: 4,
        textTransform: 'uppercase',
        marginBottom: Spacing.xs,
    },
    brandTitle: {
        fontSize: 42,
        fontWeight: '300',
        color: Colors.primary,
        fontFamily: SERIF_FONT,
        letterSpacing: 2,
    },
    subtitle: {
        fontSize: FontSize.sm,
        color: Colors.textTertiary,
        lineHeight: 20,
        textAlign: 'center',
        marginTop: Spacing.sm,
        maxWidth: '85%',
    },
    cards: {
        gap: Spacing.lg,
    },
    card: {
        flexDirection: 'row',
        backgroundColor: '#FFFFFF',
        borderRadius: 22,
        padding: Spacing.lg,
        alignItems: 'center',
        ...Shadow.md,
        borderWidth: 1,
        borderColor: Colors.borderLight,
    },
    iconCircle: {
        width: 64,
        height: 64,
        borderRadius: 32,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: Spacing.lg,
    },
    cardText: {
        flex: 1,
    },
    cardTitleRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 2,
    },
    cardTitle: {
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.text,
        fontFamily: SANS_FONT,
    },
    cardSubtitle: {
        fontSize: 13,
        color: Colors.textTertiary,
        lineHeight: 18,
    },
    adminAccessRow: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: Spacing.md,
        gap: Spacing.xs,
        opacity: 0.5,
    },
    adminText: {
        fontSize: 10,
        fontWeight: FontWeight.bold,
        color: Colors.textTertiary,
        letterSpacing: 2,
    },
    footer: {
        flex: 1,
        justifyContent: 'flex-end',
        paddingBottom: Spacing.xxl,
    },
    guestButton: {
        backgroundColor: Colors.ivory,
        paddingVertical: Spacing.lg,
        borderRadius: Radius.lg,
        alignItems: 'center',
    },
    guestButtonText: {
        fontSize: FontSize.md,
        fontWeight: FontWeight.bold,
        color: Colors.textSecondary,
    },
});

