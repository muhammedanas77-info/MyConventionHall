import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, Stack } from 'expo-router';
import { Shield, ArrowLeft } from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

export default function PrivacyScreen() {
    const router = useRouter();

    return (
        <View style={styles.container}>
            <Stack.Screen options={{ headerShown: false }} />
            <SafeAreaView style={styles.safeArea}>
                <View style={styles.header}>
                    <AnimatedPressable onPress={() => router.back()} scaleValue={0.9}>
                        <ArrowLeft size={24} color={Colors.text} />
                    </AnimatedPressable>
                    <Text style={styles.title}>Privacy Policy</Text>
                    <View style={{ width: 24 }} />
                </View>

                <ScrollView contentContainerStyle={styles.scrollContent}>
                    <View style={styles.hero}>
                        <Shield size={48} color={Colors.success} />
                        <Text style={styles.heroTitle}>Your Privacy Matters</Text>
                        <Text style={styles.heroSubtitle}>Last updated February 2026</Text>
                    </View>

                    <View style={styles.content}>
                        <Text style={styles.paragraph}>
                            At ConventionHub, we take your privacy seriously. This policy explains how we collect, use, and protect your information.
                        </Text>

                        <Text style={styles.sectionTitle}>1. Data Collection</Text>
                        <Text style={styles.paragraph}>
                            We collect basic information like your name and email when you create an account to manage your bookings and saved venues.
                        </Text>

                        <Text style={styles.sectionTitle}>2. Location Access</Text>
                        <Text style={styles.paragraph}>
                            We use your location to show nearby wedding venues and calculate distances. This data is never shared with third parties.
                        </Text>

                        <Text style={styles.sectionTitle}>3. Payment Security</Text>
                        <Text style={styles.paragraph}>
                            All payments are processed through secure gateways. We do not store your full card details on our servers.
                        </Text>
                    </View>
                </ScrollView>
            </SafeAreaView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: Colors.background },
    safeArea: { flex: 1 },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: Spacing.xl,
        paddingVertical: Spacing.lg,
        backgroundColor: Colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: Colors.borderLight,
    },
    title: { fontSize: 18, fontWeight: FontWeight.bold, color: Colors.text },
    scrollContent: { paddingBottom: Spacing.massive },
    hero: { alignItems: 'center', paddingVertical: Spacing.massive, backgroundColor: Colors.surface, marginBottom: Spacing.lg },
    heroTitle: { fontSize: 24, fontWeight: FontWeight.bold, color: Colors.text, marginTop: Spacing.md },
    heroSubtitle: { fontSize: FontSize.md, color: Colors.textTertiary, marginTop: Spacing.xs },
    content: { paddingHorizontal: Spacing.xl },
    sectionTitle: { fontSize: 18, fontWeight: FontWeight.bold, color: Colors.text, marginTop: Spacing.xl, marginBottom: Spacing.sm },
    paragraph: { fontSize: FontSize.md, color: Colors.textSecondary, lineHeight: 24 },
});
