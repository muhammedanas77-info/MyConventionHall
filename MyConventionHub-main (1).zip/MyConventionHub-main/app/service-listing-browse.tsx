/**
 * app/service-listing-browse.tsx
 *
 * Customer-facing browse screen for a single vendor sector.
 * Navigated to from (tabs)/discover.tsx sector tiles for non-venue sectors.
 *
 * Route: /service-listing-browse?sector=florist
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
    ActivityIndicator,
    FlatList,
    StyleSheet,
    Text,
    TextInput,
    View,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, Search } from 'lucide-react-native';
import { Colors, FontSize, FontWeight, Radius, Spacing } from '@/constants/theme';
import { getSectorConfig, SECTOR_LIST } from '@/constants/sectors';
import { supabase } from '@/utils/supabase';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import ErrorState from '@/components/ui/ErrorState';
import SectorCard from '@/components/features/vendor/SectorCard';
import type { ServiceListing, VendorSector } from '@/types';

interface ListingRow extends ServiceListing {
    vendor_city?: string;
    vendor_name?: string;
}

export default function ServiceListingBrowseScreen() {
    const router = useRouter();
    const { sector } = useLocalSearchParams<{ sector: string }>();

    // Validate sector param
    const validSector = SECTOR_LIST.includes(sector as VendorSector)
        ? (sector as VendorSector)
        : null;

    const config = validSector ? getSectorConfig(validSector) : null;

    const [listings, setListings] = useState<ListingRow[]>([]);
    const [filtered, setFiltered] = useState<ListingRow[]>([]);
    const [search, setSearch] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [isError, setIsError] = useState(false);

    const fetchListings = useCallback(async () => {
        if (!validSector) return;
        setIsLoading(true);
        setIsError(false);

        const { data, error } = await supabase
            .from('service_listings')
            .select(`
                *,
                vendor:vendor_profiles(
                    sector_data,
                    profiles(full_name)
                )
            `)
            .eq('sector', validSector)
            .eq('is_active', true)
            .order('rating', { ascending: false, nullsFirst: false })
            .limit(50);

        if (error) {
            setIsError(true);
        } else {
            const rows: ListingRow[] = (data ?? []).map((item: any) => ({
                ...item,
                vendor_city: item.vendor?.sector_data?.city ?? null,
                vendor_name:
                    item.vendor?.profiles?.full_name ??
                    item.vendor?.sector_data?.business_name ??
                    item.vendor?.sector_data?.artist_name ??
                    item.vendor?.sector_data?.studio_name ??
                    null,
            }));
            setListings(rows);
            setFiltered(rows);
        }
        setIsLoading(false);
    }, [validSector]);

    useEffect(() => { fetchListings(); }, [fetchListings]);

    useEffect(() => {
        if (!search.trim()) {
            setFiltered(listings);
            return;
        }
        const q = search.toLowerCase();
        setFiltered(
            listings.filter(
                (l) =>
                    l.title.toLowerCase().includes(q) ||
                    l.vendor_name?.toLowerCase().includes(q) ||
                    l.vendor_city?.toLowerCase().includes(q) ||
                    (l.tags ?? []).some((t) => t.toLowerCase().includes(q))
            )
        );
    }, [search, listings]);

    const handlePress = useCallback(
        (id: string) => { router.push(`/service/${id}` as any); },
        [router]
    );

    if (!validSector || !config) {
        return (
            <View style={styles.screen}>
                <ErrorState
                    title="Unknown category"
                    subtitle="This service category doesn't exist."
                    onRetry={() => router.back()}
                />
            </View>
        );
    }

    return (
        <View style={styles.screen}>
            <Stack.Screen options={{ headerShown: false }} />

            {/* Header */}
            <SafeAreaView edges={['top']} style={[styles.header, { backgroundColor: config.badgeColor }]}>
                <AnimatedPressable onPress={() => router.back()} scaleValue={0.9}>
                    <View style={styles.backBtn}>
                        <ArrowLeft size={22} color="#FFFFFF" />
                    </View>
                </AnimatedPressable>
                <Text style={styles.headerTitle}>{config.displayName}</Text>
                <View style={{ width: 40 }} />
            </SafeAreaView>

            {/* Search */}
            <View style={styles.searchContainer}>
                <Search size={16} color={Colors.textTertiary} />
                <TextInput
                    style={styles.searchInput}
                    placeholder={`Search ${config.displayName.toLowerCase()}s...`}
                    placeholderTextColor={Colors.textTertiary}
                    value={search}
                    onChangeText={setSearch}
                />
            </View>

            {isLoading && (
                <View style={styles.center}>
                    <ActivityIndicator size="large" color={config.badgeColor} />
                </View>
            )}

            {isError && !isLoading && (
                <ErrorState
                    title="Could not load listings"
                    subtitle="Check your connection and try again."
                    onRetry={fetchListings}
                />
            )}

            {!isLoading && !isError && (
                <FlatList
                    data={filtered}
                    keyExtractor={(item) => item.id}
                    horizontal={false}
                    numColumns={1}
                    contentContainerStyle={styles.listContent}
                    renderItem={({ item }) => (
                        <View style={styles.cardWrapper}>
                            <SectorCard
                                listing={item}
                                sector={validSector}
                                onPress={() => handlePress(item.id)}
                                fullWidth
                            />
                        </View>
                    )}
                    ListEmptyComponent={
                        <View style={styles.empty}>
                            <Text style={styles.emptyTitle}>No listings yet</Text>
                            <Text style={styles.emptySubtitle}>
                                No {config.displayName.toLowerCase()} services available right now.
                            </Text>
                        </View>
                    }
                    showsVerticalScrollIndicator={false}
                />
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        backgroundColor: Colors.background,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: Spacing.md,
        paddingBottom: Spacing.md,
    },
    backBtn: {
        width: 40,
        height: 40,
        alignItems: 'center',
        justifyContent: 'center',
    },
    headerTitle: {
        fontSize: FontSize.lg,
        fontWeight: FontWeight.bold,
        color: '#FFFFFF',
    },
    searchContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.sm,
        margin: Spacing.md,
        paddingHorizontal: Spacing.md,
        paddingVertical: Spacing.sm,
        backgroundColor: Colors.surface,
        borderRadius: Radius.lg,
        borderWidth: 1,
        borderColor: Colors.border,
    },
    searchInput: {
        flex: 1,
        fontSize: FontSize.sm,
        color: Colors.text,
    },
    center: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    listContent: {
        paddingHorizontal: Spacing.md,
        paddingBottom: Spacing.xl,
    },
    cardWrapper: {
        marginBottom: Spacing.md,
        width: '100%',
    },
    empty: {
        marginTop: 80,
        alignItems: 'center',
        paddingHorizontal: Spacing.xl,
    },
    emptyTitle: {
        fontSize: FontSize.lg,
        fontWeight: FontWeight.semibold,
        color: Colors.text,
        marginBottom: Spacing.xs,
    },
    emptySubtitle: {
        fontSize: FontSize.sm,
        color: Colors.textSecondary,
        textAlign: 'center',
    },
});
