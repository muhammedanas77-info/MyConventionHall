import React from 'react';
import { View, Text, StyleSheet, ScrollView, Linking } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, Stack } from 'expo-router';
import { HelpCircle, ArrowLeft } from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

const FAQS = [
    { q: 'How do I book a venue?', a: 'Choose a venue, select your date and slot, and proceed to pay the advance amount.' },
    { q: 'What is the cancellation policy?', a: 'Cancellations depend on the hall owner. Usually, a partial refund is provided if cancelled 30 days in advance.' },
    { q: 'Can I visit the venue before booking?', a: 'Yes, you can find the address on the venue page and visit during business hours.' },
    { q: 'How do I list my own hall?', a: 'Go to the home screen and select "Join as Owner" to register your business.' },
];

export default function HelpScreen() {
    const router = useRouter();

    return (
        <View style={styles.container}>
            <Stack.Screen options={{ headerShown: false }} />
            <SafeAreaView style={styles.safeArea}>
                <View style={styles.header}>
                    <AnimatedPressable onPress={() => router.back()} scaleValue={0.9}>
                        <ArrowLeft size={24} color={Colors.text} />
                    </AnimatedPressable>
                    <Text style={styles.title}>Help & FAQ</Text>
                    <View style={{ width: 24 }} />
                </View>

                <ScrollView contentContainerStyle={styles.scrollContent}>
                    <View style={styles.hero}>
                        <HelpCircle size={48} color={Colors.primary} />
                        <Text style={styles.heroTitle}>How can we help?</Text>
                        <Text style={styles.heroSubtitle}>Find answers to commonly asked questions</Text>
                    </View>

                    <View style={styles.section}>
                        {FAQS.map((faq, i) => (
                            <View key={i} style={styles.faqCard}>
                                <Text style={styles.question}>{faq.q}</Text>
                                <Text style={styles.answer}>{faq.a}</Text>
                            </View>
                        ))}
                    </View>

                    <View style={styles.contactCard}>
                        <Text style={styles.contactTitle}>Still need help?</Text>
                        <Text style={styles.contactText}>Our support team is available 24/7</Text>
                        <AnimatedPressable onPress={() => Linking.openURL('mailto:support@conventionhub.in?subject=Support Request')} style={styles.contactButton} scaleValue={0.98}>
                            <Text style={styles.contactButtonText}>Contact Support</Text>
                        </AnimatedPressable>
                    </View>
                </ScrollView>
            </SafeAreaView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: Colors.background },
    safeArea: { flex: 1 },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: Spacing.xl,
        paddingVertical: Spacing.lg,
        backgroundColor: Colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: Colors.borderLight,
    },
    title: { fontSize: 18, fontWeight: FontWeight.bold, color: Colors.text },
    scrollContent: { paddingBottom: Spacing.massive },
    hero: { alignItems: 'center', paddingVertical: Spacing.massive, backgroundColor: Colors.surface, marginBottom: Spacing.lg },
    heroTitle: { fontSize: 24, fontWeight: FontWeight.bold, color: Colors.text, marginTop: Spacing.md },
    heroSubtitle: { fontSize: FontSize.md, color: Colors.textTertiary, marginTop: Spacing.xs },
    section: { paddingHorizontal: Spacing.xl },
    faqCard: {
        backgroundColor: Colors.surface,
        padding: Spacing.lg,
        borderRadius: Radius.lg,
        marginBottom: Spacing.md,
        borderWidth: 1,
        borderColor: Colors.borderLight,
    },
    question: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: Spacing.sm },
    answer: { fontSize: FontSize.sm, color: Colors.textSecondary, lineHeight: 20 },
    contactCard: {
        margin: Spacing.xl,
        padding: Spacing.xl,
        backgroundColor: Colors.primaryFaded,
        borderRadius: Radius.xl,
        alignItems: 'center',
    },
    contactTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.primary, marginBottom: Spacing.xs },
    contactText: { fontSize: FontSize.sm, color: Colors.textSecondary, marginBottom: Spacing.lg },
    contactButton: { backgroundColor: Colors.primary, paddingHorizontal: Spacing.xxl, paddingVertical: Spacing.md, borderRadius: Radius.full },
    contactButtonText: { color: '#FFFFFF', fontWeight: FontWeight.bold },
});
