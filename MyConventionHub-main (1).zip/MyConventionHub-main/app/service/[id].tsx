import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    Animated,
    Platform,
    Dimensions,
    FlatList,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import {
    ArrowLeft,
    MapPin,
    Tag,
    Package,
    CalendarDays,
    ImageIcon,
    ChevronLeft,
    ChevronRight,
} from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { getUnavailableDates } from '@/utils/availabilityChecker';
import { getSectorConfig } from '@/constants/sectors';
import { formatCurrencyFull } from '@/utils/currency';
import FavouriteButton from '@/components/ui/FavouriteButton';

import AnimatedPressable from '@/components/ui/AnimatedPressable';
import ErrorState from '@/components/ui/ErrorState';
import ScreenLoader from '@/components/ui/ScreenLoader';
import type {
    ServiceListing,
    VendorProfile,
    BlockedDateRange,
    PhotographerPackage,
} from '@/types';
const { width: SCREEN_WIDTH } = Dimensions.get('window');

// ─── Types ────────────────────────────────────────────────────────────────────

interface ListingWithVendor extends ServiceListing {
    vendor: Pick<VendorProfile, 'id' | 'vendor_sector' | 'business_name' | 'sector_data'> & {
        profiles: { full_name: string | null; email: string } | null;
    };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Extract blocked_dates from any sector_data shape */
function extractBlockedDates(sectorData: VendorProfile['sector_data']): BlockedDateRange[] {
    if (!sectorData || typeof sectorData !== 'object') return [];
    const data = sectorData as Record<string, unknown>;
    if (Array.isArray(data.blocked_dates)) {
        return data.blocked_dates as BlockedDateRange[];
    }
    return [];
}

/** Format price unit for display */
function formatPriceUnit(unit: string): string {
    const labels: Record<string, string> = {
        per_event: 'per event',
        per_plate: 'per plate',
        per_hour: 'per hour',
        per_day: 'per day',
    };
    return labels[unit] ?? unit;
}

/** Get today as ISO date string */
function todayISO(): string {
    return new Date().toISOString().slice(0, 10);
}

/** Get date 12 months from today as ISO date string */
function twelveMonthsFromTodayISO(): string {
    const d = new Date();
    d.setFullYear(d.getFullYear() + 1);
    return d.toISOString().slice(0, 10);
}

/** Format ISO date for calendar display: "Mon 15 Jan" */
function formatCalendarDate(iso: string): string {
    const d = new Date(iso + 'T00:00:00');
    return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
}

/** Get all dates in a month as ISO strings */
function getDatesInMonth(year: number, month: number): string[] {
    const dates: string[] = [];
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    for (let d = 1; d <= daysInMonth; d++) {
        const mm = String(month + 1).padStart(2, '0');
        const dd = String(d).padStart(2, '0');
        dates.push(`${year}-${mm}-${dd}`);
    }
    return dates;
}

/** Get day-of-week offset (0=Sun) for the first day of a month */
function getMonthStartOffset(year: number, month: number): number {
    return new Date(year, month, 1).getDay();
}

// ─── Photo Carousel ───────────────────────────────────────────────────────────

interface PhotoCarouselProps {
    photos: string[];
    onBack: () => void;
    listingId: string;
}

function PhotoCarousel({ photos, onBack, listingId }: PhotoCarouselProps) {
    const [activeIndex, setActiveIndex] = useState(0);
    const flatListRef = useRef<FlatList>(null);
    const scrollY = useRef(new Animated.Value(0)).current;

    const hasPhotos = photos.length > 0;

    const handleScroll = useCallback((event: any) => {
        const x = event.nativeEvent.contentOffset.x;
        const index = Math.round(x / SCREEN_WIDTH);
        setActiveIndex(index);
    }, []);

    return (
        <View style={carouselStyles.container}>
            {hasPhotos ? (
                <>
                    <FlatList
                        ref={flatListRef}
                        data={photos}
                        horizontal
                        pagingEnabled
                        showsHorizontalScrollIndicator={false}
                        onMomentumScrollEnd={handleScroll}
                        keyExtractor={(_, i) => String(i)}
                        renderItem={({ item }) => (
                            <Image
                                source={{ uri: item }}
                                style={carouselStyles.image}
                                contentFit="cover"
                                transition={200}
                            />
                        )}
                    />
                    {photos.length > 1 && (
                        <View style={carouselStyles.dotsRow}>
                            {photos.map((_, i) => (
                                <View
                                    key={i}
                                    style={[
                                        carouselStyles.dot,
                                        i === activeIndex && carouselStyles.dotActive,
                                    ]}
                                />
                            ))}
                        </View>
                    )}
                    {photos.length > 1 && (
                        <View style={carouselStyles.countBadge}>
                            <ImageIcon size={13} color="#FFFFFF" />
                            <Text style={carouselStyles.countText}>
                                {activeIndex + 1}/{photos.length}
                            </Text>
                        </View>
                    )}
                </>
            ) : (
                <View style={carouselStyles.placeholder}>
                    <ImageIcon size={48} color={Colors.textTertiary} />
                    <Text style={carouselStyles.placeholderText}>No photos available</Text>
                </View>
            )}

            <LinearGradient
                colors={['rgba(0,0,0,0.45)', 'transparent']}
                style={carouselStyles.topGradient}
            />

            {/* Back button */}
            <SafeAreaView edges={['top']} style={carouselStyles.topBar}>
                <AnimatedPressable onPress={onBack} scaleValue={0.85}>
                    <View style={carouselStyles.backButton}>
                        <ArrowLeft size={20} color="#FFFFFF" />
                    </View>
                </AnimatedPressable>
                <FavouriteButton listingId={listingId} size={22} />
            </SafeAreaView>
        </View>
    );
}

const carouselStyles = StyleSheet.create({
    container: {
        height: 320,
        backgroundColor: Colors.cream,
        position: 'relative',
    },
    image: {
        width: SCREEN_WIDTH,
        height: 320,
    },
    placeholder: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        gap: Spacing.sm,
    },
    placeholderText: {
        fontSize: FontSize.sm,
        color: Colors.textTertiary,
    },
    topGradient: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: 100,
    },
    topBar: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: Spacing.lg,
        paddingBottom: Spacing.sm,
    },
    backButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(0,0,0,0.35)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    dotsRow: {
        position: 'absolute',
        bottom: Spacing.md,
        left: 0,
        right: 0,
        flexDirection: 'row',
        justifyContent: 'center',
        gap: Spacing.xs,
    },
    dot: {
        width: 6,
        height: 6,
        borderRadius: 3,
        backgroundColor: 'rgba(255,255,255,0.5)',
    },
    dotActive: {
        backgroundColor: '#FFFFFF',
        width: 18,
    },
    countBadge: {
        position: 'absolute',
        bottom: Spacing.md,
        right: Spacing.lg,
        backgroundColor: 'rgba(0,0,0,0.5)',
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: Spacing.sm,
        paddingVertical: Spacing.xxs,
        borderRadius: Radius.full,
        gap: Spacing.xs,
    },
    countText: {
        color: '#FFFFFF',
        fontSize: FontSize.xs,
        fontWeight: FontWeight.bold,
    },
});

// ─── Availability Calendar ────────────────────────────────────────────────────

interface AvailabilityCalendarProps {
    unavailableDates: string[];
    isLoading: boolean;
}

const WEEKDAY_LABELS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
const MONTH_NAMES = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
];

function AvailabilityCalendar({ unavailableDates, isLoading }: AvailabilityCalendarProps) {
    const today = new Date();
    const [viewYear, setViewYear] = useState(today.getFullYear());
    const [viewMonth, setViewMonth] = useState(today.getMonth());

    const unavailableSet = new Set(unavailableDates);
    const todayISO = today.toISOString().slice(0, 10);

    const dates = getDatesInMonth(viewYear, viewMonth);
    const startOffset = getMonthStartOffset(viewYear, viewMonth);

    const canGoPrev = !(viewYear === today.getFullYear() && viewMonth === today.getMonth());
    const maxDate = new Date(today);
    maxDate.setFullYear(maxDate.getFullYear() + 1);
    const canGoNext = new Date(viewYear, viewMonth + 1, 1) <= maxDate;

    const handlePrev = () => {
        if (!canGoPrev) return;
        if (viewMonth === 0) {
            setViewMonth(11);
            setViewYear(y => y - 1);
        } else {
            setViewMonth(m => m - 1);
        }
    };

    const handleNext = () => {
        if (!canGoNext) return;
        if (viewMonth === 11) {
            setViewMonth(0);
            setViewYear(y => y + 1);
        } else {
            setViewMonth(m => m + 1);
        }
    };

    // Build grid cells: leading empty cells + date cells
    const cells: (string | null)[] = [
        ...Array(startOffset).fill(null),
        ...dates,
    ];

    return (
        <View style={calStyles.container}>
            {/* Month navigation */}
            <View style={calStyles.header}>
                <AnimatedPressable onPress={handlePrev} scaleValue={0.85} style={calStyles.navBtn}>
                    <View style={[calStyles.navBtnInner, !canGoPrev && calStyles.navBtnDisabled]}>
                        <ChevronLeft size={18} color={canGoPrev ? Colors.text : Colors.textTertiary} />
                    </View>
                </AnimatedPressable>
                <Text style={calStyles.monthLabel}>
                    {MONTH_NAMES[viewMonth]} {viewYear}
                </Text>
                <AnimatedPressable onPress={handleNext} scaleValue={0.85} style={calStyles.navBtn}>
                    <View style={[calStyles.navBtnInner, !canGoNext && calStyles.navBtnDisabled]}>
                        <ChevronRight size={18} color={canGoNext ? Colors.text : Colors.textTertiary} />
                    </View>
                </AnimatedPressable>
            </View>

            {/* Weekday headers */}
            <View style={calStyles.weekRow}>
                {WEEKDAY_LABELS.map(d => (
                    <Text key={d} style={calStyles.weekLabel}>{d}</Text>
                ))}
            </View>

            {/* Date grid */}
            {isLoading ? (
                <View style={calStyles.loadingRow}>
                    <Text style={calStyles.loadingText}>Loading availability...</Text>
                </View>
            ) : (
                <View style={calStyles.grid}>
                    {cells.map((cell, idx) => {
                        if (!cell) {
                            return <View key={`empty-${idx}`} style={calStyles.cell} />;
                        }
                        const isPast = cell < todayISO;
                        const isUnavailable = unavailableSet.has(cell);
                        const isToday = cell === todayISO;

                        return (
                            <View
                                key={cell}
                                style={[
                                    calStyles.cell,
                                    isUnavailable && calStyles.cellUnavailable,
                                    isToday && calStyles.cellToday,
                                    isPast && calStyles.cellPast,
                                ]}
                            >
                                <Text
                                    style={[
                                        calStyles.cellText,
                                        isUnavailable && calStyles.cellTextUnavailable,
                                        isToday && calStyles.cellTextToday,
                                        isPast && calStyles.cellTextPast,
                                    ]}
                                >
                                    {parseInt(cell.slice(8), 10)}
                                </Text>
                            </View>
                        );
                    })}
                </View>
            )}

            {/* Legend */}
            <View style={calStyles.legend}>
                <View style={calStyles.legendItem}>
                    <View style={[calStyles.legendDot, { backgroundColor: Colors.successLight }]} />
                    <Text style={calStyles.legendText}>Available</Text>
                </View>
                <View style={calStyles.legendItem}>
                    <View style={[calStyles.legendDot, { backgroundColor: Colors.errorLight }]} />
                    <Text style={calStyles.legendText}>Unavailable</Text>
                </View>
                <View style={calStyles.legendItem}>
                    <View style={[calStyles.legendDot, { backgroundColor: Colors.primaryFaded2, borderWidth: 1.5, borderColor: Colors.primary }]} />
                    <Text style={calStyles.legendText}>Today</Text>
                </View>
            </View>
        </View>
    );
}

const calStyles = StyleSheet.create({
    container: {
        backgroundColor: Colors.surface,
        borderRadius: Radius.xl,
        padding: Spacing.lg,
        ...Shadow.sm,
        borderWidth: 1,
        borderColor: Colors.borderLight,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: Spacing.md,
    },
    navBtn: {
        alignSelf: 'flex-start',
    },
    navBtnInner: {
        width: 36,
        height: 36,
        borderRadius: 18,
        backgroundColor: Colors.cream,
        justifyContent: 'center',
        alignItems: 'center',
    },
    navBtnDisabled: {
        opacity: 0.35,
    },
    monthLabel: {
        fontSize: FontSize.md,
        fontWeight: FontWeight.bold,
        color: Colors.text,
    },
    weekRow: {
        flexDirection: 'row',
        marginBottom: Spacing.xs,
    },
    weekLabel: {
        flex: 1,
        textAlign: 'center',
        fontSize: FontSize.xs,
        fontWeight: FontWeight.semibold,
        color: Colors.textTertiary,
        textTransform: 'uppercase',
    },
    grid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    cell: {
        width: `${100 / 7}%`,
        aspectRatio: 1,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: Radius.sm,
        marginVertical: 1,
    },
    cellUnavailable: {
        backgroundColor: Colors.errorLight,
    },
    cellToday: {
        backgroundColor: Colors.primaryFaded2,
        borderWidth: 1.5,
        borderColor: Colors.primary,
    },
    cellPast: {
        opacity: 0.35,
    },
    cellText: {
        fontSize: FontSize.sm,
        color: Colors.text,
        fontWeight: FontWeight.medium,
    },
    cellTextUnavailable: {
        color: Colors.error,
        fontWeight: FontWeight.semibold,
    },
    cellTextToday: {
        color: Colors.primary,
        fontWeight: FontWeight.bold,
    },
    cellTextPast: {
        color: Colors.textTertiary,
    },
    loadingRow: {
        paddingVertical: Spacing.xl,
        alignItems: 'center',
    },
    loadingText: {
        fontSize: FontSize.sm,
        color: Colors.textTertiary,
    },
    legend: {
        flexDirection: 'row',
        justifyContent: 'center',
        gap: Spacing.xl,
        marginTop: Spacing.md,
        paddingTop: Spacing.md,
        borderTopWidth: 1,
        borderTopColor: Colors.borderLight,
    },
    legendItem: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xs,
    },
    legendDot: {
        width: 12,
        height: 12,
        borderRadius: 6,
    },
    legendText: {
        fontSize: FontSize.xs,
        color: Colors.textSecondary,
    },
});

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function ServiceDetailScreen() {
    const { id } = useLocalSearchParams<{ id: string }>();
    const router = useRouter();

    const [listing, setListing] = useState<ListingWithVendor | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isError, setIsError] = useState(false);
    const [unavailableDates, setUnavailableDates] = useState<string[]>([]);
    const [calendarLoading, setCalendarLoading] = useState(true);

    // ── Fetch listing + vendor ──────────────────────────────────────────────
    const fetchListing = useCallback(async () => {
        if (!id) return;
        setIsLoading(true);
        setIsError(false);
        try {
            const { data, error } = await supabase
                .from('service_listings')
                .select(`
                    *,
                    vendor:vendor_profiles (
                        id,
                        vendor_sector,
                        business_name,
                        sector_data,
                        profiles (
                            full_name,
                            email
                        )
                    )
                `)
                .eq('id', id)
                .eq('is_active', true)
                .single();

            if (error || !data) {
                setIsError(true);
                return;
            }
            setListing(data as unknown as ListingWithVendor);
        } catch {
            setIsError(true);
        } finally {
            setIsLoading(false);
        }
    }, [id]);

    // ── Fetch confirmed bookings for availability ───────────────────────────
    const fetchAvailability = useCallback(async () => {
        if (!id) return;
        setCalendarLoading(true);
        try {
            const { data: bookings, error } = await supabase
                .from('service_bookings')
                .select('event_date')
                .eq('listing_id', id)
                .neq('status', 'cancelled');

            if (error) {
                // On error, show no unavailable dates rather than blocking the UI
                setUnavailableDates([]);
                return;
            }

            const confirmedBookings = (bookings ?? []) as { event_date: string }[];
            const blockedRanges = listing
                ? extractBlockedDates(listing.vendor.sector_data)
                : [];

            const from = todayISO();
            const to = twelveMonthsFromTodayISO();
            const dates = getUnavailableDates(blockedRanges, confirmedBookings, from, to);
            setUnavailableDates(dates);
        } catch {
            setUnavailableDates([]);
        } finally {
            setCalendarLoading(false);
        }
    }, [id, listing]);

    useEffect(() => {
        fetchListing();
    }, [fetchListing]);

    useEffect(() => {
        if (listing) {
            fetchAvailability();
        }
    }, [listing, fetchAvailability]);

    // ── Loading / error states ──────────────────────────────────────────────
    if (isLoading) {
        return <ScreenLoader message="Loading service..." />;
    }

    if (isError || !listing) {
        return (
            <View style={styles.errorContainer}>
                <Stack.Screen options={{ headerShown: false }} />
                <ErrorState
                    title="Service not found"
                    subtitle="This listing may no longer be available."
                    onRetry={fetchListing}
                    retryLabel="Try Again"
                />
                <AnimatedPressable onPress={() => router.back()}>
                    <Text style={styles.errorLink}>Go back</Text>
                </AnimatedPressable>
            </View>
        );
    }

    // ── Derived data ────────────────────────────────────────────────────────
    const sectorConfig = getSectorConfig(listing.sector);
    const vendorName =
        listing.vendor.business_name ||
        listing.vendor.profiles?.full_name ||
        listing.vendor.profiles?.email ||
        'Unknown Vendor';
    const blockedRanges = extractBlockedDates(listing.vendor.sector_data);
    const packages = listing.packages as PhotographerPackage[] | null;
    const hasPackages = Array.isArray(packages) && packages.length > 0;

    // Extract city from sector_data
    const sectorData = listing.vendor.sector_data as Record<string, unknown> | null;
    const city = (sectorData?.city as string) ?? '';

    return (
        <View style={styles.screen}>
            <Stack.Screen options={{ headerShown: false }} />

            <ScrollView
                showsVerticalScrollIndicator={false}
                contentContainerStyle={styles.scrollContent}
            >
                {/* Photo Carousel */}
                <PhotoCarousel
                    photos={listing.photos}
                    onBack={() => router.back()}
                    listingId={listing.id}
                />

                {/* Content */}
                <View style={styles.contentContainer}>

                    {/* Header: sector badge + title */}
                    <View style={styles.headerSection}>
                        <View style={styles.badgeRow}>
                            <View
                                style={[
                                    styles.sectorBadge,
                                    { backgroundColor: sectorConfig.badgeColor + '22' },
                                ]}
                            >
                                <Text
                                    style={[
                                        styles.sectorBadgeText,
                                        { color: sectorConfig.badgeColor },
                                    ]}
                                >
                                    {sectorConfig.displayName}
                                </Text>
                            </View>
                        </View>

                        <Text style={styles.title}>{listing.title}</Text>

                        {/* Vendor name */}
                        <Text style={styles.vendorName}>{vendorName}</Text>

                        {/* City */}
                        {city ? (
                            <View style={styles.locationRow}>
                                <MapPin size={14} color={Colors.textTertiary} />
                                <Text style={styles.locationText}>{city}</Text>
                            </View>
                        ) : null}

                        {/* Rating */}
                        {listing.rating != null && (
                            <View style={styles.ratingRow}>
                                <Text style={styles.ratingValue}>
                                    ★ {listing.rating.toFixed(1)}
                                </Text>
                                <Text style={styles.ratingCount}>
                                    ({listing.total_reviews} {listing.total_reviews === 1 ? 'review' : 'reviews'})
                                </Text>
                            </View>
                        )}
                    </View>

                    {/* Price */}
                    <View style={styles.priceCard}>
                        <View>
                            <Text style={styles.priceAmount}>
                                {formatCurrencyFull(listing.base_price)}
                            </Text>
                            <Text style={styles.priceUnit}>
                                {formatPriceUnit(listing.price_unit)}
                            </Text>
                        </View>
                        {listing.base_price === 0 && (
                            <View style={styles.quoteBadge}>
                                <Text style={styles.quoteBadgeText}>Quote on Request</Text>
                            </View>
                        )}
                    </View>

                    {/* Description */}
                    {listing.description ? (
                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>About this Service</Text>
                            <Text style={styles.description}>{listing.description}</Text>
                        </View>
                    ) : null}

                    {/* Tags */}
                    {listing.tags.length > 0 && (
                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>Tags</Text>
                            <View style={styles.tagsRow}>
                                {listing.tags.map((tag) => (
                                    <View key={tag} style={styles.tagChip}>
                                        <Tag size={11} color={Colors.primary} />
                                        <Text style={styles.tagText}>{tag}</Text>
                                    </View>
                                ))}
                            </View>
                        </View>
                    )}

                    {/* Packages */}
                    {hasPackages && (
                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>Packages</Text>
                            <View style={styles.packagesGrid}>
                                {(packages as PhotographerPackage[]).map((pkg, idx) => (
                                    <View key={idx} style={styles.packageCard}>
                                        <View style={styles.packageIconWrap}>
                                            <Package size={18} color={Colors.primary} />
                                        </View>
                                        <View style={styles.packageInfo}>
                                            <Text style={styles.packageName}>{pkg.name}</Text>
                                            <Text style={styles.packagePrice}>
                                                {formatCurrencyFull(pkg.price)}
                                            </Text>
                                        </View>
                                    </View>
                                ))}
                            </View>
                        </View>
                    )}

                    {/* Availability Calendar */}
                    <View style={styles.section}>
                        <View style={styles.sectionTitleRow}>
                            <CalendarDays size={18} color={Colors.primary} />
                            <Text style={styles.sectionTitle}>Availability</Text>
                        </View>
                        <AvailabilityCalendar
                            unavailableDates={unavailableDates}
                            isLoading={calendarLoading}
                        />
                    </View>

                    {/* Bottom spacer for the booking bar */}
                    <View style={{ height: 120 }} />
                </View>
            </ScrollView>

            {/* Book Now bar */}
            <View style={styles.bookingBar}>
                <View style={styles.bookingBarContent}>
                    <View>
                        <Text style={styles.bookingBarPrice}>
                            {formatCurrencyFull(listing.base_price)}
                        </Text>
                        <Text style={styles.bookingBarLabel}>
                            {formatPriceUnit(listing.price_unit)}
                        </Text>
                    </View>
                    <AnimatedPressable
                        onPress={async () => {
                            const redirectPath = `/service-booking/${listing.id}`;
                            const { data: { session } } = await supabase.auth.getSession();
                            router.push(
                                session ? redirectPath as any : `/customer-login?redirect=${encodeURIComponent(redirectPath)}` as any
                            );
                        }}
                        scaleValue={0.95}
                    >
                        <LinearGradient
                            colors={[Colors.primary, Colors.primaryDark]}
                            style={styles.bookButton}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 0 }}
                        >
                            <Text style={styles.bookButtonText}>Book Now</Text>
                        </LinearGradient>
                    </AnimatedPressable>
                </View>
            </View>
        </View>
    );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        backgroundColor: Colors.background,
    },
    scrollContent: {
        flexGrow: 1,
    },
    errorContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Colors.background,
        gap: Spacing.md,
    },
    errorLink: {
        fontSize: FontSize.md,
        color: Colors.primary,
        fontWeight: FontWeight.semibold,
    },
    contentContainer: {
        backgroundColor: Colors.background,
        borderTopLeftRadius: Radius.xxl,
        borderTopRightRadius: Radius.xxl,
        marginTop: -24,
        paddingTop: Spacing.xxl,
    },
    headerSection: {
        paddingHorizontal: Spacing.xl,
        gap: Spacing.sm,
        marginBottom: Spacing.md,
    },
    badgeRow: {
        flexDirection: 'row',
        gap: Spacing.sm,
        flexWrap: 'wrap',
    },
    sectorBadge: {
        paddingHorizontal: Spacing.md,
        paddingVertical: Spacing.xxs,
        borderRadius: Radius.full,
        alignSelf: 'flex-start',
    },
    sectorBadgeText: {
        fontSize: FontSize.xs,
        fontWeight: FontWeight.bold,
        textTransform: 'uppercase',
        letterSpacing: 0.5,
    },
    title: {
        fontSize: FontSize.xxl,
        fontWeight: FontWeight.heavy,
        color: Colors.text,
        letterSpacing: -0.3,
        lineHeight: 30,
    },
    vendorName: {
        fontSize: FontSize.md,
        fontWeight: FontWeight.semibold,
        color: Colors.textSecondary,
    },
    locationRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xs,
    },
    locationText: {
        fontSize: FontSize.sm,
        color: Colors.textTertiary,
    },
    ratingRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xs,
    },
    ratingValue: {
        fontSize: FontSize.sm,
        fontWeight: FontWeight.bold,
        color: Colors.gold,
    },
    ratingCount: {
        fontSize: FontSize.sm,
        color: Colors.textTertiary,
    },
    priceCard: {
        marginHorizontal: Spacing.xl,
        marginBottom: Spacing.md,
        backgroundColor: Colors.surface,
        borderRadius: Radius.xl,
        padding: Spacing.lg,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        ...Shadow.sm,
        borderWidth: 1,
        borderColor: Colors.borderLight,
    },
    priceAmount: {
        fontSize: FontSize.xxl,
        fontWeight: FontWeight.heavy,
        color: Colors.text,
    },
    priceUnit: {
        fontSize: FontSize.sm,
        color: Colors.textTertiary,
        marginTop: 2,
    },
    quoteBadge: {
        backgroundColor: Colors.goldFaded,
        paddingHorizontal: Spacing.md,
        paddingVertical: Spacing.xs,
        borderRadius: Radius.full,
    },
    quoteBadgeText: {
        fontSize: FontSize.xs,
        fontWeight: FontWeight.semibold,
        color: Colors.goldDark,
    },
    section: {
        paddingHorizontal: Spacing.xl,
        paddingTop: Spacing.xl,
    },
    sectionTitleRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.sm,
        marginBottom: Spacing.sm,
    },
    sectionTitle: {
        fontSize: FontSize.lg,
        fontWeight: FontWeight.bold,
        color: Colors.text,
        marginBottom: Spacing.sm,
    },
    description: {
        fontSize: FontSize.md,
        color: Colors.textSecondary,
        lineHeight: 24,
    },
    tagsRow: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: Spacing.sm,
    },
    tagChip: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xs,
        backgroundColor: Colors.primaryFaded,
        paddingHorizontal: Spacing.md,
        paddingVertical: Spacing.xs,
        borderRadius: Radius.full,
    },
    tagText: {
        fontSize: FontSize.sm,
        color: Colors.primary,
        fontWeight: FontWeight.medium,
    },
    packagesGrid: {
        gap: Spacing.sm,
    },
    packageCard: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.md,
        backgroundColor: Colors.surface,
        borderRadius: Radius.lg,
        padding: Spacing.md,
        borderWidth: 1,
        borderColor: Colors.borderLight,
        ...Shadow.sm,
    },
    packageIconWrap: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: Colors.primaryFaded,
        justifyContent: 'center',
        alignItems: 'center',
    },
    packageInfo: {
        flex: 1,
    },
    packageName: {
        fontSize: FontSize.md,
        fontWeight: FontWeight.semibold,
        color: Colors.text,
    },
    packagePrice: {
        fontSize: FontSize.sm,
        color: Colors.primary,
        fontWeight: FontWeight.bold,
        marginTop: 2,
    },
    bookingBar: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        backgroundColor: Colors.surface,
        borderTopWidth: 1,
        borderTopColor: Colors.borderLight,
        paddingBottom: Platform.OS === 'ios' ? 34 : Spacing.lg,
        paddingTop: Spacing.md,
        paddingHorizontal: Spacing.xl,
        ...Shadow.lg,
    },
    bookingBarContent: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    bookingBarPrice: {
        fontSize: FontSize.xl,
        fontWeight: FontWeight.bold,
        color: Colors.text,
    },
    bookingBarLabel: {
        fontSize: FontSize.xs,
        color: Colors.textTertiary,
    },
    bookButton: {
        paddingHorizontal: Spacing.xxl,
        paddingVertical: Spacing.md,
        borderRadius: Radius.lg,
    },
    bookButtonText: {
        color: '#FFFFFF',
        fontSize: FontSize.md,
        fontWeight: FontWeight.bold,
    },
});