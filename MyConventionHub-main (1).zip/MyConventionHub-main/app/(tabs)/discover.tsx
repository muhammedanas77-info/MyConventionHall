import React, { useState, useMemo, useCallback, useRef } from 'react';
import {
    View, Text, StyleSheet, TextInput, ScrollView, FlatList,
    RefreshControl, Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
    Search, SlidersHorizontal, MapPin, Map,
    Flower2, Music, Camera, UtensilsCrossed, Sparkles, Palette,
    Shirt, Car,
} from 'lucide-react-native';
import type { LucideIcon } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { AREAS } from '@/mocks/halls';
import { useApp } from '@/providers/AppProvider';
import { useHalls } from '@/hooks/queries/useHalls';
import HallCard from '@/components/features/halls/HallCard';
import FeaturedHallCard from '@/components/features/halls/FeaturedHallCard';
import AreaChips from '@/components/features/halls/AreaChips';
import FilterModal, { type FilterState } from '@/components/features/halls/FilterModal';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import ErrorState from '@/components/ui/ErrorState';
import { SECTOR_LIST, SECTOR_CONFIGS } from '@/constants/sectors';
import type { Hall, VendorSector } from '@/types';

// ─── Icon map for sector tiles ────────────────────────────────────────────────
const SECTOR_ICON_MAP: Record<string, LucideIcon> = {
    Flower2, Music, Camera, UtensilsCrossed, Sparkles, Palette,
};

// ─── Curated tiles shown in the Event Services row ───────────────────────────
// venue is excluded (customer is already browsing venues on this screen).
// 'other' is replaced with Bridal Wear and Luxury Transport tiles.
interface ServiceTile {
    sector: VendorSector;
    displayName: string;
    iconName: string;
    Icon: LucideIcon;
    color: string;
}

const EVENT_SERVICE_TILES: ServiceTile[] = [
    { sector: 'florist',      displayName: 'Florist',      iconName: 'Flower2',        Icon: Flower2,        color: '#EC4899' },
    { sector: 'musician',     displayName: 'Musician',     iconName: 'Music',           Icon: Music,          color: '#F59E0B' },
    { sector: 'photographer', displayName: 'Photographer', iconName: 'Camera',          Icon: Camera,         color: '#0EA5E9' },
    { sector: 'caterer',      displayName: 'Caterer',      iconName: 'UtensilsCrossed', Icon: UtensilsCrossed,color: '#10B981' },
    { sector: 'decorator',    displayName: 'Decorator',    iconName: 'Sparkles',        Icon: Sparkles,       color: '#8B5CF6' },
    { sector: 'artist',       displayName: 'Artist',       iconName: 'Palette',         Icon: Palette,        color: '#F97316' },
    { sector: 'other',        displayName: 'Bridal Wear',  iconName: 'Shirt',           Icon: Shirt,          color: '#DB2777' },
    { sector: 'other',        displayName: 'Luxury Cars',  iconName: 'Car',             Icon: Car,            color: '#1D4ED8' },
];

export default function HomeScreen() {
    const router = useRouter();
    const { toggleSaveHall, isHallSaved, userName, userRole } = useApp();
    const [search, setSearch] = useState('');
    const [selectedArea, setSelectedArea] = useState('All');
    const [filterVisible, setFilterVisible] = useState(false);
    const [activeFilters, setActiveFilters] = useState<FilterState>({
        maxPrice: null,
        capacity: null,
        amenities: [],
    });

    const searchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const [debouncedSearch, setDebouncedSearch] = useState('');

    // React Query — caching, background refresh, error state all handled
    const { data: allHalls = [], isLoading: isFetching, isError, refetch } = useHalls();

    const handleSearchChange = useCallback((text: string) => {
        setSearch(text);
        if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
        searchDebounceRef.current = setTimeout(() => setDebouncedSearch(text), 300);
    }, []);

    const featuredHalls = useMemo(() => allHalls.filter((h) => h.is_featured).slice(0, 5), [allHalls]);

    const filteredHalls = useMemo(() => {
        let halls = allHalls;

        // Area Filter
        if (selectedArea !== 'All') halls = halls.filter((h) => h.area === selectedArea);

        // Search Filter
        if (debouncedSearch.trim()) {
            const q = debouncedSearch.toLowerCase();
            halls = halls.filter((h) =>
                h.name?.toLowerCase().includes(q) ||
                h.area?.toLowerCase().includes(q) ||
                h.description?.toLowerCase().includes(q) ||
                (h.amenities || []).some(a => a?.toLowerCase().includes(q))
            );
        }

        // Complex Filters
        if (activeFilters.maxPrice) {
            halls = halls.filter(h => h.price_per_day <= activeFilters.maxPrice!);
        }

        if (activeFilters.capacity) {
            const minCap = parseInt(activeFilters.capacity);
            halls = halls.filter(h => h.capacity_max >= minCap);
        }

        if (activeFilters.amenities.length > 0) {
            halls = halls.filter(h =>
                activeFilters.amenities.every(a => h.amenities.includes(a))
            );
        }

        return halls;
    }, [allHalls, selectedArea, debouncedSearch, activeFilters]);

    const activeFilterCount = useMemo(() => {
        let count = 0;
        if (activeFilters.maxPrice) count++;
        if (activeFilters.capacity) count++;
        if (activeFilters.amenities.length > 0) count += activeFilters.amenities.length;
        return count;
    }, [activeFilters]);

    const handleRefresh = useCallback(() => { refetch(); }, [refetch]);

    const navigateToHall = useCallback((hallId: string) => {
        router.push(`/hall/${hallId}` as any);
    }, [router]);

    const handleSectorTap = useCallback((sector: VendorSector) => {
        if (sector === 'venue') {
            // Stay on current screen — venue browsing is already shown below
            setSelectedArea('All');
        } else {
            router.push(`/service-listing-browse?sector=${sector}` as any);
        }
    }, [router]);

    const greetingText = useMemo(() => {
        if (userRole === 'guest' || !userName) return 'ConventionHub';
        const hour = new Date().getHours();
        const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
        return `${greeting}, ${userName.split(' ')[0]}`;
    }, [userName, userRole]);

    const renderHallCard = useCallback(({ item, index }: { item: Hall; index: number }) => (
        <HallCard hall={item} onPress={() => navigateToHall(item.id)} onSave={() => toggleSaveHall(item.id)} isSaved={isHallSaved(item.id)} index={index} />
    ), [navigateToHall, toggleSaveHall, isHallSaved]);

    const keyExtractor = useCallback((item: Hall) => item.id, []);

    const ListHeaderComponent = useMemo(() => (
        <>
            <LinearGradient colors={[Colors.primary, Colors.primaryLight]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.heroGradient}>
                <SafeAreaView edges={['top']} style={styles.heroSafe}>
                    <View style={styles.heroContent}>
                        <View style={styles.heroTopRow}>
                            <View style={styles.heroGreetingContainer}>
                                <Text style={styles.heroGreeting} numberOfLines={1}>{greetingText}</Text>
                                <Text style={styles.heroSubtitle}>Find your dream wedding venue</Text>
                            </View>
                            <View style={styles.heroCityBadge}>
                                <MapPin size={13} color={Colors.gold} />
                                <Text style={styles.heroCityText}>Bangalore</Text>
                            </View>
                        </View>
                        <View style={styles.searchContainer}>
                            <View style={styles.searchInner}>
                                <Search size={18} color={Colors.textTertiary} />
                                <TextInput style={styles.searchInput} placeholder="Search halls, areas..." placeholderTextColor={Colors.textTertiary} value={search} onChangeText={handleSearchChange} testID="search-input" />
                            </View>
                            <View style={styles.headerActions}>
                                <AnimatedPressable onPress={() => router.push('/map')} scaleValue={0.9}>
                                    <View style={styles.mapButton}>
                                        <Map size={16} color={Colors.primaryDark} />
                                    </View>
                                </AnimatedPressable>

                                <AnimatedPressable onPress={() => setFilterVisible(true)} scaleValue={0.9}>
                                    <View style={[styles.filterButton, activeFilterCount > 0 && styles.filterButtonActive]}>
                                        <SlidersHorizontal size={16} color={activeFilterCount > 0 ? '#FFFFFF' : Colors.primaryDark} />
                                        {activeFilterCount > 0 && (
                                            <View style={styles.filterBadge}>
                                                <Text style={styles.filterBadgeText}>{activeFilterCount}</Text>
                                            </View>
                                        )}
                                    </View>
                                </AnimatedPressable>
                            </View>
                        </View>
                    </View>
                </SafeAreaView>
            </LinearGradient>

            {userRole === 'guest' && (
                <View style={styles.guestBanner}><Text style={styles.guestBannerText}>Login for full access to bookings & saved venues</Text></View>
            )}

            {/* ── Event Services sector tiles ── */}
            <View style={styles.sectorSection}>
                <View style={styles.sectorSectionHeader}>
                    <Text style={styles.sectorSectionTitle}>Event Services</Text>
                    <Text style={styles.sectorSectionSubtitle}>Browse by category</Text>
                </View>
                <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.sectorScroll}
                >
                    {EVENT_SERVICE_TILES.map((tile, index) => {
                        const TileIcon = tile.Icon;
                        return (
                            <AnimatedPressable
                                key={`${tile.sector}-${index}`}
                                onPress={() => handleSectorTap(tile.sector)}
                                scaleValue={0.93}
                            >
                                <View style={[styles.sectorTile, { backgroundColor: tile.color + '15' }]}>
                                    <View style={[styles.sectorIconContainer, { backgroundColor: tile.color + '25' }]}>
                                        <TileIcon size={24} color={tile.color} strokeWidth={1.8} />
                                    </View>
                                    <Text style={[styles.sectorTileLabel, { color: tile.color }]} numberOfLines={1}>
                                        {tile.displayName}
                                    </Text>
                                </View>
                            </AnimatedPressable>
                        );
                    })}
                </ScrollView>
            </View>

            <AreaChips areas={AREAS} selectedArea={selectedArea} onSelect={setSelectedArea} />

            {!debouncedSearch && selectedArea === 'All' && activeFilterCount === 0 && featuredHalls.length > 0 && (
                <View style={styles.featuredSection}>
                    <View style={styles.sectionHeader}>
                        <Text style={styles.sectionTitle}>Top Picks</Text>
                        <Text style={styles.sectionSubtitle}>Handpicked luxury venues</Text>
                    </View>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.featuredScroll} decelerationRate="fast">
                        {featuredHalls.map((hall, index) => (
                            <FeaturedHallCard key={hall.id} hall={hall} onPress={() => navigateToHall(hall.id)} index={index} />
                        ))}
                    </ScrollView>
                </View>
            )}

            <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>{selectedArea === 'All' ? 'All Venues' : selectedArea}</Text>
                <Text style={styles.sectionSubtitle}>
                    {isFetching ? 'Loading venues...' : `${filteredHalls.length} venues found`}
                </Text>
            </View>
        </>
    ), [search, selectedArea, debouncedSearch, featuredHalls, filteredHalls.length, handleSearchChange, navigateToHall, greetingText, userRole, activeFilterCount, handleSectorTap]);

    return (
        <View style={styles.screen}>
            {isError && (
                <ErrorState
                    title="Could not load venues"
                    subtitle="Check your connection and try again."
                    onRetry={refetch}
                />
            )}
            {!isError && (
            <FlatList
                data={filteredHalls}
                renderItem={renderHallCard}
                keyExtractor={keyExtractor}
                ListHeaderComponent={ListHeaderComponent}
                contentContainerStyle={styles.listContent}
                showsVerticalScrollIndicator={false}
                refreshControl={<RefreshControl refreshing={isFetching} onRefresh={handleRefresh} tintColor={Colors.primary} colors={[Colors.primary]} />}
                ListEmptyComponent={
                    <View style={styles.emptyContainer}>
                        {!isFetching && (
                            <>
                                <Text style={styles.emptyTitle}>No venues found</Text>
                                <Text style={styles.emptySubtitle}>Try changing your search or area filter</Text>
                            </>
                        )}
                    </View>
                }
            />
            )}
            <FilterModal
                visible={filterVisible}
                onClose={() => setFilterVisible(false)}
                onApply={setActiveFilters}
                initialFilters={activeFilters}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    heroGradient: { paddingBottom: Spacing.xl },
    heroSafe: { paddingHorizontal: 0 },
    heroContent: { paddingHorizontal: Spacing.xl, paddingTop: Spacing.md, gap: Spacing.lg },
    heroTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: Spacing.md },
    heroGreetingContainer: { flex: 1 },
    heroGreeting: { fontSize: FontSize.xxxl, fontWeight: FontWeight.heavy, color: '#FFFFFF', letterSpacing: -0.5 },
    heroSubtitle: { fontSize: FontSize.sm, color: 'rgba(255,255,255,0.75)', marginTop: Spacing.xxs },
    heroCityBadge: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, backgroundColor: 'rgba(255,255,255,0.15)', paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: Radius.full, marginTop: Spacing.xs, flexShrink: 0 },
    heroCityText: { color: '#FFFFFF', fontSize: FontSize.xs, fontWeight: FontWeight.semibold },
    searchContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.surface, borderRadius: Radius.xl, paddingHorizontal: Spacing.md, paddingVertical: Platform.OS === 'web' ? Spacing.sm : Spacing.xs, gap: Spacing.sm, ...Shadow.md, justifyContent: 'space-between' },
    searchInner: { flexDirection: 'row', alignItems: 'center', flex: 1, gap: Spacing.sm, paddingHorizontal: Spacing.xs },
    searchInput: { flex: 1, fontSize: FontSize.md, color: Colors.text, paddingVertical: Spacing.sm },
    headerActions: { flexDirection: 'row', gap: Spacing.xs, alignItems: 'center' },
    mapButton: { width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.cream, justifyContent: 'center', alignItems: 'center' },
    filterButton: { width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.cream, justifyContent: 'center', alignItems: 'center' },
    filterButtonActive: { backgroundColor: Colors.primaryDark },
    filterBadge: { position: 'absolute', top: -4, right: -4, backgroundColor: Colors.gold, width: 16, height: 16, borderRadius: 8, justifyContent: 'center', alignItems: 'center', borderWidth: 1.5, borderColor: '#FFFFFF' },
    filterBadgeText: { color: '#FFFFFF', fontSize: 8, fontWeight: FontWeight.bold },
    guestBanner: { backgroundColor: Colors.primaryFaded, paddingVertical: Spacing.sm, paddingHorizontal: Spacing.xl, borderBottomWidth: 1, borderBottomColor: Colors.borderLight },
    guestBannerText: { fontSize: FontSize.xs, color: Colors.primary, textAlign: 'center', fontWeight: FontWeight.medium },
    // ── Sector tiles ──────────────────────────────────────────────────────────
    sectorSection: { paddingTop: Spacing.lg, backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.borderLight },
    sectorSectionHeader: { paddingHorizontal: Spacing.xl, paddingBottom: Spacing.sm },
    sectorSectionTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
    sectorSectionSubtitle: { fontSize: FontSize.xs, color: Colors.textTertiary, marginTop: Spacing.xxs },
    sectorScroll: { paddingHorizontal: Spacing.xl, paddingBottom: Spacing.lg, gap: Spacing.sm },
    sectorTile: {
        width: 76,
        borderRadius: Radius.lg,
        paddingVertical: Spacing.md,
        paddingHorizontal: Spacing.xs,
        alignItems: 'center',
        gap: Spacing.sm,
        ...Shadow.sm,
    },
    sectorIconContainer: {
        width: 48,
        height: 48,
        borderRadius: 24,
        justifyContent: 'center',
        alignItems: 'center',
    },
    sectorIconText: {
        fontSize: FontSize.xs,
        fontWeight: FontWeight.semibold,
        textAlign: 'center',
    },
    sectorTileLabel: {
        fontSize: 10,
        fontWeight: FontWeight.semibold,
        textAlign: 'center',
        lineHeight: 13,
    },
    // ─────────────────────────────────────────────────────────────────────────
    featuredSection: { marginTop: Spacing.lg },
    sectionHeader: { paddingHorizontal: Spacing.xl, paddingTop: Spacing.lg, paddingBottom: Spacing.sm },
    sectionTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
    sectionSubtitle: { fontSize: FontSize.sm, color: Colors.textTertiary, marginTop: Spacing.xxs },
    featuredScroll: { paddingHorizontal: Spacing.xl, paddingVertical: Spacing.sm },
    listContent: { paddingBottom: Spacing.massive },
    emptyContainer: { padding: Spacing.massive, alignItems: 'center' },
    emptyTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.semibold, color: Colors.text },
    emptySubtitle: { fontSize: FontSize.sm, color: Colors.textTertiary, marginTop: Spacing.xs },
});
