import React, { useMemo, useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, Platform, SectionList } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { CalendarDays, Clock, MapPin, ChevronRight, Package } from 'lucide-react-native';
import { Image } from 'expo-image';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { useAuth } from '@/providers/AuthProvider';
import { useCustomerBookings } from '@/hooks/queries/useBookings';
import { supabase } from '@/utils/supabase';
import { formatCurrencyFull } from '@/utils/currency';
import { formatDateDisplay } from '@/utils/date';
import { SLOT_LABELS } from '@/constants/pricing';
import { getSectorConfig } from '@/constants/sectors';
import Badge from '@/components/ui/Badge';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import ErrorState from '@/components/ui/ErrorState';
import ScreenLoader from '@/components/ui/ScreenLoader';
import type { BookingStatus, ServiceBookingStatus, VendorSector } from '@/types';
import type { NormalizedBooking } from '@/utils/booking';

// ─── Status badge config ──────────────────────────────────────────────────────

const VENUE_STATUS_VARIANTS: Record<BookingStatus, { variant: 'success' | 'warning' | 'error' | 'neutral'; label: string }> = {
    confirmed: { variant: 'success', label: 'Confirmed' },
    pending:   { variant: 'warning', label: 'Pending' },
    cancelled: { variant: 'error',   label: 'Cancelled' },
    completed: { variant: 'neutral', label: 'Completed' },
};

const SERVICE_STATUS_VARIANTS: Record<ServiceBookingStatus, { variant: 'success' | 'warning' | 'error' | 'neutral'; label: string }> = {
    confirmed: { variant: 'success', label: 'Confirmed' },
    pending:   { variant: 'warning', label: 'Pending' },
    cancelled: { variant: 'error',   label: 'Cancelled' },
    completed: { variant: 'neutral', label: 'Completed' },
};

// ─── Venue booking card ───────────────────────────────────────────────────────

function VenueBookingCard({ booking }: { booking: NormalizedBooking }) {
    const router = useRouter();
    const statusInfo = VENUE_STATUS_VARIANTS[booking.status];
    return (
        <AnimatedPressable
            onPress={() => router.push(`/booking/detail?bookingId=${booking.id}` as any)}
            testID={`booking-card-${booking.id}`}
        >
            <View style={styles.card}>
                {booking.hall?.photos?.[0] && (
                    <Image source={{ uri: booking.hall.photos[0] }} style={styles.cardImage} contentFit="cover" transition={200} />
                )}
                <View style={styles.cardContent}>
                    <View style={styles.cardHeader}>
                        <Text style={styles.cardTitle} numberOfLines={1}>{booking.hall?.name ?? 'Venue'}</Text>
                        <Badge text={statusInfo.label} variant={statusInfo.variant} size="sm" />
                    </View>
                    <View style={styles.cardDetail}>
                        <CalendarDays size={13} color={Colors.textTertiary} />
                        <Text style={styles.cardDetailText}>{formatDateDisplay(booking.date)}</Text>
                    </View>
                    <View style={styles.cardDetail}>
                        <Clock size={13} color={Colors.textTertiary} />
                        <Text style={styles.cardDetailText}>{SLOT_LABELS[booking.slot]}</Text>
                    </View>
                    {booking.hall?.area && (
                        <View style={styles.cardDetail}>
                            <MapPin size={13} color={Colors.textTertiary} />
                            <Text style={styles.cardDetailText}>{booking.hall.area}</Text>
                        </View>
                    )}
                    <View style={styles.cardFooter}>
                        <Text style={styles.cardPrice}>{formatCurrencyFull(booking.total_amount)}</Text>
                        <ChevronRight size={16} color={Colors.textTertiary} />
                    </View>
                </View>
            </View>
        </AnimatedPressable>
    );
}

// ─── Service booking card ─────────────────────────────────────────────────────

interface ServiceBookingRow {
    id: string;
    listing_id: string;
    sector: VendorSector;
    event_date: string;
    status: ServiceBookingStatus;
    total_amount: number;
    advance_amount: number;
    listing?: { title: string; photos: string[] };
    vendor?: { business_name: string | null };
}

function ServiceBookingCard({ booking }: { booking: ServiceBookingRow }) {
    const router = useRouter();
    const statusInfo = SERVICE_STATUS_VARIANTS[booking.status];
    const sectorConfig = getSectorConfig(booking.sector);
    const title = booking.listing?.title ?? 'Service';
    const vendorName = booking.vendor?.business_name ?? sectorConfig.displayName;
    const photo = booking.listing?.photos?.[0];

    return (
        <AnimatedPressable
            onPress={() => router.push(`/service/${booking.listing_id}` as any)}
            testID={`service-booking-card-${booking.id}`}
        >
            <View style={styles.card}>
                {photo ? (
                    <Image source={{ uri: photo }} style={styles.cardImage} contentFit="cover" transition={200} />
                ) : (
                    <View style={[styles.cardImagePlaceholder, { backgroundColor: sectorConfig.badgeColor + '22' }]}>
                        <Package size={28} color={sectorConfig.badgeColor} />
                    </View>
                )}
                <View style={styles.cardContent}>
                    <View style={styles.cardHeader}>
                        <Text style={styles.cardTitle} numberOfLines={1}>{title}</Text>
                        <Badge text={statusInfo.label} variant={statusInfo.variant} size="sm" />
                    </View>
                    <View style={styles.sectorBadge}>
                        <View style={[styles.sectorDot, { backgroundColor: sectorConfig.badgeColor }]} />
                        <Text style={[styles.sectorLabel, { color: sectorConfig.badgeColor }]}>{sectorConfig.displayName}</Text>
                    </View>
                    <View style={styles.cardDetail}>
                        <CalendarDays size={13} color={Colors.textTertiary} />
                        <Text style={styles.cardDetailText}>{formatDateDisplay(booking.event_date)}</Text>
                    </View>
                    <Text style={styles.vendorName} numberOfLines={1}>{vendorName}</Text>
                    <View style={styles.cardFooter}>
                        <Text style={styles.cardPrice}>{formatCurrencyFull(booking.total_amount)}</Text>
                        <ChevronRight size={16} color={Colors.textTertiary} />
                    </View>
                </View>
            </View>
        </AnimatedPressable>
    );
}

// ─── Main screen ──────────────────────────────────────────────────────────────

export default function BookingsScreen() {
    const { user } = useAuth();
    const router = useRouter();
    const [activeTab, setActiveTab] = useState<'upcoming' | 'past'>('upcoming');

    // Legacy venue bookings
    const { data: allVenueBookings = [], isLoading: venueLoading, isError: venueError, refetch: refetchVenue, isFetching: venueFetching } = useCustomerBookings(user?.id);

    // Service bookings
    const [serviceBookings, setServiceBookings] = useState<ServiceBookingRow[]>([]);
    const [serviceLoading, setServiceLoading] = useState(false);
    const [serviceError, setServiceError] = useState(false);

    const fetchServiceBookings = useCallback(async () => {
        if (!user?.id) return;
        setServiceLoading(true);
        setServiceError(false);
        try {
            const { data, error } = await supabase
                .from('service_bookings')
                .select(`
                    id, listing_id, sector, event_date, status,
                    total_amount, advance_amount,
                    listing:service_listings(title, photos),
                    vendor:vendor_profiles(business_name)
                `)
                .eq('customer_id', user.id)
                .order('event_date', { ascending: true });

            if (error) throw error;
            setServiceBookings((data ?? []) as unknown as ServiceBookingRow[]);
        } catch {
            setServiceError(true);
        } finally {
            setServiceLoading(false);
        }
    }, [user?.id]);

    useEffect(() => {
        fetchServiceBookings();
    }, [fetchServiceBookings]);

    const handleRefresh = useCallback(() => {
        refetchVenue();
        fetchServiceBookings();
    }, [refetchVenue, fetchServiceBookings]);

    // Split venue bookings
    const upcomingVenue = useMemo(
        () => allVenueBookings.filter(b => b.status === 'confirmed' || b.status === 'pending'),
        [allVenueBookings]
    );
    const pastVenue = useMemo(
        () => allVenueBookings.filter(b => b.status === 'completed' || b.status === 'cancelled'),
        [allVenueBookings]
    );

    // Split service bookings
    const upcomingService = useMemo(
        () => serviceBookings.filter(b => b.status === 'confirmed' || b.status === 'pending'),
        [serviceBookings]
    );
    const pastService = useMemo(
        () => serviceBookings.filter(b => b.status === 'completed' || b.status === 'cancelled'),
        [serviceBookings]
    );

    const isLoading = venueLoading || serviceLoading;
    const isError = venueError && serviceError;
    const isFetching = venueFetching || serviceLoading;

    const upcomingTotal = upcomingVenue.length + upcomingService.length;
    const pastTotal = pastVenue.length + pastService.length;

    // Build sections for the active tab
    const sections = useMemo(() => {
        const venueItems = activeTab === 'upcoming' ? upcomingVenue : pastVenue;
        const serviceItems = activeTab === 'upcoming' ? upcomingService : pastService;
        const result = [];
        if (venueItems.length > 0) {
            result.push({ title: 'Venues', data: venueItems, type: 'venue' as const });
        }
        if (serviceItems.length > 0) {
            result.push({ title: 'Services', data: serviceItems, type: 'service' as const });
        }
        return result;
    }, [activeTab, upcomingVenue, pastVenue, upcomingService, pastService]);

    const renderItem = useCallback(({ item, section }: { item: any; section: any }) => {
        if (section.type === 'venue') {
            return <VenueBookingCard booking={item} />;
        }
        return <ServiceBookingCard booking={item} />;
    }, []);

    const renderSectionHeader = useCallback(({ section }: { section: any }) => (
        <View style={styles.sectionHeader}>
            <Text style={styles.sectionHeaderText}>{section.title}</Text>
        </View>
    ), []);

    return (
        <View style={styles.screen}>
            <SafeAreaView edges={['top']} style={styles.header}>
                <Text style={styles.title}>My Bookings</Text>
                <View style={styles.tabBar}>
                    <AnimatedPressable onPress={() => setActiveTab('upcoming')} scaleValue={0.95}>
                        <View style={[styles.tab, activeTab === 'upcoming' && styles.tabActive]}>
                            <Text style={[styles.tabText, activeTab === 'upcoming' && styles.tabTextActive]}>
                                Upcoming ({upcomingTotal})
                            </Text>
                        </View>
                    </AnimatedPressable>
                    <AnimatedPressable onPress={() => setActiveTab('past')} scaleValue={0.95}>
                        <View style={[styles.tab, activeTab === 'past' && styles.tabActive]}>
                            <Text style={[styles.tabText, activeTab === 'past' && styles.tabTextActive]}>
                                Past ({pastTotal})
                            </Text>
                        </View>
                    </AnimatedPressable>
                </View>
            </SafeAreaView>

            {isLoading && <ScreenLoader message="Loading bookings..." />}
            {isError && <ErrorState title="Could not load bookings" onRetry={handleRefresh} />}

            {!isLoading && !isError && (
                <SectionList
                    sections={sections}
                    keyExtractor={(item) => item.id}
                    renderItem={renderItem}
                    renderSectionHeader={renderSectionHeader}
                    contentContainerStyle={styles.listContent}
                    showsVerticalScrollIndicator={false}
                    refreshing={isFetching}
                    onRefresh={handleRefresh}
                    stickySectionHeadersEnabled={false}
                    ListEmptyComponent={
                        <View style={styles.emptyContainer}>
                            <View style={styles.emptyIcon}>
                                <CalendarDays size={40} color={Colors.textTertiary} />
                            </View>
                            <Text style={styles.emptyTitle}>No bookings yet</Text>
                            <Text style={styles.emptySubtitle}>
                                {activeTab === 'upcoming'
                                    ? 'Start exploring venues and services to book your perfect event'
                                    : 'Your completed bookings will appear here'}
                            </Text>
                        </View>
                    }
                />
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    header: {
        paddingHorizontal: Spacing.xl,
        paddingBottom: Spacing.md,
        backgroundColor: Colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: Colors.borderLight,
    },
    title: {
        fontSize: FontSize.xxl,
        fontWeight: FontWeight.heavy,
        color: Colors.text,
        marginBottom: Spacing.lg,
        paddingTop: Spacing.sm,
    },
    tabBar: { flexDirection: 'row', gap: Spacing.sm },
    tab: {
        paddingHorizontal: Spacing.lg,
        paddingVertical: Spacing.sm,
        borderRadius: Radius.full,
        backgroundColor: Colors.cream,
    },
    tabActive: { backgroundColor: Colors.primary },
    tabText: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textSecondary },
    tabTextActive: { color: '#FFFFFF' },
    sectionHeader: {
        paddingHorizontal: Spacing.lg,
        paddingTop: Spacing.lg,
        paddingBottom: Spacing.sm,
    },
    sectionHeaderText: {
        fontSize: FontSize.sm,
        fontWeight: FontWeight.bold,
        color: Colors.textTertiary,
        textTransform: 'uppercase',
        letterSpacing: 1,
    },
    listContent: { paddingHorizontal: Spacing.lg, paddingBottom: Spacing.massive },
    card: {
        flexDirection: 'row',
        backgroundColor: Colors.surface,
        borderRadius: Radius.xl,
        overflow: 'hidden',
        marginBottom: Spacing.md,
        ...Shadow.md,
    },
    cardImage: { width: 100, height: 140 },
    cardImagePlaceholder: {
        width: 100,
        height: 140,
        justifyContent: 'center',
        alignItems: 'center',
    },
    cardContent: { flex: 1, padding: Spacing.md, gap: Spacing.xs },
    cardHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: Spacing.xxs,
    },
    cardTitle: {
        fontSize: FontSize.md,
        fontWeight: FontWeight.bold,
        color: Colors.text,
        flex: 1,
        marginRight: Spacing.sm,
    },
    sectorBadge: { flexDirection: 'row', alignItems: 'center', gap: 4 },
    sectorDot: { width: 7, height: 7, borderRadius: 4 },
    sectorLabel: { fontSize: 11, fontWeight: FontWeight.semibold },
    vendorName: { fontSize: FontSize.xs, color: Colors.textSecondary },
    cardDetail: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
    cardDetailText: { fontSize: FontSize.xs, color: Colors.textSecondary },
    cardFooter: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: Spacing.xs,
    },
    cardPrice: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.primary },
    emptyContainer: {
        alignItems: 'center',
        paddingTop: Spacing.massive * 2,
        paddingHorizontal: Spacing.xxl,
    },
    emptyIcon: {
        width: 80,
        height: 80,
        borderRadius: 40,
        backgroundColor: Colors.cream,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: Spacing.lg,
    },
    emptyTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: Spacing.sm },
    emptySubtitle: { fontSize: FontSize.sm, color: Colors.textTertiary, textAlign: 'center', lineHeight: 20 },
});
