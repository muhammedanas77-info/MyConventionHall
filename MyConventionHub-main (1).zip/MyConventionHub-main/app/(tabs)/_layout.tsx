import { Tabs } from "expo-router";
import { Home, CalendarDays, Heart, User } from "lucide-react-native";
import React from "react";
import { Platform } from "react-native";
import { Colors } from "@/constants/theme";

export default function TabLayout() {
    // No role guard here — any user (customer, owner, or guest) can browse
    // and book. Role-based routing is handled once in index.tsx on startup.

    return (
        <Tabs
            screenOptions={{
                tabBarActiveTintColor: Colors.primary,
                tabBarInactiveTintColor: Colors.textTertiary,
                tabBarStyle: {
                    backgroundColor: Colors.surface,
                    borderTopColor: Colors.borderLight,
                    borderTopWidth: 1,
                    ...(Platform.OS === 'web' ? { height: 60 } : {}),
                },
                tabBarLabelStyle: {
                    fontSize: 11,
                    fontWeight: '600',
                },
                headerShown: false,
            }}
        >
            <Tabs.Screen
                name="discover"
                options={{
                    title: "Discover",
                    tabBarIcon: ({ color, size }) => <Home size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="bookings"
                options={{
                    title: "Bookings",
                    tabBarIcon: ({ color, size }) => <CalendarDays size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="saved"
                options={{
                    title: "Saved",
                    tabBarIcon: ({ color, size }) => <Heart size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="profile"
                options={{
                    title: "Profile",
                    tabBarIcon: ({ color, size }) => <User size={size} color={color} />,
                }}
            />
        </Tabs>
    );
}
