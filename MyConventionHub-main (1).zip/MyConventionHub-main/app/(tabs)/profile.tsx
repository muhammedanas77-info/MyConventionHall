import React from 'react';
import { View, Text, StyleSheet, ScrollView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Image } from 'expo-image';
import { User, Heart, Bell, ChevronRight, LogOut, MapPin, Shield, HelpCircle, Edit3 } from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { useApp } from '@/providers/AppProvider';
import { useAuth } from '@/providers/AuthProvider';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

function MenuItem({ icon, label, onPress, destructive }: { icon: React.ReactNode; label: string; onPress: () => void; destructive?: boolean }) {
    return (
        <AnimatedPressable onPress={onPress} scaleValue={0.98}>
            <View style={styles.menuItem}>
                <View style={[styles.menuIconBox, destructive && styles.menuIconDestructive]}>{icon}</View>
                <Text style={[styles.menuLabel, destructive && styles.menuLabelDestructive]}>{label}</Text>
                <ChevronRight size={16} color={Colors.textTertiary} />
            </View>
        </AnimatedPressable>
    );
}

export default function ProfileScreen() {
    const { savedHallIds, bookings, logout } = useApp();
    const { profile, user } = useAuth();
    const router = useRouter();
    const displayName = profile?.full_name || user?.email?.split('@')[0] || 'Guest';

    const handleSignOut = async () => {
        const { supabase } = await import('@/utils/supabase');
        await supabase.auth.signOut();
        logout();
        router.replace('/role-select' as any);
    };

    return (
        <View style={styles.screen}>
            <ScrollView showsVerticalScrollIndicator={false}>
                <LinearGradient colors={[Colors.primary, Colors.primaryLight]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.headerGradient}>
                    <SafeAreaView edges={['top']}>
                        <View style={styles.profileHeader}>
                            <View style={styles.avatarContainer}>
                                {(profile as any)?.avatar_url ? (
                                    <Image
                                        source={{ uri: (profile as any).avatar_url }}
                                        style={styles.avatar}
                                        contentFit="cover"
                                    />
                                ) : (
                                    <LinearGradient colors={[Colors.gold, Colors.goldLight]} style={styles.avatar}>
                                        <User size={32} color={Colors.primaryDark} />
                                    </LinearGradient>
                                )}
                                <AnimatedPressable
                                    onPress={() => router.push('/profile-edit' as any)}
                                    scaleValue={0.85}
                                >
                                    <View style={styles.editBadge}>
                                        <Edit3 size={11} color={Colors.primary} />
                                    </View>
                                </AnimatedPressable>
                            </View>
                            <Text style={styles.profileName}>{displayName}</Text>
                            <View style={styles.locationBadge}>
                                <MapPin size={12} color="rgba(255,255,255,0.7)" />
                                <Text style={styles.locationText}>Bangalore</Text>
                            </View>
                            <View style={styles.statsRow}>
                                <View style={styles.statItem}><Text style={styles.statNumber}>{bookings.length}</Text><Text style={styles.statLabel}>Bookings</Text></View>
                                <View style={styles.statDivider} />
                                <View style={styles.statItem}><Text style={styles.statNumber}>{savedHallIds.length}</Text><Text style={styles.statLabel}>Saved</Text></View>
                                <View style={styles.statDivider} />
                                <View style={styles.statItem}><Text style={styles.statNumber}>4.8</Text><Text style={styles.statLabel}>Rating</Text></View>
                            </View>
                        </View>
                    </SafeAreaView>
                </LinearGradient>

                <View style={styles.menuSection}>
                    <Text style={styles.sectionLabel}>Account</Text>
                    <View style={styles.menuGroup}>
                        <MenuItem icon={<Edit3 size={18} color={Colors.primary} />} label="Edit Profile" onPress={() => router.push('/profile-edit' as any)} />
                        <MenuItem icon={<Heart size={18} color={Colors.primary} />} label="Saved Venues" onPress={() => router.push('/(tabs)/saved' as any)} />
                        <MenuItem icon={<Bell size={18} color={Colors.primary} />} label="Notifications" onPress={() => router.push('/notifications' as any)} />
                    </View>
                </View>

                <View style={styles.menuSection}>
                    <Text style={styles.sectionLabel}>Support</Text>
                    <View style={styles.menuGroup}>
                        <MenuItem icon={<HelpCircle size={18} color={Colors.primary} />} label="Help & FAQ" onPress={() => router.push('/help' as any)} />
                        <MenuItem icon={<Shield size={18} color={Colors.primary} />} label="Privacy Policy" onPress={() => router.push('/privacy' as any)} />
                    </View>
                </View>

                <View style={styles.menuSection}>
                    <View style={styles.menuGroup}>
                        <MenuItem icon={<LogOut size={18} color={Colors.error} />} label="Sign Out" onPress={handleSignOut} destructive />
                    </View>
                </View>

                <Text style={styles.version}>ConventionHub v1.0.0</Text>
                <View style={{ height: Spacing.massive }} />
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    headerGradient: { paddingBottom: Spacing.xxl },
    profileHeader: { alignItems: 'center', paddingTop: Spacing.lg, paddingHorizontal: Spacing.xl },
    avatarContainer: { position: 'relative', marginBottom: Spacing.md },
    avatar: { width: 80, height: 80, borderRadius: 40, justifyContent: 'center', alignItems: 'center', borderWidth: 3, borderColor: 'rgba(255,255,255,0.3)' },
    guestBadge: { position: 'absolute', bottom: 0, right: 0, width: 24, height: 24, borderRadius: 12, backgroundColor: Colors.surface, justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: Colors.primary },
    editBadge: { position: 'absolute', bottom: 0, right: -8, width: 28, height: 28, borderRadius: 14, backgroundColor: Colors.surface, justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: Colors.primary },
    profileName: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: '#FFFFFF', marginBottom: Spacing.xs },
    locationBadge: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, marginBottom: Spacing.xl },
    locationText: { color: 'rgba(255,255,255,0.7)', fontSize: FontSize.sm },
    statsRow: { flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.15)', borderRadius: Radius.xl, paddingVertical: Spacing.lg, paddingHorizontal: Spacing.xxl, width: '100%' },
    statItem: { flex: 1, alignItems: 'center' },
    statNumber: { fontSize: FontSize.xl, fontWeight: FontWeight.heavy, color: '#FFFFFF' },
    statLabel: { fontSize: FontSize.xs, color: 'rgba(255,255,255,0.7)', marginTop: Spacing.xxs },
    statDivider: { width: 1, backgroundColor: 'rgba(255,255,255,0.2)' },
    menuSection: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.xl },
    sectionLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textTertiary, textTransform: 'uppercase' as const, letterSpacing: 1, marginBottom: Spacing.sm, paddingHorizontal: Spacing.sm },
    menuGroup: { backgroundColor: Colors.surface, borderRadius: Radius.xl, overflow: 'hidden', ...Shadow.sm },
    menuItem: { flexDirection: 'row', alignItems: 'center', padding: Spacing.lg, gap: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.borderLight },
    menuIconBox: { width: 36, height: 36, borderRadius: Radius.md, backgroundColor: Colors.primaryFaded, justifyContent: 'center', alignItems: 'center' },
    menuIconDestructive: { backgroundColor: Colors.errorLight },
    menuLabel: { flex: 1, fontSize: FontSize.md, fontWeight: FontWeight.semibold, color: Colors.text },
    menuLabelDestructive: { color: Colors.error },
    version: { textAlign: 'center', color: Colors.textTertiary, fontSize: FontSize.xs, marginTop: Spacing.xxl },
});
