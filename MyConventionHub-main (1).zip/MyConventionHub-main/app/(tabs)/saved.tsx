import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Heart } from 'lucide-react-native';
import { Colors, Spacing, FontSize, FontWeight } from '@/constants/theme';
import { useApp } from '@/providers/AppProvider';
import { supabase } from '@/utils/supabase';
import HallCard from '@/components/features/halls/HallCard';
import type { Hall } from '@/types';

export default function SavedScreen() {
    const router = useRouter();
    const { savedHallIds, toggleSaveHall, isHallSaved } = useApp();
    const [halls, setHalls] = useState<Hall[]>([]);

    useEffect(() => {
        const fetchSavedHalls = async () => {
            if (savedHallIds.length === 0) {
                setHalls([]);
                return;
            }
            const { data } = await supabase
                .from('halls')
                .select('*')
                .in('id', savedHallIds);
            setHalls(data ?? []);
        };
        fetchSavedHalls();
    }, [savedHallIds]);

    const navigateToHall = useCallback((hallId: string) => {
        router.push(`/hall/${hallId}` as any);
    }, [router]);

    const renderHall = useCallback(({ item, index }: { item: Hall; index: number }) => (
        <HallCard
            hall={item}
            onPress={() => navigateToHall(item.id)}
            onSave={() => toggleSaveHall(item.id)}
            isSaved={isHallSaved(item.id)}
            index={index}
        />
    ), [navigateToHall, toggleSaveHall, isHallSaved]);

    return (
        <View style={styles.screen}>
            <SafeAreaView edges={['top']} style={styles.header}>
                <Text style={styles.title}>Saved Venues</Text>
                <Text style={styles.subtitle}>{halls.length} venues saved</Text>
            </SafeAreaView>

            <FlatList
                data={halls}
                renderItem={renderHall}
                keyExtractor={(item) => item.id}
                contentContainerStyle={styles.listContent}
                showsVerticalScrollIndicator={false}
                ListEmptyComponent={
                    <View style={styles.emptyContainer}>
                        <View style={styles.emptyIcon}>
                            <Heart size={40} color={Colors.textTertiary} />
                        </View>
                        <Text style={styles.emptyTitle}>No saved venues</Text>
                        <Text style={styles.emptySubtitle}>
                            Tap the heart icon on any venue to save it for later
                        </Text>
                    </View>
                }
            />
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    header: {
        paddingHorizontal: Spacing.xl,
        paddingBottom: Spacing.lg,
        backgroundColor: Colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: Colors.borderLight,
    },
    title: { fontSize: FontSize.xxl, fontWeight: FontWeight.heavy, color: Colors.text, paddingTop: Spacing.sm },
    subtitle: { fontSize: FontSize.sm, color: Colors.textTertiary, marginTop: Spacing.xxs },
    listContent: { paddingTop: Spacing.lg, paddingBottom: Spacing.massive },
    emptyContainer: { alignItems: 'center', paddingTop: Spacing.massive * 2, paddingHorizontal: Spacing.xxl },
    emptyIcon: {
        width: 80, height: 80, borderRadius: 40, backgroundColor: Colors.cream,
        justifyContent: 'center', alignItems: 'center', marginBottom: Spacing.lg,
    },
    emptyTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: Spacing.sm },
    emptySubtitle: { fontSize: FontSize.sm, color: Colors.textTertiary, textAlign: 'center', lineHeight: 20 },
});
