import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { useAuth } from '@/providers/AuthProvider';
import { supabase } from '@/utils/supabase';
import { BarChart, LineChart } from 'react-native-gifted-charts';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export default function OwnerAnalyticsScreen() {
    const { user } = useAuth();
    const [monthlyEarnings, setMonthlyEarnings] = useState<{ month: string; amount: number; bookings: number }[]>([]);

    useEffect(() => {
        const fetchAnalytics = async () => {
            if (!user) return;
            const { data: halls } = await supabase.from('halls').select('id').eq('owner_id', user.id);
            if (!halls || halls.length === 0) return;
            const hallIds = halls.map(h => h.id);

            const { data: allBookings } = await supabase
                .from('bookings')
                .select('event_date, date, total_amount, total_price, status')
                .in('hall_id', hallIds);

            if (!allBookings) return;

            const now = new Date();
            const thisMonth = now.getMonth();
            const thisYear = now.getFullYear();
            const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

            const earnings = [];
            for (let i = 5; i >= 0; i--) {
                const m = (thisMonth - i + 12) % 12;
                const y = thisMonth - i < 0 ? thisYear - 1 : thisYear;
                const monthBookings = allBookings.filter(b => {
                    const d = new Date(b.event_date ?? b.date);
                    return d.getMonth() === m && d.getFullYear() === y && b.status !== 'cancelled';
                });
                earnings.push({
                    month: MONTH_NAMES[m],
                    amount: monthBookings.reduce((s, b) => s + (b.total_amount ?? b.total_price ?? 0), 0),
                    bookings: monthBookings.length,
                });
            }
            setMonthlyEarnings(earnings);
        };
        fetchAnalytics();
    }, [user]);

    const barData = monthlyEarnings.map(item => ({
        value: item.amount,
        label: item.month,
        frontColor: Colors.primary,
    }));

    const lineData = monthlyEarnings.map(item => ({
        value: item.bookings,
        label: item.month,
    }));

    return (
        <View style={styles.screen}>
            <SafeAreaView edges={['top']} style={styles.header}>
                <Text style={styles.title}>Insights & Analytics</Text>
            </SafeAreaView>

            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Monthly Revenue Breakdown</Text>
                    <View style={styles.chartWrapper}>
                        <BarChart
                            data={barData}
                            width={SCREEN_WIDTH - Spacing.xl * 2 - 40}
                            height={220}
                            barWidth={28}
                            spacing={24}
                            roundedTop
                            roundedBottom
                            xAxisThickness={0}
                            yAxisThickness={0}
                            yAxisTextStyle={{ color: Colors.textTertiary, fontSize: 10 }}
                            noOfSections={4}
                            isAnimated
                            animationDuration={1500}
                        />
                    </View>
                </View>

                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Booking Volume Trend</Text>
                    <View style={styles.chartWrapper}>
                        <LineChart
                            data={lineData}
                            width={SCREEN_WIDTH - Spacing.xl * 2 - 40}
                            height={220}
                            thickness={3}
                            color={Colors.goldDark}
                            noOfSections={4}
                            isAnimated
                            animationDuration={1500}
                            dataPointsColor={Colors.gold}
                            dataPointsRadius={4}
                            hideRules
                            xAxisThickness={0}
                            yAxisThickness={0}
                            yAxisTextStyle={{ color: Colors.textTertiary, fontSize: 10 }}
                        />
                    </View>
                </View>
                <View style={{ height: Spacing.massive }} />
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    header: {
        paddingHorizontal: Spacing.xl, paddingBottom: Spacing.md,
        backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.borderLight,
        ...Shadow.sm,
    },
    title: {
        fontSize: FontSize.xxl, fontWeight: FontWeight.heavy, color: Colors.text,
        paddingTop: Spacing.sm,
    },
    scrollContent: { padding: Spacing.xl },
    section: { marginBottom: Spacing.xxl },
    sectionTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: Spacing.lg },
    chartWrapper: {
        backgroundColor: Colors.surface, borderRadius: Radius.xl, paddingVertical: Spacing.xl,
        paddingHorizontal: Spacing.sm, ...Shadow.md, borderWidth: 1, borderColor: 'rgba(0,0,0,0.03)'
    },
});
