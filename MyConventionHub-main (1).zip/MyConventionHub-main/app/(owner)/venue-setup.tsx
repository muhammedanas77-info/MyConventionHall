import React, { useState } from 'react';
import * as ImagePicker from 'expo-image-picker';
import { Image } from 'expo-image';
import {
    View, Text, StyleSheet, ScrollView, TextInput, Platform, KeyboardAvoidingView, Alert
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, Upload, CheckCircle2, ImagePlus } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { useAuth } from '@/providers/AuthProvider';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

const AMENITIES_LIST = [
    'AC', 'Catering Info', 'Decoration', 'Parking', 'Rooms available', 'Valet', 'Power Backup', 'DJ Allowed', 'Alcohol Allowed'
];
const AREAS = ['Jayanagar', 'Indiranagar', 'Koramangala', 'Whitefield', 'Malleshwaram', 'JP Nagar', 'Electronic City', 'Yelahanka', 'HSR Layout'];

export default function VenueSetupScreen() {
    const router = useRouter();
    const { user } = useAuth();

    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [address, setAddress] = useState('');
    const [area, setArea] = useState('Jayanagar');
    const [city, setCity] = useState('Bangalore');
    const [capacityMax, setCapacityMax] = useState('');
    const [pricePerDay, setPricePerDay] = useState('');
    const [photoUri, setPhotoUri] = useState<string | null>(null);
    const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);

    const [isLoading, setIsLoading] = useState(false);

    const toggleAmenity = (amenity: string) => {
        setSelectedAmenities(prev =>
            prev.includes(amenity) ? prev.filter(a => a !== amenity) : [...prev, amenity]
        );
    };

    const pickImage = async () => {
        const result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ['images'],
            allowsEditing: true,
            aspect: [16, 9],
            quality: 0.8,
        });

        if (!result.canceled) {
            setPhotoUri(result.assets[0].uri);
        }
    };

    const handleSave = async () => {
        if (!name || !description || !address || !capacityMax || !pricePerDay) {
            Alert.alert('Missing Fields', 'Please fill in all the required venue details.');
            return;
        }

        if (!user) {
            Alert.alert('Auth Error', 'You must be logged in to create a venue.');
            return;
        }

        setIsLoading(true);
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

        try {
            let finalPhotoUrl = 'https://images.unsplash.com/photo-1519167758481-83f5afa0d414?w=800';

            if (photoUri) {
                // Upload to Supabase Storage
                const response = await fetch(photoUri);
                const blob = await response.blob();
                const fileExt = photoUri.split('.').pop() || 'jpg';
                const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;

                const { data: uploadData, error: uploadError } = await supabase.storage
                    .from('venue-images')
                    .upload(`public/${fileName}`, blob);

                if (uploadError) {
                    console.error('Image upload failed but continuing to save venue:', uploadError);
                    Alert.alert('Upload Error', 'Image could not be uploaded. You must create "venue-images" bucket in Supabase via Dashboard first. Saving without image for now.');
                } else if (uploadData) {
                    const { data: publicUrlData } = supabase.storage
                        .from('venue-images')
                        .getPublicUrl(uploadData.path);
                    finalPhotoUrl = publicUrlData.publicUrl;
                }
            }

            const { error } = await supabase.from('halls').insert([
                {
                    owner_id: user.id,
                    name: name.trim(),
                    description: description.trim(),
                    address: address.trim(),
                    area: area,
                    city: city.trim(),
                    capacity_min: Math.floor(parseInt(capacityMax) * 0.2), // Auto calc 20% min capacity
                    capacity_max: parseInt(capacityMax),
                    price_per_day: parseInt(pricePerDay),
                    photos: [finalPhotoUrl],
                    amenities: selectedAmenities,
                    is_approved: true,  // Show immediately; admin can review and unapprove if needed
                    is_verified: true,
                }
            ]);

            if (error) throw error;

            Alert.alert('Success', 'Your venue has been submitted successfully!', [
                { text: 'OK', onPress: () => router.replace('/(owner)/dashboard') }
            ]);

        } catch (error: any) {
            console.error('Error creating venue:', error);
            Alert.alert('Error', error.message || 'Could not save the venue details.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <SafeAreaView style={styles.safeArea}>
            <View style={styles.header}>
                <AnimatedPressable onPress={() => router.back()} style={styles.backButton} scaleValue={0.9}>
                    <ArrowLeft size={24} color={Colors.text} />
                </AnimatedPressable>
                <Text style={styles.headerTitle}>Venue Setup</Text>
                <View style={{ width: 40 }} />
            </View>

            <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
                <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>

                    <Text style={styles.sectionDescription}>
                        Fill in all the details about your convention hall to start receiving bookings.
                    </Text>

                    <View style={styles.formGroup}>
                        <Text style={styles.label}>Venue Name *</Text>
                        <TextInput
                            style={styles.input}
                            placeholder="e.g. Royal Palace Hall"
                            placeholderTextColor={Colors.textTertiary}
                            value={name}
                            onChangeText={setName}
                        />
                    </View>

                    <View style={styles.formGroup}>
                        <Text style={styles.label}>Description *</Text>
                        <TextInput
                            style={[styles.input, styles.textArea]}
                            placeholder="Describe your venue, atmosphere, and special features..."
                            placeholderTextColor={Colors.textTertiary}
                            value={description}
                            onChangeText={setDescription}
                            multiline
                            numberOfLines={4}
                            textAlignVertical="top"
                        />
                    </View>

                    <View style={styles.formGroup}>
                        <Text style={styles.label}>Full Address *</Text>
                        <TextInput
                            style={styles.input}
                            placeholder="Street, Building, Landmark"
                            placeholderTextColor={Colors.textTertiary}
                            value={address}
                            onChangeText={setAddress}
                        />
                    </View>

                    <View style={styles.rowGroup}>
                        <View style={[styles.formGroup, { flex: 1 }]}>
                            <Text style={styles.label}>Area *</Text>
                            {/* Simple text input for now, but should ideally be a dropdown based on the AREAS list */}
                            <TextInput
                                style={styles.input}
                                placeholder="Area"
                                value={area}
                                onChangeText={setArea}
                            />
                        </View>
                        <View style={[styles.formGroup, { flex: 1 }]}>
                            <Text style={styles.label}>City</Text>
                            <TextInput
                                style={styles.input}
                                value={city}
                                onChangeText={setCity}
                                editable={false} // Locked to Bangalore for now based on app scope
                            />
                        </View>
                    </View>

                    <View style={styles.rowGroup}>
                        <View style={[styles.formGroup, { flex: 1 }]}>
                            <Text style={styles.label}>Max Capacity *</Text>
                            <TextInput
                                style={styles.input}
                                placeholder="e.g. 500"
                                placeholderTextColor={Colors.textTertiary}
                                value={capacityMax}
                                onChangeText={setCapacityMax}
                                keyboardType="numeric"
                            />
                        </View>
                        <View style={[styles.formGroup, { flex: 1 }]}>
                            <Text style={styles.label}>Price / Day (₹) *</Text>
                            <TextInput
                                style={styles.input}
                                placeholder="e.g. 150000"
                                placeholderTextColor={Colors.textTertiary}
                                value={pricePerDay}
                                onChangeText={setPricePerDay}
                                keyboardType="numeric"
                            />
                        </View>
                    </View>

                    <View style={styles.formGroup}>
                        <Text style={styles.label}>Venue Cover Photo</Text>
                        <AnimatedPressable onPress={pickImage} scaleValue={0.97}>
                            <View style={styles.imagePickerBox}>
                                {photoUri ? (
                                    <Image source={{ uri: photoUri }} style={styles.previewImage} contentFit="cover" />
                                ) : (
                                    <View style={styles.imagePlaceholder}>
                                        <ImagePlus size={32} color={Colors.textTertiary} />
                                        <Text style={styles.imagePlaceholderText}>Tap to select from gallery</Text>
                                    </View>
                                )}
                            </View>
                        </AnimatedPressable>
                        <Text style={styles.helperText}>*Upload a high-quality photo to attract better bookings.</Text>
                    </View>

                    <View style={styles.formGroup}>
                        <Text style={styles.label}>Amenities</Text>
                        <View style={styles.amenitiesGrid}>
                            {AMENITIES_LIST.map(amenity => (
                                <AnimatedPressable
                                    key={amenity}
                                    onPress={() => toggleAmenity(amenity)}
                                    scaleValue={0.95}
                                >
                                    <View style={[
                                        styles.amenityChip,
                                        selectedAmenities.includes(amenity) && styles.amenityChipActive
                                    ]}>
                                        {selectedAmenities.includes(amenity) && <CheckCircle2 size={12} color="#FFF" style={styles.checkIcon} />}
                                        <Text style={[
                                            styles.amenityText,
                                            selectedAmenities.includes(amenity) && styles.amenityTextActive
                                        ]}>
                                            {amenity}
                                        </Text>
                                    </View>
                                </AnimatedPressable>
                            ))}
                        </View>
                    </View>

                    <View style={{ height: Spacing.massive }} />
                </ScrollView>
            </KeyboardAvoidingView>

            <View style={styles.footer}>
                <AnimatedPressable onPress={handleSave} disabled={isLoading} scaleValue={0.96}>
                    <View style={[styles.saveButton, isLoading && styles.saveButtonDisabled]}>
                        <Upload size={20} color="#FFFFFF" strokeWidth={2.5} />
                        <Text style={styles.saveButtonText}>{isLoading ? 'Saving Venue...' : 'Save Venue Details'}</Text>
                    </View>
                </AnimatedPressable>
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: '#FFFFFF' },
    header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.borderLight },
    backButton: { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.surface, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: Colors.borderLight },
    headerTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
    scrollContent: { padding: Spacing.xl },
    sectionDescription: { fontSize: FontSize.sm, color: Colors.textTertiary, marginBottom: Spacing.xl, lineHeight: 22 },
    formGroup: { marginBottom: Spacing.lg },
    rowGroup: { flexDirection: 'row', gap: Spacing.lg },
    label: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textSecondary, marginBottom: Spacing.xs },
    input: { backgroundColor: Colors.surface, borderRadius: Radius.lg, paddingHorizontal: Spacing.lg, paddingVertical: Spacing.lg, fontSize: FontSize.md, color: Colors.text, borderWidth: 1, borderColor: Colors.borderLight },
    textArea: { height: 120, paddingTop: Spacing.lg },
    helperText: { fontSize: 12, color: Colors.textTertiary, marginTop: Spacing.xs },
    amenitiesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
    amenityChip: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderRadius: Radius.full, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.borderLight },
    amenityChipActive: { backgroundColor: Colors.text, borderColor: Colors.text },
    checkIcon: { marginRight: 4 },
    amenityText: { fontSize: FontSize.sm, color: Colors.textSecondary, fontWeight: FontWeight.medium },
    amenityTextActive: { color: '#FFFFFF', fontWeight: FontWeight.bold },
    footer: { padding: Spacing.xl, backgroundColor: '#FFFFFF', borderTopWidth: 1, borderTopColor: Colors.borderLight },
    saveButton: { flexDirection: 'row', backgroundColor: Colors.primary, paddingVertical: Spacing.lg, borderRadius: Radius.lg, justifyContent: 'center', alignItems: 'center', gap: Spacing.sm, ...Shadow.md },
    saveButtonDisabled: { opacity: 0.7 },
    saveButtonText: { color: '#FFFFFF', fontSize: FontSize.md, fontWeight: FontWeight.bold },
    imagePickerBox: { width: '100%', height: 160, borderRadius: Radius.lg, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.borderLight, overflow: 'hidden', justifyContent: 'center', alignItems: 'center', marginTop: Spacing.xs },
    previewImage: { width: '100%', height: '100%' },
    imagePlaceholder: { alignItems: 'center', justifyContent: 'center', gap: Spacing.sm },
    imagePlaceholderText: { color: Colors.textTertiary, fontSize: FontSize.sm, fontWeight: FontWeight.medium }
});
