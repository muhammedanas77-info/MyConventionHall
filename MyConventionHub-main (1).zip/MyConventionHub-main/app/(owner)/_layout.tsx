import { Tabs } from 'expo-router';
import { BarChart3, CalendarDays, LayoutDashboard, Settings, User, Wallet } from 'lucide-react-native';
import React, { useEffect } from 'react';
import { Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { Colors, FontWeight, Radius, Shadow, Spacing } from '@/constants/theme';
import { useAuth } from '@/providers/AuthProvider';
import { useApp } from '@/providers/AppProvider';

export default function OwnerTabLayout() {
    const { role: supabaseRole, isLoading } = useAuth();
    const { userRole: localRole } = useApp();
    const router = useRouter();

    const isOwner = supabaseRole === 'owner' || localRole === 'owner';

    useEffect(() => {
        if (isLoading) return;
        if (!isOwner) {
            router.replace('/role-select' as any);
        }
    }, [isOwner, isLoading, router]);

    if (isLoading || !isOwner) return null;

    return (
        <Tabs
            screenOptions={{
                tabBarActiveTintColor: Colors.primaryDark,
                tabBarInactiveTintColor: Colors.textTertiary,
                tabBarStyle: {
                    backgroundColor: Colors.surface,
                    borderTopColor: 'transparent',
                    height: Platform.OS === 'ios' ? 86 : 72,
                    paddingTop: Spacing.sm,
                    paddingBottom: Platform.OS === 'ios' ? Spacing.xl : Spacing.sm,
                    paddingHorizontal: Spacing.sm,
                    ...Shadow.lg,
                },
                tabBarLabelStyle: {
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                },
                tabBarItemStyle: {
                    borderRadius: Radius.lg,
                    paddingVertical: Spacing.xs,
                },
                headerShown: false,
            }}
        >
            <Tabs.Screen
                name="dashboard"
                options={{
                    title: 'Dashboard',
                    tabBarIcon: ({ color, size }) => <LayoutDashboard size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="owner-bookings"
                options={{
                    title: 'Bookings',
                    tabBarIcon: ({ color, size }) => <CalendarDays size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="owner-profile"
                options={{
                    title: 'Profile',
                    tabBarIcon: ({ color, size }) => <User size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="owner-analytics"
                options={{
                    title: 'Insights',
                    href: null,
                    tabBarIcon: ({ color, size }) => <BarChart3 size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="owner-payouts"
                options={{
                    title: 'Payouts',
                    href: null,
                    tabBarIcon: ({ color, size }) => <Wallet size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="venue-setup"
                options={{
                    title: 'Venue Setup',
                    href: null,
                    tabBarIcon: ({ color, size }) => <Settings size={size} color={color} />,
                }}
            />
        </Tabs>
    );
}
