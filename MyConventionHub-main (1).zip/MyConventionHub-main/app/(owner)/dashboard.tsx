import React, { useRef, useEffect, useCallback } from 'react';
import {
    View, Text, StyleSheet, ScrollView, Animated, Platform, Dimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { TrendingUp, CalendarDays, DollarSign, BarChart3, Bell, ChevronRight, Settings, Wallet, PlusCircle, CheckCircle2, Clock3, XCircle } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { useApp } from '@/providers/AppProvider';
import { useAuth } from '@/providers/AuthProvider';
import { useOwnerDashboard } from '@/hooks/queries/useOwnerDashboard';
import type { SlotType } from '@/types';
import { formatCurrencyFull, formatCurrencyCompact } from '@/utils/currency';
import { formatDateShort } from '@/utils/date';
import { SLOT_LABELS } from '@/constants/pricing';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import Badge from '@/components/ui/Badge';
import { BarChart } from 'react-native-gifted-charts';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const SERIF_FONT = Platform.select({ ios: 'Georgia', android: 'serif', web: 'Georgia, serif', default: 'serif' });

export default function OwnerDashboardScreen() {
    const router = useRouter();
    const { userName } = useApp();
    const fadeAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
    }, [fadeAnim]);

    const { user } = useAuth();
    const { stats, isFetching, refetch } = useOwnerDashboard(user?.id);
    const { upcomingBookings, monthlyEarnings, growthPct } = stats;

    const barData = monthlyEarnings.map(item => ({
        value: item.amount,
        label: item.month,
        frontColor: Colors.primaryDark,
        topLabelComponent: () => (
            <Text style={{ color: Colors.textTertiary, fontSize: 9, marginBottom: 4, fontWeight: 'bold' }}>
                {formatCurrencyCompact(item.amount)}
            </Text>
        )
    }));

    const handleQuickAction = useCallback((route: string) => {
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        router.push(route as any);
    }, [router]);

    const greeting = new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 17 ? 'Good afternoon' : 'Good evening';

    return (
        <View style={styles.screen}>
            <ScrollView showsVerticalScrollIndicator={false}>
                <LinearGradient colors={['#3A1014', Colors.primaryDark, Colors.primary]} style={styles.headerGradient}>
                    <SafeAreaView edges={['top']}>
                        <Animated.View style={[styles.headerContent, { opacity: fadeAnim }]}>
                            <View style={styles.headerRow}>
                                <View style={styles.headerTextGroup}>
                                    <View style={styles.partnerBadge}>
                                        <Text style={styles.partnerBadgeText}>VENUE PARTNER</Text>
                                    </View>
                                    <Text style={styles.greeting}>{greeting},</Text>
                                    <Text style={styles.userName}>{userName ? userName.split(' ')[0].charAt(0).toUpperCase() + userName.split(' ')[0].slice(1) : 'Partner'}</Text>
                                    <Text style={styles.dateText}>{new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</Text>
                                </View>
                                <View style={styles.headerActionGroup}>
                                    <AnimatedPressable onPress={() => { }} scaleValue={0.9}>
                                        <View style={styles.headerIcon}><Bell size={20} color="#FFFFFF" /></View>
                                    </AnimatedPressable>
                                </View>
                            </View>
                            <View style={styles.headerStatsRow}>
                                <View style={styles.headerStat}>
                                    <Text style={styles.headerStatValue}>{stats.pendingBookings}</Text>
                                    <Text style={styles.headerStatLabel}>Awaiting action</Text>
                                </View>
                                <View style={styles.headerDivider} />
                                <View style={styles.headerStat}>
                                    <Text style={styles.headerStatValue}>{stats.confirmedBookings}</Text>
                                    <Text style={styles.headerStatLabel}>Confirmed</Text>
                                </View>
                            </View>
                        </Animated.View>
                    </SafeAreaView>
                </LinearGradient>

                <View style={styles.body}>
                    <View style={styles.earningsCard}>
                        <View style={styles.earningsHeader}>
                            <View>
                                <Text style={styles.earningsLabel}>This Month Revenue</Text>
                                <Text style={styles.earningsAmount}>{formatCurrencyFull(stats.totalEarningsThisMonth)}</Text>
                            </View>
                            <View style={styles.revenueIcon}>
                                <Wallet size={20} color={Colors.primaryDark} />
                            </View>
                        </View>
                        <View style={styles.growthRow}>
                            <TrendingUp size={14} color={Colors.success} />
                            <Text style={styles.growthText}>{growthPct >= 0 ? '+' : ''}{growthPct}% vs last month</Text>
                        </View>
                        <View style={styles.miniStats}>
                            {[
                                { bg: Colors.successLight, fg: Colors.success, icon: <CheckCircle2 size={16} color={Colors.success} />, num: stats.confirmedBookings, label: 'Confirmed' },
                                { bg: Colors.warningLight, fg: Colors.warning, icon: <Clock3 size={16} color={Colors.warning} />, num: stats.pendingBookings, label: 'Pending' },
                                { bg: Colors.errorLight, fg: Colors.error, icon: <XCircle size={16} color={Colors.error} />, num: stats.cancelledBookings, label: 'Cancelled' },
                            ].map((stat) => (
                                <View key={stat.label} style={styles.miniStat}>
                                    <View style={[styles.miniStatIcon, { backgroundColor: stat.bg }]}>
                                        {stat.icon}
                                        <Text style={[styles.miniStatNum, { color: stat.fg }]}>{stat.num}</Text>
                                    </View>
                                    <Text style={styles.miniStatLabel}>{stat.label}</Text>
                                </View>
                            ))}
                        </View>
                    </View>

                    <View style={styles.section}>
                        <View style={styles.sectionHeader}>
                            <Text style={styles.sectionTitle}>Earnings Trend</Text>
                            <AnimatedPressable onPress={() => router.push('/(owner)/owner-analytics' as any)} scaleValue={0.95}>
                                <Text style={styles.viewAllText}>Full Report</Text>
                            </AnimatedPressable>
                        </View>
                        <AnimatedPressable onPress={() => router.push('/(owner)/owner-analytics' as any)} scaleValue={0.98}>
                            <View style={styles.chartContainer}>
                                <BarChart
                                    data={barData}
                                    width={SCREEN_WIDTH - Spacing.xl * 2 - 40}
                                    height={140}
                                    barWidth={32}
                                    spacing={30}
                                    roundedTop
                                    roundedBottom
                                    xAxisThickness={0}
                                    yAxisThickness={0}
                                    hideYAxisText
                                    noOfSections={3}
                                    isAnimated
                                    animationDuration={1500}
                                />
                            </View>
                        </AnimatedPressable>
                    </View>

                    <View style={styles.section}>
                        <Text style={styles.sectionTitle}>Quick Actions</Text>
                        <View style={styles.quickActions}>
                            {[
                                { icon: <PlusCircle size={22} color={Colors.primaryDark} />, label: 'Add Venue', route: '/(owner)/venue-setup' },
                                { icon: <CalendarDays size={22} color={Colors.primary} />, label: 'Calendar', route: '/owner-availability' },
                                { icon: <DollarSign size={22} color={Colors.goldDark} />, label: 'Pricing', route: '/owner-pricing' },
                                { icon: <Wallet size={22} color={Colors.saffron} />, label: 'Payouts', route: '/(owner)/owner-payouts' },
                                { icon: <BarChart3 size={22} color={Colors.success} />, label: 'Insights', route: '/(owner)/owner-analytics' },
                                { icon: <Settings size={22} color={Colors.textTertiary} />, label: 'Settings', route: '/(owner)/owner-profile' },
                            ].map((action, i) => (
                                <AnimatedPressable key={action.label} onPress={() => handleQuickAction(action.route)} scaleValue={0.95}>
                                    <View style={[styles.quickActionItem, { backgroundColor: ['rgba(0,0,0,0.05)', Colors.primaryFaded, Colors.goldFaded, 'rgba(232,125,62,0.1)', Colors.successLight, Colors.cream][i] }]}>
                                        <View style={[styles.quickActionIconWrap, { backgroundColor: Colors.surface }]}>{action.icon}</View>
                                        <Text style={styles.quickActionLabel}>{action.label}</Text>
                                    </View>
                                </AnimatedPressable>
                            ))}
                        </View>
                    </View>

                    <View style={styles.section}>
                        <View style={styles.sectionHeader}>
                            <Text style={styles.sectionTitle}>Upcoming Bookings</Text>
                            <AnimatedPressable onPress={() => router.push('/(owner)/owner-bookings' as any)} scaleValue={0.95}>
                                <Text style={styles.viewAllText}>View All</Text>
                            </AnimatedPressable>
                        </View>
                        {upcomingBookings.length === 0 ? (
                            <View style={styles.emptyBookings}>
                                <CalendarDays size={32} color={Colors.textTertiary} />
                                <Text style={styles.emptyText}>No upcoming bookings</Text>
                            </View>
                        ) : (
                            <View style={styles.bookingsContainer}>
                                {upcomingBookings.map((booking, index) => (
                                    <View key={booking.id} style={[styles.bookingMini, index === upcomingBookings.length - 1 && { borderBottomWidth: 0 }]}>
                                        <View style={[styles.bookingAccent, { backgroundColor: booking.status === 'confirmed' ? Colors.success : Colors.warning }]} />
                                        <View style={styles.bookingMiniContent}>
                                            <View style={styles.bookingMiniRow}>
                                                <Text style={styles.bookingMiniName}>{(booking as any).customer_name || 'Customer'}</Text>
                                                <Badge text={booking.status === 'confirmed' ? 'Confirmed' : 'Pending'} variant={booking.status === 'confirmed' ? 'success' : 'warning'} size="sm" />
                                            </View>
                                            <Text style={styles.bookingMiniDate}>{formatDateShort((booking as any).event_date ?? booking.date)} - {SLOT_LABELS[((booking as any).slot_type ?? booking.slot) as SlotType]} - {(booking as any).guest_count ?? booking.guest_count} guests</Text>
                                            <Text style={styles.bookingMiniAmount}>{formatCurrencyFull((booking as any).total_amount ?? booking.total_amount)}</Text>
                                        </View>
                                        <ChevronRight size={16} color={Colors.textTertiary} style={{ marginRight: Spacing.md }} />
                                    </View>
                                ))}
                            </View>
                        )}
                    </View>
                    <View style={{ height: Spacing.massive * 1.5 }} />
                </View>
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    headerGradient: { paddingBottom: Spacing.xxl, borderBottomLeftRadius: 30, borderBottomRightRadius: 30 },
    headerContent: { paddingHorizontal: Spacing.xl, paddingTop: Spacing.xl, paddingBottom: Spacing.sm },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    headerTextGroup: { flex: 1 },
    headerActionGroup: { marginLeft: Spacing.md },
    partnerBadge: { alignSelf: 'flex-start', backgroundColor: 'rgba(255,255,255,0.16)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 6, marginBottom: Spacing.sm, borderWidth: 1, borderColor: 'rgba(255,255,255,0.16)' },
    partnerBadgeText: { fontSize: 9, color: '#FFF', fontWeight: FontWeight.bold, letterSpacing: 1.5 },
    greeting: { fontSize: FontSize.md, color: 'rgba(255,255,255,0.8)', fontFamily: SERIF_FONT, marginBottom: 2 },
    userName: { fontSize: 26, fontWeight: FontWeight.heavy, color: '#FFFFFF', fontFamily: SERIF_FONT, marginBottom: 4 },
    dateText: { fontSize: FontSize.sm, color: 'rgba(255,255,255,0.8)', fontWeight: FontWeight.medium },
    headerIcon: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.12)', justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' },
    headerStatsRow: { flexDirection: 'row', alignItems: 'center', marginTop: Spacing.xxl, padding: Spacing.md, borderRadius: Radius.lg, backgroundColor: 'rgba(255,255,255,0.1)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.14)' },
    headerStat: { flex: 1 },
    headerStatValue: { color: '#FFFFFF', fontSize: FontSize.xxl, fontWeight: FontWeight.heavy },
    headerStatLabel: { color: 'rgba(255,255,255,0.72)', fontSize: FontSize.xs, fontWeight: FontWeight.bold, textTransform: 'uppercase', letterSpacing: 0.6 },
    headerDivider: { width: 1, height: 36, backgroundColor: 'rgba(255,255,255,0.18)', marginHorizontal: Spacing.md },
    body: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.lg },
    earningsCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.xl, marginTop: -Spacing.xxl, ...Shadow.lg, borderWidth: 1, borderColor: 'rgba(0,0,0,0.03)' },
    earningsHeader: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: Spacing.md },
    revenueIcon: { width: 44, height: 44, borderRadius: Radius.md, backgroundColor: Colors.primaryFaded, justifyContent: 'center', alignItems: 'center' },
    earningsLabel: { fontSize: FontSize.xs, color: Colors.textSecondary, fontWeight: FontWeight.bold, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: Spacing.xs },
    earningsAmount: { fontSize: 34, fontWeight: FontWeight.heavy, color: Colors.text, marginBottom: Spacing.xs },
    growthRow: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, marginBottom: Spacing.xl, marginTop: Spacing.xs, backgroundColor: Colors.successLight, paddingHorizontal: Spacing.sm, paddingVertical: 5, borderRadius: Radius.full },
    growthBadge: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xxs, backgroundColor: Colors.successLight, paddingHorizontal: Spacing.sm, paddingVertical: 4, borderRadius: Radius.full },
    growthText: { fontSize: FontSize.sm, color: Colors.success, fontWeight: FontWeight.bold },
    growthSubText: { fontSize: FontSize.sm, color: Colors.textTertiary, fontWeight: FontWeight.medium },
    miniStats: { flexDirection: 'row', gap: Spacing.sm, paddingTop: Spacing.lg, borderTopWidth: 1, borderTopColor: Colors.borderLight },
    miniStat: { flex: 1, alignItems: 'center', gap: Spacing.xs },
    miniStatIcon: { width: 54, height: 46, borderRadius: Radius.lg, justifyContent: 'center', alignItems: 'center', marginBottom: 2, flexDirection: 'row', gap: Spacing.xs },
    miniStatNum: { fontSize: FontSize.lg, fontWeight: FontWeight.heavy },
    miniStatLabel: { fontSize: 11, color: Colors.textSecondary, fontWeight: FontWeight.semibold, textTransform: 'uppercase' },
    section: { marginTop: Spacing.xxl },
    sectionTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.heavy, color: Colors.text, marginBottom: Spacing.xs },
    sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.md },
    viewAllText: { fontSize: FontSize.sm, color: Colors.primaryDark, fontWeight: FontWeight.bold },
    chartContainer: { alignItems: 'center', backgroundColor: Colors.surface, paddingTop: Spacing.xl, paddingBottom: Spacing.lg, paddingRight: Spacing.xl, borderRadius: Radius.xl, ...Shadow.sm, borderWidth: 1, borderColor: Colors.borderLight },
    quickActions: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
    quickActionItem: { width: (SCREEN_WIDTH - Spacing.lg * 2 - Spacing.sm * 2) / 3, minHeight: 102, borderRadius: Radius.lg, padding: Spacing.md, alignItems: 'center', justifyContent: 'center', gap: Spacing.sm, borderWidth: 1, borderColor: Colors.borderLight },
    quickActionIconWrap: { width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center', ...Shadow.sm },
    quickActionLabel: { fontSize: 11, color: Colors.textSecondary, fontWeight: FontWeight.bold, textAlign: 'center' },
    bookingsContainer: { backgroundColor: Colors.surface, borderRadius: Radius.xl, paddingHorizontal: Spacing.lg, ...Shadow.md, borderWidth: 1, borderColor: 'rgba(0,0,0,0.03)' },
    bookingMini: { flexDirection: 'row', alignItems: 'center', paddingVertical: Spacing.lg, borderBottomWidth: 1, borderBottomColor: Colors.borderLight },
    bookingAccent: { width: 4, height: 40, borderRadius: 2, marginRight: Spacing.md },
    bookingMiniContent: { flex: 1, gap: Spacing.xxs },
    bookingMiniRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    bookingMiniName: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text },
    bookingMiniDate: { fontSize: FontSize.xs, color: Colors.textTertiary, fontWeight: FontWeight.medium },
    bookingMiniAmount: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.primaryDark, marginTop: 4 },
    emptyBookings: { backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.xxl, alignItems: 'center', gap: Spacing.sm, ...Shadow.sm },
    emptyText: { fontSize: FontSize.sm, color: Colors.textTertiary },
});
