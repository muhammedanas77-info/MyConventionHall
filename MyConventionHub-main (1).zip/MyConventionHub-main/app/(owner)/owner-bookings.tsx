import React, { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import {
    View, Text, StyleSheet, FlatList, Animated, Linking, Platform, TextInput, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { MessageCircle, CalendarDays, Users, CheckCircle2, XCircle, PhoneCall, StickyNote, FileText } from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { formatCurrencyFull } from '@/utils/currency';
import { formatDateDisplay } from '@/utils/date';
import { SLOT_LABELS } from '@/constants/pricing';
import Badge from '@/components/ui/Badge';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import { useAuth } from '@/providers/AuthProvider';
import { supabase } from '@/utils/supabase';
import { normalizeBooking } from '@/utils/booking';
import { sendBookingNotification, type NotificationType } from '@/utils/notifications';
import type { Booking, BookingStatus } from '@/types';

const FILTERS: { key: BookingStatus | 'all'; label: string }[] = [
    { key: 'all', label: 'All' },
    { key: 'confirmed', label: 'Confirmed' },
    { key: 'pending', label: 'Pending' },
    { key: 'completed', label: 'Completed' },
    { key: 'cancelled', label: 'Cancelled' },
];

const STATUS_MAP: Record<BookingStatus, { variant: 'success' | 'warning' | 'error' | 'neutral'; label: string }> = {
    confirmed: { variant: 'success', label: 'Confirmed' },
    pending: { variant: 'warning', label: 'Pending' },
    cancelled: { variant: 'error', label: 'Cancelled' },
    completed: { variant: 'neutral', label: 'Completed' },
};

const ACCENT_COLORS: Record<BookingStatus, string> = {
    confirmed: Colors.success,
    pending: Colors.warning,
    cancelled: Colors.error,
    completed: Colors.textTertiary,
};

function BookingCard({
    booking,
    index,
    onConfirm,
    onReject,
    onMarkContacted,
    onSaveNote,
}: {
    booking: Booking;
    index: number;
    onConfirm: (booking: Booking) => void;
    onReject: (bookingId: string) => void;
    onMarkContacted: (bookingId: string) => void;
    onSaveNote: (bookingId: string, note: string) => void;
}) {
    const entryAnim = useRef(new Animated.Value(0)).current;
    const [note, setNote] = useState((booking as any).internal_notes ?? '');
    const customer = (booking as any).customer;
    const customerName = (booking as any).customer_name ?? customer?.full_name ?? booking.customer_id ?? 'Customer';
    const customerPhone = (booking as any).customer_phone ?? customer?.phone ?? '+91 00000 00000';
    const customerEmail = (booking as any).customer_email ?? customer?.email ?? '';
    const statusInfo = STATUS_MAP[booking.status];
    const payment = (booking as any).payments?.[0];

    useEffect(() => {
        Animated.spring(entryAnim, {
            toValue: 1, delay: index * 60, useNativeDriver: true, speed: 14, bounciness: 3,
        }).start();
    }, []);

    const handleWhatsApp = () => {
        const cleanPhone = customerPhone.replace(/\D/g, '');
        const msg = encodeURIComponent(
            `Hello! This is ConventionHub confirming your booking for ${formatDateDisplay(booking.date)}. Please let us know if you need anything.`
        );
        Linking.openURL(`https://wa.me/${cleanPhone}?text=${msg}`).catch(console.log);
    };

    return (
        <Animated.View style={[styles.cardWrapper, {
            opacity: entryAnim,
            transform: [{ translateY: entryAnim.interpolate({ inputRange: [0, 1], outputRange: [30, 0] }) }],
        }]}> 
            <View style={styles.card}>
                <View style={[styles.cardAccent, { backgroundColor: ACCENT_COLORS[booking.status] }]} />
                <View style={styles.cardContent}>
                    <View style={styles.cardHeader}>
                        <Text style={styles.cardName}>{booking.hall?.name ?? 'Booking'}</Text>
                        <Badge text={statusInfo.label} variant={statusInfo.variant} size="sm" />
                    </View>
                    <Text style={styles.cardPhone}>{customerName} {customerEmail ? `· ${customerEmail}` : ''}</Text>
                    <View style={styles.cardDetails}>
                        <View style={styles.cardDetail}>
                            <CalendarDays size={12} color={Colors.textTertiary} />
                            <Text style={styles.cardDetailText}>{formatDateDisplay(booking.date)}</Text>
                        </View>
                        <View style={styles.cardDetail}>
                            <Users size={12} color={Colors.textTertiary} />
                            <Text style={styles.cardDetailText}>{booking.guest_count} guests · {SLOT_LABELS[booking.slot]}</Text>
                        </View>
                    </View>
                    <View style={styles.cardFooter}>
                        <View>
                            <Text style={styles.cardAmount}>{formatCurrencyFull(booking.total_amount)}</Text>
                            <Text style={styles.cardAdvance}>Advance: {formatCurrencyFull(booking.advance_amount)}</Text>
                        </View>
                        {booking.status === 'confirmed' && (
                            <AnimatedPressable onPress={handleWhatsApp} scaleValue={0.9}>
                                <View style={styles.whatsappButton}>
                                    <MessageCircle size={14} color="#FFFFFF" />
                                    <Text style={styles.whatsappText}>WhatsApp</Text>
                                </View>
                            </AnimatedPressable>
                        )}
                    </View>

                    {payment?.verification_screenshot_url && (
                        <View style={styles.paymentProofBox}>
                            <View style={styles.proofHeader}>
                                <FileText size={12} color={Colors.primaryDark} />
                                <Text style={styles.proofTitle}>Payment Proof Submitted</Text>
                            </View>
                            <AnimatedPressable 
                                onPress={() => Linking.openURL(payment.verification_screenshot_url)} 
                                scaleValue={0.98}
                            >
                                <View style={styles.viewProofButton}>
                                    <Text style={styles.viewProofText}>View Screenshot</Text>
                                </View>
                            </AnimatedPressable>
                        </View>
                    )}

                    <View style={styles.partnerMetaRow}>
                        <View style={[styles.contactBadge, (booking as any).partner_contacted && styles.contactBadgeDone]}>
                            <PhoneCall size={12} color={(booking as any).partner_contacted ? Colors.success : Colors.textTertiary} />
                            <Text style={[styles.contactBadgeText, (booking as any).partner_contacted && styles.contactBadgeTextDone]}>
                                {(booking as any).partner_contacted ? 'Contacted' : 'Not contacted'}
                            </Text>
                        </View>
                        <Text style={styles.paymentStatusText}>Payment: {(booking as any).payment_verified ? 'Verified' : (payment?.status === 'submitted' ? 'Reviewing' : 'Pending')}</Text>
                    </View>
                    <View style={styles.partnerActions}>
                        <AnimatedPressable onPress={() => onConfirm(booking)} scaleValue={0.95}>
                            <View style={styles.confirmButton}>
                                <CheckCircle2 size={14} color="#FFFFFF" />
                                <Text style={styles.confirmText}>Confirm</Text>
                            </View>
                        </AnimatedPressable>
                        <AnimatedPressable onPress={() => onReject(booking.id)} scaleValue={0.95}>
                            <View style={styles.rejectButton}>
                                <XCircle size={14} color={Colors.error} />
                                <Text style={styles.rejectText}>Reject</Text>
                            </View>
                        </AnimatedPressable>
                        <AnimatedPressable onPress={() => onMarkContacted(booking.id)} scaleValue={0.95}>
                            <View style={styles.contactedButton}>
                                <PhoneCall size={14} color={Colors.primaryDark} />
                                <Text style={styles.contactedText}>Contacted</Text>
                            </View>
                        </AnimatedPressable>
                    </View>
                    <View style={styles.noteBox}>
                        <StickyNote size={14} color={Colors.textTertiary} />
                        <TextInput
                            style={styles.noteInput}
                            value={note}
                            onChangeText={setNote}
                            placeholder="Internal note for your team"
                            placeholderTextColor={Colors.textTertiary}
                        />
                        <AnimatedPressable onPress={() => onSaveNote(booking.id, note)} scaleValue={0.95}>
                            <Text style={styles.noteSaveText}>Save</Text>
                        </AnimatedPressable>
                    </View>
                </View>
            </View>
        </Animated.View>
    );
}

export default function OwnerBookingsScreen() {
    const { user } = useAuth();
    const [filter, setFilter] = useState<BookingStatus | 'all'>('all');
    const [bookings, setBookings] = useState<Booking[]>([]);

    const fetchOwnerBookings = useCallback(async () => {
            if (!user?.id) return;

            const { data: halls } = await supabase.from('halls').select('id').eq('owner_id', user.id);
            if (!halls || halls.length === 0) {
                setBookings([]);
                return;
            }

            const hallIds = halls.map((h: any) => h.id);
            const { data: bookingData } = await supabase
                .from('bookings')
                .select('*, hall: halls(*), customer: profiles!bookings_customer_id_fkey(full_name, phone, email), payments(*)')
                .in('hall_id', hallIds)
                .order('event_date', { ascending: false });

            if (bookingData) {
                setBookings(bookingData.map((item: any) => normalizeBooking(item)));
            }
    }, [user]);

    useEffect(() => {
        fetchOwnerBookings();
    }, [fetchOwnerBookings]);

    const updateBooking = useCallback(async (
        bookingId: string,
        values: Record<string, unknown>,
        successMessage: string,
        notificationType?: NotificationType
    ) => {
        const { error } = await supabase.from('bookings').update(values).eq('id', bookingId);
        if (error) {
            Alert.alert('Unable to update booking', error.message);
            return;
        }
        await fetchOwnerBookings();
        if (notificationType) {
            sendBookingNotification(notificationType, bookingId).catch(console.log);
        }
        if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        Alert.alert('Saved', successMessage);
    }, [fetchOwnerBookings]);

    const handleConfirm = useCallback((booking: Booking) => {
        Alert.alert('Confirm Booking', 'Confirm this booking with the venue?', [
            { text: 'Cancel', style: 'cancel' },
            {
                text: 'Confirm',
                onPress: () => updateBooking(
                    booking.id,
                    { venue_confirmation_status: 'confirmed', status: (booking as any).payment_verified ? 'confirmed' : 'pending' },
                    (booking as any).payment_verified ? 'Booking confirmed by venue partner.' : 'Venue confirmed. Booking will be final after payment verification.',
                    'partner_confirmed'
                )
            },
        ]);
    }, [updateBooking]);

    const handleReject = useCallback((bookingId: string) => {
        Alert.alert('Reject Booking', 'Rejecting this booking will cancel it for the customer.', [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Reject', style: 'destructive', onPress: () => updateBooking(bookingId, { venue_confirmation_status: 'rejected', status: 'cancelled' }, 'Booking rejected by venue partner.', 'partner_rejected') },
        ]);
    }, [updateBooking]);

    const handleMarkContacted = useCallback((bookingId: string) => {
        updateBooking(bookingId, { partner_contacted: true, partner_contacted_at: new Date().toISOString() }, 'Customer marked as contacted.', 'partner_contacted');
    }, [updateBooking]);

    const handleSaveNote = useCallback((bookingId: string, note: string) => {
        updateBooking(bookingId, { internal_notes: note }, 'Internal note saved.');
    }, [updateBooking]);

    const filteredBookings = useMemo(() => {
        if (filter === 'all') return bookings;
        return bookings.filter((b) => b.status === filter);
    }, [filter, bookings]);

    return (
        <View style={styles.screen}>
            <SafeAreaView edges={['top']} style={styles.header}>
                <Text style={styles.title}>All Bookings</Text>
                <View style={styles.filterRow}>
                    {FILTERS.map((f) => (
                        <AnimatedPressable key={f.key} onPress={() => setFilter(f.key)} scaleValue={0.95}>
                            <View style={[styles.filterChip, filter === f.key && styles.filterChipActive]}>
                                <Text style={[styles.filterChipText, filter === f.key && styles.filterChipTextActive]}>
                                    {f.label}
                                </Text>
                            </View>
                        </AnimatedPressable>
                    ))}
                </View>
            </SafeAreaView>

            <FlatList
                data={filteredBookings}
                renderItem={({ item, index }) => (
                    <BookingCard
                        booking={item}
                        index={index}
                        onConfirm={handleConfirm}
                        onReject={handleReject}
                        onMarkContacted={handleMarkContacted}
                        onSaveNote={handleSaveNote}
                    />
                )}
                keyExtractor={(item) => item.id}
                contentContainerStyle={styles.listContent}
                showsVerticalScrollIndicator={false}
                ListEmptyComponent={
                    <View style={styles.emptyContainer}>
                        <CalendarDays size={40} color={Colors.textTertiary} />
                        <Text style={styles.emptyTitle}>No bookings found</Text>
                        <Text style={styles.emptySubtitle}>Bookings matching this filter will appear here</Text>
                    </View>
                }
            />
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    header: {
        paddingHorizontal: Spacing.xl, paddingBottom: Spacing.xl,
        backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.borderLight, ...Shadow.sm
    },
    title: {
        fontSize: FontSize.xxl, fontWeight: FontWeight.heavy, color: Colors.text,
        marginBottom: Spacing.lg, paddingTop: Spacing.sm,
    },
    filterRow: { flexDirection: 'row', gap: Spacing.sm, flexWrap: 'wrap' },
    filterChip: {
        paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs,
        borderRadius: Radius.full, backgroundColor: Colors.cream,
    },
    filterChipActive: { backgroundColor: Colors.primaryDark },
    filterChipText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textSecondary },
    filterChipTextActive: { color: '#FFFFFF' },
    listContent: { padding: Spacing.xl, paddingBottom: Spacing.massive },
    cardWrapper: { marginBottom: Spacing.lg },
    card: {
        flexDirection: 'row', backgroundColor: Colors.surface,
        borderRadius: Radius.xl, overflow: 'hidden', ...Shadow.md, borderWidth: 1, borderColor: 'rgba(0,0,0,0.03)'
    },
    cardAccent: { width: 4 },
    cardContent: { flex: 1, padding: Spacing.lg, gap: Spacing.sm },
    cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    cardName: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text },
    cardPhone: { fontSize: FontSize.xs, color: Colors.textTertiary },
    cardDetails: { gap: Spacing.xxs },
    cardDetail: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
    cardDetailText: { fontSize: FontSize.sm, color: Colors.textSecondary, fontWeight: FontWeight.medium },
    cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: Spacing.sm },
    cardAmount: { fontSize: FontSize.xl, fontWeight: FontWeight.heavy, color: Colors.primaryDark },
    cardAdvance: { fontSize: FontSize.xs, color: Colors.textTertiary, fontWeight: FontWeight.bold },
    whatsappButton: {
        flexDirection: 'row', alignItems: 'center', gap: Spacing.xs,
        backgroundColor: '#25D366', paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
        borderRadius: Radius.md,
    },
    whatsappText: { fontSize: FontSize.xs, color: '#FFFFFF', fontWeight: FontWeight.semibold },
    paymentProofBox: { backgroundColor: Colors.cream, borderRadius: Radius.lg, padding: Spacing.md, marginTop: Spacing.sm, borderStyle: 'dashed', borderWidth: 1, borderColor: Colors.primaryDark },
    proofHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, marginBottom: Spacing.sm },
    proofTitle: { fontSize: 11, fontWeight: FontWeight.bold, color: Colors.primaryDark },
    viewProofButton: { backgroundColor: Colors.surface, paddingVertical: 6, borderRadius: Radius.md, alignItems: 'center', ...Shadow.sm },
    viewProofText: { fontSize: 11, fontWeight: FontWeight.bold, color: Colors.primaryDark },
    partnerMetaRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: Spacing.sm, marginTop: Spacing.sm },
    contactBadge: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xxs, backgroundColor: Colors.cream, paddingHorizontal: Spacing.sm, paddingVertical: 5, borderRadius: Radius.full },
    contactBadgeDone: { backgroundColor: Colors.successLight },
    contactBadgeText: { fontSize: 11, color: Colors.textTertiary, fontWeight: FontWeight.bold },
    contactBadgeTextDone: { color: Colors.success },
    paymentStatusText: { fontSize: 11, color: Colors.textTertiary, fontWeight: FontWeight.bold },
    partnerActions: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, paddingTop: Spacing.sm },
    confirmButton: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, backgroundColor: Colors.success, paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderRadius: Radius.full },
    confirmText: { color: '#FFFFFF', fontSize: FontSize.xs, fontWeight: FontWeight.bold },
    rejectButton: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, borderWidth: 1, borderColor: Colors.error, paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderRadius: Radius.full },
    rejectText: { color: Colors.error, fontSize: FontSize.xs, fontWeight: FontWeight.bold },
    contactedButton: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, backgroundColor: Colors.cream, paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderRadius: Radius.full },
    contactedText: { color: Colors.primaryDark, fontSize: FontSize.xs, fontWeight: FontWeight.bold },
    noteBox: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, backgroundColor: Colors.cream, borderRadius: Radius.md, paddingHorizontal: Spacing.md, marginTop: Spacing.sm },
    noteInput: { flex: 1, minHeight: 44, color: Colors.text, fontSize: FontSize.sm },
    noteSaveText: { color: Colors.primaryDark, fontWeight: FontWeight.bold, fontSize: FontSize.sm },
    emptyContainer: { alignItems: 'center', paddingTop: Spacing.massive * 2, gap: Spacing.sm },
    emptyTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
    emptySubtitle: { fontSize: FontSize.sm, color: Colors.textTertiary },
});
