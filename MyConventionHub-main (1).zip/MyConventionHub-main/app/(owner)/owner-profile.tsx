import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
    Building, CalendarDays, BarChart3, Settings, Bell,
    HelpCircle, Shield, FileText, LogOut, ChevronRight, Crown,
} from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { useApp } from '@/providers/AppProvider';
import { useAuth } from '@/providers/AuthProvider';
import { supabase } from '@/utils/supabase';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

function MenuItem({ icon, label, onPress, destructive }: {
    icon: React.ReactNode; label: string; onPress: () => void; destructive?: boolean;
}) {
    return (
        <AnimatedPressable onPress={onPress} scaleValue={0.98}>
            <View style={styles.menuItem}>
                <View style={[styles.menuIconBox, destructive && styles.menuIconDestructive]}>{icon}</View>
                <Text style={[styles.menuLabel, destructive && styles.menuLabelDestructive]}>{label}</Text>
                <ChevronRight size={16} color={Colors.textTertiary} />
            </View>
        </AnimatedPressable>
    );
}

export default function OwnerProfileScreen() {
    const router = useRouter();
    const { userName, logout } = useApp();
    const { user } = useAuth();
    const [profileStats, setProfileStats] = useState({ totalBookings: 0, occupancyRate: 0, rating: 0 });

    useEffect(() => {
        const fetchStats = async () => {
            if (!user) return;
            const { data: halls } = await supabase.from('halls').select('id, rating, total_reviews').eq('owner_id', user.id);
            if (!halls || halls.length === 0) return;
            const hallIds = halls.map(h => h.id);

            const { data: bookings } = await supabase
                .from('bookings')
                .select('status')
                .in('hall_id', hallIds);

            const total = bookings?.length ?? 0;
            const confirmed = bookings?.filter(b => b.status === 'confirmed' || b.status === 'completed').length ?? 0;
            const avgRating = halls.reduce((s, h) => s + (h.rating ?? 0), 0) / halls.length;

            // Occupancy: confirmed bookings out of total possible slots in last 30 days (rough estimate)
            const occupancy = total > 0 ? Math.round((confirmed / Math.max(total, 1)) * 100) : 0;

            setProfileStats({
                totalBookings: total,
                occupancyRate: occupancy,
                rating: Math.round(avgRating * 10) / 10,
            });
        };
        fetchStats();
    }, [user]);

    const handleLogout = () => {
        Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Sign Out', style: 'destructive', onPress: () => { logout(); router.replace('/role-select' as any); } },
        ]);
    };

    return (
        <View style={styles.screen}>
            <ScrollView showsVerticalScrollIndicator={false}>
                <LinearGradient colors={[Colors.primary, Colors.primaryLight]} style={styles.headerGradient}>
                    <SafeAreaView edges={['top']}>
                        <View style={styles.profileHeader}>
                            <View style={styles.avatarWrap}>
                                <LinearGradient colors={[Colors.gold, Colors.goldLight]} style={styles.avatar}>
                                    <Building size={28} color={Colors.primaryDark} />
                                </LinearGradient>
                                <View style={styles.ownerBadge}><Crown size={10} color={Colors.gold} /></View>
                            </View>
                            <Text style={styles.profileName}>{userName || 'Hall Owner'}</Text>
                            <Text style={styles.profileRole}>Venue Partner</Text>
                            <View style={styles.statsRow}>
                                <View style={styles.statItem}>
                                    <Text style={styles.statNum}>{profileStats.totalBookings}</Text>
                                    <Text style={styles.statLabel}>Bookings</Text>
                                </View>
                                <View style={styles.statDiv} />
                                <View style={styles.statItem}>
                                    <Text style={styles.statNum}>{profileStats.occupancyRate}%</Text>
                                    <Text style={styles.statLabel}>Occupancy</Text>
                                </View>
                                <View style={styles.statDiv} />
                                <View style={styles.statItem}>
                                    <Text style={styles.statNum}>{profileStats.rating || '—'}</Text>
                                    <Text style={styles.statLabel}>Rating</Text>
                                </View>
                            </View>
                        </View>
                    </SafeAreaView>
                </LinearGradient>

                <View style={styles.menuSection}>
                    <Text style={styles.sectionLabel}>Venue Management</Text>
                    <View style={styles.menuGroup}>
                        <MenuItem icon={<CalendarDays size={18} color={Colors.primary} />} label="Availability" onPress={() => router.push('/owner-availability' as any)} />
                        <MenuItem icon={<BarChart3 size={18} color={Colors.primary} />} label="Analytics" onPress={() => router.push('/owner-analytics' as any)} />
                        <MenuItem icon={<Settings size={18} color={Colors.primary} />} label="Hall Settings" onPress={() => router.push('/(owner)/venue-setup' as any)} />
                    </View>
                </View>

                <View style={styles.menuSection}>
                    <Text style={styles.sectionLabel}>Support</Text>
                    <View style={styles.menuGroup}>
                        <MenuItem icon={<Bell size={18} color={Colors.primary} />} label="Notifications" onPress={() => router.push('/notifications' as any)} />
                        <MenuItem icon={<HelpCircle size={18} color={Colors.primary} />} label="Help & Support" onPress={() => router.push('/help' as any)} />
                        <MenuItem icon={<Shield size={18} color={Colors.primary} />} label="Privacy Policy" onPress={() => router.push('/privacy' as any)} />
                        <MenuItem icon={<FileText size={18} color={Colors.primary} />} label="Terms of Service" onPress={() => router.push('/terms' as any)} />
                    </View>
                </View>

                <View style={styles.menuSection}>
                    <View style={styles.menuGroup}>
                        <MenuItem icon={<LogOut size={18} color={Colors.error} />} label="Sign Out" onPress={handleLogout} destructive />
                    </View>
                </View>

                <Text style={styles.version}>ConventionHub Partner v1.0.0</Text>
                <View style={{ height: Spacing.massive }} />
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    headerGradient: { paddingBottom: Spacing.xxl },
    profileHeader: { alignItems: 'center', paddingTop: Spacing.lg, paddingHorizontal: Spacing.xl },
    avatarWrap: { position: 'relative', marginBottom: Spacing.md },
    avatar: {
        width: 76, height: 76, borderRadius: 38, justifyContent: 'center', alignItems: 'center',
        borderWidth: 3, borderColor: 'rgba(255,255,255,0.3)',
    },
    ownerBadge: {
        position: 'absolute', bottom: 0, right: 0, width: 24, height: 24, borderRadius: 12,
        backgroundColor: Colors.surface, justifyContent: 'center', alignItems: 'center',
        borderWidth: 2, borderColor: Colors.primary,
    },
    profileName: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: '#FFFFFF' },
    profileRole: { fontSize: FontSize.sm, color: 'rgba(255,255,255,0.7)', marginTop: Spacing.xxs, marginBottom: Spacing.xl },
    statsRow: {
        flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.15)',
        borderRadius: Radius.xl, paddingVertical: Spacing.lg, paddingHorizontal: Spacing.xxl, width: '100%',
    },
    statItem: { flex: 1, alignItems: 'center' },
    statNum: { fontSize: FontSize.xl, fontWeight: FontWeight.heavy, color: '#FFFFFF' },
    statLabel: { fontSize: FontSize.xs, color: 'rgba(255,255,255,0.7)', marginTop: Spacing.xxs },
    statDiv: { width: 1, backgroundColor: 'rgba(255,255,255,0.2)' },
    menuSection: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.xl },
    sectionLabel: {
        fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textTertiary,
        textTransform: 'uppercase' as const, letterSpacing: 1, marginBottom: Spacing.sm, paddingHorizontal: Spacing.sm,
    },
    menuGroup: { backgroundColor: Colors.surface, borderRadius: Radius.xl, overflow: 'hidden', ...Shadow.sm },
    menuItem: {
        flexDirection: 'row', alignItems: 'center', padding: Spacing.lg, gap: Spacing.md,
        borderBottomWidth: 1, borderBottomColor: Colors.borderLight,
    },
    menuIconBox: {
        width: 36, height: 36, borderRadius: Radius.md, backgroundColor: Colors.primaryFaded,
        justifyContent: 'center', alignItems: 'center',
    },
    menuIconDestructive: { backgroundColor: Colors.errorLight },
    menuLabel: { flex: 1, fontSize: FontSize.md, fontWeight: FontWeight.semibold, color: Colors.text },
    menuLabelDestructive: { color: Colors.error },
    version: { textAlign: 'center', color: Colors.textTertiary, fontSize: FontSize.xs, marginTop: Spacing.xxl },
});
