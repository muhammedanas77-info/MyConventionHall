import React, { useState, useMemo, useEffect } from 'react';
import {
    View, Text, StyleSheet, ScrollView, Dimensions, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { TrendingUp, TrendingDown, Wallet, CircleDollarSign, ArrowUpRight, ArrowDownRight, Clock, CheckCircle2, Ban } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { useAuth } from '@/providers/AuthProvider';
import { supabase } from '@/utils/supabase';
import { formatCurrencyFull, formatCurrencyCompact } from '@/utils/currency';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import Badge from '@/components/ui/Badge';
import { BarChart } from 'react-native-gifted-charts';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const SERIF_FONT = Platform.select({ ios: 'Georgia', android: 'serif', web: 'Georgia, serif', default: 'serif' });

type TabKey = 'overview' | 'payouts' | 'transactions';

export default function OwnerPayoutsScreen() {
    const [activeTab, setActiveTab] = useState<TabKey>('overview');
    const { user } = useAuth();

    const [monthlyEarnings, setMonthlyEarnings] = useState<{ month: string; amount: number }[]>([]);
    const [completedBookings, setCompletedBookings] = useState<any[]>([]);
    const [payoutHistory, setPayoutHistory] = useState<any[]>([]);
    const [stats, setStats] = useState({
        totalEarningsThisMonth: 0,
        lastMonthEarnings: 0,
    });

    useEffect(() => {
        const fetchData = async () => {
            if (!user) return;

            const { data: halls } = await supabase.from('halls').select('id').eq('owner_id', user.id);
            if (!halls || halls.length === 0) return;
            const hallIds = halls.map(h => h.id);

            const { data: allBookings } = await supabase
                .from('bookings')
                .select('*')
                .in('hall_id', hallIds)
                .order('event_date', { ascending: false });

            if (!allBookings) return;

            const now = new Date();
            const thisMonth = now.getMonth();
            const thisYear = now.getFullYear();
            const lastMonth = thisMonth === 0 ? 11 : thisMonth - 1;
            const lastMonthYear = thisMonth === 0 ? thisYear - 1 : thisYear;

            const sumAmount = (arr: any[]) => arr.reduce((s, b) => s + (b.total_amount ?? b.total_price ?? 0), 0);

            const thisMonthBookings = allBookings.filter(b => {
                const d = new Date(b.event_date ?? b.date);
                return d.getMonth() === thisMonth && d.getFullYear() === thisYear && b.status !== 'cancelled';
            });
            const lastMonthBookings = allBookings.filter(b => {
                const d = new Date(b.event_date ?? b.date);
                return d.getMonth() === lastMonth && d.getFullYear() === lastMonthYear && b.status !== 'cancelled';
            });

            setStats({
                totalEarningsThisMonth: sumAmount(thisMonthBookings),
                lastMonthEarnings: sumAmount(lastMonthBookings),
            });

            // Last 6 months earnings
            const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            const earnings: { month: string; amount: number }[] = [];
            for (let i = 5; i >= 0; i--) {
                const m = (thisMonth - i + 12) % 12;
                const y = thisMonth - i < 0 ? thisYear - 1 : thisYear;
                const monthTotal = allBookings
                    .filter(b => {
                        const d = new Date(b.event_date ?? b.date);
                        return d.getMonth() === m && d.getFullYear() === y && b.status !== 'cancelled';
                    })
                    .reduce((s, b) => s + (b.total_amount ?? b.total_price ?? 0), 0);
                earnings.push({ month: MONTH_NAMES[m], amount: monthTotal });
            }
            setMonthlyEarnings(earnings);

            setCompletedBookings(
                allBookings.filter(b => b.status === 'confirmed' || b.status === 'completed')
            );

            // Fetch payout history from commissions table
            const { data: commissions } = await supabase
                .from('commissions')
                .select('*')
                .eq('owner_id', user.id)
                .order('created_at', { ascending: false });

            setPayoutHistory(commissions ?? []);
        };

        fetchData();
    }, [user]);

    const growthPct = stats.lastMonthEarnings > 0
        ? Math.round(((stats.totalEarningsThisMonth - stats.lastMonthEarnings) / stats.lastMonthEarnings) * 100)
        : 0;
    const isPositiveGrowth = growthPct >= 0;

    const totalCommission = useMemo(() =>
        completedBookings.reduce((sum, b) => sum + (b.commission_amount ?? 0), 0), [completedBookings]
    );
    const totalEarnings = useMemo(() =>
        completedBookings.reduce((sum, b) => sum + (b.total_amount ?? b.total_price ?? 0), 0), [completedBookings]
    );
    const netPayout = totalEarnings - totalCommission;

    const barData = monthlyEarnings.map(item => ({
        value: item.amount,
        label: item.month,
        frontColor: Colors.primaryDark,
        gradientColor: Colors.primaryLight,
        topLabelComponent: () => (
            <Text style={{ color: Colors.textTertiary, fontSize: 8, marginBottom: 2, fontWeight: '700' as const }}>
                {formatCurrencyCompact(item.amount)}
            </Text>
        ),
    }));

    const tabs: { key: TabKey; label: string }[] = [
        { key: 'overview', label: 'Overview' },
        { key: 'payouts', label: 'Payouts' },
        { key: 'transactions', label: 'Transactions' },
    ];

    const getStatusIcon = (status: string) => {
        switch (status) {
            case 'completed': return <CheckCircle2 size={14} color={Colors.success} />;
            case 'pending': return <Clock size={14} color={Colors.warning} />;
            case 'cancelled': return <Ban size={14} color={Colors.error} />;
            default: return null;
        }
    };

    const formatDate = (dateStr: string) => {
        const d = new Date(dateStr);
        return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
    };

    return (
        <View style={styles.screen}>
            <LinearGradient colors={[Colors.primaryDark, Colors.primary]} style={styles.headerGradient}>
                <SafeAreaView edges={['top']}>
                    <View style={styles.headerContent}>
                        <View style={styles.headerBadge}>
                            <Text style={styles.headerBadgeText}>FINANCIAL OVERVIEW</Text>
                        </View>
                        <Text style={styles.headerTitle}>Payouts & Earnings</Text>
                        <Text style={styles.headerSubtitle}>Track your revenue, commissions, and payout history</Text>
                    </View>
                </SafeAreaView>
            </LinearGradient>

            <View style={styles.tabContainer}>
                {tabs.map(tab => (
                    <AnimatedPressable key={tab.key} onPress={() => setActiveTab(tab.key)} scaleValue={0.95}>
                        <View style={[styles.tab, activeTab === tab.key && styles.tabActive]}>
                            <Text style={[styles.tabText, activeTab === tab.key && styles.tabTextActive]}>{tab.label}</Text>
                        </View>
                    </AnimatedPressable>
                ))}
            </View>

            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
                {activeTab === 'overview' && (
                    <>
                        {/* Summary Cards */}
                        <View style={styles.summaryGrid}>
                            <View style={[styles.summaryCard, { borderLeftColor: Colors.primaryDark }]}>
                                <View style={[styles.summaryIconWrap, { backgroundColor: Colors.primaryFaded }]}>
                                    <Wallet size={20} color={Colors.primaryDark} />
                                </View>
                                <Text style={styles.summaryLabel}>NET PAYOUT</Text>
                                <Text style={styles.summaryAmount}>{formatCurrencyCompact(netPayout)}</Text>
                                <View style={styles.summaryGrowthRow}>
                                    {isPositiveGrowth ? <ArrowUpRight size={12} color={Colors.success} /> : <ArrowDownRight size={12} color={Colors.error} />}
                                    <Text style={[styles.summaryGrowth, { color: isPositiveGrowth ? Colors.success : Colors.error }]}>
                                        {isPositiveGrowth ? '+' : ''}{growthPct}%
                                    </Text>
                                </View>
                            </View>

                            <View style={[styles.summaryCard, { borderLeftColor: Colors.goldDark }]}>
                                <View style={[styles.summaryIconWrap, { backgroundColor: Colors.goldFaded }]}>
                                    <CircleDollarSign size={20} color={Colors.goldDark} />
                                </View>
                                <Text style={styles.summaryLabel}>COMMISSION</Text>
                                <Text style={styles.summaryAmount}>{formatCurrencyCompact(totalCommission)}</Text>
                                <Text style={styles.summarySubtext}>Platform fee (8%)</Text>
                            </View>
                        </View>

                        <View style={[styles.summaryCardFull]}>
                            <View style={styles.summaryFullRow}>
                                <View>
                                    <Text style={styles.summaryLabel}>THIS MONTH</Text>
                                    <Text style={[styles.summaryAmount, { fontSize: 28 }]}>
                                        {formatCurrencyFull(stats.totalEarningsThisMonth)}
                                    </Text>
                                </View>
                                <View style={styles.growthPill}>
                                    {isPositiveGrowth ? <TrendingUp size={14} color={Colors.success} /> : <TrendingDown size={14} color={Colors.error} />}
                                    <Text style={[styles.growthPillText, { color: isPositiveGrowth ? Colors.success : Colors.error }]}>
                                        {isPositiveGrowth ? '+' : ''}{growthPct}% vs last month
                                    </Text>
                                </View>
                            </View>
                        </View>

                        {/* Revenue Chart */}
                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>Revenue Trend</Text>
                            <View style={styles.chartWrapper}>
                                <BarChart
                                    data={barData}
                                    width={SCREEN_WIDTH - Spacing.xl * 2 - 40}
                                    height={180}
                                    barWidth={28}
                                    spacing={26}
                                    roundedTop
                                    roundedBottom
                                    xAxisThickness={0}
                                    yAxisThickness={0}
                                    hideYAxisText
                                    noOfSections={4}
                                    isAnimated
                                    animationDuration={1500}
                                />
                            </View>
                        </View>
                    </>
                )}

                {activeTab === 'payouts' && (
                    <View style={styles.section}>
                        <Text style={styles.sectionTitle}>Payout History</Text>
                        {payoutHistory.length === 0 ? (
                            <View style={{ padding: Spacing.xxl, alignItems: 'center' }}>
                                <Text style={{ color: Colors.textTertiary, fontSize: FontSize.sm }}>No payouts yet</Text>
                            </View>
                        ) : payoutHistory.map((payout, index) => (
                            <View key={payout.id} style={[styles.payoutCard, index === payoutHistory.length - 1 && { marginBottom: 0 }]}>
                                <View style={styles.payoutRow}>
                                    <View style={styles.payoutBody}>
                                        <View style={styles.payoutTop}>
                                            <Text style={styles.payoutAmount}>{formatCurrencyFull(payout.owner_payout ?? 0)}</Text>
                                            <Badge
                                                text={payout.status === 'paid' ? 'Paid' : payout.status === 'calculated' ? 'Calculated' : 'Pending'}
                                                variant={payout.status === 'paid' ? 'success' : 'warning'}
                                                size="sm"
                                            />
                                        </View>
                                        <Text style={styles.payoutDate}>{formatDate(payout.created_at)}</Text>
                                        <View style={styles.payoutDetails}>
                                            <Text style={styles.payoutRef}>Commission: {formatCurrencyFull(payout.admin_commission ?? 0)}</Text>
                                            <Text style={styles.payoutMethod}>Platform fee (8%)</Text>
                                        </View>
                                    </View>
                                </View>
                            </View>
                        ))}
                    </View>
                )}

                {activeTab === 'transactions' && (
                    <View style={styles.section}>
                        <Text style={styles.sectionTitle}>Booking Transactions</Text>
                        {completedBookings.length === 0 ? (
                            <View style={{ padding: Spacing.xxl, alignItems: 'center' }}>
                                <Text style={{ color: Colors.textTertiary, fontSize: FontSize.sm }}>No transactions yet</Text>
                            </View>
                        ) : completedBookings.map((booking, index) => (
                            <View key={booking.id} style={[styles.transactionCard, index === completedBookings.length - 1 && { marginBottom: 0 }]}>
                                <View style={styles.transactionRow}>
                                    <View style={[styles.transactionAccent, { backgroundColor: booking.status === 'completed' ? Colors.success : Colors.primary }]} />
                                    <View style={styles.transactionContent}>
                                        <View style={styles.transactionTop}>
                                            <Text style={styles.transactionName}>{booking.customer_name || 'Customer'}</Text>
                                            <Text style={styles.transactionAmount}>{formatCurrencyFull(booking.total_amount ?? booking.total_price ?? 0)}</Text>
                                        </View>
                                        <Text style={styles.transactionDate}>{formatDate(booking.event_date ?? booking.date)}</Text>
                                        <View style={styles.transactionFooter}>
                                            <View style={styles.transactionDetail}>
                                                <Text style={styles.transactionLabel}>Advance:</Text>
                                                <Text style={styles.transactionValue}>{formatCurrencyFull(booking.advance_amount ?? 0)}</Text>
                                            </View>
                                            <View style={styles.transactionDetail}>
                                                <Text style={styles.transactionLabel}>Commission:</Text>
                                                <Text style={[styles.transactionValue, { color: Colors.error }]}>-{formatCurrencyFull(booking.commission_amount ?? 0)}</Text>
                                            </View>
                                        </View>
                                    </View>
                                </View>
                            </View>
                        ))}
                    </View>
                )}

                <View style={{ height: Spacing.massive * 1.5 }} />
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    headerGradient: { paddingBottom: Spacing.xl, borderBottomLeftRadius: Radius.xxl, borderBottomRightRadius: Radius.xxl },
    headerContent: { paddingHorizontal: Spacing.xl, paddingTop: Spacing.xl, paddingBottom: Spacing.md },
    headerBadge: { alignSelf: 'flex-start', backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 6, marginBottom: Spacing.sm },
    headerBadgeText: { fontSize: 9, color: '#FFF', fontWeight: FontWeight.bold, letterSpacing: 1.5 },
    headerTitle: { fontSize: 26, fontWeight: FontWeight.heavy, color: '#FFFFFF', fontFamily: SERIF_FONT, marginBottom: 4 },
    headerSubtitle: { fontSize: FontSize.sm, color: 'rgba(255,255,255,0.75)', fontWeight: FontWeight.medium },
    tabContainer: { flexDirection: 'row', paddingHorizontal: Spacing.xl, paddingTop: Spacing.lg, paddingBottom: Spacing.sm, gap: Spacing.sm },
    tab: { paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm, borderRadius: Radius.full, backgroundColor: Colors.cream },
    tabActive: { backgroundColor: Colors.primaryDark },
    tabText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textSecondary },
    tabTextActive: { color: '#FFFFFF' },
    scrollContent: { padding: Spacing.xl },
    summaryGrid: { flexDirection: 'row', gap: Spacing.md },
    summaryCard: {
        flex: 1, backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.lg,
        ...Shadow.md, borderWidth: 1, borderColor: 'rgba(0,0,0,0.03)', borderLeftWidth: 4, gap: Spacing.xs,
    },
    summaryIconWrap: { width: 36, height: 36, borderRadius: 18, justifyContent: 'center', alignItems: 'center', marginBottom: Spacing.xs },
    summaryLabel: { fontSize: 10, fontWeight: FontWeight.bold, color: Colors.textTertiary, letterSpacing: 1 },
    summaryAmount: { fontSize: FontSize.xl, fontWeight: FontWeight.heavy, color: Colors.text },
    summaryGrowthRow: { flexDirection: 'row', alignItems: 'center', gap: 2 },
    summaryGrowth: { fontSize: FontSize.xs, fontWeight: FontWeight.bold },
    summarySubtext: { fontSize: FontSize.xs, color: Colors.textTertiary },
    summaryCardFull: {
        marginTop: Spacing.md, backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.xl,
        ...Shadow.md, borderWidth: 1, borderColor: 'rgba(0,0,0,0.03)',
    },
    summaryFullRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
    growthPill: {
        flexDirection: 'row', alignItems: 'center', gap: Spacing.xxs,
        backgroundColor: Colors.successLight, paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: Radius.full,
    },
    growthPillText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold },
    section: { marginTop: Spacing.xxl },
    sectionTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.primaryDark, marginBottom: Spacing.lg },
    chartWrapper: {
        alignItems: 'center', backgroundColor: Colors.surface, paddingTop: Spacing.xl, paddingBottom: Spacing.lg,
        paddingRight: Spacing.xl, borderRadius: Radius.xl, ...Shadow.md, borderWidth: 1, borderColor: 'rgba(0,0,0,0.03)',
    },
    payoutCard: {
        backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.lg, marginBottom: Spacing.md,
        ...Shadow.sm, borderWidth: 1, borderColor: 'rgba(0,0,0,0.03)',
    },
    payoutRow: { gap: Spacing.sm },
    payoutBody: { gap: Spacing.xs },
    payoutTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    payoutAmount: { fontSize: FontSize.lg, fontWeight: FontWeight.heavy, color: Colors.text },
    payoutDate: { fontSize: FontSize.sm, color: Colors.textTertiary, fontWeight: FontWeight.medium },
    payoutDetails: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: Spacing.xs, paddingTop: Spacing.sm, borderTopWidth: 1, borderTopColor: Colors.borderLight },
    payoutRef: { fontSize: FontSize.xs, color: Colors.textSecondary, fontWeight: FontWeight.bold, fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace' },
    payoutMethod: { fontSize: FontSize.xs, color: Colors.textTertiary },
    transactionCard: {
        backgroundColor: Colors.surface, borderRadius: Radius.xl, overflow: 'hidden', marginBottom: Spacing.md,
        ...Shadow.sm, borderWidth: 1, borderColor: 'rgba(0,0,0,0.03)',
    },
    transactionRow: { flexDirection: 'row' },
    transactionAccent: { width: 4 },
    transactionContent: { flex: 1, padding: Spacing.lg, gap: Spacing.xs },
    transactionTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    transactionName: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text },
    transactionAmount: { fontSize: FontSize.md, fontWeight: FontWeight.heavy, color: Colors.primaryDark },
    transactionDate: { fontSize: FontSize.xs, color: Colors.textTertiary, fontWeight: FontWeight.medium },
    transactionFooter: { flexDirection: 'row', justifyContent: 'space-between', marginTop: Spacing.sm, paddingTop: Spacing.sm, borderTopWidth: 1, borderTopColor: Colors.borderLight },
    transactionDetail: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xxs },
    transactionLabel: { fontSize: FontSize.xs, color: Colors.textTertiary },
    transactionValue: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.text },
});
