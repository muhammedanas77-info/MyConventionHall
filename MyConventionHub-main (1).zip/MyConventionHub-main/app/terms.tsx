import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, Stack } from 'expo-router';
import { FileText, ArrowLeft } from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

export default function TermsScreen() {
    const router = useRouter();

    return (
        <View style={styles.container}>
            <Stack.Screen options={{ headerShown: false }} />
            <SafeAreaView style={styles.safeArea}>
                <View style={styles.header}>
                    <AnimatedPressable onPress={() => router.back()} scaleValue={0.9}>
                        <ArrowLeft size={24} color={Colors.text} />
                    </AnimatedPressable>
                    <Text style={styles.title}>Terms of Service</Text>
                    <View style={{ width: 24 }} />
                </View>

                <ScrollView contentContainerStyle={styles.scrollContent}>
                    <View style={styles.hero}>
                        <FileText size={48} color={Colors.primary} />
                        <Text style={styles.heroTitle}>Terms of Service</Text>
                        <Text style={styles.heroSubtitle}>Last updated February 2026</Text>
                    </View>

                    <View style={styles.content}>
                        <Text style={styles.paragraph}>
                            By using ConventionHub, you agree to these terms. Please read them carefully before booking or listing a venue.
                        </Text>

                        <Text style={styles.sectionTitle}>1. Bookings & Payments</Text>
                        <Text style={styles.paragraph}>
                            All bookings require an advance payment of 30% of the total amount. The remaining balance is payable directly to the venue on the event day. Bookings are confirmed only after admin verification of your payment.
                        </Text>

                        <Text style={styles.sectionTitle}>2. Cancellations & Refunds</Text>
                        <Text style={styles.paragraph}>
                            Cancellations made 30 or more days before the event are eligible for a full refund of the advance. Cancellations between 15–29 days receive a 50% refund. Cancellations within 14 days are non-refundable.
                        </Text>

                        <Text style={styles.sectionTitle}>3. Venue Owners</Text>
                        <Text style={styles.paragraph}>
                            Venue partners must provide accurate information about their halls. ConventionHub charges an 8% platform commission on confirmed bookings. Listings are subject to admin approval before going live.
                        </Text>

                        <Text style={styles.sectionTitle}>4. User Conduct</Text>
                        <Text style={styles.paragraph}>
                            Users must not misuse the platform, provide false information, or attempt to circumvent the payment process. Violations may result in account suspension.
                        </Text>

                        <Text style={styles.sectionTitle}>5. Liability</Text>
                        <Text style={styles.paragraph}>
                            ConventionHub acts as a marketplace connecting customers and venue owners. We are not liable for disputes between parties, venue quality issues, or force majeure events.
                        </Text>

                        <Text style={styles.sectionTitle}>6. Contact</Text>
                        <Text style={styles.paragraph}>
                            For any questions about these terms, contact us at support@conventionhub.in
                        </Text>
                    </View>
                </ScrollView>
            </SafeAreaView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: Colors.background },
    safeArea: { flex: 1 },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: Spacing.xl,
        paddingVertical: Spacing.lg,
        backgroundColor: Colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: Colors.borderLight,
    },
    title: { fontSize: 18, fontWeight: FontWeight.bold, color: Colors.text },
    scrollContent: { paddingBottom: Spacing.massive },
    hero: {
        alignItems: 'center',
        paddingVertical: Spacing.massive,
        backgroundColor: Colors.surface,
        marginBottom: Spacing.lg,
    },
    heroTitle: { fontSize: 24, fontWeight: FontWeight.bold, color: Colors.text, marginTop: Spacing.md },
    heroSubtitle: { fontSize: FontSize.md, color: Colors.textTertiary, marginTop: Spacing.xs },
    content: { paddingHorizontal: Spacing.xl },
    sectionTitle: {
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: Colors.text,
        marginTop: Spacing.xl,
        marginBottom: Spacing.sm,
    },
    paragraph: { fontSize: FontSize.md, color: Colors.textSecondary, lineHeight: 24 },
});
