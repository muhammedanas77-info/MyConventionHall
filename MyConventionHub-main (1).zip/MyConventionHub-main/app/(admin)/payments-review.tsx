import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, Alert, Platform, Linking } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '@/providers/AuthProvider';
import { fetchPendingPayments, verifyPayment, rejectPayment } from '@/utils/payments';
import { supabase } from '@/utils/supabase';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { formatDateShort } from '@/utils/date';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import Badge from '@/components/ui/Badge';
import { CalendarDays, CheckCircle2, XCircle, FileText } from 'lucide-react-native';

export default function PaymentsReviewScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const loadPayments = useCallback(async () => {
    setLoading(true);
    const { data: payments, error } = await fetchPendingPayments();
    if (error) {
      console.error('Load payments error:', error);
      setItems([]);
      setLoading(false);
      return;
    }

    const bookingIds = payments?.map((payment: any) => payment.booking_id) ?? [];
    const { data: bookings } = await supabase
      .from('bookings')
      .select('id, hall_id, event_date, slot_type, customer_id, customer_name, customer_phone, customer_email, total_amount, advance_amount, status')
      .in('id', bookingIds);

    const hallIds = bookings?.map((booking: any) => booking.hall_id) ?? [];
    const { data: halls } = await supabase.from('halls').select('id, name').in('id', hallIds);

    const bookingsById = (bookings || []).reduce((acc: any, booking: any) => {
      acc[booking.id] = booking;
      return acc;
    }, {} as Record<string, any>);

    const hallsById = (halls || []).reduce((acc: any, hall: any) => {
      acc[hall.id] = hall;
      return acc;
    }, {} as Record<string, any>);

    setItems((payments || []).map((payment: any) => ({
      ...payment,
      booking: bookingsById[payment.booking_id],
      hall: hallsById[bookingsById[payment.booking_id]?.hall_id],
    })));
    setLoading(false);
  }, []);

  useEffect(() => {
    loadPayments();
  }, [loadPayments]);

  const handleVerify = async (paymentId: string) => {
    if (!user?.id) return;
    Alert.alert('Verify Payment', 'Mark this payment as verified?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Verify',
        onPress: async () => {
          setLoading(true);
          const result = await verifyPayment(paymentId, user.id);
          setLoading(false);
          if (!result.success) {
            Alert.alert('Error', result.error || 'Unable to verify payment.');
            return;
          }
          loadPayments();
        },
      },
    ]);
  };

  const handleReject = async (paymentId: string) => {
    if (!user?.id) return;
    Alert.alert('Reject Payment', 'Mark this payment as failed?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Reject',
        style: 'destructive',
        onPress: async () => {
          setLoading(true);
          const result = await rejectPayment(paymentId, user.id, 'Payment rejected by admin');
          setLoading(false);
          if (result.error) {
            Alert.alert('Error', result.error.message || 'Unable to reject payment.');
            return;
          }
          loadPayments();
        },
      },
    ]);
  };

  const renderItem = ({ item }: { item: any }) => {
    const booking = item.booking;
    const hallName = item.hall?.name ?? 'Unknown venue';
    return (
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <View>
            <Text style={styles.hallName}>{hallName}</Text>
            <Text style={styles.metaText}>{booking?.customer_name ?? booking?.customer_id ?? 'Customer'}</Text>
          </View>
          <Badge text={item.status === 'submitted' ? 'Review' : 'Pending'} variant={item.status === 'submitted' ? 'warning' : 'neutral'} size="sm" />
        </View>

        <View style={styles.row}>
          <CalendarDays size={14} color={Colors.textTertiary} />
          <Text style={styles.rowText}>{booking?.event_date ? new Date(booking.event_date).toLocaleDateString('en-IN') : '—'}</Text>
        </View>
        <View style={styles.row}>
          <FileText size={14} color={Colors.textTertiary} />
          <Text style={styles.rowText}>{booking?.slot_type ?? '—'}</Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.currencyLabel}>Advance</Text>
          <Text style={styles.currencyValue}>₹{item.advance_amount?.toLocaleString('en-IN')}</Text>
        </View>

        {item.verification_screenshot_url && (
          <AnimatedPressable 
            onPress={() => Linking.openURL(item.verification_screenshot_url)} 
            scaleValue={0.96}
            style={styles.proofContainer}
          >
            <View style={styles.proofButton}>
              <FileText size={16} color={Colors.primaryDark} />
              <Text style={styles.proofButtonText}>View Payment Screenshot</Text>
            </View>
          </AnimatedPressable>
        )}

        <View style={styles.actionRow}>
          <AnimatedPressable onPress={() => handleVerify(item.id)} scaleValue={0.96}>
            <View style={styles.verifyButton}>
              <CheckCircle2 size={16} color="#FFFFFF" />
              <Text style={styles.verifyText}>Verify</Text>
            </View>
          </AnimatedPressable>
          <AnimatedPressable onPress={() => handleReject(item.id)} scaleValue={0.96}>
            <View style={styles.rejectButton}>
              <XCircle size={16} color={Colors.error} />
              <Text style={styles.rejectText}>Reject</Text>
            </View>
          </AnimatedPressable>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.screen}>
      <SafeAreaView edges={['top']} style={styles.safeArea}>
        <View style={styles.header}>
          <Text style={styles.title}>Payment Reviews</Text>
          <Text style={styles.subtitle}>Verify customer payments and confirm bookings.</Text>
        </View>

        <FlatList
          data={items}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={(
            <View style={styles.emptyState}>
              <Text style={styles.emptyTitle}>No pending payments</Text>
              <Text style={styles.emptySubtitle}>All payments are up to date.</Text>
            </View>
          )}
          refreshing={loading}
          onRefresh={loadPayments}
        />
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background },
  safeArea: { flex: 1 },
  header: { paddingHorizontal: Spacing.xl, paddingBottom: Spacing.lg, backgroundColor: Colors.surface, borderBottomWidth: 1, borderColor: Colors.borderLight, ...Shadow.sm },
  title: { fontSize: FontSize.xxxl, fontWeight: FontWeight.heavy, color: Colors.text, marginBottom: Spacing.xs },
  subtitle: { fontSize: FontSize.sm, color: Colors.textSecondary },
  listContent: { padding: Spacing.xl, paddingBottom: Spacing.massive },
  card: { backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.lg, marginBottom: Spacing.lg, ...Shadow.sm, borderWidth: 1, borderColor: Colors.borderLight },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.md },
  hallName: { fontSize: FontSize.lg, fontWeight: FontWeight.heavy, color: Colors.text },
  metaText: { fontSize: FontSize.sm, color: Colors.textSecondary, marginTop: Spacing.xs },
  row: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, marginBottom: Spacing.sm },
  rowText: { color: Colors.textSecondary, fontSize: FontSize.sm },
  currencyLabel: { flex: 1, color: Colors.textSecondary, fontSize: FontSize.sm },
  currencyValue: { color: Colors.text, fontWeight: FontWeight.bold, fontSize: FontSize.sm },
  proofContainer: { marginTop: Spacing.md, marginBottom: Spacing.sm },
  proofButton: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, backgroundColor: Colors.cream, padding: Spacing.md, borderRadius: Radius.lg, borderStyle: 'dashed', borderWidth: 1, borderColor: Colors.primaryDark },
  proofButtonText: { color: Colors.primaryDark, fontWeight: FontWeight.bold, fontSize: FontSize.sm },
  actionRow: { flexDirection: 'row', gap: Spacing.sm, marginTop: Spacing.md },
  verifyButton: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.xs, backgroundColor: Colors.success, paddingVertical: Spacing.sm, borderRadius: Radius.full },
  verifyText: { color: '#FFFFFF', fontWeight: FontWeight.bold },
  rejectButton: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.xs, borderWidth: 1, borderColor: Colors.error, paddingVertical: Spacing.sm, borderRadius: Radius.full },
  rejectText: { color: Colors.error, fontWeight: FontWeight.bold },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: Spacing.massive },
  emptyTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  emptySubtitle: { fontSize: FontSize.sm, color: Colors.textSecondary, marginTop: Spacing.sm, textAlign: 'center' },
});
