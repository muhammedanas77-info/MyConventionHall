import { Tabs } from 'expo-router';
import { LayoutDashboard, CalendarDays, CheckSquare, DollarSign, ReceiptText, Wallet, Users, BookOpen, BellOff } from 'lucide-react-native';
import React, { useEffect } from 'react';
import { Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { Colors } from '@/constants/theme';
import { useAuth } from '@/providers/AuthProvider';
import { useApp } from '@/providers/AppProvider';

export default function AdminTabLayout() {
    const { role: supabaseRole, isLoading, user } = useAuth();
    const { userRole: localRole } = useApp();
    const router = useRouter();

    // Accept admin from either Supabase session OR local biometric login
    const isAdmin = supabaseRole === 'admin' || localRole === 'admin';

    useEffect(() => {
        if (isLoading) return;
        if (!isAdmin) {
            router.replace('/role-select' as any);
        }
    }, [isAdmin, isLoading, router]);

    if (isLoading || !isAdmin) return null;

    return (
        <Tabs
            screenOptions={{
                tabBarActiveTintColor: Colors.primary,
                tabBarInactiveTintColor: Colors.textTertiary,
                tabBarStyle: {
                    backgroundColor: Colors.surface,
                    borderTopColor: Colors.borderLight,
                    borderTopWidth: 1,
                    ...(Platform.OS === 'web' ? { height: 60 } : {}),
                },
                tabBarLabelStyle: {
                    fontSize: 11,
                    fontWeight: '600' as const,
                },
                headerShown: false,
            }}
        >
            <Tabs.Screen
                name="admin-dashboard"
                options={{
                    title: 'Dashboard',
                    tabBarIcon: ({ color, size }) => <LayoutDashboard size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="admin-bookings"
                options={{
                    title: 'Bookings',
                    tabBarIcon: ({ color, size }) => <CalendarDays size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="approvals"
                options={{
                    title: 'Approvals',
                    tabBarIcon: ({ color, size }) => <CheckSquare size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="payments-review"
                options={{
                    title: 'Payments',
                    tabBarIcon: ({ color, size }) => <ReceiptText size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="commissions"
                options={{
                    title: 'Revenue',
                    tabBarIcon: ({ color, size }) => <DollarSign size={size} color={color} />,
                }}
            />
            {/* Payouts screen — accessible via navigation, not shown in tab bar */}
            <Tabs.Screen
                name="payouts"
                options={{
                    title: 'Payouts',
                    tabBarIcon: ({ color, size }) => <Wallet size={size} color={color} />,
                    href: null,
                }}
            />
            {/* Sector Revenue screen — accessible via navigation, not shown in tab bar */}
            <Tabs.Screen
                name="sector-revenue"
                options={{
                    title: 'Sector Revenue',
                    tabBarIcon: ({ color, size }) => <DollarSign size={size} color={color} />,
                    href: null,
                }}
            />
            {/* Service Listings screen — accessible via navigation, not shown in tab bar */}
            <Tabs.Screen
                name="service-listings"
                options={{
                    title: 'Service Listings',
                    tabBarIcon: ({ color, size }) => <LayoutDashboard size={size} color={color} />,
                    href: null,
                }}
            />
            {/* Vendors screen — accessible via navigation, not shown in tab bar */}
            <Tabs.Screen
                name="vendors"
                options={{
                    title: 'Vendors',
                    tabBarIcon: ({ color, size }) => <Users size={size} color={color} />,
                    href: null,
                }}
            />
            {/* Service Bookings screen — accessible via navigation, not shown in tab bar */}
            <Tabs.Screen
                name="service-bookings"
                options={{
                    title: 'Service Bookings',
                    tabBarIcon: ({ color, size }) => <BookOpen size={size} color={color} />,
                    href: null,
                }}
            />
            {/* Vendor detail screen — accessible via navigation, not shown in tab bar */}
            <Tabs.Screen
                name="vendor/[id]"
                options={{
                    title: 'Vendor Detail',
                    tabBarIcon: ({ color, size }) => <Users size={size} color={color} />,
                    href: null,
                }}
            />
        </Tabs>
    );
}
