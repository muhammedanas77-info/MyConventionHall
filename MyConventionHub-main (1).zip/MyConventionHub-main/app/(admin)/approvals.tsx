import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
    View, Text, StyleSheet, FlatList, Animated, Alert, Platform, Linking, ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import {
    CheckCircle2, XCircle, ShieldCheck, MapPin, Users, Phone, MessageCircle, Clock,
} from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { formatCurrencyFull } from '@/utils/currency';
import { formatTimeAgo } from '@/utils/date';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import Badge from '@/components/ui/Badge';
import type { Hall } from '@/types';

function PendingHallCard({ hall, index, onApprove, onReject }: {
    hall: Hall; index: number; onApprove: (id: string) => void; onReject: (id: string) => void;
}) {
    const entryAnim = useRef(new Animated.Value(0)).current;
    const daysWaiting = Math.max(1, Math.floor((Date.now() - new Date(hall.created_at).getTime()) / 86400000));

    useEffect(() => {
        Animated.spring(entryAnim, {
            toValue: 1, delay: index * 100, useNativeDriver: true, speed: 14, bounciness: 3,
        }).start();
    }, []);

    return (
        <Animated.View style={[styles.pendingCard, {
            opacity: entryAnim,
            transform: [{ translateY: entryAnim.interpolate({ inputRange: [0, 1], outputRange: [40, 0] }) }],
        }]}>
            <Image source={{ uri: hall.photos[0] }} style={styles.hallImage} contentFit="cover" transition={200} />
            <View style={styles.cardBody}>
                <View style={styles.cardHeader}>
                    <Text style={styles.hallName}>{hall.name}</Text>
                    <View style={styles.waitBadge}>
                        <Clock size={10} color={Colors.warning} />
                        <Text style={styles.waitText}>{daysWaiting}d waiting</Text>
                    </View>
                </View>

                <View style={styles.detailRow}>
                    <MapPin size={12} color={Colors.textTertiary} />
                    <Text style={styles.detailText}>{hall.area}, {hall.city}</Text>
                </View>
                <View style={styles.detailRow}>
                    <Users size={12} color={Colors.textTertiary} />
                    <Text style={styles.detailText}>{hall.capacity_min}-{hall.capacity_max} guests</Text>
                </View>
                <Text style={styles.priceText}>{formatCurrencyFull(hall.price_per_day)}/day</Text>

                <View style={styles.amenitiesList}>
                    {hall.amenities.slice(0, 5).map(a => (
                        <View key={a} style={styles.amenityChip}>
                            <Text style={styles.amenityText}>{a}</Text>
                        </View>
                    ))}
                    {hall.amenities.length > 5 && (
                        <View style={styles.amenityChip}>
                            <Text style={styles.amenityText}>+{hall.amenities.length - 5}</Text>
                        </View>
                    )}
                </View>

                <View style={styles.actionButtons}>
                    <AnimatedPressable onPress={() => onApprove(hall.id)} scaleValue={0.95} testID={`approve-${hall.id}`}>
                        <View style={styles.approveButton}>
                            <CheckCircle2 size={16} color="#FFFFFF" />
                            <Text style={styles.approveText}>Approve</Text>
                        </View>
                    </AnimatedPressable>
                    <AnimatedPressable onPress={() => onReject(hall.id)} scaleValue={0.95}>
                        <View style={styles.rejectButton}>
                            <XCircle size={16} color={Colors.error} />
                            <Text style={styles.rejectText}>Reject</Text>
                        </View>
                    </AnimatedPressable>
                    <AnimatedPressable onPress={() => onApprove(hall.id)} scaleValue={0.95}>
                        <View style={styles.verifyButton}>
                            <ShieldCheck size={16} color={Colors.gold} />
                            <Text style={styles.verifyText}>Approve & Verify</Text>
                        </View>
                    </AnimatedPressable>
                </View>
            </View>
        </Animated.View>
    );
}

export default function ApprovalsScreen() {
    const [activeTab, setActiveTab] = useState<'pending' | 'approved'>('pending');
    const [pendingHalls, setPendingHalls] = useState<Hall[]>([]);
    const [approvedHalls, setApprovedHalls] = useState<Hall[]>([]);

    const loadHalls = useCallback(async () => {
        const { data: pending } = await supabase
            .from('halls')
            .select('*')
            .eq('is_approved', false)
            .order('created_at', { ascending: false });
        const { data: approved } = await supabase
            .from('halls')
            .select('*')
            .eq('is_approved', true)
            .order('created_at', { ascending: false });
        setPendingHalls((pending || []) as Hall[]);
        setApprovedHalls((approved || []) as Hall[]);
    }, []);

    useEffect(() => {
        loadHalls();
    }, [loadHalls]);

    const handleApprove = useCallback((id: string) => {
        Alert.alert('Approve Hall', 'Are you sure you want to approve this hall?', [
            { text: 'Cancel', style: 'cancel' },
            {
                text: 'Approve', onPress: async () => {
                    const { error } = await supabase.from('halls').update({ is_approved: true }).eq('id', id);
                    if (error) {
                        Alert.alert('Unable to approve', error.message);
                        return;
                    }
                    if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                    loadHalls();
                },
            },
        ]);
    }, [loadHalls]);

    const handleReject = useCallback((id: string) => {
        Alert.alert('Reject Hall', 'Please confirm rejection. The owner will be notified.', [
            { text: 'Cancel', style: 'cancel' },
            {
                text: 'Reject', style: 'destructive', onPress: async () => {
                    const { error } = await supabase.from('halls').delete().eq('id', id);
                    if (error) {
                        Alert.alert('Unable to reject', error.message);
                        return;
                    }
                    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                    loadHalls();
                },
            },
        ]);
    }, [loadHalls]);

    return (
        <View style={styles.screen}>
            <SafeAreaView edges={['top']} style={styles.header}>
                <View style={styles.adminBadge}>
                    <Text style={styles.adminBadgeText}>ADMIN ROOT</Text>
                </View>
                <Text style={styles.title}>Hall Approvals</Text>
                <View style={styles.tabBar}>
                    <AnimatedPressable onPress={() => setActiveTab('pending')} scaleValue={0.95}>
                        <View style={[styles.tab, activeTab === 'pending' && styles.tabActive]}>
                            <Text style={[styles.tabText, activeTab === 'pending' && styles.tabTextActive]}>
                                Pending ({pendingHalls.length})
                            </Text>
                        </View>
                    </AnimatedPressable>
                    <AnimatedPressable onPress={() => setActiveTab('approved')} scaleValue={0.95}>
                        <View style={[styles.tab, activeTab === 'approved' && styles.tabActive]}>
                            <Text style={[styles.tabText, activeTab === 'approved' && styles.tabTextActive]}>
                                Approved ({approvedHalls.length})
                            </Text>
                        </View>
                    </AnimatedPressable>
                </View>
            </SafeAreaView>

            {activeTab === 'pending' ? (
                <FlatList
                    data={pendingHalls}
                    renderItem={({ item, index }) => (
                        <PendingHallCard hall={item} index={index} onApprove={handleApprove} onReject={handleReject} />
                    )}
                    keyExtractor={(item) => item.id}
                    contentContainerStyle={styles.listContent}
                    showsVerticalScrollIndicator={false}
                    ListEmptyComponent={
                        <View style={styles.emptyContainer}>
                            <CheckCircle2 size={48} color={Colors.success} />
                            <Text style={styles.emptyTitle}>All clear!</Text>
                            <Text style={styles.emptySubtitle}>No pending approvals at the moment</Text>
                        </View>
                    }
                />
            ) : (
                <FlatList
                    data={approvedHalls}
                    renderItem={({ item }) => (
                        <View style={styles.approvedRow}>
                            <Image source={{ uri: item.photos[0] }} style={styles.approvedThumb} contentFit="cover" />
                            <View style={styles.approvedInfo}>
                                <Text style={styles.approvedName} numberOfLines={1}>{item.name}</Text>
                                <Text style={styles.approvedMeta}>{item.area} · {formatCurrencyFull(item.price_per_day)}</Text>
                            </View>
                            <View style={styles.approvedBadges}>
                                {item.is_verified && <Badge text="Verified" variant="success" size="sm" />}
                                {item.is_featured && <Badge text="Featured" variant="gold" size="sm" />}
                            </View>
                        </View>
                    )}
                    keyExtractor={(item) => item.id}
                    contentContainerStyle={styles.listContent}
                    showsVerticalScrollIndicator={false}
                />
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    header: {
        paddingHorizontal: Spacing.xl, paddingBottom: Spacing.xl,
        backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.borderLight, ...Shadow.sm
    },
    adminBadge: { alignSelf: 'flex-start', backgroundColor: Colors.primaryDark, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, marginBottom: Spacing.sm },
    adminBadgeText: { fontSize: 10, color: '#FFFFFF', fontWeight: FontWeight.bold, letterSpacing: 1 },
    title: { fontSize: FontSize.xxxl, fontWeight: FontWeight.heavy, color: Colors.text, marginBottom: Spacing.lg },
    tabBar: { flexDirection: 'row', gap: Spacing.sm },
    tab: { paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md, borderRadius: Radius.full, backgroundColor: Colors.cream },
    tabActive: { backgroundColor: Colors.primaryDark },
    tabText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textSecondary },
    tabTextActive: { color: '#FFFFFF' },
    listContent: { padding: Spacing.xl, paddingBottom: Spacing.massive },
    pendingCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, overflow: 'hidden', marginBottom: Spacing.xl, borderWidth: 1, borderColor: Colors.borderLight, ...Shadow.md },
    hallImage: { width: '100%', height: 200 },
    cardBody: { padding: Spacing.xl, gap: Spacing.md },
    cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
    hallName: { fontSize: FontSize.xl, fontWeight: FontWeight.heavy, color: Colors.primaryDark, flex: 1, marginRight: Spacing.sm },
    waitBadge: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xxs, backgroundColor: Colors.warningLight, paddingHorizontal: Spacing.sm, paddingVertical: Spacing.xs, borderRadius: Radius.full },
    waitText: { fontSize: FontSize.sm, color: Colors.warning, fontWeight: FontWeight.bold },
    detailRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
    detailText: { fontSize: FontSize.sm, color: Colors.textSecondary, fontWeight: FontWeight.medium },
    priceText: { fontSize: FontSize.lg, fontWeight: FontWeight.heavy, color: Colors.text },
    amenitiesList: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xs, marginTop: Spacing.xs },
    amenityChip: { backgroundColor: Colors.cream, paddingHorizontal: Spacing.sm, paddingVertical: Spacing.xxs, borderRadius: Radius.md },
    amenityText: { fontSize: FontSize.xs, color: Colors.textSecondary, fontWeight: FontWeight.semibold },
    actionButtons: { flexDirection: 'row', gap: Spacing.md, marginTop: Spacing.lg, flexWrap: 'wrap', borderTopWidth: 1, borderTopColor: Colors.borderLight, paddingTop: Spacing.lg },
    approveButton: {
        flexDirection: 'row', alignItems: 'center', gap: Spacing.xs,
        backgroundColor: Colors.success, paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md, borderRadius: Radius.lg, ...Shadow.sm
    },
    approveText: { color: '#FFFFFF', fontSize: FontSize.md, fontWeight: FontWeight.bold },
    rejectButton: {
        flexDirection: 'row', alignItems: 'center', gap: Spacing.xs,
        borderWidth: 1, borderColor: Colors.error, paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md, borderRadius: Radius.lg,
    },
    rejectText: { color: Colors.error, fontSize: FontSize.md, fontWeight: FontWeight.bold },
    verifyButton: {
        flexDirection: 'row', alignItems: 'center', gap: Spacing.xs,
        backgroundColor: Colors.goldDark, borderWidth: 0,
        paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md, borderRadius: Radius.lg, ...Shadow.sm
    },
    verifyText: { color: '#FFFFFF', fontSize: FontSize.md, fontWeight: FontWeight.bold },
    emptyContainer: { alignItems: 'center', paddingTop: Spacing.massive * 2, gap: Spacing.lg },
    emptyTitle: { fontSize: FontSize.xxl, fontWeight: FontWeight.heavy, color: Colors.text },
    emptySubtitle: { fontSize: FontSize.md, color: Colors.textTertiary },
    approvedRow: {
        flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.surface,
        borderRadius: Radius.xl, padding: Spacing.lg, gap: Spacing.lg, marginBottom: Spacing.md, ...Shadow.sm, borderWidth: 1, borderColor: Colors.borderLight
    },
    approvedThumb: { width: 64, height: 64, borderRadius: Radius.md },
    approvedInfo: { flex: 1 },
    approvedName: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: 4 },
    approvedMeta: { fontSize: FontSize.sm, color: Colors.textTertiary, fontWeight: FontWeight.medium },
    approvedBadges: { flexDirection: 'row', gap: Spacing.xs },
});
