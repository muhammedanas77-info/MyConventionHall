/**
 * app/(admin)/service-listings.tsx
 *
 * Cross-sector service listing management for admins.
 *
 * Requirements: 8.5, 8.6, 8.9
 *
 * Key behaviours:
 *  - Deactivate: sets is_active = false; shows a warning with the count of
 *    pending/confirmed bookings before confirming.
 *  - Permanent delete: pre-flight checks active-booking count; if > 0 skips
 *    deletion and reports "deletion skipped: active bookings exist" with count;
 *    if the count query errors, falls back to the most recent successful count
 *    and labels the outcome with a "cached count" notice.
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Alert,
  Platform,
  TextInput,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import {
  List,
  Search,
  ToggleLeft,
  ToggleRight,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Tag,
  DollarSign,
  Star,
} from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { formatCurrencyFull } from '@/utils/currency';
import { SECTOR_LIST, SECTOR_CONFIGS } from '@/constants/sectors';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import type { ServiceListing, VendorSector } from '@/types';

// ─── Types ────────────────────────────────────────────────────────────────────

interface ListingRow extends ServiceListing {
  vendor?: { business_name: string | null; profile?: { email: string } | null };
}

type SectorFilter = VendorSector | 'all';
type ActiveFilter = 'all' | 'active' | 'inactive';

// ─── Helpers ──────────────────────────────────────────────────────────────────

const PRICE_UNIT_LABELS: Record<string, string> = {
  per_event: '/ event',
  per_plate: '/ plate',
  per_hour: '/ hour',
  per_day: '/ day',
};

function SectorBadge({ sector }: { sector: VendorSector }) {
  const cfg = SECTOR_CONFIGS[sector];
  return (
    <View style={[styles.sectorBadge, { backgroundColor: cfg.badgeColor + '22' }]}>
      <Text style={[styles.sectorBadgeText, { color: cfg.badgeColor }]}>
        {cfg.displayName}
      </Text>
    </View>
  );
}

// ─── Main screen ──────────────────────────────────────────────────────────────

export default function AdminServiceListingsScreen() {
  const [listings, setListings] = useState<ListingRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  // Filters
  const [sectorFilter, setSectorFilter] = useState<SectorFilter>('all');
  const [activeFilter, setActiveFilter] = useState<ActiveFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Per-listing cached active-booking counts (used as fallback when count query errors)
  const cachedBookingCounts = useRef<Record<string, number>>({});

  // ── Data fetching ──────────────────────────────────────────────────────────

  const fetchListings = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    else setLoading(true);

    let query = supabase
      .from('service_listings')
      .select(
        `id, vendor_id, sector, title, description, base_price, price_unit,
         photos, tags, packages, is_active, rating, total_reviews, created_at,
         vendor:vendor_profiles(business_name, profile:profiles(email))`
      )
      .order('created_at', { ascending: false });

    if (sectorFilter !== 'all') {
      query = query.eq('sector', sectorFilter);
    }
    if (activeFilter === 'active') {
      query = query.eq('is_active', true);
    } else if (activeFilter === 'inactive') {
      query = query.eq('is_active', false);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Admin fetch service listings error:', error);
    } else {
      setListings((data ?? []) as unknown as ListingRow[]);
    }

    if (isRefresh) setRefreshing(false);
    else setLoading(false);
  }, [sectorFilter, activeFilter]);

  useEffect(() => {
    fetchListings();
  }, [fetchListings]);

  // ── Active-booking count helper ────────────────────────────────────────────

  /**
   * Returns the count of pending/confirmed bookings for a listing.
   * On success, updates the cache. On error, returns null.
   */
  const fetchActiveBookingCount = useCallback(
    async (listingId: string): Promise<number | null> => {
      const { count, error } = await supabase
        .from('service_bookings')
        .select('id', { count: 'exact', head: true })
        .eq('listing_id', listingId)
        .in('status', ['pending', 'confirmed']);

      if (error) {
        console.warn('Active booking count query error:', error.message);
        return null;
      }

      const result = count ?? 0;
      cachedBookingCounts.current[listingId] = result;
      return result;
    },
    []
  );

  // ── Deactivate ─────────────────────────────────────────────────────────────

  const handleDeactivate = useCallback(
    async (listing: ListingRow) => {
      if (!listing.is_active) return; // already inactive

      // Fetch active booking count for the warning (Req 8.5)
      const count = await fetchActiveBookingCount(listing.id);
      const displayCount = count ?? cachedBookingCounts.current[listing.id] ?? 0;

      const warningMessage =
        displayCount > 0
          ? `This listing has ${displayCount} active booking${displayCount !== 1 ? 's' : ''} (pending or confirmed). Deactivating will hide it from customers but will NOT cancel existing bookings.\n\nProceed?`
          : 'This listing has no active bookings. Deactivate it?';

      Alert.alert(
        'Deactivate Listing',
        warningMessage,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Deactivate',
            style: 'destructive',
            onPress: async () => {
              const { error } = await supabase
                .from('service_listings')
                .update({ is_active: false })
                .eq('id', listing.id);

              if (error) {
                Alert.alert('Error', `Could not deactivate listing: ${error.message}`);
                return;
              }

              if (Platform.OS !== 'web') {
                Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              }
              fetchListings();
            },
          },
        ]
      );
    },
    [fetchActiveBookingCount, fetchListings]
  );

  // ── Reactivate ─────────────────────────────────────────────────────────────

  const handleReactivate = useCallback(
    async (listing: ListingRow) => {
      Alert.alert(
        'Reactivate Listing',
        `Reactivate "${listing.title}"? It will become visible to customers again.`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Reactivate',
            onPress: async () => {
              const { error } = await supabase
                .from('service_listings')
                .update({ is_active: true })
                .eq('id', listing.id);

              if (error) {
                Alert.alert('Error', `Could not reactivate listing: ${error.message}`);
                return;
              }

              if (Platform.OS !== 'web') {
                Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              }
              fetchListings();
            },
          },
        ]
      );
    },
    [fetchListings]
  );

  // ── Permanent delete ───────────────────────────────────────────────────────

  const handleDelete = useCallback(
    async (listing: ListingRow) => {
      Alert.alert(
        'Delete Listing',
        `Permanently delete "${listing.title}"? This cannot be undone.`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Delete',
            style: 'destructive',
            onPress: async () => {
              // Pre-flight: check active booking count (Req 8.6)
              const liveCount = await fetchActiveBookingCount(listing.id);
              const isCached = liveCount === null;
              const effectiveCount =
                liveCount ?? cachedBookingCounts.current[listing.id] ?? 0;

              if (effectiveCount > 0) {
                // Deletion skipped — report outcome with count (Req 8.6)
                const cachedNotice = isCached ? ' (cached count)' : '';
                Alert.alert(
                  'Deletion Skipped',
                  `deletion skipped: active bookings exist\n\n${effectiveCount} active booking${effectiveCount !== 1 ? 's' : ''} found${cachedNotice}. Remove or cancel all active bookings before deleting this listing.`
                );
                return;
              }

              // Safe to delete
              const { error } = await supabase
                .from('service_listings')
                .delete()
                .eq('id', listing.id);

              if (error) {
                // Postgres FK violation means bookings exist despite count = 0
                // (race condition). Treat as "active bookings exist".
                if (
                  error.code === '23503' ||
                  error.message?.toLowerCase().includes('foreign key')
                ) {
                  Alert.alert(
                    'Deletion Skipped',
                    'deletion skipped: active bookings exist\n\nA booking was created between the count check and the delete. Please retry.'
                  );
                } else {
                  Alert.alert('Error', `Could not delete listing: ${error.message}`);
                }
                return;
              }

              if (Platform.OS !== 'web') {
                Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              }
              Alert.alert('Deleted', `"${listing.title}" has been permanently deleted.`);
              fetchListings();
            },
          },
        ]
      );
    },
    [fetchActiveBookingCount, fetchListings]
  );

  // ── Filtered list ──────────────────────────────────────────────────────────

  const filteredListings = React.useMemo(() => {
    if (!searchQuery.trim()) return listings;
    const q = searchQuery.toLowerCase();
    return listings.filter(
      (l) =>
        l.title.toLowerCase().includes(q) ||
        (l.description ?? '').toLowerCase().includes(q) ||
        l.tags.some((t) => t.toLowerCase().includes(q))
    );
  }, [listings, searchQuery]);

  // ── Render item ────────────────────────────────────────────────────────────

  const renderItem = useCallback(
    ({ item }: { item: ListingRow }) => {
      const vendorName =
        item.vendor?.business_name ?? item.vendor?.profile?.email ?? 'Unknown vendor';
      const priceLabel = PRICE_UNIT_LABELS[item.price_unit] ?? '';

      return (
        <View style={[styles.card, !item.is_active && styles.cardInactive]}>
          {/* Header row */}
          <View style={styles.cardHeader}>
            <View style={styles.cardTitleGroup}>
              <Text style={styles.cardTitle} numberOfLines={2}>
                {item.title}
              </Text>
              <Text style={styles.cardVendor} numberOfLines={1}>
                {vendorName}
              </Text>
            </View>
            <View style={styles.cardBadges}>
              <SectorBadge sector={item.sector as VendorSector} />
              <View
                style={[
                  styles.statusBadge,
                  item.is_active ? styles.statusActive : styles.statusInactive,
                ]}
              >
                {item.is_active ? (
                  <CheckCircle2 size={10} color={Colors.success} />
                ) : (
                  <XCircle size={10} color={Colors.textTertiary} />
                )}
                <Text
                  style={[
                    styles.statusText,
                    { color: item.is_active ? Colors.success : Colors.textTertiary },
                  ]}
                >
                  {item.is_active ? 'Active' : 'Inactive'}
                </Text>
              </View>
            </View>
          </View>

          {/* Price + rating row */}
          <View style={styles.metaRow}>
            <View style={styles.metaItem}>
              <DollarSign size={12} color={Colors.textTertiary} />
              <Text style={styles.metaText}>
                {formatCurrencyFull(item.base_price)}
                {priceLabel}
              </Text>
            </View>
            {item.rating != null && (
              <View style={styles.metaItem}>
                <Star size={12} color={Colors.gold} />
                <Text style={styles.metaText}>
                  {item.rating.toFixed(1)} ({item.total_reviews})
                </Text>
              </View>
            )}
          </View>

          {/* Tags */}
          {item.tags.length > 0 && (
            <View style={styles.tagsRow}>
              <Tag size={11} color={Colors.textTertiary} />
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <View style={styles.tagsInner}>
                  {item.tags.slice(0, 6).map((tag) => (
                    <View key={tag} style={styles.tagChip}>
                      <Text style={styles.tagText}>{tag}</Text>
                    </View>
                  ))}
                  {item.tags.length > 6 && (
                    <View style={styles.tagChip}>
                      <Text style={styles.tagText}>+{item.tags.length - 6}</Text>
                    </View>
                  )}
                </View>
              </ScrollView>
            </View>
          )}

          {/* Action buttons */}
          <View style={styles.actionRow}>
            {/* Toggle active / inactive */}
            <AnimatedPressable
              onPress={() =>
                item.is_active ? handleDeactivate(item) : handleReactivate(item)
              }
              scaleValue={0.95}
              style={styles.actionBtnWrapper}
            >
              <View
                style={[
                  styles.actionBtn,
                  item.is_active ? styles.deactivateBtn : styles.reactivateBtn,
                ]}
              >
                {item.is_active ? (
                  <ToggleRight size={14} color={Colors.warning} />
                ) : (
                  <ToggleLeft size={14} color={Colors.success} />
                )}
                <Text
                  style={[
                    styles.actionBtnText,
                    { color: item.is_active ? Colors.warning : Colors.success },
                  ]}
                >
                  {item.is_active ? 'Deactivate' : 'Reactivate'}
                </Text>
              </View>
            </AnimatedPressable>

            {/* Permanent delete */}
            <AnimatedPressable
              onPress={() => handleDelete(item)}
              scaleValue={0.95}
              style={styles.actionBtnWrapper}
            >
              <View style={[styles.actionBtn, styles.deleteBtn]}>
                <Trash2 size={14} color={Colors.error} />
                <Text style={[styles.actionBtnText, { color: Colors.error }]}>
                  Delete
                </Text>
              </View>
            </AnimatedPressable>
          </View>
        </View>
      );
    },
    [handleDeactivate, handleReactivate, handleDelete]
  );

  // ── Render ─────────────────────────────────────────────────────────────────

  return (
    <View style={styles.screen}>
      {/* Header */}
      <SafeAreaView edges={['top']} style={styles.header}>
        <View style={styles.adminBadge}>
          <Text style={styles.adminBadgeText}>ADMIN ROOT</Text>
        </View>
        <View style={styles.titleRow}>
          <List size={22} color={Colors.primaryDark} />
          <Text style={styles.title}>Service Listings</Text>
        </View>
        <Text style={styles.subtitle}>
          {filteredListings.length} listing{filteredListings.length !== 1 ? 's' : ''}
          {sectorFilter !== 'all' ? ` · ${SECTOR_CONFIGS[sectorFilter].displayName}` : ''}
        </Text>

        {/* Search */}
        <View style={styles.searchRow}>
          <Search size={16} color={Colors.textTertiary} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search title, description, tags…"
            placeholderTextColor={Colors.textTertiary}
            value={searchQuery}
            onChangeText={setSearchQuery}
            returnKeyType="search"
            clearButtonMode="while-editing"
          />
        </View>

        {/* Sector filter chips */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterScroll}
        >
          <AnimatedPressable
            onPress={() => setSectorFilter('all')}
            scaleValue={0.95}
          >
            <View
              style={[
                styles.filterChip,
                sectorFilter === 'all' && styles.filterChipActive,
              ]}
            >
              <Text
                style={[
                  styles.filterChipText,
                  sectorFilter === 'all' && styles.filterChipTextActive,
                ]}
              >
                All Sectors
              </Text>
            </View>
          </AnimatedPressable>
          {SECTOR_LIST.map((s) => (
            <AnimatedPressable
              key={s}
              onPress={() => setSectorFilter(s)}
              scaleValue={0.95}
            >
              <View
                style={[
                  styles.filterChip,
                  sectorFilter === s && styles.filterChipActive,
                  sectorFilter === s && {
                    backgroundColor: SECTOR_CONFIGS[s].badgeColor,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.filterChipText,
                    sectorFilter === s && styles.filterChipTextActive,
                  ]}
                >
                  {SECTOR_CONFIGS[s].displayName}
                </Text>
              </View>
            </AnimatedPressable>
          ))}
        </ScrollView>

        {/* Active/inactive filter */}
        <View style={styles.activeFilterRow}>
          {(['all', 'active', 'inactive'] as ActiveFilter[]).map((f) => (
            <AnimatedPressable
              key={f}
              onPress={() => setActiveFilter(f)}
              scaleValue={0.95}
            >
              <View
                style={[
                  styles.activeChip,
                  activeFilter === f && styles.activeChipSelected,
                ]}
              >
                <Text
                  style={[
                    styles.activeChipText,
                    activeFilter === f && styles.activeChipTextSelected,
                  ]}
                >
                  {f.charAt(0).toUpperCase() + f.slice(1)}
                </Text>
              </View>
            </AnimatedPressable>
          ))}
        </View>
      </SafeAreaView>

      {/* List */}
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.primary} />
          <Text style={styles.loadingText}>Loading listings…</Text>
        </View>
      ) : (
        <FlatList
          data={filteredListings}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshing={refreshing}
          onRefresh={() => fetchListings(true)}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <AlertTriangle size={40} color={Colors.textTertiary} />
              <Text style={styles.emptyTitle}>No listings found</Text>
              <Text style={styles.emptySubtitle}>
                {searchQuery
                  ? 'Try a different search term or clear the filters.'
                  : 'No service listings match the current filters.'}
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background },

  // Header
  header: {
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.lg,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
    ...Shadow.sm,
  },
  adminBadge: {
    alignSelf: 'flex-start',
    backgroundColor: Colors.primaryDark,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginBottom: Spacing.sm,
  },
  adminBadgeText: {
    fontSize: 10,
    color: '#FFFFFF',
    fontWeight: FontWeight.bold,
    letterSpacing: 1,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.xs,
  },
  title: {
    fontSize: FontSize.xxxl,
    fontWeight: FontWeight.heavy,
    color: Colors.text,
  },
  subtitle: {
    fontSize: FontSize.sm,
    color: Colors.textTertiary,
    marginBottom: Spacing.md,
    fontWeight: FontWeight.medium,
  },

  // Search
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.cream,
    borderRadius: Radius.lg,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    marginBottom: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  searchInput: {
    flex: 1,
    fontSize: FontSize.md,
    color: Colors.text,
    paddingVertical: 0,
  },

  // Sector filter
  filterScroll: {
    gap: Spacing.sm,
    paddingRight: Spacing.xl,
    marginBottom: Spacing.sm,
  },
  filterChip: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: Radius.full,
    backgroundColor: Colors.cream,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  filterChipActive: {
    backgroundColor: Colors.primaryDark,
    borderColor: Colors.primaryDark,
  },
  filterChipText: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
    color: Colors.textSecondary,
  },
  filterChipTextActive: { color: '#FFFFFF' },

  // Active/inactive filter
  activeFilterRow: {
    flexDirection: 'row',
    gap: Spacing.sm,
    marginTop: Spacing.xs,
  },
  activeChip: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: Radius.full,
    backgroundColor: Colors.cream,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  activeChipSelected: {
    backgroundColor: Colors.primaryDark,
    borderColor: Colors.primaryDark,
  },
  activeChipText: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
    color: Colors.textSecondary,
  },
  activeChipTextSelected: { color: '#FFFFFF' },

  // List
  listContent: { padding: Spacing.xl, paddingBottom: Spacing.massive },

  // Card
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    ...Shadow.sm,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  cardInactive: {
    opacity: 0.65,
    borderColor: Colors.warmGray,
    backgroundColor: Colors.cream,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.sm,
    gap: Spacing.sm,
  },
  cardTitleGroup: { flex: 1 },
  cardTitle: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.bold,
    color: Colors.text,
    marginBottom: 2,
  },
  cardVendor: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
  },
  cardBadges: { alignItems: 'flex-end', gap: Spacing.xs },

  // Sector badge
  sectorBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: Radius.full,
  },
  sectorBadgeText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
  },

  // Status badge
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: Radius.full,
  },
  statusActive: { backgroundColor: Colors.successLight },
  statusInactive: { backgroundColor: Colors.warmGray },
  statusText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold },

  // Meta row
  metaRow: {
    flexDirection: 'row',
    gap: Spacing.lg,
    marginBottom: Spacing.sm,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  metaText: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    fontWeight: FontWeight.semibold,
  },

  // Tags
  tagsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    marginBottom: Spacing.sm,
  },
  tagsInner: { flexDirection: 'row', gap: Spacing.xs },
  tagChip: {
    backgroundColor: Colors.cream,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  tagText: {
    fontSize: FontSize.xs,
    color: Colors.textSecondary,
    fontWeight: FontWeight.semibold,
  },

  // Action buttons
  actionRow: {
    flexDirection: 'row',
    gap: Spacing.sm,
    marginTop: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
    paddingTop: Spacing.sm,
  },
  actionBtnWrapper: { flex: 1 },
  actionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.xs,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.lg,
    borderWidth: 1,
  },
  deactivateBtn: {
    borderColor: Colors.warning,
    backgroundColor: Colors.warningLight,
  },
  reactivateBtn: {
    borderColor: Colors.success,
    backgroundColor: Colors.successLight,
  },
  deleteBtn: {
    borderColor: Colors.error,
    backgroundColor: Colors.errorLight,
  },
  actionBtnText: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
  },

  // Loading
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.md,
  },
  loadingText: {
    fontSize: FontSize.md,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
  },

  // Empty
  emptyContainer: {
    alignItems: 'center',
    paddingTop: Spacing.massive * 2,
    gap: Spacing.md,
  },
  emptyTitle: {
    fontSize: FontSize.xl,
    fontWeight: FontWeight.bold,
    color: Colors.text,
  },
  emptySubtitle: {
    fontSize: FontSize.md,
    color: Colors.textTertiary,
    textAlign: 'center',
    paddingHorizontal: Spacing.xl,
  },
});
