import React, { useCallback, useEffect, useMemo, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, Animated, Platform, Dimensions, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { CalendarDays, ChevronRight, TrendingUp, Building, Wallet, AlertCircle } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { useAdminDashboard } from '@/hooks/queries/useAdminDashboard';
import { useApp } from '@/providers/AppProvider';
import { formatCurrencyFull, formatCurrencyCompact } from '@/utils/currency';
import { formatTimeAgo } from '@/utils/date';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import ErrorState from '@/components/ui/ErrorState';
import ScreenLoader from '@/components/ui/ScreenLoader';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const SERIF_FONT = Platform.select({ ios: 'Georgia', android: 'serif', web: 'Georgia, serif', default: 'serif' });

export default function AdminDashboardScreen() {
    const router = useRouter();
    const { logout } = useApp();
    const fadeAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
    }, []);

    const { data, isLoading, isError, refetch } = useAdminDashboard();
    const stats = data ?? { totalHalls: 0, activeBookings: 0, todayRevenue: 0, pendingApprovals: 0, netRevenue: 0, totalCommission: 0, totalDiscounts: 0 };
    const chartData = (data?.monthlyRevenue?.length ?? 0) > 0 ? data!.monthlyRevenue : [{ month: 'Now', commission: 0 }];
    const topHalls = data?.topHalls ?? [];
    const recentActivity = data?.recentActivity ?? [];
    const maxRevenue = Math.max(1, ...chartData.map(r => r.commission));
    const revenueGrowth = useMemo(() => {
        if (chartData.length < 2) return 0;
        const previous = chartData[chartData.length - 2].commission || 1;
        const current = chartData[chartData.length - 1].commission;
        return Math.round(((current - previous) / previous) * 100);
    }, [chartData]);

    return (
        <View style={styles.screen}>
            {isLoading && <ScreenLoader message="Loading dashboard..." />}
            {isError && <ErrorState title="Could not load dashboard" onRetry={refetch} />}
            {!isLoading && !isError && (
            <ScrollView showsVerticalScrollIndicator={false} refreshControl={undefined}>
                <LinearGradient colors={[Colors.primaryDark, Colors.primary]} style={styles.headerGradient}>
                    <SafeAreaView edges={['top']}>
                        <Animated.View style={[styles.headerContent, { opacity: fadeAnim }]}>
                            <View style={styles.headerRow}>
                                <View style={styles.headerTextGroup}>
                                    <View style={styles.adminBadge}><Text style={styles.adminBadgeText}>ADMIN ROOT</Text></View>
                                    <Text style={styles.headerTitle}>Command Center</Text>
                                    <Text style={styles.headerDate}>{new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</Text>
                                </View>
                                <AnimatedPressable onPress={() => {
                                    Alert.alert('Sign Out', 'Are you sure?', [
                                        { text: 'Cancel', style: 'cancel' },
                                        { text: 'Sign Out', style: 'destructive', onPress: () => { logout(); router.replace('/role-select' as any); } },
                                    ]);
                                }} scaleValue={0.9}>
                                    <View style={styles.logoutBtn}><Text style={styles.logoutText}>Log Out</Text></View>
                                </AnimatedPressable>
                            </View>
                        </Animated.View>
                    </SafeAreaView>
                </LinearGradient>

                <View style={styles.body}>
                    <View style={styles.statsGrid}>
                        {[
                            { label: 'Total Halls', value: stats.totalHalls.toString(), icon: <Building size={20} color={Colors.primary} />, iconBg: Colors.primaryFaded },
                            { label: 'Active Bookings', value: stats.activeBookings.toString(), icon: <CalendarDays size={20} color={Colors.goldDark} />, iconBg: Colors.goldFaded },
                            { label: "Today's Revenue", value: formatCurrencyCompact(stats.todayRevenue), icon: <Wallet size={20} color={Colors.success} />, iconBg: Colors.successLight },
                            { label: 'Pending Apps', value: stats.pendingApprovals.toString(), icon: <AlertCircle size={20} color={stats.pendingApprovals > 0 ? Colors.error : Colors.textTertiary} />, iconBg: stats.pendingApprovals > 0 ? 'rgba(255,59,48,0.1)' : Colors.cream, urgent: stats.pendingApprovals > 0 },
                        ].map((stat) => (
                            <View key={stat.label} style={[styles.statCard, stat.urgent && styles.statCardUrgent]}>
                                <View style={[styles.statIconWrap, { backgroundColor: stat.iconBg }]}>{stat.icon}</View>
                                <View style={styles.statBottomInfo}>
                                    <Text style={[styles.statNum, stat.urgent && { color: Colors.error }]}>{stat.value}</Text>
                                    <Text style={[styles.statLabel, stat.urgent && { color: Colors.error }]} numberOfLines={1}>{stat.label}</Text>
                                </View>
                            </View>
                        ))}
                    </View>

                    <View style={styles.section}>
                        <Text style={styles.sectionTitle}>Platform Revenue</Text>
                        <View style={styles.revenueCard}>
                            <View style={styles.revenueRow}>
                                <View>
                                    <Text style={styles.revenueLabel}>Net Revenue</Text>
                                    <Text style={styles.revenueAmount}>{formatCurrencyFull(stats.netRevenue)}</Text>
                                </View>
                                <View style={styles.revenueTrend}>
                                    <TrendingUp size={14} color={Colors.success} />
                                    <Text style={styles.revenueTrendText}>{revenueGrowth >= 0 ? '+' : ''}{revenueGrowth}%</Text>
                                </View>
                            </View>
                            <View style={styles.revenueDetails}>
                                <View style={styles.revenueDetail}>
                                    <Text style={styles.revenueDetailLabel}>Commission</Text>
                                    <Text style={styles.revenueDetailValue}>{formatCurrencyFull(stats.totalCommission)}</Text>
                                </View>
                                <View style={styles.revenueDetail}>
                                    <Text style={styles.revenueDetailLabel}>Discounts</Text>
                                    <Text style={[styles.revenueDetailValue, { color: Colors.error }]}>-{formatCurrencyFull(stats.totalDiscounts)}</Text>
                                </View>
                            </View>
                        </View>
                    </View>

                    <View style={styles.section}>
                        <Text style={styles.sectionTitle}>Monthly Revenue</Text>
                        <View style={styles.chartContainer}>
                            {chartData.map((item) => (
                                <View key={item.month} style={styles.chartBar}>
                                    <Text style={styles.chartValue}>{formatCurrencyCompact(item.commission)}</Text>
                                    <View style={styles.chartBarTrack}>
                                        <LinearGradient colors={[Colors.primary, Colors.primaryLight]} style={[styles.chartBarFill, { height: `${(item.commission / maxRevenue) * 100}%` as any }]} />
                                    </View>
                                    <Text style={styles.chartLabel}>{item.month}</Text>
                                </View>
                            ))}
                        </View>
                    </View>

                    {stats.pendingApprovals > 0 && (
                        <AnimatedPressable onPress={() => router.push('/(admin)/approvals' as any)} scaleValue={0.97}>
                            <View style={styles.actionCard}>
                                <CalendarDays size={20} color={Colors.error} />
                                <View style={styles.actionCardContent}>
                                    <Text style={styles.actionCardTitle}>Review Pending Halls</Text>
                                    <Text style={styles.actionCardSubtitle}>{stats.pendingApprovals} halls awaiting approval</Text>
                                </View>
                                <ChevronRight size={18} color={Colors.primary} />
                            </View>
                        </AnimatedPressable>
                    )}

                    <View style={styles.section}>
                        <Text style={styles.sectionTitle}>Top Performing Halls</Text>
                        {(topHalls.length > 0 ? topHalls : [{ id: 'empty', name: 'No confirmed venue revenue yet', monthlyBookings: 0, monthlyRevenue: 0 }]).map((hall, index) => (
                            <View key={hall.id} style={styles.topHallRow}>
                                <Text style={styles.topHallRank}>#{index + 1}</Text>
                                <View style={styles.topHallInfo}>
                                    <Text style={styles.topHallName} numberOfLines={1}>{hall.name}</Text>
                                    <Text style={styles.topHallMeta}>{hall.monthlyBookings} bookings · {formatCurrencyCompact(hall.monthlyRevenue)}</Text>
                                </View>
                            </View>
                        ))}
                    </View>

                    <View style={styles.section}>
                        <Text style={styles.sectionTitle}>Recent Activity</Text>
                        <View style={styles.activityCard}>
                            {(recentActivity.length > 0 ? recentActivity : [{ id: 'empty', text: 'No recent booking activity yet', time: new Date().toISOString() }]).map((activity, index, list) => (
                                <View key={activity.id} style={[styles.activityRow, index === list.length - 1 && { borderBottomWidth: 0 }]}>
                                    <View style={styles.activityIcon}><CalendarDays size={16} color={Colors.primary} /></View>
                                    <View style={styles.activityContent}>
                                        <Text style={styles.activityText} numberOfLines={2}>{activity.text}</Text>
                                        <Text style={styles.activityTime}>{formatTimeAgo(activity.time)}</Text>
                                    </View>
                                </View>
                            ))}
                        </View>
                    </View>
                    <View style={{ height: Spacing.massive * 1.5 }} />
                </View>
            </ScrollView>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    headerGradient: { paddingBottom: Spacing.xl, borderBottomLeftRadius: Radius.xxl, borderBottomRightRadius: Radius.xxl },
    headerContent: { paddingHorizontal: Spacing.xl, paddingTop: Spacing.xl, paddingBottom: Spacing.md },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    headerTextGroup: { flex: 1 },
    adminBadge: { alignSelf: 'flex-start', backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 6, marginBottom: Spacing.sm },
    adminBadgeText: { fontSize: 9, color: '#FFF', fontWeight: FontWeight.bold, letterSpacing: 1.5 },
    headerTitle: { fontSize: 26, fontWeight: FontWeight.heavy, color: '#FFFFFF', fontFamily: SERIF_FONT, marginBottom: 4 },
    headerDate: { fontSize: FontSize.sm, color: 'rgba(255,255,255,0.8)', fontWeight: FontWeight.medium },
    logoutBtn: { backgroundColor: 'rgba(255,255,255,0.1)', paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm, borderRadius: Radius.full, borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' },
    logoutText: { color: '#FFFFFF', fontSize: FontSize.xs, fontWeight: FontWeight.bold },
    body: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.xl },
    statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md },
    statCard: { width: (SCREEN_WIDTH - Spacing.lg * 2 - Spacing.md) / 2, borderRadius: Radius.xl, padding: Spacing.lg, ...Shadow.md, justifyContent: 'space-between', minHeight: 120, borderWidth: 1, borderColor: 'rgba(0,0,0,0.03)', backgroundColor: Colors.surface },
    statCardUrgent: { borderWidth: 1, borderColor: 'rgba(255,59,48,0.3)', backgroundColor: '#FFF5F5' },
    statIconWrap: { width: 42, height: 42, borderRadius: 21, justifyContent: 'center', alignItems: 'center' },
    statBottomInfo: { marginTop: Spacing.md },
    statNum: { fontSize: 26, fontWeight: FontWeight.heavy, marginBottom: 2, color: Colors.text },
    statLabel: { fontSize: 11, color: Colors.textTertiary, fontWeight: FontWeight.bold, textTransform: 'uppercase', letterSpacing: 0.5 },
    section: { marginTop: Spacing.xxl },
    sectionTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.primaryDark, marginBottom: Spacing.md },
    revenueCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.xl, ...Shadow.md, borderWidth: 1, borderColor: Colors.borderLight },
    revenueRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: Spacing.xl, borderBottomWidth: 1, borderBottomColor: Colors.borderLight, paddingBottom: Spacing.lg },
    revenueLabel: { fontSize: FontSize.sm, color: Colors.textTertiary, fontWeight: FontWeight.bold, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: Spacing.xs },
    revenueAmount: { fontSize: 32, fontWeight: FontWeight.heavy, color: Colors.text },
    revenueTrend: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xxs, backgroundColor: Colors.successLight, paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: Radius.full },
    revenueTrendText: { fontSize: FontSize.sm, color: Colors.success, fontWeight: FontWeight.bold },
    revenueDetails: { flexDirection: 'row', gap: Spacing.xl },
    revenueDetail: { flex: 1, backgroundColor: Colors.cream, padding: Spacing.md, borderRadius: Radius.lg },
    revenueDetailLabel: { fontSize: FontSize.xs, color: Colors.textSecondary, fontWeight: FontWeight.semibold, marginBottom: 4 },
    revenueDetailValue: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text },
    chartContainer: { flexDirection: 'row', justifyContent: 'space-between', height: 180, alignItems: 'flex-end', backgroundColor: Colors.surface, padding: Spacing.lg, borderRadius: Radius.xl, ...Shadow.sm, borderWidth: 1, borderColor: Colors.borderLight },
    chartBar: { flex: 1, alignItems: 'center', gap: Spacing.xs },
    chartValue: { fontSize: 10, color: Colors.textTertiary, fontWeight: FontWeight.bold },
    chartBarTrack: { width: 32, flex: 1, backgroundColor: Colors.cream, borderRadius: Radius.md, overflow: 'hidden', justifyContent: 'flex-end' },
    chartBarFill: { width: '100%', borderRadius: Radius.md },
    chartLabel: { fontSize: FontSize.xs, color: Colors.textSecondary, fontWeight: FontWeight.bold },
    actionCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.errorLight, borderRadius: Radius.xl, padding: Spacing.xl, gap: Spacing.lg, marginTop: Spacing.xxl, ...Shadow.sm },
    actionCardContent: { flex: 1 },
    actionCardTitle: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.error, marginBottom: 2 },
    actionCardSubtitle: { fontSize: FontSize.sm, color: Colors.error, opacity: 0.8, fontWeight: FontWeight.medium },
    topHallRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.lg, gap: Spacing.lg, marginBottom: Spacing.sm, ...Shadow.sm, borderWidth: 1, borderColor: Colors.borderLight },
    topHallRank: { fontSize: FontSize.md, fontWeight: FontWeight.bold, width: 36, textAlign: 'center', color: Colors.primaryDark },
    topHallInfo: { flex: 1 },
    topHallName: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: 2 },
    topHallMeta: { fontSize: FontSize.xs, color: Colors.textTertiary, fontWeight: FontWeight.medium },
    activityCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, paddingHorizontal: Spacing.lg, ...Shadow.md, borderWidth: 1, borderColor: Colors.borderLight },
    activityRow: { flexDirection: 'row', gap: Spacing.md, paddingVertical: Spacing.lg, borderBottomWidth: 1, borderBottomColor: Colors.borderLight, alignItems: 'flex-start' },
    activityIcon: { width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.primaryFaded, justifyContent: 'center', alignItems: 'center' },
    activityContent: { flex: 1, paddingTop: 2 },
    activityText: { fontSize: FontSize.sm, color: Colors.text, lineHeight: 20, fontWeight: FontWeight.medium },
    activityTime: { fontSize: FontSize.xs, color: Colors.textTertiary, marginTop: Spacing.xs, fontWeight: FontWeight.semibold },
});
