import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  BarChart3,
  CalendarRange,
  TrendingUp,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { formatCurrencyCompact } from '@/utils/currency';
import { SECTOR_LIST, SECTOR_CONFIGS } from '@/constants/sectors';
import type { VendorSector } from '@/types';

// ─── Date range helpers ───────────────────────────────────────────────────────

function getMonthBounds(date: Date): { start: string; end: string } {
  const y = date.getFullYear();
  const m = date.getMonth();
  const start = new Date(y, m, 1);
  const end = new Date(y, m + 1, 0); // last day of month
  return {
    start: start.toISOString().slice(0, 10),
    end: end.toISOString().slice(0, 10),
  };
}

function formatMonthLabel(date: Date): string {
  return date.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
}

// ─── Types ────────────────────────────────────────────────────────────────────

interface SectorMetrics {
  sector: VendorSector;
  bookingCount: number;
  totalRevenue: number;
  totalCommission: number;
  cappedCount: number;
  cappedRevenue: number;
  cappedCommission: number;
}

interface BookingRow {
  id: string;
  sector: string;
  event_date: string;
  status: string;
  total_amount: number;
  commission: {
    id: string;
    commission_amount: number;
    is_capped: boolean;
  } | {
    id: string;
    commission_amount: number;
    is_capped: boolean;
  }[] | null;
}

// ─── Preset date range options ────────────────────────────────────────────────

type RangePreset = 'current_month' | 'last_month' | 'last_3_months' | 'all_time';

const RANGE_PRESETS: { key: RangePreset; label: string }[] = [
  { key: 'current_month', label: 'This Month' },
  { key: 'last_month', label: 'Last Month' },
  { key: 'last_3_months', label: 'Last 3 Months' },
  { key: 'all_time', label: 'All Time' },
];

function getDateRangeForPreset(preset: RangePreset): { start: string | null; end: string | null } {
  const now = new Date();
  if (preset === 'current_month') {
    const { start, end } = getMonthBounds(now);
    return { start, end };
  }
  if (preset === 'last_month') {
    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const { start, end } = getMonthBounds(lastMonth);
    return { start, end };
  }
  if (preset === 'last_3_months') {
    const threeMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 2, 1);
    const { end } = getMonthBounds(now);
    return { start: threeMonthsAgo.toISOString().slice(0, 10), end };
  }
  // all_time
  return { start: null, end: null };
}

// ─── Sector row component ─────────────────────────────────────────────────────

interface SectorRowProps {
  metrics: SectorMetrics;
  expanded: boolean;
  onToggle: () => void;
}

function SectorRow({ metrics, expanded, onToggle }: SectorRowProps) {
  const config = SECTOR_CONFIGS[metrics.sector];
  const hasCapped = metrics.cappedCount > 0;

  return (
    <View style={styles.sectorCard}>
      {/* Header row */}
      <TouchableOpacity
        style={styles.sectorHeader}
        onPress={onToggle}
        activeOpacity={0.7}
      >
        <View style={[styles.sectorBadge, { backgroundColor: config.badgeColor + '22' }]}>
          <Text style={[styles.sectorBadgeText, { color: config.badgeColor }]}>
            {config.displayName.toUpperCase()}
          </Text>
        </View>

        <View style={styles.sectorHeaderRight}>
          {hasCapped && (
            <View style={styles.cappedIndicator}>
              <AlertTriangle size={12} color={Colors.warning} />
              <Text style={styles.cappedIndicatorText}>{metrics.cappedCount} capped</Text>
            </View>
          )}
          {expanded ? (
            <ChevronUp size={18} color={Colors.textTertiary} />
          ) : (
            <ChevronDown size={18} color={Colors.textTertiary} />
          )}
        </View>
      </TouchableOpacity>

      {/* KPI grid */}
      <View style={styles.kpiGrid}>
        <View style={styles.kpiItem}>
          <Text style={styles.kpiValue}>{metrics.bookingCount}</Text>
          <Text style={styles.kpiLabel}>Bookings</Text>
        </View>
        <View style={[styles.kpiItem, styles.kpiDivider]}>
          <Text style={styles.kpiValue}>{formatCurrencyCompact(metrics.totalRevenue)}</Text>
          <Text style={styles.kpiLabel}>Revenue</Text>
        </View>
        <View style={[styles.kpiItem, styles.kpiDivider]}>
          <Text style={[styles.kpiValue, { color: Colors.primary }]}>
            {formatCurrencyCompact(metrics.totalCommission)}
          </Text>
          <Text style={styles.kpiLabel}>Commission</Text>
        </View>
      </View>

      {/* Capped commissions sub-section */}
      {expanded && hasCapped && (
        <View style={styles.cappedSection}>
          <View style={styles.cappedSectionHeader}>
            <AlertTriangle size={14} color={Colors.warning} />
            <Text style={styles.cappedSectionTitle}>Capped Commissions</Text>
          </View>
          <Text style={styles.cappedSectionNote}>
            Commission was capped at 50% of booking value for {metrics.cappedCount}{' '}
            {metrics.cappedCount === 1 ? 'booking' : 'bookings'}.
          </Text>
          <View style={styles.cappedKpiRow}>
            <View style={styles.cappedKpiItem}>
              <Text style={styles.cappedKpiValue}>{metrics.cappedCount}</Text>
              <Text style={styles.cappedKpiLabel}>Capped Bookings</Text>
            </View>
            <View style={styles.cappedKpiItem}>
              <Text style={styles.cappedKpiValue}>
                {formatCurrencyCompact(metrics.cappedRevenue)}
              </Text>
              <Text style={styles.cappedKpiLabel}>Booking Revenue</Text>
            </View>
            <View style={styles.cappedKpiItem}>
              <Text style={[styles.cappedKpiValue, { color: Colors.warning }]}>
                {formatCurrencyCompact(metrics.cappedCommission)}
              </Text>
              <Text style={styles.cappedKpiLabel}>Commission Earned</Text>
            </View>
          </View>
        </View>
      )}

      {/* Expanded but no capped rows */}
      {expanded && !hasCapped && (
        <View style={styles.cappedSection}>
          <Text style={styles.noCappedText}>No capped commissions in this period.</Text>
        </View>
      )}
    </View>
  );
}

// ─── Main screen ──────────────────────────────────────────────────────────────

export default function SectorRevenueScreen() {
  const [selectedPreset, setSelectedPreset] = useState<RangePreset>('current_month');
  const [metrics, setMetrics] = useState<SectorMetrics[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expandedSectors, setExpandedSectors] = useState<Set<VendorSector>>(new Set());

  const dateRange = useMemo(() => getDateRangeForPreset(selectedPreset), [selectedPreset]);

  const rangeLabel = useMemo(() => {
    if (selectedPreset === 'all_time') return 'All Time';
    if (selectedPreset === 'current_month') return formatMonthLabel(new Date());
    if (selectedPreset === 'last_month') {
      const d = new Date();
      return formatMonthLabel(new Date(d.getFullYear(), d.getMonth() - 1, 1));
    }
    if (selectedPreset === 'last_3_months') {
      const now = new Date();
      const from = new Date(now.getFullYear(), now.getMonth() - 2, 1);
      return `${formatMonthLabel(from)} – ${formatMonthLabel(now)}`;
    }
    return '';
  }, [selectedPreset]);

  const fetchMetrics = useCallback(async () => {
    setError(null);
    try {
      // Query service_bookings (with date + status filter) and join service_commissions.
      // Filtering on the parent table (service_bookings) ensures the date range is
      // applied server-side; the commission data is pulled via the FK join.
      let bookingsQuery = supabase
        .from('service_bookings')
        .select(
          'id, sector, event_date, status, total_amount, commission:service_commissions(id, commission_amount, is_capped)'
        )
        .in('status', ['confirmed', 'completed']);

      if (dateRange.start) {
        bookingsQuery = bookingsQuery.gte('event_date', dateRange.start);
      }
      if (dateRange.end) {
        bookingsQuery = bookingsQuery.lte('event_date', dateRange.end);
      }

      const { data, error: fetchError } = await bookingsQuery;

      if (fetchError) throw fetchError;

      // Aggregate per sector
      const map = new Map<VendorSector, SectorMetrics>();

      // Initialise all sectors with zero values
      for (const sector of SECTOR_LIST) {
        map.set(sector, {
          sector,
          bookingCount: 0,
          totalRevenue: 0,
          totalCommission: 0,
          cappedCount: 0,
          cappedRevenue: 0,
          cappedCommission: 0,
        });
      }

      for (const row of (data ?? []) as BookingRow[]) {
        const existing = map.get(row.sector as VendorSector);
        if (!existing) continue;

        // commission is a 1:1 FK join — Supabase returns it as an object or null
        const commission = Array.isArray(row.commission)
          ? row.commission[0] ?? null
          : row.commission ?? null;

        const commissionAmount = commission?.commission_amount ?? 0;
        const isCapped = commission?.is_capped ?? false;

        existing.bookingCount += 1;
        existing.totalRevenue += row.total_amount;
        existing.totalCommission += commissionAmount;

        if (isCapped) {
          existing.cappedCount += 1;
          existing.cappedRevenue += row.total_amount;
          existing.cappedCommission += commissionAmount;
        }
      }

      setMetrics(Array.from(map.values()));
    } catch (err: any) {
      setError(err?.message ?? 'Failed to load sector revenue data.');
    }
  }, [dateRange]);

  useEffect(() => {
    setLoading(true);
    fetchMetrics().finally(() => setLoading(false));
  }, [fetchMetrics]);

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchMetrics();
    setRefreshing(false);
  }, [fetchMetrics]);

  const toggleSector = useCallback((sector: VendorSector) => {
    setExpandedSectors((prev) => {
      const next = new Set(prev);
      if (next.has(sector)) {
        next.delete(sector);
      } else {
        next.add(sector);
      }
      return next;
    });
  }, []);

  // Totals across all sectors
  const totals = useMemo(() => {
    return metrics.reduce(
      (acc, m) => ({
        bookingCount: acc.bookingCount + m.bookingCount,
        totalRevenue: acc.totalRevenue + m.totalRevenue,
        totalCommission: acc.totalCommission + m.totalCommission,
        cappedCount: acc.cappedCount + m.cappedCount,
      }),
      { bookingCount: 0, totalRevenue: 0, totalCommission: 0, cappedCount: 0 }
    );
  }, [metrics]);

  // Only show sectors that have data (or all if no data at all)
  const activeSectors = useMemo(() => {
    const withData = metrics.filter((m) => m.bookingCount > 0);
    return withData.length > 0 ? withData : metrics;
  }, [metrics]);

  return (
    <View style={styles.screen}>
      {/* Header */}
      <SafeAreaView edges={['top']} style={styles.headerSafe}>
        <View style={styles.headerContent}>
          <View style={styles.adminBadge}>
            <Text style={styles.adminBadgeText}>ADMIN ROOT</Text>
          </View>
          <View style={styles.headerRow}>
            <View style={styles.headerLeft}>
              <BarChart3 size={22} color={Colors.primaryDark} style={{ marginRight: Spacing.sm }} />
              <Text style={styles.headerTitle}>Sector Revenue</Text>
            </View>
          </View>
          <View style={styles.rangeRow}>
            <CalendarRange size={14} color={Colors.textTertiary} />
            <Text style={styles.rangeLabel}>{rangeLabel}</Text>
          </View>
        </View>

        {/* Date range preset chips */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.presetRow}
        >
          {RANGE_PRESETS.map((preset) => (
            <TouchableOpacity
              key={preset.key}
              style={[
                styles.presetChip,
                selectedPreset === preset.key && styles.presetChipActive,
              ]}
              onPress={() => setSelectedPreset(preset.key)}
              activeOpacity={0.7}
            >
              <Text
                style={[
                  styles.presetChipText,
                  selectedPreset === preset.key && styles.presetChipTextActive,
                ]}
              >
                {preset.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </SafeAreaView>

      {/* Body */}
      {loading ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={Colors.primary} />
          <Text style={styles.loadingText}>Loading sector metrics…</Text>
        </View>
      ) : error ? (
        <View style={styles.centered}>
          <AlertTriangle size={40} color={Colors.error} />
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity style={styles.retryBtn} onPress={() => fetchMetrics()}>
            <Text style={styles.retryBtnText}>Retry</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scrollContent}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              tintColor={Colors.primary}
            />
          }
        >
          {/* Platform totals summary */}
          <View style={styles.totalsCard}>
            <Text style={styles.totalsTitle}>Platform Totals</Text>
            <View style={styles.totalsGrid}>
              <View style={styles.totalItem}>
                <Text style={styles.totalValue}>{totals.bookingCount}</Text>
                <Text style={styles.totalLabel}>Total Bookings</Text>
              </View>
              <View style={[styles.totalItem, styles.totalDivider]}>
                <Text style={styles.totalValue}>
                  {formatCurrencyCompact(totals.totalRevenue)}
                </Text>
                <Text style={styles.totalLabel}>Total Revenue</Text>
              </View>
              <View style={[styles.totalItem, styles.totalDivider]}>
                <Text style={[styles.totalValue, { color: Colors.primary }]}>
                  {formatCurrencyCompact(totals.totalCommission)}
                </Text>
                <Text style={styles.totalLabel}>Commission Earned</Text>
              </View>
            </View>
            {totals.cappedCount > 0 && (
              <View style={styles.totalsCappedBanner}>
                <AlertTriangle size={14} color={Colors.warning} />
                <Text style={styles.totalsCappedText}>
                  {totals.cappedCount} capped commission{totals.cappedCount !== 1 ? 's' : ''} across all sectors
                </Text>
              </View>
            )}
          </View>

          {/* Per-sector breakdown */}
          <View style={styles.sectionHeader}>
            <TrendingUp size={16} color={Colors.primaryDark} />
            <Text style={styles.sectionTitle}>Per-Sector Breakdown</Text>
          </View>

          {activeSectors.length === 0 ? (
            <View style={styles.emptyState}>
              <BarChart3 size={48} color={Colors.textTertiary} />
              <Text style={styles.emptyTitle}>No data for this period</Text>
              <Text style={styles.emptySubtitle}>
                There are no confirmed or completed bookings in the selected date range.
              </Text>
            </View>
          ) : (
            activeSectors.map((m) => (
              <SectorRow
                key={m.sector}
                metrics={m}
                expanded={expandedSectors.has(m.sector)}
                onToggle={() => toggleSector(m.sector)}
              />
            ))
          )}

          <View style={{ height: Spacing.massive * 1.5 }} />
        </ScrollView>
      )}
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
  },

  // Header
  headerSafe: {
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
    ...Shadow.sm,
  },
  headerContent: {
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.md,
    paddingBottom: Spacing.sm,
  },
  adminBadge: {
    alignSelf: 'flex-start',
    backgroundColor: Colors.primaryDark,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginBottom: Spacing.sm,
  },
  adminBadgeText: {
    fontSize: 10,
    color: '#FFFFFF',
    fontWeight: FontWeight.bold,
    letterSpacing: 1,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Spacing.xs,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  headerTitle: {
    fontSize: FontSize.xxxl,
    fontWeight: FontWeight.heavy,
    color: Colors.primaryDark,
  },
  rangeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    marginBottom: Spacing.sm,
  },
  rangeLabel: {
    fontSize: FontSize.sm,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
  },

  // Preset chips
  presetRow: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.lg,
    gap: Spacing.sm,
  },
  presetChip: {
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: Radius.full,
    backgroundColor: Colors.cream,
  },
  presetChipActive: {
    backgroundColor: Colors.primaryDark,
  },
  presetChipText: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
    color: Colors.textSecondary,
  },
  presetChipTextActive: {
    color: '#FFFFFF',
  },

  // Loading / error
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.xxl,
    gap: Spacing.lg,
  },
  loadingText: {
    fontSize: FontSize.md,
    color: Colors.textSecondary,
    fontWeight: FontWeight.medium,
  },
  errorText: {
    fontSize: FontSize.md,
    color: Colors.error,
    textAlign: 'center',
    fontWeight: FontWeight.medium,
  },
  retryBtn: {
    backgroundColor: Colors.primary,
    paddingHorizontal: Spacing.xxl,
    paddingVertical: Spacing.md,
    borderRadius: Radius.full,
  },
  retryBtnText: {
    color: '#FFFFFF',
    fontWeight: FontWeight.bold,
    fontSize: FontSize.md,
  },

  // Scroll body
  scrollContent: {
    padding: Spacing.xl,
  },

  // Platform totals card
  totalsCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.xl,
    padding: Spacing.xl,
    marginBottom: Spacing.xxl,
    ...Shadow.md,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  totalsTitle: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.bold,
    color: Colors.primaryDark,
    marginBottom: Spacing.lg,
  },
  totalsGrid: {
    flexDirection: 'row',
  },
  totalItem: {
    flex: 1,
    alignItems: 'center',
  },
  totalDivider: {
    borderLeftWidth: 1,
    borderLeftColor: Colors.borderLight,
  },
  totalValue: {
    fontSize: FontSize.xxl,
    fontWeight: FontWeight.heavy,
    color: Colors.text,
    marginBottom: Spacing.xxs,
  },
  totalLabel: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontWeight: FontWeight.bold,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    textAlign: 'center',
  },
  totalsCappedBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    marginTop: Spacing.lg,
    backgroundColor: Colors.warningLight,
    borderRadius: Radius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
  },
  totalsCappedText: {
    fontSize: FontSize.sm,
    color: Colors.warning,
    fontWeight: FontWeight.semibold,
    flex: 1,
  },

  // Section header
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    fontSize: FontSize.xl,
    fontWeight: FontWeight.bold,
    color: Colors.primaryDark,
  },

  // Sector card
  sectorCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.xl,
    marginBottom: Spacing.md,
    ...Shadow.sm,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    overflow: 'hidden',
  },
  sectorHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
  },
  sectorBadge: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: Radius.full,
  },
  sectorBadgeText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
    letterSpacing: 0.8,
  },
  sectorHeaderRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  cappedIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xxs,
    backgroundColor: Colors.warningLight,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: Radius.full,
  },
  cappedIndicatorText: {
    fontSize: 11,
    color: Colors.warning,
    fontWeight: FontWeight.bold,
  },

  // KPI grid inside sector card
  kpiGrid: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.lg,
  },
  kpiItem: {
    flex: 1,
    alignItems: 'center',
  },
  kpiDivider: {
    borderLeftWidth: 1,
    borderLeftColor: Colors.borderLight,
  },
  kpiValue: {
    fontSize: FontSize.xl,
    fontWeight: FontWeight.heavy,
    color: Colors.text,
    marginBottom: 2,
  },
  kpiLabel: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontWeight: FontWeight.bold,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },

  // Capped commissions sub-section
  cappedSection: {
    backgroundColor: Colors.warningLight,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.lg,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
  },
  cappedSectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    marginBottom: Spacing.xs,
  },
  cappedSectionTitle: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
    color: Colors.warning,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  cappedSectionNote: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    marginBottom: Spacing.lg,
    lineHeight: 18,
  },
  cappedKpiRow: {
    flexDirection: 'row',
  },
  cappedKpiItem: {
    flex: 1,
    alignItems: 'center',
  },
  cappedKpiValue: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.heavy,
    color: Colors.text,
    marginBottom: 2,
  },
  cappedKpiLabel: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontWeight: FontWeight.bold,
    textTransform: 'uppercase',
    letterSpacing: 0.4,
    textAlign: 'center',
  },
  noCappedText: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    fontStyle: 'italic',
  },

  // Empty state
  emptyState: {
    alignItems: 'center',
    paddingVertical: Spacing.massive,
    gap: Spacing.md,
  },
  emptyTitle: {
    fontSize: FontSize.xl,
    fontWeight: FontWeight.bold,
    color: Colors.textSecondary,
  },
  emptySubtitle: {
    fontSize: FontSize.sm,
    color: Colors.textTertiary,
    textAlign: 'center',
    lineHeight: 20,
    maxWidth: 280,
  },
});
