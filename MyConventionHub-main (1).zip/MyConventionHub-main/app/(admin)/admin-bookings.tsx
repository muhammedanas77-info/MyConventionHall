import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { View, Text, StyleSheet, FlatList, Alert, Platform } from 'react-native';
import { Image } from 'expo-image';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import ImageViewing from 'react-native-image-viewing';
import { CalendarDays, Users, CheckCircle2, XCircle, FileText, Wallet, Eye } from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { formatCurrencyFull } from '@/utils/currency';
import { formatDateDisplay } from '@/utils/date';
import { SLOT_LABELS } from '@/constants/pricing';
import Badge from '@/components/ui/Badge';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import { useAuth } from '@/providers/AuthProvider';
import { supabase } from '@/utils/supabase';
import { normalizeBooking } from '@/utils/booking';
import type { BookingStatus, SlotType } from '@/types';

const FILTERS: { key: BookingStatus | 'all'; label: string }[] = [
    { key: 'all', label: 'All' },
    { key: 'confirmed', label: 'Confirmed' },
    { key: 'pending', label: 'Pending' },
    { key: 'completed', label: 'Completed' },
    { key: 'cancelled', label: 'Cancelled' },
];

const STATUS_MAP: Record<BookingStatus, { variant: 'success' | 'warning' | 'error' | 'neutral'; label: string }> = {
    confirmed: { variant: 'success', label: 'Confirmed' },
    pending: { variant: 'warning', label: 'Pending' },
    cancelled: { variant: 'error', label: 'Cancelled' },
    completed: { variant: 'neutral', label: 'Completed' },
};

function getPaymentProofPath(value?: string | null) {
    if (!value) return null;
    if (!value.startsWith('http')) return value.replace(/^payment-proofs\//, '');

    const match = value.match(/\/payment-proofs\/(.+)$/);
    return match?.[1] ? decodeURIComponent(match[1].split('?')[0]) : null;
}

function PaymentProofPreview({
    proofValue,
    onOpen,
}: {
    proofValue: string;
    onOpen: (url: string) => void;
}) {
    const [resolvedUrl, setResolvedUrl] = useState<string | null>(null);
    const [loadFailed, setLoadFailed] = useState(false);

    useEffect(() => {
        let isMounted = true;

        const resolveUrl = async () => {
            setLoadFailed(false);
            const path = getPaymentProofPath(proofValue);
            if (!path) {
                setResolvedUrl(proofValue.startsWith('http') ? proofValue : null);
                return;
            }

            const { data, error } = await supabase.storage
                .from('payment-proofs')
                .createSignedUrl(path, 60 * 60);

            if (!isMounted) return;
            setResolvedUrl(data?.signedUrl ?? (proofValue.startsWith('http') ? proofValue : null));
            if (error) console.warn('Unable to create payment proof signed URL:', error.message);
        };

        resolveUrl();
        return () => {
            isMounted = false;
        };
    }, [proofValue]);

    return (
        <AnimatedPressable onPress={() => resolvedUrl && onOpen(resolvedUrl)} scaleValue={0.98} disabled={!resolvedUrl}>
            <View style={styles.proofPreviewContainer}>
                {resolvedUrl && !loadFailed ? (
                    <Image
                        source={{ uri: resolvedUrl }}
                        style={styles.proofPreview}
                        contentFit="cover"
                        transition={180}
                        onError={() => setLoadFailed(true)}
                    />
                ) : (
                    <View style={styles.proofPreviewFallback}>
                        <FileText size={22} color={Colors.textTertiary} />
                        <Text style={styles.proofFallbackText}>
                            {loadFailed ? 'Unable to load preview' : 'Preparing preview'}
                        </Text>
                    </View>
                )}
                <View style={styles.expandBadge}>
                    <Eye size={12} color="#FFFFFF" />
                    <Text style={styles.expandText}>Tap to enlarge</Text>
                </View>
            </View>
        </AnimatedPressable>
    );
}

export default function AdminBookingsScreen() {
    const { user } = useAuth();
    const [filter, setFilter] = useState<BookingStatus | 'all'>('all');
    const [bookings, setBookings] = useState<any[]>([]);
    const [loading, setLoading] = useState(false);
    const [screenshotUrl, setScreenshotUrl] = useState<string | null>(null);

    const fetchAllBookings = useCallback(async () => {
        setLoading(true);
        const { data, error } = await supabase
            .from('bookings')
            .select('*, hall: halls(*), customer: profiles!bookings_customer_id_fkey(full_name, phone, email), payments(*)')
            .order('created_at', { ascending: false });

        if (error) {
            console.error('Admin fetch bookings error:', error);
            setBookings([]);
            setLoading(false);
            return;
        }

        if (data) {
            const normalized = data.map((item: any) => normalizeBooking(item));
            setBookings(normalized);
        }
        setLoading(false);
    }, []);

    useEffect(() => {
        fetchAllBookings();
    }, [fetchAllBookings]);

    const handleVerifyPayment = useCallback(async (bookingId: string) => {
        if (!user?.id) return;
        Alert.alert('Approve Booking', 'Mark this booking as approved and payment verified?', [
            { text: 'Cancel', style: 'cancel' },
            {
                text: 'Approve',
                onPress: async () => {
                    setLoading(true);
                    try {
                        // Step 1: Update payment record first (admin has RLS for payments)
                        const { error: payError } = await supabase
                            .from('payments')
                            .update({
                                status: 'verified',
                                verified_at: new Date().toISOString(),
                                verified_by_admin: user.id,
                            })
                            .eq('booking_id', bookingId);

                        if (payError) {
                            console.warn('Payment update error:', payError.message);
                        }

                        // Step 2: Update booking payment fields without touching constrained status values.
                        const { error: bookingError } = await supabase
                            .from('bookings')
                            .update({
                                payment_verified: true,
                                payment_verified_at: new Date().toISOString(),
                            })
                            .eq('id', bookingId);

                        if (bookingError) {
                            // If even payment_verified fails, show error
                            Alert.alert('Error', bookingError.message);
                            setLoading(false);
                            return;
                        }

                        // Step 3: Try to update status separately; if constraint fails, payment is still verified.
                        const { error: statusError } = await supabase
                            .from('bookings')
                            .update({ status: 'confirmed' })
                            .eq('id', bookingId);

                        if (statusError) {
                            console.warn('Status update failed (constraint), booking still marked as verified:', statusError.message);
                        }

                        if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                        Alert.alert('Success', 'Booking approved! Payment has been verified.');
                        fetchAllBookings();
                    } catch (err: any) {
                        Alert.alert('Error', err.message || 'Something went wrong.');
                    }
                    setLoading(false);
                },
            },
        ]);
    }, [user, fetchAllBookings]);

    const handleReject = useCallback(async (bookingId: string) => {
        Alert.alert('Reject Booking', 'Cancel this booking?', [
            { text: 'Cancel', style: 'cancel' },
            {
                text: 'Reject',
                style: 'destructive',
                onPress: async () => {
                    const { error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', bookingId);
                    if (error) {
                        Alert.alert('Error', error.message);
                        return;
                    }
                    if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                    Alert.alert('Done', 'Booking rejected.');
                    fetchAllBookings();
                },
            },
        ]);
    }, [fetchAllBookings]);

    const filteredBookings = useMemo(() => {
        if (filter === 'all') return bookings;
        return bookings.filter((b) => b.status === filter);
    }, [filter, bookings]);

    const renderItem = ({ item }: { item: any }) => {
        const statusInfo = STATUS_MAP[item.status as BookingStatus];
        const customer = item.customer;
        const customerName = item.customer_name ?? customer?.full_name ?? 'Customer';
        const payment = item.payments?.[0];
        const screenshotUrlVal = payment?.verification_screenshot_url;

        return (
            <View style={styles.card}>
                <View style={styles.cardHeader}>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.hallName}>{item.hall?.name ?? 'Venue'}</Text>
                        <Text style={styles.customerName}>{customerName}</Text>
                    </View>
                    <Badge text={item.payment_verified ? 'Approved' : statusInfo.label} variant={item.payment_verified ? 'success' : statusInfo.variant} size="sm" />
                </View>

                <View style={styles.detailsRow}>
                    <View style={styles.detail}>
                        <CalendarDays size={13} color={Colors.textTertiary} />
                        <Text style={styles.detailText}>{formatDateDisplay(item.date)}</Text>
                    </View>
                    <View style={styles.detail}>
                        <Users size={13} color={Colors.textTertiary} />
                        <Text style={styles.detailText}>{item.guest_count} guests - {SLOT_LABELS[item.slot as SlotType]}</Text>
                    </View>
                </View>

                <View style={styles.amountRow}>
                    <View>
                        <Text style={styles.amount}>{formatCurrencyFull(item.total_amount)}</Text>
                        <Text style={styles.advance}>Advance: {formatCurrencyFull(item.advance_amount)}</Text>
                    </View>
                    <View style={[styles.paymentBadge, { backgroundColor: item.payment_verified ? Colors.successLight : Colors.cream }]}>
                        {item.payment_verified ? (
                            <CheckCircle2 size={12} color={Colors.success} />
                        ) : (
                            <Wallet size={12} color={Colors.textTertiary} />
                        )}
                        <Text style={[styles.paymentBadgeText, { color: item.payment_verified ? Colors.success : Colors.textTertiary }]}>
                            {item.payment_verified ? 'Verified' : (payment?.status === 'submitted' ? 'Review' : 'Pending')}
                        </Text>
                    </View>
                </View>

                {/* Payment screenshot inline preview */}
                {screenshotUrlVal && (
                    <View style={styles.proofSection}>
                        <View style={styles.proofHeader}>
                            <FileText size={14} color={Colors.primaryDark} />
                            <Text style={styles.proofTitle}>Payment Screenshot</Text>
                        </View>
                        <PaymentProofPreview proofValue={screenshotUrlVal} onOpen={setScreenshotUrl} />
                    </View>
                )}

                {!item.payment_verified && item.status === 'pending' && (
                    <View style={styles.actionRow}>
                        <AnimatedPressable onPress={() => handleVerifyPayment(item.id)} scaleValue={0.96} style={{ flex: 1 }}>
                            <View style={styles.verifyBtn}>
                                <CheckCircle2 size={14} color="#FFFFFF" />
                                <Text style={styles.verifyText}>Approve</Text>
                            </View>
                        </AnimatedPressable>
                        <AnimatedPressable onPress={() => handleReject(item.id)} scaleValue={0.96} style={{ flex: 1 }}>
                            <View style={styles.rejectBtn}>
                                <XCircle size={14} color={Colors.error} />
                                <Text style={styles.rejectText}>Reject</Text>
                            </View>
                        </AnimatedPressable>
                    </View>
                )}
            </View>
        );
    };

    return (
        <View style={styles.screen}>
            <SafeAreaView edges={['top']} style={styles.header}>
                <Text style={styles.title}>All Bookings</Text>
                <Text style={styles.subtitle}>{bookings.length} total bookings</Text>
                <View style={styles.filterRow}>
                    {FILTERS.map((f) => (
                        <AnimatedPressable key={f.key} onPress={() => setFilter(f.key)} scaleValue={0.95}>
                            <View style={[styles.filterChip, filter === f.key && styles.filterChipActive]}>
                                <Text style={[styles.filterChipText, filter === f.key && styles.filterChipTextActive]}>
                                    {f.label}
                                </Text>
                            </View>
                        </AnimatedPressable>
                    ))}
                </View>
            </SafeAreaView>

            <FlatList
                data={filteredBookings}
                renderItem={renderItem}
                keyExtractor={(item) => item.id}
                contentContainerStyle={styles.listContent}
                showsVerticalScrollIndicator={false}
                refreshing={loading}
                onRefresh={fetchAllBookings}
                ListEmptyComponent={
                    <View style={styles.emptyContainer}>
                        <CalendarDays size={40} color={Colors.textTertiary} />
                        <Text style={styles.emptyTitle}>No bookings found</Text>
                        <Text style={styles.emptySubtitle}>Bookings matching this filter will appear here</Text>
                    </View>
                }
            />

            <ImageViewing
                images={screenshotUrl ? [{ uri: screenshotUrl }] : []}
                imageIndex={0}
                visible={!!screenshotUrl}
                onRequestClose={() => setScreenshotUrl(null)}
                animationType="fade"
                swipeToCloseEnabled
            />
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    header: { paddingHorizontal: Spacing.xl, paddingBottom: Spacing.lg, backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.borderLight, ...Shadow.sm },
    title: { fontSize: FontSize.xxl, fontWeight: FontWeight.heavy, color: Colors.text, paddingTop: Spacing.sm },
    subtitle: { fontSize: FontSize.sm, color: Colors.textTertiary, marginBottom: Spacing.md },
    filterRow: { flexDirection: 'row', gap: Spacing.sm, flexWrap: 'wrap' },
    filterChip: { paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: Radius.full, backgroundColor: Colors.cream },
    filterChipActive: { backgroundColor: Colors.primaryDark },
    filterChipText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textSecondary },
    filterChipTextActive: { color: '#FFFFFF' },
    listContent: { padding: Spacing.xl, paddingBottom: Spacing.massive },
    card: { backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.lg, marginBottom: Spacing.md, ...Shadow.sm, borderWidth: 1, borderColor: Colors.borderLight },
    cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: Spacing.sm },
    hallName: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text },
    customerName: { fontSize: FontSize.xs, color: Colors.textTertiary, marginTop: 2 },
    detailsRow: { gap: Spacing.xs, marginBottom: Spacing.sm },
    detail: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
    detailText: { fontSize: FontSize.sm, color: Colors.textSecondary },
    amountRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.sm },
    amount: { fontSize: FontSize.lg, fontWeight: FontWeight.heavy, color: Colors.primaryDark },
    advance: { fontSize: FontSize.xs, color: Colors.textTertiary, fontWeight: FontWeight.bold },
    paymentBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: Spacing.sm, paddingVertical: 4, borderRadius: Radius.full },
    paymentBadgeText: { fontSize: 11, fontWeight: FontWeight.bold },
    proofSection: { marginBottom: Spacing.sm },
    proofHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, marginBottom: Spacing.sm },
    proofTitle: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.primaryDark },
    proofPreviewContainer: { borderRadius: Radius.lg, overflow: 'hidden', position: 'relative', backgroundColor: Colors.cream },
    proofPreview: { width: '100%', height: 160, borderRadius: Radius.lg },
    proofPreviewFallback: { height: 160, alignItems: 'center', justifyContent: 'center', gap: Spacing.xs, backgroundColor: Colors.cream },
    proofFallbackText: { color: Colors.textTertiary, fontSize: FontSize.xs, fontWeight: FontWeight.bold },
    expandBadge: { position: 'absolute', bottom: Spacing.sm, right: Spacing.sm, flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(0,0,0,0.6)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: Radius.full },
    expandText: { color: '#FFFFFF', fontSize: 10, fontWeight: FontWeight.bold },
    actionRow: { flexDirection: 'row', gap: Spacing.sm, marginTop: Spacing.sm },
    verifyBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.xs, backgroundColor: Colors.success, paddingVertical: Spacing.sm, borderRadius: Radius.full },
    verifyText: { color: '#FFFFFF', fontWeight: FontWeight.bold, fontSize: FontSize.sm },
    rejectBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.xs, borderWidth: 1, borderColor: Colors.error, paddingVertical: Spacing.sm, borderRadius: Radius.full },
    rejectText: { color: Colors.error, fontWeight: FontWeight.bold, fontSize: FontSize.sm },
    emptyContainer: { alignItems: 'center', paddingTop: Spacing.massive * 2, gap: Spacing.sm },
    emptyTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
    emptySubtitle: { fontSize: FontSize.sm, color: Colors.textTertiary },
});
