import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
    View, Text, StyleSheet, FlatList, Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { formatCurrencyFull, formatCurrencyCompact } from '@/utils/currency';
import { formatDateDisplay } from '@/utils/date';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import Badge from '@/components/ui/Badge';
import type { BookingStatus } from '@/types';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const STATUS_COLORS: Record<BookingStatus, string> = {
    confirmed: Colors.successLight,
    pending: Colors.warningLight,
    cancelled: Colors.errorLight,
    completed: Colors.cream,
};

const TIME_FILTERS = ['This Week', 'This Month', 'Custom'] as const;

export default function CommissionsScreen() {
    const [timeFilter, setTimeFilter] = useState<typeof TIME_FILTERS[number]>('This Month');
    const [commissions, setCommissions] = useState<any[]>([]);

    const loadCommissions = useCallback(async () => {
        const { data } = await supabase
            .from('commissions')
            .select('*, booking: bookings(*, hall: halls(name))')
            .order('created_at', { ascending: false });
        setCommissions(data || []);
    }, []);

    useEffect(() => {
        loadCommissions();
    }, [loadCommissions]);

    const allBookings = useMemo(() => {
        const now = new Date();
        const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

        return commissions.map(c => ({
            id: c.id,
            status: (c.status === 'paid' ? 'completed' : c.status === 'calculated' ? 'confirmed' : 'pending') as BookingStatus,
            hallName: c.booking?.hall?.name || 'Unknown Hall',
            date: c.booking?.event_date || c.created_at,
            dateObj: new Date(c.booking?.event_date || c.created_at),
            total_amount: c.booking?.total_amount || 0,
            commission_amount: c.admin_commission || 0,
            discount_amount: c.discount || 0,
        })).filter(b => {
            if (timeFilter === 'This Month') return b.dateObj >= thirtyDaysAgo;
            if (timeFilter === 'This Week') return b.dateObj >= sevenDaysAgo;
            return true; // Custom shows all for now
        }).sort((a, b) => b.dateObj.getTime() - a.dateObj.getTime());
    }, [timeFilter, commissions]);

    const totalCommission = useMemo(() => allBookings.reduce((sum, b) => sum + b.commission_amount, 0), [allBookings]);
    const totalDiscount = useMemo(() => allBookings.reduce((sum, b) => sum + b.discount_amount, 0), [allBookings]);
    const avgCommission = useMemo(() => allBookings.length > 0 ? Math.round(totalCommission / allBookings.length) : 0, [allBookings, totalCommission]);

    const chartItems = useMemo(() => {
        const months = new Map<string, number>();
        allBookings.forEach((item) => {
            const label = item.dateObj.toLocaleDateString('en-IN', { month: 'short' });
            months.set(label, (months.get(label) || 0) + item.commission_amount);
        });
        const entries = Array.from(months.entries()).slice(0, 6);
        return entries.length > 0 ? entries.map(([month, commission]) => ({ month, commission })) : [{ month: 'Now', commission: 0 }];
    }, [allBookings]);
    const maxRevenue = Math.max(1, ...chartItems.map(r => r.commission));

    return (
        <View style={styles.screen}>
            <SafeAreaView edges={['top']} style={styles.header}>
                <View style={styles.adminBadge}>
                    <Text style={styles.adminBadgeText}>ADMIN ROOT</Text>
                </View>
                <Text style={styles.title}>Commission Report</Text>
                <View style={styles.filterRow}>
                    {TIME_FILTERS.map(f => (
                        <AnimatedPressable key={f} onPress={() => setTimeFilter(f)} scaleValue={0.95}>
                            <View style={[styles.filterChip, timeFilter === f && styles.filterChipActive]}>
                                <Text style={[styles.filterText, timeFilter === f && styles.filterTextActive]}>{f}</Text>
                            </View>
                        </AnimatedPressable>
                    ))}
                </View>
            </SafeAreaView>

            <FlatList
                data={allBookings}
                keyExtractor={(item) => item.id}
                showsVerticalScrollIndicator={false}
                contentContainerStyle={styles.listContent}
                ListHeaderComponent={
                    <>
                        <View style={styles.summaryGrid}>
                            {[
                                { label: 'Gross Commission', value: formatCurrencyFull(totalCommission), color: Colors.primary },
                                { label: 'Total Discounts', value: `-${formatCurrencyFull(totalDiscount)}`, color: Colors.error },
                                { label: 'Net Revenue', value: formatCurrencyFull(totalCommission - totalDiscount), color: Colors.success },
                                { label: 'Avg per Booking', value: formatCurrencyFull(avgCommission), color: Colors.gold },
                            ].map(item => (
                                <View key={item.label} style={styles.summaryCard}>
                                    <Text style={styles.summaryLabel}>{item.label}</Text>
                                    <Text style={[styles.summaryValue, { color: item.color }]}>{item.value}</Text>
                                </View>
                            ))}
                        </View>

                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>Daily Revenue</Text>
                            <View style={styles.chartContainer}>
                                {chartItems.map((item) => (
                                    <View key={item.month} style={styles.chartBar}>
                                        <Text style={styles.chartValue}>{formatCurrencyCompact(item.commission)}</Text>
                                        <View style={styles.chartBarTrack}>
                                            <LinearGradient
                                                colors={[Colors.primary, Colors.primaryLight]}
                                                style={[styles.chartBarFill, { height: `${(item.commission / maxRevenue) * 100}%` as any }]}
                                            />
                                        </View>
                                        <Text style={styles.chartLabel}>{item.month}</Text>
                                    </View>
                                ))}
                            </View>
                        </View>

                        <Text style={styles.tableTitle}>Booking Details</Text>
                        <View style={styles.tableHeader}>
                            <Text style={[styles.tableHeaderText, { flex: 2 }]}>Hall</Text>
                            <Text style={[styles.tableHeaderText, { flex: 1 }]}>Total</Text>
                            <Text style={[styles.tableHeaderText, { flex: 1 }]}>Comm.</Text>
                            <Text style={[styles.tableHeaderText, { flex: 1 }]}>Status</Text>
                        </View>
                    </>
                }
                renderItem={({ item }) => (
                    <View style={[styles.tableRow, { backgroundColor: STATUS_COLORS[item.status] || Colors.surface }]}>
                        <View style={{ flex: 2 }}>
                            <Text style={styles.rowHall} numberOfLines={1}>{item.hallName}</Text>
                            <Text style={styles.rowDate}>{formatDateDisplay(item.date)}</Text>
                        </View>
                        <Text style={[styles.rowValue, { flex: 1 }]}>{formatCurrencyCompact(item.total_amount)}</Text>
                        <Text style={[styles.rowValue, { flex: 1, color: Colors.primary }]}>{formatCurrencyCompact(item.commission_amount)}</Text>
                        <View style={{ flex: 1 }}>
                            <Badge
                                text={item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                                variant={item.status === 'confirmed' ? 'success' : item.status === 'pending' ? 'warning' : item.status === 'cancelled' ? 'error' : 'neutral'}
                                size="sm"
                            />
                        </View>
                    </View>
                )}
                ListFooterComponent={<View style={{ height: Spacing.massive }} />}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    header: {
        paddingHorizontal: Spacing.xl, paddingBottom: Spacing.xl,
        backgroundColor: Colors.surface, borderBottomWidth: 1, borderBottomColor: Colors.borderLight, ...Shadow.sm
    },
    adminBadge: { alignSelf: 'flex-start', backgroundColor: Colors.primaryDark, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, marginBottom: Spacing.sm },
    adminBadgeText: { fontSize: 10, color: '#FFFFFF', fontWeight: FontWeight.bold, letterSpacing: 1 },
    title: { fontSize: FontSize.xxxl, fontWeight: FontWeight.heavy, color: Colors.primaryDark, marginBottom: Spacing.lg },
    filterRow: { flexDirection: 'row', gap: Spacing.sm },
    filterChip: { paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md, borderRadius: Radius.full, backgroundColor: Colors.cream },
    filterChipActive: { backgroundColor: Colors.primaryDark },
    filterText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textSecondary },
    filterTextActive: { color: '#FFFFFF' },
    listContent: { padding: Spacing.xl },
    summaryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, marginBottom: Spacing.xxl },
    summaryCard: {
        width: (SCREEN_WIDTH - Spacing.xl * 2 - Spacing.sm) / 2,
        backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.xl, ...Shadow.sm, borderWidth: 1, borderColor: Colors.borderLight, minHeight: 110, justifyContent: 'center'
    },
    summaryLabel: { fontSize: FontSize.xs, color: Colors.textTertiary, fontWeight: FontWeight.bold, marginBottom: Spacing.xs },
    summaryValue: { fontSize: FontSize.xxl, fontWeight: FontWeight.heavy },
    section: { marginBottom: Spacing.xxl, backgroundColor: Colors.surface, padding: Spacing.xl, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.borderLight, ...Shadow.sm },
    sectionTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.primaryDark, marginBottom: Spacing.xl },
    chartContainer: { flexDirection: 'row', justifyContent: 'space-between', height: 160, alignItems: 'flex-end' },
    chartBar: { flex: 1, alignItems: 'center', gap: Spacing.xs },
    chartValue: { fontSize: 10, color: Colors.textTertiary, fontWeight: FontWeight.bold },
    chartBarTrack: { width: 32, flex: 1, backgroundColor: Colors.background, borderRadius: Radius.md, overflow: 'hidden', justifyContent: 'flex-end' },
    chartBarFill: { width: '100%', borderRadius: Radius.md },
    chartLabel: { fontSize: FontSize.xs, color: Colors.textSecondary, fontWeight: FontWeight.bold },
    tableTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: Spacing.md },
    tableHeader: {
        flexDirection: 'row', backgroundColor: Colors.cream, paddingHorizontal: Spacing.md,
        paddingVertical: Spacing.sm, borderRadius: Radius.sm, marginBottom: Spacing.xs,
    },
    tableHeaderText: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textSecondary, textTransform: 'uppercase' as const },
    tableRow: {
        flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.md,
        paddingVertical: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.borderLight,
        borderRadius: Radius.xs,
    },
    rowHall: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.text },
    rowDate: { fontSize: 10, color: Colors.textTertiary, marginTop: 1 },
    rowValue: { fontSize: FontSize.sm, fontWeight: FontWeight.medium, color: Colors.text },
});
