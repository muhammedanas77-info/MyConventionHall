/**
 * app/(admin)/notification-failures.tsx
 *
 * Admin screen listing notification delivery failures.
 *
 * Requirements: 10.9, 8.9
 *
 * Features:
 *  - Lists all rows from `notification_failures` table
 *  - Displays: recipient email, notification type, booking ID, vendor ID,
 *    error message, attempt count, and failed_at timestamp
 *  - Sorted by `failed_at DESC` (most recent failures first)
 *  - Pull-to-refresh reloads the list
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  BellOff,
  Mail,
  AlertTriangle,
  RefreshCw,
  Hash,
  Clock,
  RotateCcw,
  Store,
  BookOpen,
} from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import type { NotificationFailure } from '@/types';

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Formats a notification_type slug into a human-readable label.
 * e.g. "booking_received_customer" → "Booking Received (Customer)"
 */
function formatNotificationType(type: string): string {
  return type
    .split('_')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

/**
 * Formats an ISO timestamp into a readable date + time string.
 * e.g. "2024-03-15T14:32:00Z" → "15 Mar 2024, 14:32"
 */
function formatFailedAt(isoString: string): string {
  const date = new Date(isoString);
  if (Number.isNaN(date.getTime())) return isoString;

  const day = date.getDate();
  const month = date.toLocaleString('en-IN', { month: 'short' });
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');

  return `${day} ${month} ${year}, ${hours}:${minutes}`;
}

/**
 * Truncates a UUID to a short display form: first 8 chars + "…"
 */
function shortId(id: string | null): string {
  if (!id) return '—';
  return id.length > 8 ? `${id.slice(0, 8)}…` : id;
}

// ─── Type badge ───────────────────────────────────────────────────────────────

const TYPE_BADGE_COLORS: Record<string, { bg: string; text: string }> = {
  booking_received_customer: { bg: '#E0F2FE', text: '#0369A1' },
  booking_received_vendor: { bg: '#E0F2FE', text: '#0369A1' },
  booking_confirmed: { bg: Colors.successLight, text: Colors.success },
  booking_rejected: { bg: Colors.errorLight, text: Colors.error },
  booking_cancelled: { bg: Colors.warningLight, text: Colors.warning },
  vendor_approved: { bg: Colors.successLight, text: Colors.success },
  vendor_rejected: { bg: Colors.errorLight, text: Colors.error },
};

function TypeBadge({ type }: { type: string }) {
  const colors = TYPE_BADGE_COLORS[type] ?? {
    bg: Colors.cream,
    text: Colors.textSecondary,
  };
  return (
    <View style={[styles.typeBadge, { backgroundColor: colors.bg }]}>
      <Text style={[styles.typeBadgeText, { color: colors.text }]}>
        {formatNotificationType(type)}
      </Text>
    </View>
  );
}

// ─── Attempt badge ────────────────────────────────────────────────────────────

function AttemptsBadge({ attempts }: { attempts: number }) {
  // 3 attempts = max retries exhausted (per Req 10.9)
  const isMaxed = attempts >= 3;
  return (
    <View
      style={[
        styles.attemptsBadge,
        isMaxed ? styles.attemptsBadgeMaxed : styles.attemptsBadgePartial,
      ]}
    >
      <RotateCcw size={10} color={isMaxed ? Colors.error : Colors.warning} />
      <Text
        style={[
          styles.attemptsBadgeText,
          { color: isMaxed ? Colors.error : Colors.warning },
        ]}
      >
        {attempts} attempt{attempts !== 1 ? 's' : ''}
      </Text>
    </View>
  );
}

// ─── Failure card ─────────────────────────────────────────────────────────────

function FailureCard({ item }: { item: NotificationFailure }) {
  return (
    <View style={styles.card}>
      {/* Header: type badge + attempts badge */}
      <View style={styles.cardHeader}>
        <TypeBadge type={item.notification_type} />
        <AttemptsBadge attempts={item.attempts} />
      </View>

      {/* Recipient email */}
      <View style={styles.fieldRow}>
        <Mail size={13} color={Colors.textTertiary} />
        <Text style={styles.fieldValue} numberOfLines={1}>
          {item.recipient_email}
        </Text>
      </View>

      {/* Error message */}
      <View style={styles.errorBox}>
        <AlertTriangle size={12} color={Colors.error} />
        <Text style={styles.errorText} numberOfLines={3}>
          {item.error_message}
        </Text>
      </View>

      {/* IDs row */}
      <View style={styles.idsRow}>
        {item.booking_id ? (
          <View style={styles.idItem}>
            <BookOpen size={11} color={Colors.textTertiary} />
            <Text style={styles.idLabel}>Booking</Text>
            <Text style={styles.idValue}>{shortId(item.booking_id)}</Text>
          </View>
        ) : null}
        {item.vendor_id ? (
          <View style={styles.idItem}>
            <Store size={11} color={Colors.textTertiary} />
            <Text style={styles.idLabel}>Vendor</Text>
            <Text style={styles.idValue}>{shortId(item.vendor_id)}</Text>
          </View>
        ) : null}
        {!item.booking_id && !item.vendor_id ? (
          <Text style={styles.noIdsText}>No booking or vendor reference</Text>
        ) : null}
      </View>

      {/* Footer: failed_at + record ID */}
      <View style={styles.cardFooter}>
        <View style={styles.footerLeft}>
          <Clock size={11} color={Colors.textTertiary} />
          <Text style={styles.failedAtText}>{formatFailedAt(item.failed_at)}</Text>
        </View>
        <View style={styles.footerRight}>
          <Hash size={10} color={Colors.textTertiary} />
          <Text style={styles.recordIdText}>{shortId(item.id)}</Text>
        </View>
      </View>
    </View>
  );
}

// ─── Main screen ──────────────────────────────────────────────────────────────

export default function AdminNotificationFailuresScreen() {
  const [failures, setFailures] = useState<NotificationFailure[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  // ── Data fetching ──────────────────────────────────────────────────────────

  const fetchFailures = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    else setLoading(true);

    const { data, error } = await supabase
      .from('notification_failures')
      .select(
        'id, recipient_email, notification_type, booking_id, vendor_id, error_message, attempts, failed_at'
      )
      .order('failed_at', { ascending: false });

    if (error) {
      console.error('Admin fetch notification failures error:', error);
    } else {
      setFailures((data ?? []) as NotificationFailure[]);
    }

    if (isRefresh) setRefreshing(false);
    else setLoading(false);
  }, []);

  useEffect(() => {
    fetchFailures();
  }, [fetchFailures]);

  // ── Render ─────────────────────────────────────────────────────────────────

  return (
    <View style={styles.screen}>
      {/* Header */}
      <SafeAreaView edges={['top']} style={styles.header}>
        <View style={styles.adminBadge}>
          <Text style={styles.adminBadgeText}>ADMIN ROOT</Text>
        </View>
        <View style={styles.titleRow}>
          <BellOff size={22} color={Colors.primaryDark} />
          <Text style={styles.title}>Notification Failures</Text>
        </View>
        <Text style={styles.subtitle}>
          {failures.length} failure{failures.length !== 1 ? 's' : ''} · sorted by most recent
        </Text>

        {/* Legend */}
        <View style={styles.legendRow}>
          <View style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: Colors.error }]} />
            <Text style={styles.legendText}>3 attempts (exhausted)</Text>
          </View>
          <View style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: Colors.warning }]} />
            <Text style={styles.legendText}>Partial retries</Text>
          </View>
        </View>
      </SafeAreaView>

      {/* List */}
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.primary} />
          <Text style={styles.loadingText}>Loading failures…</Text>
        </View>
      ) : (
        <FlatList
          data={failures}
          renderItem={({ item }) => <FailureCard item={item} />}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshing={refreshing}
          onRefresh={() => fetchFailures(true)}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <BellOff size={48} color={Colors.textTertiary} />
              <Text style={styles.emptyTitle}>No failures recorded</Text>
              <Text style={styles.emptySubtitle}>
                Notification failures will appear here when email delivery is exhausted after 3 retry attempts.
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background },

  // Header
  header: {
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.lg,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
    ...Shadow.sm,
  },
  adminBadge: {
    alignSelf: 'flex-start',
    backgroundColor: Colors.primaryDark,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginBottom: Spacing.sm,
  },
  adminBadgeText: {
    fontSize: 10,
    color: '#FFFFFF',
    fontWeight: FontWeight.bold,
    letterSpacing: 1,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.xs,
  },
  title: {
    fontSize: FontSize.xxxl,
    fontWeight: FontWeight.heavy,
    color: Colors.text,
  },
  subtitle: {
    fontSize: FontSize.sm,
    color: Colors.textTertiary,
    marginBottom: Spacing.md,
    fontWeight: FontWeight.medium,
  },

  // Legend
  legendRow: {
    flexDirection: 'row',
    gap: Spacing.lg,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  legendDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  legendText: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
  },

  // List
  listContent: { padding: Spacing.xl, paddingBottom: Spacing.massive },

  // Card
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    ...Shadow.sm,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },

  // Card header
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.md,
    gap: Spacing.sm,
    flexWrap: 'wrap',
  },

  // Type badge
  typeBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: Radius.full,
    flexShrink: 1,
  },
  typeBadgeText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
  },

  // Attempts badge
  attemptsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: Radius.full,
  },
  attemptsBadgeMaxed: { backgroundColor: Colors.errorLight },
  attemptsBadgePartial: { backgroundColor: Colors.warningLight },
  attemptsBadgeText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
  },

  // Field row (email)
  fieldRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    marginBottom: Spacing.sm,
  },
  fieldValue: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    fontWeight: FontWeight.medium,
    flex: 1,
  },

  // Error box
  errorBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.xs,
    backgroundColor: Colors.errorLight,
    borderRadius: Radius.md,
    padding: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  errorText: {
    fontSize: FontSize.xs,
    color: Colors.error,
    fontWeight: FontWeight.medium,
    flex: 1,
    lineHeight: 16,
  },

  // IDs row
  idsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
    marginBottom: Spacing.sm,
    paddingTop: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
  },
  idItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  idLabel: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
  },
  idValue: {
    fontSize: FontSize.xs,
    color: Colors.textSecondary,
    fontWeight: FontWeight.bold,
    fontVariant: ['tabular-nums'],
  },
  noIdsText: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontStyle: 'italic',
  },

  // Card footer
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
    marginTop: Spacing.xs,
  },
  footerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  failedAtText: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
  },
  footerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  recordIdText: {
    fontSize: 10,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
    fontVariant: ['tabular-nums'],
  },

  // Loading
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.md,
  },
  loadingText: {
    fontSize: FontSize.md,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
  },

  // Empty
  emptyContainer: {
    alignItems: 'center',
    paddingTop: Spacing.massive * 2,
    gap: Spacing.md,
  },
  emptyTitle: {
    fontSize: FontSize.xl,
    fontWeight: FontWeight.bold,
    color: Colors.text,
  },
  emptySubtitle: {
    fontSize: FontSize.md,
    color: Colors.textTertiary,
    textAlign: 'center',
    paddingHorizontal: Spacing.xl,
    lineHeight: 22,
  },
});
