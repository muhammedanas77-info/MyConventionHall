/**
 * app/(admin)/service-bookings.tsx
 *
 * Cross-sector service bookings overview for admins.
 *
 * Requirements: 8.7, 8.9
 *
 * Key behaviours:
 *  - Simultaneous filters: sector, booking status, event date range
 *    (start date to end date inclusive), and city (case-insensitive substring).
 *  - Each row shows vendor name, customer name, status badge, total/advance
 *    amounts, sector badge, event date, event type, and guest count.
 *  - All filters are applied server-side via Supabase query composition.
 *  - Pull-to-refresh reloads with the current filter state.
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  ScrollView,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  BookOpen,
  Search,
  CalendarDays,
  Users,
  DollarSign,
  AlertTriangle,
  User,
  Building2,
} from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { formatCurrencyFull } from '@/utils/currency';
import { formatDateDisplay } from '@/utils/date';
import { SECTOR_LIST, SECTOR_CONFIGS } from '@/constants/sectors';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import type { ServiceBooking, VendorSector, ServiceBookingStatus } from '@/types';

// ─── Types ────────────────────────────────────────────────────────────────────

interface BookingRow {
  id: string;
  listing_id: string;
  vendor_id: string;
  customer_id: string;
  sector: string;
  event_date: string;
  event_type: string;
  guest_count: number | null;
  total_amount: number;
  advance_amount: number;
  status: string;
  special_requests: string | null;
  rejection_reason: string | null;
  created_at: string;
  vendor?: { business_name: string | null; profile?: { email: string } | null };
  customer?: { full_name: string; email?: string };
}

type SectorFilter = VendorSector | 'all';
type StatusFilter = ServiceBookingStatus | 'all';

// ─── Constants ────────────────────────────────────────────────────────────────

const STATUS_OPTIONS: { key: StatusFilter; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'pending', label: 'Pending' },
  { key: 'confirmed', label: 'Confirmed' },
  { key: 'completed', label: 'Completed' },
  { key: 'cancelled', label: 'Cancelled' },
];

const STATUS_COLORS: Record<ServiceBookingStatus, { bg: string; text: string }> = {
  pending: { bg: Colors.warningLight, text: Colors.warning },
  confirmed: { bg: Colors.successLight, text: Colors.success },
  completed: { bg: '#E0F2FE', text: '#0369A1' },
  cancelled: { bg: Colors.errorLight, text: Colors.error },
};

const EVENT_TYPE_LABELS: Record<string, string> = {
  wedding: 'Wedding',
  birthday: 'Birthday',
  corporate: 'Corporate',
  other: 'Other',
};

const PRICE_UNIT_LABELS: Record<string, string> = {
  per_event: '/ event',
  per_plate: '/ plate',
  per_hour: '/ hour',
  per_day: '/ day',
};

// ─── Sub-components ───────────────────────────────────────────────────────────

function SectorBadge({ sector }: { sector: VendorSector }) {
  const cfg = SECTOR_CONFIGS[sector];
  return (
    <View style={[styles.sectorBadge, { backgroundColor: cfg.badgeColor + '22' }]}>
      <Text style={[styles.sectorBadgeText, { color: cfg.badgeColor }]}>
        {cfg.displayName}
      </Text>
    </View>
  );
}

function StatusBadge({ status }: { status: ServiceBookingStatus }) {
  const colors = STATUS_COLORS[status];
  return (
    <View style={[styles.statusBadge, { backgroundColor: colors.bg }]}>
      <Text style={[styles.statusBadgeText, { color: colors.text }]}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Text>
    </View>
  );
}

// ─── Date input helper ────────────────────────────────────────────────────────

/**
 * Minimal inline date input (YYYY-MM-DD text field).
 * A full date-picker is not used here to keep the admin screen dependency-free;
 * the admin is expected to type ISO dates directly.
 */
function DateInput({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
}) {
  return (
    <View style={styles.dateInputWrapper}>
      <Text style={styles.dateInputLabel}>{label}</Text>
      <TextInput
        style={styles.dateInput}
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor={Colors.textTertiary}
        keyboardType="numbers-and-punctuation"
        maxLength={10}
        returnKeyType="done"
      />
    </View>
  );
}

// ─── Main screen ──────────────────────────────────────────────────────────────

export default function AdminServiceBookingsScreen() {
  const [bookings, setBookings] = useState<BookingRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  // Filters
  const [sectorFilter, setSectorFilter] = useState<SectorFilter>('all');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [cityQuery, setCityQuery] = useState('');

  // ── Data fetching ──────────────────────────────────────────────────────────

  const fetchBookings = useCallback(
    async (isRefresh = false) => {
      if (isRefresh) setRefreshing(true);
      else setLoading(true);

      // Build query with simultaneous filters (Req 8.7)
      let query = supabase
        .from('service_bookings')
        .select(
          `id, listing_id, vendor_id, customer_id, sector, event_date, event_type,
           guest_count, total_amount, advance_amount, status, special_requests,
           rejection_reason, created_at,
           vendor:vendor_profiles(
             business_name,
             sector_data,
             profile:profiles(email)
           ),
           customer:profiles!service_bookings_customer_id_fkey(full_name, email),
           listing:service_listings(title, price_unit)`
        )
        .order('event_date', { ascending: false });

      // Sector filter
      if (sectorFilter !== 'all') {
        query = query.eq('sector', sectorFilter);
      }

      // Status filter
      if (statusFilter !== 'all') {
        query = query.eq('status', statusFilter);
      }

      // Event date range — inclusive (Req 8.7)
      const trimmedFrom = dateFrom.trim();
      const trimmedTo = dateTo.trim();
      if (trimmedFrom && isValidDate(trimmedFrom)) {
        query = query.gte('event_date', trimmedFrom);
      }
      if (trimmedTo && isValidDate(trimmedTo)) {
        query = query.lte('event_date', trimmedTo);
      }

      const { data, error } = await query;

      if (error) {
        console.error('Admin fetch service bookings error:', error);
      } else {
        setBookings((data ?? []) as unknown as BookingRow[]);
      }

      if (isRefresh) setRefreshing(false);
      else setLoading(false);
    },
    [sectorFilter, statusFilter, dateFrom, dateTo]
  );

  useEffect(() => {
    fetchBookings();
  }, [fetchBookings]);

  // ── Client-side city filter ────────────────────────────────────────────────
  // City is stored inside vendor_profiles.sector_data (JSONB), so we filter
  // client-side after the server query rather than using a Postgres expression.

  const filteredBookings = useMemo(() => {
    const q = cityQuery.trim().toLowerCase();
    if (!q) return bookings;

    return bookings.filter((b) => {
      // Try to extract city from sector_data JSONB
      const sectorData = (b.vendor as any)?.sector_data;
      const city: string = sectorData?.city ?? '';
      return city.toLowerCase().includes(q);
    });
  }, [bookings, cityQuery]);

  // ── Render item ────────────────────────────────────────────────────────────

  const renderItem = useCallback(({ item }: { item: BookingRow }) => {
    const vendorName =
      (item.vendor as any)?.business_name ??
      (item.vendor as any)?.profile?.email ??
      'Unknown vendor';
    const customerName =
      (item.customer as any)?.full_name ??
      (item.customer as any)?.email ??
      'Unknown customer';
    const listingTitle = (item as any).listing?.title ?? '—';
    const priceUnit = (item as any).listing?.price_unit ?? 'per_event';
    const priceUnitLabel = PRICE_UNIT_LABELS[priceUnit] ?? '';

    return (
      <View style={styles.card}>
        {/* Top row: vendor + sector badge */}
        <View style={styles.cardHeader}>
          <View style={styles.cardHeaderLeft}>
            <View style={styles.nameRow}>
              <Building2 size={12} color={Colors.textTertiary} />
              <Text style={styles.vendorName} numberOfLines={1}>
                {vendorName}
              </Text>
            </View>
            <Text style={styles.listingTitle} numberOfLines={1}>
              {listingTitle}
            </Text>
          </View>
          <View style={styles.badgesColumn}>
            <SectorBadge sector={item.sector as VendorSector} />
            <StatusBadge status={item.status as ServiceBookingStatus} />
          </View>
        </View>

        {/* Customer row */}
        <View style={styles.metaRow}>
          <User size={12} color={Colors.textTertiary} />
          <Text style={styles.metaText} numberOfLines={1}>
            {customerName}
          </Text>
        </View>

        {/* Event date + type */}
        <View style={styles.detailsRow}>
          <View style={styles.detailItem}>
            <CalendarDays size={12} color={Colors.textTertiary} />
            <Text style={styles.detailText}>{formatDateDisplay(item.event_date)}</Text>
          </View>
          <View style={styles.detailItem}>
            <Text style={styles.eventTypePill}>
              {EVENT_TYPE_LABELS[item.event_type] ?? item.event_type}
            </Text>
          </View>
          {item.guest_count != null && (
            <View style={styles.detailItem}>
              <Users size={12} color={Colors.textTertiary} />
              <Text style={styles.detailText}>{item.guest_count} guests</Text>
            </View>
          )}
        </View>

        {/* Amounts */}
        <View style={styles.amountsRow}>
          <View style={styles.amountBlock}>
            <DollarSign size={12} color={Colors.textTertiary} />
            <View>
              <Text style={styles.totalAmount}>
                {formatCurrencyFull(item.total_amount)}
                <Text style={styles.priceUnit}>{priceUnitLabel}</Text>
              </Text>
              <Text style={styles.advanceAmount}>
                Advance: {formatCurrencyFull(item.advance_amount)}
              </Text>
            </View>
          </View>
        </View>

        {/* Special requests (if present) */}
        {item.special_requests ? (
          <View style={styles.specialRequestsRow}>
            <Text style={styles.specialRequestsLabel}>Note: </Text>
            <Text style={styles.specialRequestsText} numberOfLines={2}>
              {item.special_requests}
            </Text>
          </View>
        ) : null}

        {/* Rejection reason (if cancelled) */}
        {item.status === 'cancelled' && item.rejection_reason ? (
          <View style={styles.rejectionRow}>
            <Text style={styles.rejectionLabel}>Rejection: </Text>
            <Text style={styles.rejectionText} numberOfLines={2}>
              {item.rejection_reason}
            </Text>
          </View>
        ) : null}

        {/* Booking ID footer */}
        <Text style={styles.bookingId} numberOfLines={1}>
          ID: {item.id}
        </Text>
      </View>
    );
  }, []);

  // ── Render ─────────────────────────────────────────────────────────────────

  return (
    <View style={styles.screen}>
      {/* Header */}
      <SafeAreaView edges={['top']} style={styles.header}>
        <View style={styles.adminBadge}>
          <Text style={styles.adminBadgeText}>ADMIN ROOT</Text>
        </View>
        <View style={styles.titleRow}>
          <BookOpen size={22} color={Colors.primaryDark} />
          <Text style={styles.title}>Service Bookings</Text>
        </View>
        <Text style={styles.subtitle}>
          {filteredBookings.length} booking
          {filteredBookings.length !== 1 ? 's' : ''}
          {sectorFilter !== 'all'
            ? ` · ${SECTOR_CONFIGS[sectorFilter].displayName}`
            : ''}
          {statusFilter !== 'all' ? ` · ${statusFilter}` : ''}
        </Text>

        {/* City search */}
        <View style={styles.searchRow}>
          <Search size={16} color={Colors.textTertiary} />
          <TextInput
            style={styles.searchInput}
            placeholder="Filter by city…"
            placeholderTextColor={Colors.textTertiary}
            value={cityQuery}
            onChangeText={setCityQuery}
            returnKeyType="search"
            clearButtonMode="while-editing"
          />
        </View>

        {/* Date range inputs */}
        <View style={styles.dateRangeRow}>
          <DateInput
            label="From"
            value={dateFrom}
            onChange={setDateFrom}
            placeholder="YYYY-MM-DD"
          />
          <View style={styles.dateSeparator}>
            <Text style={styles.dateSeparatorText}>→</Text>
          </View>
          <DateInput
            label="To"
            value={dateTo}
            onChange={setDateTo}
            placeholder="YYYY-MM-DD"
          />
        </View>

        {/* Sector filter chips */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterScroll}
        >
          <AnimatedPressable onPress={() => setSectorFilter('all')} scaleValue={0.95}>
            <View
              style={[
                styles.filterChip,
                sectorFilter === 'all' && styles.filterChipActive,
              ]}
            >
              <Text
                style={[
                  styles.filterChipText,
                  sectorFilter === 'all' && styles.filterChipTextActive,
                ]}
              >
                All Sectors
              </Text>
            </View>
          </AnimatedPressable>
          {SECTOR_LIST.map((s) => (
            <AnimatedPressable
              key={s}
              onPress={() => setSectorFilter(s)}
              scaleValue={0.95}
            >
              <View
                style={[
                  styles.filterChip,
                  sectorFilter === s && styles.filterChipActive,
                  sectorFilter === s && { backgroundColor: SECTOR_CONFIGS[s].badgeColor },
                ]}
              >
                <Text
                  style={[
                    styles.filterChipText,
                    sectorFilter === s && styles.filterChipTextActive,
                  ]}
                >
                  {SECTOR_CONFIGS[s].displayName}
                </Text>
              </View>
            </AnimatedPressable>
          ))}
        </ScrollView>

        {/* Status filter chips */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterScroll}
        >
          {STATUS_OPTIONS.map((opt) => (
            <AnimatedPressable
              key={opt.key}
              onPress={() => setStatusFilter(opt.key)}
              scaleValue={0.95}
            >
              <View
                style={[
                  styles.filterChip,
                  statusFilter === opt.key && styles.filterChipActive,
                ]}
              >
                <Text
                  style={[
                    styles.filterChipText,
                    statusFilter === opt.key && styles.filterChipTextActive,
                  ]}
                >
                  {opt.label}
                </Text>
              </View>
            </AnimatedPressable>
          ))}
        </ScrollView>
      </SafeAreaView>

      {/* List */}
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.primary} />
          <Text style={styles.loadingText}>Loading bookings…</Text>
        </View>
      ) : (
        <FlatList
          data={filteredBookings}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshing={refreshing}
          onRefresh={() => fetchBookings(true)}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <AlertTriangle size={40} color={Colors.textTertiary} />
              <Text style={styles.emptyTitle}>No bookings found</Text>
              <Text style={styles.emptySubtitle}>
                {cityQuery || sectorFilter !== 'all' || statusFilter !== 'all' || dateFrom || dateTo
                  ? 'Try adjusting the filters to see more results.'
                  : 'Service bookings will appear here once customers start booking.'}
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Returns true if the string is a valid ISO date (YYYY-MM-DD). */
function isValidDate(s: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(s);
  return !Number.isNaN(d.getTime());
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background },

  // Header
  header: {
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.lg,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
    ...Shadow.sm,
  },
  adminBadge: {
    alignSelf: 'flex-start',
    backgroundColor: Colors.primaryDark,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginBottom: Spacing.sm,
  },
  adminBadgeText: {
    fontSize: 10,
    color: '#FFFFFF',
    fontWeight: FontWeight.bold,
    letterSpacing: 1,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.xs,
  },
  title: {
    fontSize: FontSize.xxxl,
    fontWeight: FontWeight.heavy,
    color: Colors.text,
  },
  subtitle: {
    fontSize: FontSize.sm,
    color: Colors.textTertiary,
    marginBottom: Spacing.md,
    fontWeight: FontWeight.medium,
  },

  // City search
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.cream,
    borderRadius: Radius.lg,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    marginBottom: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  searchInput: {
    flex: 1,
    fontSize: FontSize.md,
    color: Colors.text,
    paddingVertical: 0,
  },

  // Date range
  dateRangeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  dateInputWrapper: { flex: 1 },
  dateInputLabel: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
    color: Colors.textTertiary,
    marginBottom: 4,
  },
  dateInput: {
    backgroundColor: Colors.cream,
    borderRadius: Radius.lg,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    fontSize: FontSize.sm,
    color: Colors.text,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  dateSeparator: {
    paddingTop: Spacing.lg,
  },
  dateSeparatorText: {
    fontSize: FontSize.md,
    color: Colors.textTertiary,
    fontWeight: FontWeight.bold,
  },

  // Filter chips
  filterScroll: {
    gap: Spacing.sm,
    paddingRight: Spacing.xl,
    marginBottom: Spacing.sm,
  },
  filterChip: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: Radius.full,
    backgroundColor: Colors.cream,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  filterChipActive: {
    backgroundColor: Colors.primaryDark,
    borderColor: Colors.primaryDark,
  },
  filterChipText: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
    color: Colors.textSecondary,
  },
  filterChipTextActive: { color: '#FFFFFF' },

  // List
  listContent: { padding: Spacing.xl, paddingBottom: Spacing.massive },

  // Card
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    ...Shadow.sm,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },

  // Card header
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.sm,
    gap: Spacing.sm,
  },
  cardHeaderLeft: { flex: 1 },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    marginBottom: 2,
  },
  vendorName: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.bold,
    color: Colors.text,
    flex: 1,
  },
  listingTitle: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
  },
  badgesColumn: {
    alignItems: 'flex-end',
    gap: Spacing.xs,
  },

  // Sector badge
  sectorBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: Radius.full,
  },
  sectorBadgeText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
  },

  // Status badge
  statusBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: Radius.full,
  },
  statusBadgeText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
  },

  // Customer row
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    marginBottom: Spacing.sm,
  },
  metaText: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    fontWeight: FontWeight.medium,
    flex: 1,
  },

  // Details row
  detailsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
    marginBottom: Spacing.sm,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  detailText: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    fontWeight: FontWeight.medium,
  },
  eventTypePill: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
    color: Colors.primaryDark,
    backgroundColor: Colors.primaryFaded,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: Radius.full,
    overflow: 'hidden',
  },

  // Amounts
  amountsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Spacing.sm,
    paddingTop: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
  },
  amountBlock: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.xs,
  },
  totalAmount: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.heavy,
    color: Colors.primaryDark,
  },
  priceUnit: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.medium,
    color: Colors.textTertiary,
  },
  advanceAmount: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontWeight: FontWeight.bold,
    marginTop: 2,
  },

  // Special requests
  specialRequestsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: Spacing.xs,
  },
  specialRequestsLabel: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
    color: Colors.textSecondary,
  },
  specialRequestsText: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    flex: 1,
  },

  // Rejection reason
  rejectionRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: Spacing.xs,
  },
  rejectionLabel: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
    color: Colors.error,
  },
  rejectionText: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    flex: 1,
  },

  // Booking ID
  bookingId: {
    fontSize: 10,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
    marginTop: Spacing.xs,
  },

  // Loading
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.md,
  },
  loadingText: {
    fontSize: FontSize.md,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
  },

  // Empty
  emptyContainer: {
    alignItems: 'center',
    paddingTop: Spacing.massive * 2,
    gap: Spacing.md,
  },
  emptyTitle: {
    fontSize: FontSize.xl,
    fontWeight: FontWeight.bold,
    color: Colors.text,
  },
  emptySubtitle: {
    fontSize: FontSize.md,
    color: Colors.textTertiary,
    textAlign: 'center',
    paddingHorizontal: Spacing.xl,
  },
});
