/**
 * app/(admin)/vendors.tsx
 *
 * Cross-sector vendor management screen for admins.
 *
 * Requirements: 8.1, 8.9
 *
 * Features:
 *  - Lists all registered vendors across all sectors
 *  - Simultaneous filters: sector (dropdown), is_approved (tri-state), city (search box)
 *  - Tap row → /(admin)/vendor/[id] for approve/reject actions
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  ScrollView,
  ActivityIndicator,
  Modal,
  Pressable,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import {
  Users,
  Search,
  ChevronDown,
  ChevronRight,
  CheckCircle2,
  XCircle,
  Clock,
  MapPin,
  Store,
  ChevronUp,
} from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { SECTOR_LIST, SECTOR_CONFIGS } from '@/constants/sectors';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import type { VendorProfile, VendorSector } from '@/types';

// ─── Types ────────────────────────────────────────────────────────────────────

interface VendorRow extends VendorProfile {
  /** Joined from profiles table */
  profile?: { email: string; full_name: string | null } | null;
}

type SectorFilter = VendorSector | 'all';
type ApprovalFilter = 'all' | 'approved' | 'pending' | 'rejected';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function SectorBadge({ sector }: { sector: VendorSector }) {
  const cfg = SECTOR_CONFIGS[sector];
  return (
    <View style={[styles.sectorBadge, { backgroundColor: cfg.badgeColor + '22' }]}>
      <Text style={[styles.sectorBadgeText, { color: cfg.badgeColor }]}>
        {cfg.displayName}
      </Text>
    </View>
  );
}

function ApprovalBadge({ isApproved, rejectionReason }: { isApproved: boolean; rejectionReason: string | null }) {
  if (isApproved) {
    return (
      <View style={[styles.approvalBadge, styles.approvalBadgeApproved]}>
        <CheckCircle2 size={10} color={Colors.success} />
        <Text style={[styles.approvalBadgeText, { color: Colors.success }]}>Approved</Text>
      </View>
    );
  }
  if (rejectionReason) {
    return (
      <View style={[styles.approvalBadge, styles.approvalBadgeRejected]}>
        <XCircle size={10} color={Colors.error} />
        <Text style={[styles.approvalBadgeText, { color: Colors.error }]}>Rejected</Text>
      </View>
    );
  }
  return (
    <View style={[styles.approvalBadge, styles.approvalBadgePending]}>
      <Clock size={10} color={Colors.warning} />
      <Text style={[styles.approvalBadgeText, { color: Colors.warning }]}>Pending</Text>
    </View>
  );
}

// ─── Sector Dropdown ──────────────────────────────────────────────────────────

function SectorDropdown({
  value,
  onChange,
}: {
  value: SectorFilter;
  onChange: (v: SectorFilter) => void;
}) {
  const [open, setOpen] = useState(false);

  const label =
    value === 'all' ? 'All Sectors' : SECTOR_CONFIGS[value].displayName;

  const options: { key: SectorFilter; label: string }[] = [
    { key: 'all', label: 'All Sectors' },
    ...SECTOR_LIST.map((s) => ({ key: s as SectorFilter, label: SECTOR_CONFIGS[s].displayName })),
  ];

  return (
    <View>
      <AnimatedPressable onPress={() => setOpen(true)} scaleValue={0.97}>
        <View style={styles.dropdownTrigger}>
          <Text style={styles.dropdownTriggerText}>{label}</Text>
          <ChevronDown size={14} color={Colors.textSecondary} />
        </View>
      </AnimatedPressable>

      <Modal
        visible={open}
        transparent
        animationType="fade"
        onRequestClose={() => setOpen(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setOpen(false)}>
          <View style={styles.dropdownMenu}>
            <Text style={styles.dropdownMenuTitle}>Filter by Sector</Text>
            {options.map((opt) => (
              <AnimatedPressable
                key={opt.key}
                onPress={() => {
                  onChange(opt.key);
                  setOpen(false);
                }}
                scaleValue={0.97}
              >
                <View
                  style={[
                    styles.dropdownOption,
                    value === opt.key && styles.dropdownOptionSelected,
                  ]}
                >
                  {opt.key !== 'all' && (
                    <View
                      style={[
                        styles.dropdownDot,
                        { backgroundColor: SECTOR_CONFIGS[opt.key as VendorSector].badgeColor },
                      ]}
                    />
                  )}
                  <Text
                    style={[
                      styles.dropdownOptionText,
                      value === opt.key && styles.dropdownOptionTextSelected,
                    ]}
                  >
                    {opt.label}
                  </Text>
                  {value === opt.key && (
                    <CheckCircle2 size={14} color={Colors.primary} style={{ marginLeft: 'auto' }} />
                  )}
                </View>
              </AnimatedPressable>
            ))}
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

// ─── Approval Tri-state Filter ────────────────────────────────────────────────

const APPROVAL_OPTIONS: { key: ApprovalFilter; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'approved', label: 'Approved' },
  { key: 'pending', label: 'Pending' },
  { key: 'rejected', label: 'Rejected' },
];

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function AdminVendorsScreen() {
  const router = useRouter();

  const [vendors, setVendors] = useState<VendorRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  // Filters
  const [sectorFilter, setSectorFilter] = useState<SectorFilter>('all');
  const [approvalFilter, setApprovalFilter] = useState<ApprovalFilter>('all');
  const [citySearch, setCitySearch] = useState('');

  // ── Data fetching ──────────────────────────────────────────────────────────

  const fetchVendors = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    else setLoading(true);

    let query = supabase
      .from('vendor_profiles')
      .select(
        `id, vendor_sector, business_name, phone, is_approved,
         profile_completion_status, rejection_reason, sector_data,
         created_at, updated_at,
         profile:profiles(email, full_name)`
      )
      .order('created_at', { ascending: false });

    // Server-side sector filter
    if (sectorFilter !== 'all') {
      query = query.eq('vendor_sector', sectorFilter);
    }

    // Server-side approval filter
    if (approvalFilter === 'approved') {
      query = query.eq('is_approved', true);
    } else if (approvalFilter === 'pending') {
      // Pending = not approved AND no rejection reason
      query = query.eq('is_approved', false).is('rejection_reason', null);
    } else if (approvalFilter === 'rejected') {
      // Rejected = not approved AND has a rejection reason
      query = query.eq('is_approved', false).not('rejection_reason', 'is', null);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Admin fetch vendors error:', error);
    } else {
      setVendors((data ?? []) as unknown as VendorRow[]);
    }

    if (isRefresh) setRefreshing(false);
    else setLoading(false);
  }, [sectorFilter, approvalFilter]);

  useEffect(() => {
    fetchVendors();
  }, [fetchVendors]);

  // ── Client-side city filter ────────────────────────────────────────────────

  const filteredVendors = useMemo(() => {
    if (!citySearch.trim()) return vendors;
    const q = citySearch.trim().toLowerCase();
    return vendors.filter((v) => {
      // city lives inside sector_data JSONB
      const sectorData = v.sector_data as Record<string, unknown> | null;
      const city = (sectorData?.city as string | undefined) ?? '';
      return city.toLowerCase().includes(q);
    });
  }, [vendors, citySearch]);

  // ── Render item ────────────────────────────────────────────────────────────

  const renderItem = useCallback(
    ({ item }: { item: VendorRow }) => {
      const displayName =
        item.business_name ??
        item.profile?.full_name ??
        item.profile?.email ??
        'Unknown vendor';

      const sectorData = item.sector_data as Record<string, unknown> | null;
      const city = (sectorData?.city as string | undefined) ?? null;

      const registeredAt = new Date(item.created_at).toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      });

      return (
        <AnimatedPressable
          onPress={() => router.push(`/(admin)/vendor/${item.id}` as any)}
          scaleValue={0.98}
        >
          <View style={styles.card}>
            {/* Header row */}
            <View style={styles.cardHeader}>
              <View style={styles.cardTitleGroup}>
                <Text style={styles.cardName} numberOfLines={1}>
                  {displayName}
                </Text>
                {item.profile?.email && (
                  <Text style={styles.cardEmail} numberOfLines={1}>
                    {item.profile.email}
                  </Text>
                )}
              </View>
              <View style={styles.cardBadges}>
                <SectorBadge sector={item.vendor_sector} />
                <ApprovalBadge
                  isApproved={item.is_approved}
                  rejectionReason={item.rejection_reason}
                />
              </View>
            </View>

            {/* Meta row */}
            <View style={styles.metaRow}>
              {city ? (
                <View style={styles.metaItem}>
                  <MapPin size={12} color={Colors.textTertiary} />
                  <Text style={styles.metaText}>{city}</Text>
                </View>
              ) : null}
              <View style={styles.metaItem}>
                <Clock size={12} color={Colors.textTertiary} />
                <Text style={styles.metaText}>Registered {registeredAt}</Text>
              </View>
            </View>

            {/* Profile completion */}
            {item.profile_completion_status === 'incomplete' && !item.is_approved && (
              <View style={styles.incompleteBanner}>
                <Text style={styles.incompleteBannerText}>Profile incomplete</Text>
              </View>
            )}

            {/* Chevron */}
            <View style={styles.chevronRow}>
              <Text style={styles.tapHint}>Tap to view details</Text>
              <ChevronRight size={16} color={Colors.textTertiary} />
            </View>
          </View>
        </AnimatedPressable>
      );
    },
    [router]
  );

  // ── Render ─────────────────────────────────────────────────────────────────

  return (
    <View style={styles.screen}>
      {/* Header */}
      <SafeAreaView edges={['top']} style={styles.header}>
        <View style={styles.adminBadge}>
          <Text style={styles.adminBadgeText}>ADMIN ROOT</Text>
        </View>
        <View style={styles.titleRow}>
          <Users size={22} color={Colors.primaryDark} />
          <Text style={styles.title}>Vendors</Text>
        </View>
        <Text style={styles.subtitle}>
          {filteredVendors.length} vendor{filteredVendors.length !== 1 ? 's' : ''}
          {sectorFilter !== 'all'
            ? ` · ${SECTOR_CONFIGS[sectorFilter].displayName}`
            : ''}
        </Text>

        {/* Filter row: sector dropdown + approval tri-state */}
        <View style={styles.filterRow}>
          {/* Sector dropdown */}
          <View style={styles.dropdownWrapper}>
            <SectorDropdown value={sectorFilter} onChange={setSectorFilter} />
          </View>

          {/* Approval tri-state chips */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.approvalChipsRow}
          >
            {APPROVAL_OPTIONS.map((opt) => (
              <AnimatedPressable
                key={opt.key}
                onPress={() => setApprovalFilter(opt.key)}
                scaleValue={0.95}
              >
                <View
                  style={[
                    styles.approvalChip,
                    approvalFilter === opt.key && styles.approvalChipActive,
                  ]}
                >
                  <Text
                    style={[
                      styles.approvalChipText,
                      approvalFilter === opt.key && styles.approvalChipTextActive,
                    ]}
                  >
                    {opt.label}
                  </Text>
                </View>
              </AnimatedPressable>
            ))}
          </ScrollView>
        </View>

        {/* City search box */}
        <View style={styles.searchRow}>
          <Search size={16} color={Colors.textTertiary} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search by city…"
            placeholderTextColor={Colors.textTertiary}
            value={citySearch}
            onChangeText={setCitySearch}
            returnKeyType="search"
            clearButtonMode="while-editing"
            autoCorrect={false}
            autoCapitalize="words"
          />
          {citySearch.length > 0 && Platform.OS !== 'ios' && (
            <AnimatedPressable onPress={() => setCitySearch('')} scaleValue={0.9}>
              <XCircle size={16} color={Colors.textTertiary} />
            </AnimatedPressable>
          )}
        </View>
      </SafeAreaView>

      {/* List */}
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.primary} />
          <Text style={styles.loadingText}>Loading vendors…</Text>
        </View>
      ) : (
        <FlatList
          data={filteredVendors}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshing={refreshing}
          onRefresh={() => fetchVendors(true)}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Store size={48} color={Colors.textTertiary} />
              <Text style={styles.emptyTitle}>No vendors found</Text>
              <Text style={styles.emptySubtitle}>
                {citySearch
                  ? `No vendors in "${citySearch}". Try a different city.`
                  : 'No vendors match the current filters.'}
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background },

  // Header
  header: {
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.lg,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
    ...Shadow.sm,
  },
  adminBadge: {
    alignSelf: 'flex-start',
    backgroundColor: Colors.primaryDark,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginBottom: Spacing.sm,
  },
  adminBadgeText: {
    fontSize: 10,
    color: '#FFFFFF',
    fontWeight: FontWeight.bold,
    letterSpacing: 1,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.xs,
  },
  title: {
    fontSize: FontSize.xxxl,
    fontWeight: FontWeight.heavy,
    color: Colors.text,
  },
  subtitle: {
    fontSize: FontSize.sm,
    color: Colors.textTertiary,
    marginBottom: Spacing.md,
    fontWeight: FontWeight.medium,
  },

  // Filter row
  filterRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  dropdownWrapper: {
    flexShrink: 0,
  },

  // Sector dropdown trigger
  dropdownTrigger: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    backgroundColor: Colors.cream,
    borderRadius: Radius.lg,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  dropdownTriggerText: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
    color: Colors.textSecondary,
  },

  // Dropdown modal
  modalOverlay: {
    flex: 1,
    backgroundColor: Colors.overlay,
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.xl,
  },
  dropdownMenu: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    width: '100%',
    maxWidth: 320,
    ...Shadow.lg,
  },
  dropdownMenuTitle: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.heavy,
    color: Colors.text,
    marginBottom: Spacing.md,
  },
  dropdownOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.sm,
    borderRadius: Radius.md,
  },
  dropdownOptionSelected: {
    backgroundColor: Colors.primaryFaded,
  },
  dropdownDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  dropdownOptionText: {
    fontSize: FontSize.md,
    color: Colors.textSecondary,
    fontWeight: FontWeight.medium,
    flex: 1,
  },
  dropdownOptionTextSelected: {
    color: Colors.primary,
    fontWeight: FontWeight.bold,
  },

  // Approval chips
  approvalChipsRow: {
    gap: Spacing.xs,
    paddingRight: Spacing.sm,
  },
  approvalChip: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: Radius.full,
    backgroundColor: Colors.cream,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  approvalChipActive: {
    backgroundColor: Colors.primaryDark,
    borderColor: Colors.primaryDark,
  },
  approvalChipText: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
    color: Colors.textSecondary,
  },
  approvalChipTextActive: { color: '#FFFFFF' },

  // City search
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.cream,
    borderRadius: Radius.lg,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  searchInput: {
    flex: 1,
    fontSize: FontSize.md,
    color: Colors.text,
    paddingVertical: 0,
  },

  // List
  listContent: { padding: Spacing.xl, paddingBottom: Spacing.massive },

  // Card
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    ...Shadow.sm,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.sm,
    gap: Spacing.sm,
  },
  cardTitleGroup: { flex: 1 },
  cardName: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.bold,
    color: Colors.text,
    marginBottom: 2,
  },
  cardEmail: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
  },
  cardBadges: {
    alignItems: 'flex-end',
    gap: Spacing.xs,
  },

  // Sector badge
  sectorBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: Radius.full,
  },
  sectorBadgeText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
  },

  // Approval badge
  approvalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: Radius.full,
  },
  approvalBadgeApproved: { backgroundColor: Colors.successLight },
  approvalBadgePending: { backgroundColor: Colors.warningLight },
  approvalBadgeRejected: { backgroundColor: Colors.errorLight },
  approvalBadgeText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.bold,
  },

  // Meta row
  metaRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
    marginBottom: Spacing.sm,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  metaText: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    fontWeight: FontWeight.medium,
  },

  // Incomplete banner
  incompleteBanner: {
    backgroundColor: Colors.warningLight,
    borderRadius: Radius.sm,
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    alignSelf: 'flex-start',
    marginBottom: Spacing.sm,
  },
  incompleteBannerText: {
    fontSize: FontSize.xs,
    color: Colors.warning,
    fontWeight: FontWeight.bold,
  },

  // Chevron row
  chevronRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: Spacing.xs,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
    paddingTop: Spacing.sm,
    marginTop: Spacing.xs,
  },
  tapHint: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
  },

  // Loading
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.md,
  },
  loadingText: {
    fontSize: FontSize.md,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
  },

  // Empty
  emptyContainer: {
    alignItems: 'center',
    paddingTop: Spacing.massive * 2,
    gap: Spacing.md,
  },
  emptyTitle: {
    fontSize: FontSize.xl,
    fontWeight: FontWeight.bold,
    color: Colors.text,
  },
  emptySubtitle: {
    fontSize: FontSize.md,
    color: Colors.textTertiary,
    textAlign: 'center',
    paddingHorizontal: Spacing.xl,
  },
});
