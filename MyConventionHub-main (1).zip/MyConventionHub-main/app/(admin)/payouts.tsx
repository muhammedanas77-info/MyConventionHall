import React, { useCallback, useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    Alert,
    Platform,
    ActivityIndicator,
    RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Wallet, CheckCircle2, Clock } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { formatCurrencyFull } from '@/utils/currency';
import { SECTOR_CONFIGS } from '@/constants/sectors';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import type { VendorSector } from '@/types';

// ─── Types ────────────────────────────────────────────────────────────────────

interface VendorPayoutRow {
    vendor_id: string;
    vendor_name: string;
    sector: VendorSector;
    pending_count: number;
    total_pending_payout: number;
}

// ─── Vendor payout card ───────────────────────────────────────────────────────

function VendorPayoutCard({
    item,
    onMarkPaid,
    isProcessing,
}: {
    item: VendorPayoutRow;
    onMarkPaid: (vendorId: string, vendorName: string) => void;
    isProcessing: boolean;
}) {
    const sectorConfig = SECTOR_CONFIGS[item.sector];
    const badgeColor = sectorConfig?.badgeColor ?? Colors.textTertiary;
    const sectorLabel = sectorConfig?.displayName ?? item.sector;

    return (
        <View style={styles.card}>
            <View style={styles.cardHeader}>
                <View style={styles.vendorInfo}>
                    <Text style={styles.vendorName} numberOfLines={1}>
                        {item.vendor_name}
                    </Text>
                    <View style={[styles.sectorBadge, { backgroundColor: badgeColor + '20' }]}>
                        <View style={[styles.sectorDot, { backgroundColor: badgeColor }]} />
                        <Text style={[styles.sectorLabel, { color: badgeColor }]}>
                            {sectorLabel}
                        </Text>
                    </View>
                </View>
                <View style={styles.pendingCountBadge}>
                    <Clock size={12} color={Colors.warning} />
                    <Text style={styles.pendingCountText}>
                        {item.pending_count} pending
                    </Text>
                </View>
            </View>

            <View style={styles.payoutRow}>
                <View>
                    <Text style={styles.payoutLabel}>Total Pending Payout</Text>
                    <Text style={styles.payoutAmount}>
                        {formatCurrencyFull(item.total_pending_payout)}
                    </Text>
                </View>
                <AnimatedPressable
                    onPress={() => onMarkPaid(item.vendor_id, item.vendor_name)}
                    scaleValue={0.95}
                    disabled={isProcessing}
                >
                    <View style={[styles.markPaidButton, isProcessing && styles.markPaidButtonDisabled]}>
                        {isProcessing ? (
                            <ActivityIndicator size="small" color="#FFFFFF" />
                        ) : (
                            <>
                                <CheckCircle2 size={16} color="#FFFFFF" />
                                <Text style={styles.markPaidText}>Mark all as paid</Text>
                            </>
                        )}
                    </View>
                </AnimatedPressable>
            </View>
        </View>
    );
}

// ─── Main screen ──────────────────────────────────────────────────────────────

export default function PayoutsScreen() {
    const [vendors, setVendors] = useState<VendorPayoutRow[]>([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [processingId, setProcessingId] = useState<string | null>(null);
    const [totalPending, setTotalPending] = useState(0);

    // ── Fetch vendors with pending commissions ──────────────────────────────

    const loadPayouts = useCallback(async (isRefresh = false) => {
        if (isRefresh) {
            setRefreshing(true);
        } else {
            setLoading(true);
        }

        try {
            // Aggregate pending commissions per vendor, joining vendor_profiles for name + sector
            const { data, error } = await supabase
                .from('service_commissions')
                .select(`
                    vendor_id,
                    vendor_payout,
                    vendor_profiles!inner (
                        business_name,
                        vendor_sector
                    )
                `)
                .eq('status', 'pending');

            if (error) {
                Alert.alert('Error', 'Could not load payout data. Please try again.');
                return;
            }

            // Group by vendor_id client-side
            const grouped = new Map<string, VendorPayoutRow>();

            for (const row of data ?? []) {
                const profile = row.vendor_profiles as unknown as {
                    business_name: string | null;
                    vendor_sector: VendorSector;
                };
                const existing = grouped.get(row.vendor_id);
                if (existing) {
                    existing.pending_count += 1;
                    existing.total_pending_payout += Number(row.vendor_payout ?? 0);
                } else {
                    grouped.set(row.vendor_id, {
                        vendor_id: row.vendor_id,
                        vendor_name: profile.business_name ?? 'Unnamed Vendor',
                        sector: profile.vendor_sector,
                        pending_count: 1,
                        total_pending_payout: Number(row.vendor_payout ?? 0),
                    });
                }
            }

            const rows = Array.from(grouped.values()).sort(
                (a, b) => b.total_pending_payout - a.total_pending_payout,
            );

            setVendors(rows);
            setTotalPending(rows.reduce((sum, r) => sum + r.total_pending_payout, 0));
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    }, []);

    useEffect(() => {
        loadPayouts();
    }, [loadPayouts]);

    // ── Mark all pending commissions for a vendor as paid ──────────────────

    const handleMarkPaid = useCallback(
        (vendorId: string, vendorName: string) => {
            Alert.alert(
                'Mark All as Paid',
                `Mark all pending commissions for ${vendorName} as paid? This cannot be undone.`,
                [
                    { text: 'Cancel', style: 'cancel' },
                    {
                        text: 'Confirm',
                        onPress: async () => {
                            setProcessingId(vendorId);
                            try {
                                const now = new Date().toISOString();
                                const { error } = await supabase
                                    .from('service_commissions')
                                    .update({ status: 'paid', paid_at: now })
                                    .eq('vendor_id', vendorId)
                                    .eq('status', 'pending');

                                if (error) {
                                    Alert.alert('Error', 'Could not update commissions. Please try again.');
                                    return;
                                }

                                if (Platform.OS !== 'web') {
                                    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                                }

                                // Remove the vendor from the list immediately
                                setVendors((prev) => {
                                    const updated = prev.filter((v) => v.vendor_id !== vendorId);
                                    setTotalPending(updated.reduce((sum, r) => sum + r.total_pending_payout, 0));
                                    return updated;
                                });
                            } finally {
                                setProcessingId(null);
                            }
                        },
                    },
                ],
            );
        },
        [],
    );

    // ── Render ──────────────────────────────────────────────────────────────

    if (loading) {
        return (
            <View style={styles.screen}>
                <SafeAreaView edges={['top']} style={styles.header}>
                    <View style={styles.adminBadge}>
                        <Text style={styles.adminBadgeText}>ADMIN ROOT</Text>
                    </View>
                    <Text style={styles.title}>Vendor Payouts</Text>
                </SafeAreaView>
                <View style={styles.centered}>
                    <ActivityIndicator size="large" color={Colors.primary} />
                    <Text style={styles.loadingText}>Loading payouts…</Text>
                </View>
            </View>
        );
    }

    return (
        <View style={styles.screen}>
            <SafeAreaView edges={['top']} style={styles.header}>
                <View style={styles.adminBadge}>
                    <Text style={styles.adminBadgeText}>ADMIN ROOT</Text>
                </View>
                <Text style={styles.title}>Vendor Payouts</Text>
                {vendors.length > 0 && (
                    <View style={styles.summaryRow}>
                        <View style={styles.summaryItem}>
                            <Text style={styles.summaryLabel}>Vendors Pending</Text>
                            <Text style={styles.summaryValue}>{vendors.length}</Text>
                        </View>
                        <View style={styles.summaryDivider} />
                        <View style={styles.summaryItem}>
                            <Text style={styles.summaryLabel}>Total Pending</Text>
                            <Text style={[styles.summaryValue, { color: Colors.primary }]}>
                                {formatCurrencyFull(totalPending)}
                            </Text>
                        </View>
                    </View>
                )}
            </SafeAreaView>

            <FlatList
                data={vendors}
                keyExtractor={(item) => item.vendor_id}
                contentContainerStyle={styles.listContent}
                showsVerticalScrollIndicator={false}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={() => loadPayouts(true)}
                        tintColor={Colors.primary}
                        colors={[Colors.primary]}
                    />
                }
                renderItem={({ item }) => (
                    <VendorPayoutCard
                        item={item}
                        onMarkPaid={handleMarkPaid}
                        isProcessing={processingId === item.vendor_id}
                    />
                )}
                ListEmptyComponent={
                    <View style={styles.emptyContainer}>
                        <View style={styles.emptyIconWrap}>
                            <Wallet size={40} color={Colors.success} />
                        </View>
                        <Text style={styles.emptyTitle}>All caught up!</Text>
                        <Text style={styles.emptySubtitle}>
                            No pending vendor payouts at the moment.
                        </Text>
                    </View>
                }
                ListFooterComponent={<View style={{ height: Spacing.massive }} />}
            />
        </View>
    );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        backgroundColor: Colors.background,
    },
    header: {
        paddingHorizontal: Spacing.xl,
        paddingBottom: Spacing.xl,
        backgroundColor: Colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: Colors.borderLight,
        ...Shadow.sm,
    },
    adminBadge: {
        alignSelf: 'flex-start',
        backgroundColor: Colors.primaryDark,
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 6,
        marginBottom: Spacing.sm,
    },
    adminBadgeText: {
        fontSize: 10,
        color: '#FFFFFF',
        fontWeight: FontWeight.bold,
        letterSpacing: 1,
    },
    title: {
        fontSize: FontSize.xxxl,
        fontWeight: FontWeight.heavy,
        color: Colors.primaryDark,
        marginBottom: Spacing.lg,
    },
    summaryRow: {
        flexDirection: 'row',
        backgroundColor: Colors.cream,
        borderRadius: Radius.xl,
        paddingVertical: Spacing.lg,
        paddingHorizontal: Spacing.xl,
        alignItems: 'center',
    },
    summaryItem: {
        flex: 1,
        alignItems: 'center',
    },
    summaryDivider: {
        width: 1,
        height: 36,
        backgroundColor: Colors.border,
    },
    summaryLabel: {
        fontSize: FontSize.xs,
        color: Colors.textTertiary,
        fontWeight: FontWeight.bold,
        textTransform: 'uppercase',
        letterSpacing: 0.5,
        marginBottom: Spacing.xs,
    },
    summaryValue: {
        fontSize: FontSize.xl,
        fontWeight: FontWeight.heavy,
        color: Colors.text,
    },
    listContent: {
        padding: Spacing.xl,
    },
    card: {
        backgroundColor: Colors.surface,
        borderRadius: Radius.xl,
        padding: Spacing.xl,
        marginBottom: Spacing.lg,
        borderWidth: 1,
        borderColor: Colors.borderLight,
        ...Shadow.md,
    },
    cardHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: Spacing.lg,
    },
    vendorInfo: {
        flex: 1,
        marginRight: Spacing.md,
        gap: Spacing.xs,
    },
    vendorName: {
        fontSize: FontSize.lg,
        fontWeight: FontWeight.bold,
        color: Colors.text,
    },
    sectorBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-start',
        paddingHorizontal: Spacing.sm,
        paddingVertical: Spacing.xxs,
        borderRadius: Radius.full,
        gap: Spacing.xs,
    },
    sectorDot: {
        width: 6,
        height: 6,
        borderRadius: 3,
    },
    sectorLabel: {
        fontSize: FontSize.xs,
        fontWeight: FontWeight.bold,
    },
    pendingCountBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xxs,
        backgroundColor: Colors.warningLight,
        paddingHorizontal: Spacing.sm,
        paddingVertical: Spacing.xs,
        borderRadius: Radius.full,
    },
    pendingCountText: {
        fontSize: FontSize.xs,
        color: Colors.warning,
        fontWeight: FontWeight.bold,
    },
    payoutRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingTop: Spacing.lg,
        borderTopWidth: 1,
        borderTopColor: Colors.borderLight,
    },
    payoutLabel: {
        fontSize: FontSize.xs,
        color: Colors.textTertiary,
        fontWeight: FontWeight.semibold,
        marginBottom: Spacing.xs,
        textTransform: 'uppercase',
        letterSpacing: 0.5,
    },
    payoutAmount: {
        fontSize: FontSize.xxl,
        fontWeight: FontWeight.heavy,
        color: Colors.text,
    },
    markPaidButton: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xs,
        backgroundColor: Colors.success,
        paddingHorizontal: Spacing.xl,
        paddingVertical: Spacing.md,
        borderRadius: Radius.lg,
        minWidth: 140,
        justifyContent: 'center',
        ...Shadow.sm,
    },
    markPaidButtonDisabled: {
        opacity: 0.6,
    },
    markPaidText: {
        color: '#FFFFFF',
        fontSize: FontSize.sm,
        fontWeight: FontWeight.bold,
    },
    centered: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        gap: Spacing.lg,
    },
    loadingText: {
        fontSize: FontSize.md,
        color: Colors.textSecondary,
        fontWeight: FontWeight.medium,
    },
    emptyContainer: {
        alignItems: 'center',
        paddingTop: Spacing.massive * 2,
        gap: Spacing.lg,
    },
    emptyIconWrap: {
        width: 80,
        height: 80,
        borderRadius: 40,
        backgroundColor: Colors.successLight,
        justifyContent: 'center',
        alignItems: 'center',
    },
    emptyTitle: {
        fontSize: FontSize.xxl,
        fontWeight: FontWeight.heavy,
        color: Colors.text,
    },
    emptySubtitle: {
        fontSize: FontSize.md,
        color: Colors.textTertiary,
        textAlign: 'center',
        paddingHorizontal: Spacing.xxxl,
    },
});
