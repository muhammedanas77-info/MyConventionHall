import { Link, Stack } from "expo-router";
import { StyleSheet, Text, View } from "react-native";
import { Colors, Spacing, FontSize, FontWeight, Radius } from "@/constants/theme";

export default function NotFoundScreen() {
    return (
        <>
            <Stack.Screen options={{ title: "Not Found" }} />
            <View style={styles.container}>
                <Text style={styles.title}>Something went wrong</Text>
                <Text style={styles.subtitle}>
                    The page you are looking for doesn't exist or has been moved.
                </Text>
                <Link href="/discover" style={styles.link}>
                    <Text style={styles.linkText}>Back to Discover</Text>
                </Link>
            </View>
        </>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        padding: Spacing.xxl,
        backgroundColor: Colors.background,
    },
    emoji: {
        fontSize: 48,
        marginBottom: Spacing.lg,
    },
    title: {
        fontSize: FontSize.xxl,
        fontWeight: FontWeight.bold,
        color: Colors.text,
        marginBottom: Spacing.sm,
    },
    subtitle: {
        fontSize: FontSize.md,
        color: Colors.textTertiary,
        textAlign: "center",
        marginBottom: Spacing.xxl,
    },
    link: {
        backgroundColor: Colors.primary,
        paddingHorizontal: Spacing.xxl,
        paddingVertical: Spacing.md,
        borderRadius: Radius.lg,
    },
    linkText: {
        fontSize: FontSize.md,
        color: "#FFFFFF",
        fontWeight: FontWeight.bold,
    },
});
