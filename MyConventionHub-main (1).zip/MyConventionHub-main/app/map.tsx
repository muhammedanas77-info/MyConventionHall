import React, { useMemo, useCallback, useState, useEffect } from 'react';
import {
    View,
    StyleSheet,
    Text,
    Platform,
    Dimensions,
    ScrollView,
    TouchableOpacity,
    Linking,
    StatusBar,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, MapPin, Navigation2, Star, Users } from 'lucide-react-native';
import { Image } from 'expo-image';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import type { Hall } from '@/types';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import { formatCurrency } from '@/utils/currency';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const CARD_IMAGE_HEIGHT = 160;

// Coordinates for Bangalore area venues
const VENUE_COORDINATES: Record<string, { lat: number; lng: number }> = {
    'hall-001': { lat: 12.9719, lng: 77.5937 },
    'hall-002': { lat: 12.9141, lng: 77.5841 },
    'hall-003': { lat: 12.9279, lng: 77.6271 },
    'hall-004': { lat: 12.9915, lng: 77.5946 },
    'hall-005': { lat: 12.9352, lng: 77.6245 },
    'hall-006': { lat: 13.0279, lng: 77.5409 },
    'hall-007': { lat: 12.9081, lng: 77.5504 },
    'hall-008': { lat: 12.9010, lng: 77.6042 },
    'hall-009': { lat: 12.9563, lng: 77.5857 },
    'hall-010': { lat: 12.9823, lng: 77.5712 },
};

export default function AppMapScreen() {
    const router = useRouter();

    const [allHalls, setAllHalls] = useState<Hall[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchHalls = async () => {
            try {
                const { data, error } = await supabase.from('halls').select('*');
                if (error) throw error;
                setAllHalls(data || []);
            } catch (err) {
                console.error('Error fetching map halls:', err);
            } finally {
                setIsLoading(false);
            }
        };
        fetchHalls();
    }, []);

    const hallsWithLocations = useMemo(() => {
        const ids = Object.keys(VENUE_COORDINATES);
        return allHalls.map((hall, index) => {
            const coords = VENUE_COORDINATES[hall.id] ?? VENUE_COORDINATES[ids[index % ids.length]];
            return { ...hall, coordinate: coords };
        });
    }, [allHalls]);

    const openInMaps = useCallback((hallName: string, lat: number, lng: number) => {
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

        const encodedName = encodeURIComponent(hallName);

        if (Platform.OS === 'ios') {
            // Try Google Maps first, fall back to Apple Maps
            const googleMapsUrl = `comgooglemaps://?daddr=${lat},${lng}&directionsmode=driving`;
            const appleMapsUrl = `maps://app?daddr=${lat},${lng}&q=${encodedName}`;

            Linking.canOpenURL(googleMapsUrl)
                .then((supported) => {
                    if (supported) {
                        Linking.openURL(googleMapsUrl);
                    } else {
                        Linking.openURL(appleMapsUrl);
                    }
                })
                .catch(() => Linking.openURL(appleMapsUrl));
        } else {
            // Android - open Google Maps
            const url = `google.navigation:q=${lat},${lng}&mode=d`;
            const webFallback = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&destination_place_id=${encodedName}`;

            Linking.canOpenURL(url)
                .then((supported) => {
                    if (supported) {
                        Linking.openURL(url);
                    } else {
                        Linking.openURL(webFallback);
                    }
                })
                .catch(() => Linking.openURL(webFallback));
        }
    }, []);

    const navigateToHall = useCallback((hallId: string) => {
        if (Platform.OS !== 'web') Haptics.selectionAsync();
        router.push(`/hall/${hallId}` as any);
    }, [router]);

    return (
        <View style={styles.screen}>
            <StatusBar barStyle="dark-content" />

            {/* Header */}
            <View style={styles.headerContainer}>
                <SafeAreaView edges={['top']} style={styles.safeHeader}>
                    <AnimatedPressable onPress={() => router.back()} style={styles.backButton}>
                        <ArrowLeft size={20} color={Colors.text} strokeWidth={2.5} />
                    </AnimatedPressable>
                    <View style={styles.headerCenter}>
                        <MapPin size={18} color={Colors.primary} strokeWidth={2.5} />
                        <Text style={styles.headerTitle}>Venue Locations</Text>
                    </View>
                    <View style={{ width: 40 }} />
                </SafeAreaView>
            </View>

            {/* Venue List */}
            <ScrollView
                style={styles.scrollView}
                contentContainerStyle={styles.scrollContent}
                showsVerticalScrollIndicator={false}
            >
                {/* Info Banner */}
                <View style={styles.infoBanner}>
                    <View style={styles.infoBannerIcon}>
                        <Navigation2 size={16} color={Colors.primary} strokeWidth={2.5} />
                    </View>
                    <Text style={styles.infoBannerText}>
                        Tap <Text style={styles.infoBannerBold}>Get Directions</Text> to open in Google Maps
                    </Text>
                </View>

                {/* Venue Count */}
                <Text style={styles.venueCount}>
                    {isLoading ? 'Loading venues...' : `${hallsWithLocations.length} venues in Bangalore`}
                </Text>

                {/* Venue Cards */}
                {hallsWithLocations.map((hall, index) => (
                    <TouchableOpacity
                        key={hall.id}
                        style={styles.venueCard}
                        onPress={() => navigateToHall(hall.id)}
                        activeOpacity={0.9}
                    >
                        {/* Card Image */}
                        <View style={styles.imageContainer}>
                            <Image
                                source={{ uri: hall.photos[0] }}
                                style={styles.venueImage}
                                contentFit="cover"
                                transition={300}
                            />
                            <LinearGradient
                                colors={['transparent', 'rgba(0,0,0,0.6)']}
                                style={styles.imageGradient}
                            />
                            {/* Price Badge */}
                            <View style={styles.priceBadge}>
                                <Text style={styles.priceText}>
                                    {formatCurrency(hall.price_per_day)}
                                </Text>
                                <Text style={styles.priceUnit}>/day</Text>
                            </View>
                            {/* Rating */}
                            {hall.rating > 0 && (
                                <View style={styles.ratingBadge}>
                                    <Star size={10} color="#FFD700" fill="#FFD700" />
                                    <Text style={styles.ratingText}>{hall.rating}</Text>
                                </View>
                            )}
                        </View>

                        {/* Card Content */}
                        <View style={styles.cardContent}>
                            <View style={styles.cardInfo}>
                                <Text style={styles.venueName} numberOfLines={1}>
                                    {hall.name}
                                </Text>
                                <View style={styles.locationRow}>
                                    <MapPin size={12} color={Colors.textTertiary} strokeWidth={2} />
                                    <Text style={styles.venueArea}>{hall.area}, Bangalore</Text>
                                </View>
                                <View style={styles.metaRow}>
                                    <View style={styles.metaItem}>
                                        <Users size={12} color={Colors.textTertiary} strokeWidth={2} />
                                        <Text style={styles.metaText}>
                                            {hall.capacity_min}–{hall.capacity_max}
                                        </Text>
                                    </View>
                                    {hall.is_verified && (
                                        <View style={styles.verifiedBadge}>
                                            <Text style={styles.verifiedText}>✓ Verified</Text>
                                        </View>
                                    )}
                                </View>
                            </View>

                            {/* Directions Icon */}
                            <TouchableOpacity
                                style={styles.directionsButton}
                                onPress={(e) => {
                                    e.stopPropagation();
                                    openInMaps(
                                        hall.name,
                                        hall.coordinate.lat,
                                        hall.coordinate.lng
                                    );
                                }}
                                activeOpacity={0.6}
                                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                            >
                                <View style={styles.directionsIconCircle}>
                                    <Navigation2 size={16} color="#FFFFFF" strokeWidth={2.5} />
                                </View>
                            </TouchableOpacity>
                        </View>
                    </TouchableOpacity>
                ))}

                {/* Bottom spacer */}
                <View style={{ height: 40 }} />
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        backgroundColor: Colors.background,
    },

    // Header
    headerContainer: {
        backgroundColor: Colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: Colors.borderLight,
        ...Shadow.sm,
        zIndex: 10,
    },
    safeHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: Spacing.lg,
        paddingBottom: Spacing.md,
    },
    backButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: Colors.ivory,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: Colors.borderLight,
    },
    headerCenter: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xs,
    },
    headerTitle: {
        fontSize: FontSize.lg,
        fontWeight: FontWeight.bold,
        color: Colors.text,
    },

    // Scroll
    scrollView: {
        flex: 1,
    },
    scrollContent: {
        paddingHorizontal: Spacing.lg,
        paddingTop: Spacing.lg,
    },

    // Info Banner
    infoBanner: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Colors.primaryFaded,
        borderRadius: Radius.lg,
        padding: Spacing.md,
        marginBottom: Spacing.lg,
        gap: Spacing.sm,
        borderWidth: 1,
        borderColor: Colors.primaryFaded2,
    },
    infoBannerIcon: {
        width: 32,
        height: 32,
        borderRadius: 16,
        backgroundColor: Colors.surface,
        justifyContent: 'center',
        alignItems: 'center',
    },
    infoBannerText: {
        flex: 1,
        fontSize: FontSize.sm,
        color: Colors.textSecondary,
        lineHeight: 18,
    },
    infoBannerBold: {
        fontWeight: FontWeight.bold,
        color: Colors.primary,
    },

    // Venue Count
    venueCount: {
        fontSize: FontSize.sm,
        color: Colors.textTertiary,
        fontWeight: FontWeight.medium,
        marginBottom: Spacing.md,
        paddingLeft: Spacing.xs,
    },

    // Venue Card
    venueCard: {
        backgroundColor: Colors.surface,
        borderRadius: Radius.xl,
        marginBottom: Spacing.lg,
        overflow: 'hidden',
        borderWidth: 1,
        borderColor: Colors.borderLight,
        ...Shadow.md,
    },

    // Image
    imageContainer: {
        position: 'relative',
        height: CARD_IMAGE_HEIGHT,
    },
    venueImage: {
        width: '100%',
        height: '100%',
    },
    imageGradient: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        height: CARD_IMAGE_HEIGHT / 2,
    },
    priceBadge: {
        position: 'absolute',
        bottom: Spacing.sm,
        left: Spacing.sm,
        flexDirection: 'row',
        alignItems: 'baseline',
        backgroundColor: 'rgba(255,255,255,0.95)',
        paddingHorizontal: Spacing.md,
        paddingVertical: Spacing.xs,
        borderRadius: Radius.full,
        ...Shadow.sm,
    },
    priceText: {
        fontSize: FontSize.md,
        fontWeight: FontWeight.bold,
        color: Colors.primaryDark,
    },
    priceUnit: {
        fontSize: FontSize.xs,
        color: Colors.textTertiary,
        fontWeight: FontWeight.medium,
        marginLeft: 2,
    },
    ratingBadge: {
        position: 'absolute',
        bottom: Spacing.sm,
        right: Spacing.sm,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 3,
        backgroundColor: 'rgba(255,255,255,0.95)',
        paddingHorizontal: Spacing.sm,
        paddingVertical: Spacing.xs,
        borderRadius: Radius.full,
        ...Shadow.sm,
    },
    ratingText: {
        fontSize: FontSize.xs,
        fontWeight: FontWeight.bold,
        color: Colors.text,
    },

    // Card Content
    cardContent: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: Spacing.lg,
        gap: Spacing.md,
    },
    cardInfo: {
        flex: 1,
    },
    venueName: {
        fontSize: FontSize.lg,
        fontWeight: FontWeight.bold,
        color: Colors.text,
        marginBottom: 4,
    },
    locationRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        marginBottom: 6,
    },
    venueArea: {
        fontSize: FontSize.sm,
        color: Colors.textTertiary,
    },
    metaRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.sm,
    },
    metaItem: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
    },
    metaText: {
        fontSize: FontSize.xs,
        color: Colors.textTertiary,
        fontWeight: FontWeight.medium,
    },
    verifiedBadge: {
        backgroundColor: Colors.successLight,
        paddingHorizontal: Spacing.sm,
        paddingVertical: 2,
        borderRadius: Radius.full,
    },
    verifiedText: {
        fontSize: 10,
        color: Colors.success,
        fontWeight: FontWeight.bold,
    },

    // Directions Icon
    directionsButton: {
        padding: 2,
    },
    directionsIconCircle: {
        width: 38,
        height: 38,
        borderRadius: 19,
        backgroundColor: '#4285F4',
        justifyContent: 'center',
        alignItems: 'center',
        ...Shadow.sm,
    },
});
