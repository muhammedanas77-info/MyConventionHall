import React, { useCallback, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ActivityIndicator,
    Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Clock } from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { useApp } from '@/providers/AppProvider';
import { useVendor } from '@/providers/VendorProvider';
import { useAuth } from '@/providers/AuthProvider';
import { getSectorConfig } from '@/constants/sectors';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

const SANS_FONT = Platform.select({
    ios: 'System',
    android: 'sans-serif',
    web: 'system-ui, sans-serif',
    default: 'sans-serif',
});

export default function VendorPendingApprovalScreen() {
    const router = useRouter();
    const { logout } = useApp();
    const { vendorProfile, sector } = useVendor();
    const { user } = useAuth();
    const [isLoggingOut, setIsLoggingOut] = useState(false);

    // Derive display values
    const sectorDisplayName = sector ? getSectorConfig(sector).displayName : 'Service';
    const sectorBadgeColor = sector ? getSectorConfig(sector).badgeColor : Colors.textTertiary;

    const businessName =
        vendorProfile?.business_name?.trim() ||
        user?.email ||
        'Your account';

    const handleLogout = useCallback(async () => {
        if (isLoggingOut) return;
        setIsLoggingOut(true);
        try {
            await supabase.auth.signOut();
            logout();
            router.replace('/role-select' as any);
        } catch (err) {
            console.warn('[VendorPendingApproval] logout error:', err);
            // Still clear local state and navigate even if signOut fails
            logout();
            router.replace('/role-select' as any);
        } finally {
            setIsLoggingOut(false);
        }
    }, [isLoggingOut, logout, router]);

    return (
        <View style={styles.container}>
            <SafeAreaView style={styles.safeArea}>
                {/* Illustration */}
                <View style={styles.illustrationWrapper}>
                    <View style={styles.iconCircle}>
                        <Clock size={56} color={Colors.gold} strokeWidth={1.5} />
                    </View>
                    <View style={[styles.sectorBadge, { backgroundColor: sectorBadgeColor + '22' }]}>
                        <Text style={[styles.sectorBadgeText, { color: sectorBadgeColor }]}>
                            {sectorDisplayName}
                        </Text>
                    </View>
                </View>

                {/* Content */}
                <View style={styles.content}>
                    <Text style={styles.headline}>Application Under Review</Text>

                    <Text style={styles.businessName} numberOfLines={2}>
                        {businessName}
                    </Text>

                    <Text style={styles.body}>
                        Thank you for registering as a{' '}
                        <Text style={[styles.sectorInline, { color: sectorBadgeColor }]}>
                            {sectorDisplayName}
                        </Text>{' '}
                        on ConventionHub. Our team is reviewing your application and will notify
                        you by email once it's approved — usually within 1–2 business days.
                    </Text>

                    <View style={styles.infoCard}>
                        <Text style={styles.infoTitle}>What happens next?</Text>
                        <View style={styles.infoRow}>
                            <View style={styles.bullet} />
                            <Text style={styles.infoText}>
                                You'll receive an email when your account is approved.
                            </Text>
                        </View>
                        <View style={styles.infoRow}>
                            <View style={styles.bullet} />
                            <Text style={styles.infoText}>
                                Once approved, you can create listings and accept bookings.
                            </Text>
                        </View>
                        <View style={styles.infoRow}>
                            <View style={styles.bullet} />
                            <Text style={styles.infoText}>
                                Log back in after approval to access your vendor dashboard.
                            </Text>
                        </View>
                    </View>
                </View>

                {/* Logout */}
                <View style={styles.footer}>
                    <AnimatedPressable onPress={handleLogout} scaleValue={0.97} disabled={isLoggingOut}>
                        <View style={[styles.logoutButton, isLoggingOut && styles.logoutButtonDisabled]}>
                            {isLoggingOut ? (
                                <ActivityIndicator size="small" color={Colors.error} />
                            ) : (
                                <Text style={styles.logoutButtonText}>Log Out</Text>
                            )}
                        </View>
                    </AnimatedPressable>
                </View>
            </SafeAreaView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.background,
    },
    safeArea: {
        flex: 1,
        paddingHorizontal: Spacing.xl,
    },

    // ── Illustration ──────────────────────────────────────────────────────────
    illustrationWrapper: {
        alignItems: 'center',
        paddingTop: Spacing.huge * 1.5,
        paddingBottom: Spacing.xxl,
        gap: Spacing.lg,
    },
    iconCircle: {
        width: 120,
        height: 120,
        borderRadius: Radius.full,
        backgroundColor: Colors.goldFaded,
        justifyContent: 'center',
        alignItems: 'center',
        ...Shadow.md,
    },
    sectorBadge: {
        paddingHorizontal: Spacing.lg,
        paddingVertical: Spacing.xs,
        borderRadius: Radius.full,
    },
    sectorBadgeText: {
        fontSize: FontSize.sm,
        fontWeight: FontWeight.semibold,
        fontFamily: SANS_FONT,
        letterSpacing: 0.5,
        textTransform: 'uppercase',
    },

    // ── Content ───────────────────────────────────────────────────────────────
    content: {
        flex: 1,
        gap: Spacing.lg,
    },
    headline: {
        fontSize: FontSize.xxl,
        fontWeight: FontWeight.bold,
        color: Colors.text,
        fontFamily: SANS_FONT,
        textAlign: 'center',
    },
    businessName: {
        fontSize: FontSize.lg,
        fontWeight: FontWeight.medium,
        color: Colors.textSecondary,
        fontFamily: SANS_FONT,
        textAlign: 'center',
    },
    body: {
        fontSize: FontSize.md,
        color: Colors.textSecondary,
        lineHeight: 24,
        textAlign: 'center',
        fontFamily: SANS_FONT,
    },
    sectorInline: {
        fontWeight: FontWeight.semibold,
    },

    // ── Info card ─────────────────────────────────────────────────────────────
    infoCard: {
        backgroundColor: Colors.surface,
        borderRadius: Radius.lg,
        padding: Spacing.xl,
        gap: Spacing.md,
        borderWidth: 1,
        borderColor: Colors.borderLight,
        ...Shadow.sm,
    },
    infoTitle: {
        fontSize: FontSize.md,
        fontWeight: FontWeight.semibold,
        color: Colors.text,
        fontFamily: SANS_FONT,
        marginBottom: Spacing.xs,
    },
    infoRow: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        gap: Spacing.sm,
    },
    bullet: {
        width: 6,
        height: 6,
        borderRadius: Radius.full,
        backgroundColor: Colors.gold,
        marginTop: 8,
        flexShrink: 0,
    },
    infoText: {
        flex: 1,
        fontSize: FontSize.sm,
        color: Colors.textSecondary,
        lineHeight: 20,
        fontFamily: SANS_FONT,
    },

    // ── Footer ────────────────────────────────────────────────────────────────
    footer: {
        paddingBottom: Spacing.xxl,
        paddingTop: Spacing.lg,
    },
    logoutButton: {
        backgroundColor: Colors.errorLight,
        paddingVertical: Spacing.lg,
        borderRadius: Radius.lg,
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: 52,
    },
    logoutButtonDisabled: {
        opacity: 0.6,
    },
    logoutButtonText: {
        fontSize: FontSize.md,
        fontWeight: FontWeight.semibold,
        color: Colors.error,
        fontFamily: SANS_FONT,
    },
});
