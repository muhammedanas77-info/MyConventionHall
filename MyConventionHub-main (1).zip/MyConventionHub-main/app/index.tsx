import React, { useEffect, useRef } from 'react';
import { View } from 'react-native';
import { useRouter } from 'expo-router';
import { useApp } from '@/providers/AppProvider';
import { useAuth } from '@/providers/AuthProvider';

// Module-level flag survives component remounts (unlike useRef which resets).
// Guarantees the startup redirect fires at most once per JS bundle lifetime.
let _initialRedirectDone = false;

export default function SplashScreen() {
    const router = useRouter();
    const { isLoaded, hasSeenOnboarding } = useApp();
    const { isLoading: authLoading, role: supabaseRole, user } = useAuth();

    const didRedirectRef = useRef(_initialRedirectDone);

    useEffect(() => {
        if (didRedirectRef.current) return;
        if (!isLoaded || authLoading) return;

        didRedirectRef.current = true;
        _initialRedirectDone = true;

        if (!hasSeenOnboarding) {
            router.replace('/onboarding' as any);
            return;
        }

        if (!user || !supabaseRole) {
            router.replace('/role-select' as any);
        } else if (supabaseRole === 'customer') {
            router.replace('/(tabs)/discover' as any);
        } else if (supabaseRole === 'owner') {
            router.replace('/(owner)/dashboard' as any);
        } else if (supabaseRole === 'admin') {
            router.replace('/(admin)/admin-dashboard' as any);
        } else if (supabaseRole === 'vendor') {
            router.replace('/(vendor)/dashboard' as any);
        } else {
            router.replace('/role-select' as any);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isLoaded, authLoading]); // intentionally minimal — runs once when both flags clear

    return <View style={{ flex: 1, backgroundColor: '#FFFFFF' }} />;
}
