import React, { useCallback, useEffect, useState } from 'react';
import {
    ActivityIndicator,
    Alert,
    FlatList,
    Image,
    Platform,
    Pressable,
    RefreshControl,
    StyleSheet,
    Switch,
    Text,
    View,
} from 'react-native';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { Plus, Trash2 } from 'lucide-react-native';
import { supabase } from '@/utils/supabase';
import { useAuth } from '@/providers/AuthProvider';
import { useVendor } from '@/providers/VendorProvider';
import { SECTOR_CONFIGS } from '@/constants/sectors';
import {
    Colors,
    FontSize,
    FontWeight,
    Radius,
    Shadow,
    Spacing,
} from '@/constants/theme';
import type { ServiceListing } from '@/types';

// ─── Price unit labels ────────────────────────────────────────────────────────

const PRICE_UNIT_LABELS: Record<string, string> = {
    per_event: '/ event',
    per_plate: '/ plate',
    per_hour: '/ hr',
    per_day: '/ day',
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatPrice(price: number): string {
    return `₹${price.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

// ─── Empty state ──────────────────────────────────────────────────────────────

function EmptyState({ onAdd, accentColor }: { onAdd: () => void; accentColor: string }) {
    return (
        <View style={styles.emptyContainer}>
            <Text style={styles.emptyTitle}>No listings yet</Text>
            <Text style={styles.emptySubtitle}>
                Create your first service listing so customers can discover and book you.
            </Text>
            <Pressable
                style={({ pressed }) => [styles.emptyButton, { backgroundColor: pressed ? accentColor + 'CC' : accentColor }]}
                onPress={onAdd}
            >
                <Plus size={18} color={Colors.textOnPrimary} />
                <Text style={styles.emptyButtonText}>Add Listing</Text>
            </Pressable>
        </View>
    );
}

// ─── Listing row ──────────────────────────────────────────────────────────────

interface ListingRowProps {
    item: ServiceListing;
    onToggleActive: (listing: ServiceListing) => void;
    onDelete: (listing: ServiceListing) => void;
    onPress: (listing: ServiceListing) => void;
    toggling: boolean;
}

function ListingRow({ item, onToggleActive, onDelete, onPress, toggling }: ListingRowProps) {
    const sectorConfig = SECTOR_CONFIGS[item.sector];
    const primaryPhoto = item.photos?.[0] ?? null;

    return (
        <Pressable
            style={({ pressed }) => [styles.card, pressed && styles.pressed]}
            onPress={() => onPress(item)}
        >
            {/* Photo */}
            <View style={styles.photoContainer}>
                {primaryPhoto ? (
                    <Image
                        source={{ uri: primaryPhoto }}
                        style={styles.photo}
                        resizeMode="cover"
                    />
                ) : (
                    <View style={styles.photoPlaceholder}>
                        <Text style={styles.photoPlaceholderText}>No Photo</Text>
                    </View>
                )}
            </View>

            {/* Content */}
            <View style={styles.cardContent}>
                {/* Title + sector badge */}
                <View style={styles.titleRow}>
                    <Text style={styles.title} numberOfLines={1}>
                        {item.title}
                    </Text>
                    <View
                        style={[
                            styles.sectorBadge,
                            { backgroundColor: sectorConfig?.badgeColor ?? Colors.textTertiary },
                        ]}
                    >
                        <Text style={styles.sectorBadgeText}>
                            {sectorConfig?.displayName ?? item.sector}
                        </Text>
                    </View>
                </View>

                {/* Price */}
                <Text style={styles.price}>
                    {formatPrice(item.base_price)}{' '}
                    <Text style={styles.priceUnit}>
                        {PRICE_UNIT_LABELS[item.price_unit] ?? item.price_unit}
                    </Text>
                </Text>

                {/* Actions row */}
                <View style={styles.actionsRow}>
                    {/* Active toggle */}
                    <View style={styles.toggleRow}>
                        <Text style={styles.toggleLabel}>
                            {item.is_active ? 'Active' : 'Inactive'}
                        </Text>
                        <Switch
                            value={item.is_active}
                            onValueChange={() => onToggleActive(item)}
                            disabled={toggling}
                            trackColor={{
                                false: Colors.warmGray,
                                true: Colors.success,
                            }}
                            thumbColor={Colors.surface}
                        />
                    </View>

                    {/* Delete */}
                    <Pressable
                        style={({ pressed }) => [
                            styles.deleteButton,
                            pressed && styles.deleteButtonPressed,
                        ]}
                        onPress={() => onDelete(item)}
                        hitSlop={8}
                    >
                        <Trash2 size={16} color={Colors.error} />
                    </Pressable>
                </View>
            </View>
        </Pressable>
    );
}

// ─── Main screen ──────────────────────────────────────────────────────────────

export default function ListingsScreen() {
    const router = useRouter();
    const { user } = useAuth();
    const { vendorProfile, sector } = useVendor();
    const accentColor = (sector ? SECTOR_CONFIGS[sector]?.badgeColor : null) ?? Colors.primary;

    const [listings, setListings] = useState<ServiceListing[]>([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [togglingId, setTogglingId] = useState<string | null>(null);

    // ── Fetch ──────────────────────────────────────────────────────────────────

    const fetchListings = useCallback(async () => {
        if (!user) return;

        const { data, error } = await supabase
            .from('service_listings')
            .select('*')
            .eq('vendor_id', user.id)
            .order('created_at', { ascending: false });

        if (error) {
            console.warn('[Listings] fetch error:', error.message);
            Alert.alert('Error', 'Could not load your listings. Please try again.');
        } else {
            setListings((data as ServiceListing[]) ?? []);
        }
    }, [user]);

    useEffect(() => {
        setLoading(true);
        fetchListings().finally(() => setLoading(false));
    }, [fetchListings]);

    const handleRefresh = useCallback(async () => {
        setRefreshing(true);
        await fetchListings();
        setRefreshing(false);
    }, [fetchListings]);

    // ── Toggle is_active ───────────────────────────────────────────────────────

    const handleToggleActive = useCallback(
        async (listing: ServiceListing) => {
            if (togglingId) return; // prevent concurrent toggles
            setTogglingId(listing.id);

            // Optimistic update
            setListings((prev) =>
                prev.map((l) =>
                    l.id === listing.id ? { ...l, is_active: !l.is_active } : l
                )
            );

            const { error } = await supabase
                .from('service_listings')
                .update({ is_active: !listing.is_active })
                .eq('id', listing.id);

            if (error) {
                // Revert on failure
                setListings((prev) =>
                    prev.map((l) =>
                        l.id === listing.id ? { ...l, is_active: listing.is_active } : l
                    )
                );
                Alert.alert('Error', 'Could not update listing status. Please try again.');
            } else {
                if (Platform.OS !== 'web') {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                }
            }

            setTogglingId(null);
        },
        [togglingId]
    );

    // ── Delete ─────────────────────────────────────────────────────────────────

    const handleDelete = useCallback((listing: ServiceListing) => {
        Alert.alert(
            'Delete Listing',
            `Are you sure you want to delete "${listing.title}"? This cannot be undone.`,
            [
                { text: 'Cancel', style: 'cancel' },
                {
                    text: 'Delete',
                    style: 'destructive',
                    onPress: async () => {
                        const { error } = await supabase
                            .from('service_listings')
                            .delete()
                            .eq('id', listing.id);

                        if (error) {
                            // Postgres FK violation: listing has active bookings (error code 23503)
                            if (error.code === '23503') {
                                Alert.alert(
                                    'Cannot Delete',
                                    'Cannot delete: listing has active bookings'
                                );
                            } else {
                                Alert.alert(
                                    'Error',
                                    error.message || 'Could not delete the listing. Please try again.'
                                );
                            }
                        } else {
                            if (Platform.OS !== 'web') {
                                Haptics.notificationAsync(
                                    Haptics.NotificationFeedbackType.Success
                                );
                            }
                            setListings((prev) => prev.filter((l) => l.id !== listing.id));
                        }
                    },
                },
            ]
        );
    }, []);

    // ── Navigation ─────────────────────────────────────────────────────────────

    const handleAddListing = useCallback(() => {
        router.push('/(vendor)/listing/new' as any);
    }, [router]);

    const handlePressListing = useCallback(
        (listing: ServiceListing) => {
            router.push(`/(vendor)/listing/${listing.id}` as any);
        },
        [router]
    );

    // ── Render ─────────────────────────────────────────────────────────────────

    if (loading) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color={accentColor} />
            </View>
        );
    }

    return (
        <View style={styles.container}>
            {/* Header */}
            <View style={styles.header}>
                <Text style={styles.headerTitle}>My Listings</Text>
                {vendorProfile?.business_name ? (
                    <Text style={styles.headerSubtitle} numberOfLines={1}>
                        {vendorProfile.business_name}
                    </Text>
                ) : null}
            </View>

            {/* List */}
            <FlatList
                data={listings}
                keyExtractor={(item) => item.id}
                contentContainerStyle={[
                    styles.listContent,
                    listings.length === 0 && styles.listContentEmpty,
                ]}
                renderItem={({ item }) => (
                    <ListingRow
                        item={item}
                        onToggleActive={handleToggleActive}
                        onDelete={handleDelete}
                        onPress={handlePressListing}
                        toggling={togglingId === item.id}
                    />
                )}
                ListEmptyComponent={<EmptyState onAdd={handleAddListing} accentColor={accentColor} />}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={handleRefresh}
                        tintColor={accentColor}
                        colors={[accentColor]}
                    />
                }
                showsVerticalScrollIndicator={false}
            />

            {/* FAB — only shown when there are listings */}
            {listings.length > 0 && (
                <Pressable
                    style={({ pressed }) => [styles.fab, { backgroundColor: pressed ? accentColor + 'CC' : accentColor }]}
                    onPress={handleAddListing}
                >
                    <Plus size={24} color={Colors.textOnPrimary} />
                </Pressable>
            )}
        </View>
    );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.background,
    },

    // Loading
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Colors.background,
    },

    // Header
    header: {
        paddingTop: Platform.OS === 'ios' ? 60 : 48,
        paddingBottom: Spacing.lg,
        paddingHorizontal: Spacing.xl,
        backgroundColor: Colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: Colors.border,
        ...Shadow.sm,
    },
    headerTitle: {
        fontSize: FontSize.xxl,
        fontWeight: FontWeight.bold,
        color: Colors.text,
    },
    headerSubtitle: {
        marginTop: Spacing.xxs,
        fontSize: FontSize.sm,
        fontWeight: FontWeight.regular,
        color: Colors.textSecondary,
    },

    // List
    listContent: {
        padding: Spacing.lg,
        gap: Spacing.md,
    },
    listContentEmpty: {
        flex: 1,
    },

    // Card
    card: {
        flexDirection: 'row',
        backgroundColor: Colors.surface,
        borderRadius: Radius.lg,
        overflow: 'hidden',
        ...Shadow.sm,
    },
    pressed: {
        opacity: 0.85,
    },

    // Photo
    photoContainer: {
        width: 96,
        height: 96,
    },
    photo: {
        width: '100%',
        height: '100%',
    },
    photoPlaceholder: {
        width: '100%',
        height: '100%',
        backgroundColor: Colors.skeleton,
        justifyContent: 'center',
        alignItems: 'center',
    },
    photoPlaceholderText: {
        fontSize: FontSize.xs,
        color: Colors.textTertiary,
        fontWeight: FontWeight.medium,
    },

    // Card content
    cardContent: {
        flex: 1,
        padding: Spacing.md,
        justifyContent: 'space-between',
    },
    titleRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.sm,
        flexWrap: 'wrap',
    },
    title: {
        flex: 1,
        fontSize: FontSize.md,
        fontWeight: FontWeight.semibold,
        color: Colors.text,
    },
    sectorBadge: {
        paddingHorizontal: Spacing.sm,
        paddingVertical: Spacing.xxs,
        borderRadius: Radius.full,
    },
    sectorBadgeText: {
        fontSize: FontSize.xs,
        fontWeight: FontWeight.semibold,
        color: Colors.textOnPrimary,
    },

    // Price
    price: {
        marginTop: Spacing.xs,
        fontSize: FontSize.md,
        fontWeight: FontWeight.bold,
        color: Colors.text,
    },
    priceUnit: {
        fontSize: FontSize.sm,
        fontWeight: FontWeight.regular,
        color: Colors.textSecondary,
    },

    // Actions
    actionsRow: {
        marginTop: Spacing.sm,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    toggleRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xs,
    },
    toggleLabel: {
        fontSize: FontSize.sm,
        fontWeight: FontWeight.medium,
        color: Colors.textSecondary,
    },
    deleteButton: {
        padding: Spacing.xs,
        borderRadius: Radius.sm,
    },
    deleteButtonPressed: {
        backgroundColor: Colors.errorLight,
    },

    // Empty state
    emptyContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: Spacing.xxxl,
        gap: Spacing.lg,
    },
    emptyTitle: {
        fontSize: FontSize.xl,
        fontWeight: FontWeight.bold,
        color: Colors.text,
        textAlign: 'center',
    },
    emptySubtitle: {
        fontSize: FontSize.md,
        fontWeight: FontWeight.regular,
        color: Colors.textSecondary,
        textAlign: 'center',
        lineHeight: 22,
    },
    emptyButton: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.sm,
        paddingHorizontal: Spacing.xl,
        paddingVertical: Spacing.md,
        borderRadius: Radius.lg,
        ...Shadow.sm,
    },
    emptyButtonText: {
        fontSize: FontSize.md,
        fontWeight: FontWeight.semibold,
        color: Colors.textOnPrimary,
    },

    // FAB
    fab: {
        position: 'absolute',
        bottom: Platform.OS === 'ios' ? 32 : 24,
        right: Spacing.xl,
        width: 56,
        height: 56,
        borderRadius: Radius.full,
        justifyContent: 'center',
        alignItems: 'center',
        ...Shadow.lg,
    },
});
