import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  Alert,
  Platform,
  KeyboardAvoidingView,
  ActivityIndicator,
  Switch,
  Image,
} from 'react-native';
import { useRouter, useLocalSearchParams, Stack } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import { ArrowLeft, Camera, X, Plus, Trash2 } from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { useVendor } from '@/providers/VendorProvider';
import { SECTOR_CONFIGS } from '@/constants/sectors';
import type { PriceUnit } from '@/types';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import ScreenLoader from '@/components/ui/ScreenLoader';
import ErrorState from '@/components/ui/ErrorState';

// ─── Constants ────────────────────────────────────────────────────────────────

const PRICE_UNITS: { value: PriceUnit; label: string }[] = [
  { value: 'per_event', label: 'Per Event' },
  { value: 'per_plate', label: 'Per Plate' },
  { value: 'per_hour', label: 'Per Hour' },
  { value: 'per_day', label: 'Per Day' },
];

const MAX_PHOTOS = 10;
const MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024;
const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

// ─── Types ────────────────────────────────────────────────────────────────────

interface PhotoAsset {
  uri: string;
  isRemote: boolean;
  mimeType?: string;
  fileSize?: number;
  fileName?: string;
}

interface FormErrors {
  title?: string;
  base_price?: string;
  photos?: string;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getMimeExtension(mimeType: string): string {
  switch (mimeType) {
    case 'image/jpeg': return 'jpg';
    case 'image/png': return 'png';
    case 'image/webp': return 'webp';
    default: return 'jpg';
  }
}

function sanitizeFileName(name: string): string {
  return name.replace(/[^a-zA-Z0-9._-]/g, '_');
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function EditListingScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { vendorProfile, sector } = useVendor();

  // ── Load state ──────────────────────────────────────────────────────────────
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);

  // ── Form state ──────────────────────────────────────────────────────────────
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [basePrice, setBasePrice] = useState('');
  const [priceUnit, setPriceUnit] = useState<PriceUnit>('per_event');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [photos, setPhotos] = useState<PhotoAsset[]>([]);
  const [isActive, setIsActive] = useState(true);

  // ── UI state ────────────────────────────────────────────────────────────────
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<string | null>(null);
  const [isDirty, setIsDirty] = useState(false);

  // ── Derived ─────────────────────────────────────────────────────────────────
  const vendorId = vendorProfile?.id ?? null;
  const sectorConfig = sector ? SECTOR_CONFIGS[sector] : null;

  // ── Load listing ────────────────────────────────────────────────────────────
  const loadListing = useCallback(async () => {
    if (!id) return;
    setIsLoading(true);
    setIsError(false);

    const { data, error } = await supabase
      .from('service_listings')
      .select('*')
      .eq('id', id)
      .single();

    if (error || !data) {
      setIsError(true);
      setIsLoading(false);
      return;
    }

    setTitle(data.title ?? '');
    setDescription(data.description ?? '');
    setBasePrice(String(data.base_price ?? ''));
    setPriceUnit((data.price_unit as PriceUnit) ?? 'per_event');
    setTags(data.tags ?? []);
    setIsActive(data.is_active ?? true);
    setPhotos(
      (data.photos ?? []).map((uri: string) => ({ uri, isRemote: true }))
    );
    setIsLoading(false);
  }, [id]);

  useEffect(() => { loadListing(); }, [loadListing]);

  // ── Mark dirty on any change ─────────────────────────────────────────────
  const markDirty = useCallback(() => setIsDirty(true), []);

  // ── Validation ──────────────────────────────────────────────────────────────
  const validate = useCallback((): boolean => {
    const newErrors: FormErrors = {};

    if (!title.trim()) {
      newErrors.title = 'Title is required.';
    } else if (title.trim().length < 5) {
      newErrors.title = 'Title must be at least 5 characters.';
    } else if (title.trim().length > 120) {
      newErrors.title = 'Title must be under 120 characters.';
    }

    const priceNum = parseFloat(basePrice);
    if (!basePrice.trim()) {
      newErrors.base_price = 'Price is required.';
    } else if (isNaN(priceNum) || priceNum <= 0) {
      newErrors.base_price = 'Enter a valid price greater than 0.';
    } else if (priceNum > 10_000_000) {
      newErrors.base_price = 'Price cannot exceed ₹1,00,00,000.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [title, basePrice]);

  // ── Photo picking ────────────────────────────────────────────────────────────
  const pickPhoto = useCallback(async () => {
    if (photos.length >= MAX_PHOTOS) {
      Alert.alert('Limit reached', `You can upload up to ${MAX_PHOTOS} photos.`);
      return;
    }

    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Allow photo access to upload images.');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.85,
      allowsMultipleSelection: true,
      selectionLimit: MAX_PHOTOS - photos.length,
    });

    if (result.canceled) return;

    const newErrors: FormErrors = { ...errors };
    const valid: PhotoAsset[] = [];

    for (const asset of result.assets) {
      if (asset.fileSize && asset.fileSize > MAX_FILE_SIZE_BYTES) {
        newErrors.photos = 'Some images exceed the 5 MB limit and were skipped.';
        continue;
      }
      if (asset.mimeType && !ALLOWED_MIME_TYPES.includes(asset.mimeType)) {
        newErrors.photos = 'Only JPEG, PNG, and WebP images are allowed.';
        continue;
      }
      valid.push({ uri: asset.uri, isRemote: false, mimeType: asset.mimeType, fileSize: asset.fileSize, fileName: asset.fileName ?? undefined });
    }

    setErrors(newErrors);
    setPhotos((prev) => [...prev, ...valid].slice(0, MAX_PHOTOS));
    markDirty();
  }, [photos, errors, markDirty]);

  const removePhoto = useCallback((index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
    markDirty();
  }, [markDirty]);

  // ── Tag handling ─────────────────────────────────────────────────────────────
  const addTag = useCallback(() => {
    const tag = tagInput.trim().toLowerCase();
    if (!tag || tags.includes(tag) || tags.length >= 10) return;
    setTags((prev) => [...prev, tag]);
    setTagInput('');
    markDirty();
  }, [tagInput, tags, markDirty]);

  const removeTag = useCallback((tag: string) => {
    setTags((prev) => prev.filter((t) => t !== tag));
    markDirty();
  }, [markDirty]);

  // ── Upload local photos to Supabase storage ──────────────────────────────────
  const uploadPhotos = useCallback(async (): Promise<string[]> => {
    const urls: string[] = [];

    for (let i = 0; i < photos.length; i++) {
      const photo = photos[i];

      if (photo.isRemote) {
        urls.push(photo.uri);
        continue;
      }

      setUploadProgress(`Uploading photo ${i + 1} of ${photos.length}…`);

      const ext = photo.mimeType ? getMimeExtension(photo.mimeType) : 'jpg';
      const rawName = photo.fileName ?? `photo_${Date.now()}_${i}.${ext}`;
      const fileName = sanitizeFileName(rawName);
      const path = `${vendorId}/listings/${id}/${fileName}`;

      const response = await fetch(photo.uri);
      const blob = await response.blob();

      const { error } = await supabase.storage
        .from('vendor-assets')
        .upload(path, blob, {
          contentType: photo.mimeType ?? 'image/jpeg',
          upsert: true,
        });

      if (error) throw new Error(`Upload failed: ${error.message}`);

      const { data: urlData } = supabase.storage
        .from('vendor-assets')
        .getPublicUrl(path);

      urls.push(urlData.publicUrl);
    }

    setUploadProgress(null);
    return urls;
  }, [photos, vendorId, id]);

  // ── Save ─────────────────────────────────────────────────────────────────────
  const handleSave = useCallback(async () => {
    if (!validate()) return;
    if (!vendorId || !id) return;

    setIsSubmitting(true);
    try {
      const photoUrls = await uploadPhotos();

      const { error } = await supabase
        .from('service_listings')
        .update({
          title: title.trim(),
          description: description.trim() || null,
          base_price: parseFloat(basePrice),
          price_unit: priceUnit,
          tags,
          photos: photoUrls,
          is_active: isActive,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id)
        .eq('vendor_id', vendorId);

      if (error) throw error;

      setIsDirty(false);
      Alert.alert('Saved', 'Your listing has been updated.', [
        { text: 'OK', onPress: () => router.back() },
      ]);
    } catch (err: any) {
      Alert.alert('Error', err?.message ?? 'Failed to save. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  }, [validate, vendorId, id, uploadPhotos, title, description, basePrice, priceUnit, tags, isActive, router]);

  // ── Delete ───────────────────────────────────────────────────────────────────
  const handleDelete = useCallback(async () => {
    if (!vendorId || !id) return;

    Alert.alert(
      'Delete Listing',
      'This will permanently remove the listing. Active bookings will prevent deletion.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            setIsDeleting(true);
            try {
              // Guard: block deletion if active bookings exist
              const { count, error: countErr } = await supabase
                .from('service_bookings')
                .select('id', { count: 'exact', head: true })
                .eq('listing_id', id)
                .in('status', ['pending', 'confirmed']);

              if (countErr) throw countErr;

              if ((count ?? 0) > 0) {
                Alert.alert(
                  'Cannot Delete',
                  'This listing has active bookings. Cancel or complete them first.'
                );
                return;
              }

              const { error } = await supabase
                .from('service_listings')
                .delete()
                .eq('id', id)
                .eq('vendor_id', vendorId);

              if (error) throw error;

              router.replace('/(vendor)/dashboard' as any);
            } catch (err: any) {
              Alert.alert('Error', err?.message ?? 'Could not delete listing.');
            } finally {
              setIsDeleting(false);
            }
          },
        },
      ]
    );
  }, [vendorId, id, router]);

  // ── Render ───────────────────────────────────────────────────────────────────

  if (isLoading) return <ScreenLoader />;

  if (isError) {
    return (
      <View style={styles.screen}>
        <ErrorState
          title="Could not load listing"
          subtitle="Check your connection and try again."
          onRetry={loadListing}
        />
      </View>
    );
  }

  const accentColor = sectorConfig?.badgeColor ?? Colors.primary;

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ headerShown: false }} />

      {/* Header */}
      <SafeAreaView edges={['top']} style={[styles.header, { backgroundColor: accentColor }]}>
        <AnimatedPressable onPress={() => router.back()} scaleValue={0.9}>
          <View style={styles.headerBtn}>
            <ArrowLeft size={22} color="#FFFFFF" />
          </View>
        </AnimatedPressable>
        <Text style={styles.headerTitle}>Edit Listing</Text>
        <AnimatedPressable onPress={handleDelete} scaleValue={0.9} disabled={isDeleting}>
          <View style={styles.headerBtn}>
            {isDeleting
              ? <ActivityIndicator size="small" color="#FFFFFF" />
              : <Trash2 size={20} color="#FFFFFF" />
            }
          </View>
        </AnimatedPressable>
      </SafeAreaView>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Active toggle */}
          <View style={styles.card}>
            <View style={styles.toggleRow}>
              <View>
                <Text style={styles.label}>Listing Active</Text>
                <Text style={styles.hint}>Inactive listings won't appear in search.</Text>
              </View>
              <Switch
                value={isActive}
                onValueChange={(v) => { setIsActive(v); markDirty(); }}
                trackColor={{ false: Colors.border, true: accentColor }}
                thumbColor="#FFFFFF"
              />
            </View>
          </View>

          {/* Title */}
          <View style={styles.card}>
            <Text style={styles.label}>Title *</Text>
            <TextInput
              style={[styles.input, errors.title ? styles.inputError : null]}
              value={title}
              onChangeText={(v) => { setTitle(v); markDirty(); }}
              placeholder="e.g. Premium Floral Arch for Weddings"
              placeholderTextColor={Colors.textTertiary}
              maxLength={120}
            />
            {errors.title && <Text style={styles.errorText}>{errors.title}</Text>}
            <Text style={styles.charCount}>{title.length}/120</Text>
          </View>

          {/* Description */}
          <View style={styles.card}>
            <Text style={styles.label}>Description</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              value={description}
              onChangeText={(v) => { setDescription(v); markDirty(); }}
              placeholder="Describe your service, packages, what's included…"
              placeholderTextColor={Colors.textTertiary}
              multiline
              numberOfLines={5}
              maxLength={1000}
              textAlignVertical="top"
            />
            <Text style={styles.charCount}>{description.length}/1000</Text>
          </View>

          {/* Pricing */}
          <View style={styles.card}>
            <Text style={styles.label}>Base Price (₹) *</Text>
            <TextInput
              style={[styles.input, errors.base_price ? styles.inputError : null]}
              value={basePrice}
              onChangeText={(v) => { setBasePrice(v); markDirty(); }}
              placeholder="e.g. 15000"
              placeholderTextColor={Colors.textTertiary}
              keyboardType="numeric"
            />
            {errors.base_price && <Text style={styles.errorText}>{errors.base_price}</Text>}

            <Text style={[styles.label, { marginTop: Spacing.md }]}>Price Unit</Text>
            <View style={styles.unitRow}>
              {PRICE_UNITS.map((u) => (
                <AnimatedPressable
                  key={u.value}
                  onPress={() => { setPriceUnit(u.value); markDirty(); }}
                  scaleValue={0.95}
                >
                  <View style={[
                    styles.unitChip,
                    priceUnit === u.value && { backgroundColor: accentColor, borderColor: accentColor },
                  ]}>
                    <Text style={[
                      styles.unitChipText,
                      priceUnit === u.value && { color: '#FFFFFF' },
                    ]}>{u.label}</Text>
                  </View>
                </AnimatedPressable>
              ))}
            </View>
          </View>

          {/* Tags */}
          <View style={styles.card}>
            <Text style={styles.label}>Tags</Text>
            <Text style={styles.hint}>Add searchable keywords (max 10)</Text>
            <View style={styles.tagInputRow}>
              <TextInput
                style={[styles.input, { flex: 1, marginBottom: 0 }]}
                value={tagInput}
                onChangeText={setTagInput}
                placeholder="e.g. outdoor, luxury…"
                placeholderTextColor={Colors.textTertiary}
                onSubmitEditing={addTag}
                returnKeyType="done"
                blurOnSubmit={false}
              />
              <AnimatedPressable onPress={addTag} scaleValue={0.9}>
                <View style={[styles.addTagBtn, { backgroundColor: accentColor }]}>
                  <Plus size={18} color="#FFFFFF" />
                </View>
              </AnimatedPressable>
            </View>
            {tags.length > 0 && (
              <View style={styles.tagList}>
                {tags.map((tag) => (
                  <View key={tag} style={[styles.tagChip, { borderColor: accentColor }]}>
                    <Text style={[styles.tagText, { color: accentColor }]}>{tag}</Text>
                    <AnimatedPressable onPress={() => removeTag(tag)} scaleValue={0.9}>
                      <X size={12} color={accentColor} />
                    </AnimatedPressable>
                  </View>
                ))}
              </View>
            )}
          </View>

          {/* Photos */}
          <View style={styles.card}>
            <Text style={styles.label}>Photos</Text>
            <Text style={styles.hint}>Up to {MAX_PHOTOS} photos · JPEG/PNG/WebP · max 5 MB each</Text>
            {errors.photos && <Text style={styles.errorText}>{errors.photos}</Text>}

            <View style={styles.photoGrid}>
              {photos.map((photo, index) => (
                <View key={`${photo.uri}-${index}`} style={styles.photoWrapper}>
                  <Image source={{ uri: photo.uri }} style={styles.photo} resizeMode="cover" />
                  <AnimatedPressable
                    onPress={() => removePhoto(index)}
                    scaleValue={0.9}
                    style={styles.removePhotoBtn}
                  >
                    <X size={14} color="#FFFFFF" />
                  </AnimatedPressable>
                  {!photo.isRemote && (
                    <View style={styles.newBadge}>
                      <Text style={styles.newBadgeText}>NEW</Text>
                    </View>
                  )}
                </View>
              ))}

              {photos.length < MAX_PHOTOS && (
                <AnimatedPressable onPress={pickPhoto} scaleValue={0.95}>
                  <View style={[styles.addPhotoBtn, { borderColor: accentColor }]}>
                    <Camera size={24} color={accentColor} />
                    <Text style={[styles.addPhotoText, { color: accentColor }]}>Add</Text>
                  </View>
                </AnimatedPressable>
              )}
            </View>
          </View>

          {uploadProgress && (
            <View style={styles.progressRow}>
              <ActivityIndicator size="small" color={accentColor} />
              <Text style={styles.progressText}>{uploadProgress}</Text>
            </View>
          )}
        </ScrollView>

        {/* Save button */}
        <SafeAreaView edges={['bottom']} style={styles.footer}>
          <AnimatedPressable
            onPress={handleSave}
            scaleValue={0.97}
            disabled={isSubmitting || !isDirty}
          >
            <View style={[
              styles.saveBtn,
              { backgroundColor: accentColor },
              (isSubmitting || !isDirty) && styles.saveBtnDisabled,
            ]}>
              {isSubmitting
                ? <ActivityIndicator color="#FFFFFF" />
                : <Text style={styles.saveBtnText}>Save Changes</Text>
              }
            </View>
          </AnimatedPressable>
        </SafeAreaView>
      </KeyboardAvoidingView>
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingBottom: Spacing.md,
  },
  headerBtn: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.bold,
    color: '#FFFFFF',
  },
  scrollContent: {
    padding: Spacing.md,
    gap: Spacing.md,
    paddingBottom: Spacing.xl,
  },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    ...Shadow.sm,
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  label: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.semibold,
    color: Colors.text,
    marginBottom: Spacing.xs,
  },
  hint: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    marginBottom: Spacing.sm,
  },
  input: {
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    fontSize: FontSize.sm,
    color: Colors.text,
    backgroundColor: Colors.background,
    marginBottom: Spacing.xs,
  },
  inputError: {
    borderColor: '#EF4444',
  },
  textArea: {
    height: 120,
  },
  errorText: {
    fontSize: FontSize.xs,
    color: '#EF4444',
    marginTop: 2,
  },
  charCount: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    textAlign: 'right',
  },
  unitRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
    marginTop: Spacing.xs,
  },
  unitChip: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: Radius.full,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.surface,
  },
  unitChipText: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    fontWeight: FontWeight.medium,
  },
  tagInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  addTagBtn: {
    width: 40,
    height: 40,
    borderRadius: Radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tagList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
    marginTop: Spacing.sm,
  },
  tagChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: Radius.full,
    borderWidth: 1,
    backgroundColor: Colors.background,
  },
  tagText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.medium,
  },
  photoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
    marginTop: Spacing.sm,
  },
  photoWrapper: {
    width: 90,
    height: 90,
    borderRadius: Radius.md,
    overflow: 'hidden',
    position: 'relative',
  },
  photo: {
    width: '100%',
    height: '100%',
  },
  removePhotoBtn: {
    position: 'absolute',
    top: 4,
    right: 4,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(0,0,0,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  newBadge: {
    position: 'absolute',
    bottom: 4,
    left: 4,
    backgroundColor: '#10B981',
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: Radius.sm,
  },
  newBadgeText: {
    fontSize: 9,
    color: '#FFFFFF',
    fontWeight: FontWeight.bold,
  },
  addPhotoBtn: {
    width: 90,
    height: 90,
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    backgroundColor: Colors.background,
  },
  addPhotoText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.medium,
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.md,
  },
  progressText: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
  },
  footer: {
    padding: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    backgroundColor: Colors.surface,
  },
  saveBtn: {
    height: 52,
    borderRadius: Radius.lg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  saveBtnDisabled: {
    opacity: 0.5,
  },
  saveBtnText: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.bold,
    color: '#FFFFFF',
  },
});
