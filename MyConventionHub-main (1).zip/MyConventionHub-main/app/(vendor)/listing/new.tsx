import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  Platform,
  KeyboardAvoidingView,
  ActivityIndicator,
} from 'react-native';
import { useRouter, Stack } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import { ArrowLeft, Camera, X, Plus, Tag } from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { useVendor } from '@/providers/VendorProvider';
import { SECTOR_CONFIGS } from '@/constants/sectors';
import type { PriceUnit } from '@/types';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

// ─── Constants ────────────────────────────────────────────────────────────────

const PRICE_UNITS: { value: PriceUnit; label: string }[] = [
  { value: 'per_event', label: 'Per Event' },
  { value: 'per_plate', label: 'Per Plate' },
  { value: 'per_hour', label: 'Per Hour' },
  { value: 'per_day', label: 'Per Day' },
];

const MAX_PHOTOS = 10;
const MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024; // 5 MB
const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

// ─── Types ────────────────────────────────────────────────────────────────────

interface PhotoAsset {
  uri: string;
  mimeType?: string;
  fileSize?: number;
  fileName?: string;
}

interface FormErrors {
  title?: string;
  base_price?: string;
  photos?: string;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getMimeExtension(mimeType: string): string {
  switch (mimeType) {
    case 'image/jpeg': return 'jpg';
    case 'image/png': return 'png';
    case 'image/webp': return 'webp';
    default: return 'jpg';
  }
}

function sanitizeFileName(name: string): string {
  return name.replace(/[^a-zA-Z0-9._-]/g, '_');
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function NewListingScreen() {
  const router = useRouter();
  const { vendorProfile, sector } = useVendor();

  // ── Form state ──────────────────────────────────────────────────────────────
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [basePrice, setBasePrice] = useState('');
  const [priceUnit, setPriceUnit] = useState<PriceUnit>(
    sector ? SECTOR_CONFIGS[sector].defaultPriceUnit : 'per_event'
  );
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [photos, setPhotos] = useState<PhotoAsset[]>([]);

  // ── UI state ────────────────────────────────────────────────────────────────
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<string | null>(null);

  // ── Derived ─────────────────────────────────────────────────────────────────
  const vendorId = vendorProfile?.id ?? null;
  const sectorConfig = sector ? SECTOR_CONFIGS[sector] : null;

  // ── Validation ──────────────────────────────────────────────────────────────
  const validate = useCallback((): boolean => {
    const newErrors: FormErrors = {};

    if (!title.trim()) {
      newErrors.title = 'Title is required.';
    } else if (title.trim().length > 200) {
      newErrors.title = 'Title must be 200 characters or fewer.';
    }

    if (!basePrice.trim()) {
      newErrors.base_price = 'Base price is required.';
    } else {
      const parsed = parseFloat(basePrice);
      if (isNaN(parsed) || parsed < 0) {
        newErrors.base_price = 'Base price must be 0 or greater.';
      } else if (parsed > 999999.99) {
        newErrors.base_price = 'Base price cannot exceed ₹999,999.99.';
      }
    }

    if (photos.length === 0) {
      newErrors.photos = 'At least one photo is required.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [title, basePrice, photos]);

  // ── Tag management ──────────────────────────────────────────────────────────
  const addTag = useCallback(() => {
    const raw = tagInput.trim();
    if (!raw) return;

    // Support comma-separated input
    const newTags = raw
      .split(',')
      .map((t) => t.trim())
      .filter((t) => t.length > 0 && !tags.includes(t));

    if (newTags.length > 0) {
      setTags((prev) => [...prev, ...newTags]);
    }
    setTagInput('');
  }, [tagInput, tags]);

  const removeTag = useCallback((tag: string) => {
    setTags((prev) => prev.filter((t) => t !== tag));
  }, []);

  // ── Photo picker ────────────────────────────────────────────────────────────
  const pickPhotos = useCallback(async () => {
    if (photos.length >= MAX_PHOTOS) {
      Alert.alert('Limit reached', `You can upload a maximum of ${MAX_PHOTOS} photos.`);
      return;
    }

    const remaining = MAX_PHOTOS - photos.length;

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      selectionLimit: remaining,
      quality: 0.85,
      exif: false,
    });

    if (result.canceled) return;

    const validAssets: PhotoAsset[] = [];
    const rejections: string[] = [];

    for (const asset of result.assets) {
      const mime = asset.mimeType ?? 'image/jpeg';
      const size = asset.fileSize ?? 0;

      if (!ALLOWED_MIME_TYPES.includes(mime)) {
        rejections.push(`${asset.fileName ?? 'file'}: unsupported format (JPEG, PNG, WebP only)`);
        continue;
      }
      if (size > MAX_FILE_SIZE_BYTES) {
        rejections.push(`${asset.fileName ?? 'file'}: exceeds 5 MB limit`);
        continue;
      }

      validAssets.push({
        uri: asset.uri,
        mimeType: mime,
        fileSize: size,
        fileName: asset.fileName ?? undefined,
      });
    }

    if (rejections.length > 0) {
      Alert.alert('Some photos were skipped', rejections.join('\n'));
    }

    if (validAssets.length > 0) {
      setPhotos((prev) => [...prev, ...validAssets].slice(0, MAX_PHOTOS));
      // Clear photo error if we now have photos
      setErrors((prev) => ({ ...prev, photos: undefined }));
    }
  }, [photos]);

  const removePhoto = useCallback((index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
  }, []);

  // ── Upload photos to Supabase Storage ───────────────────────────────────────
  const uploadPhotos = useCallback(
    async (listingId: string): Promise<string[]> => {
      if (!vendorId) throw new Error('Vendor ID not available');

      const publicUrls: string[] = [];

      for (let i = 0; i < photos.length; i++) {
        const photo = photos[i];
        setUploadProgress(`Uploading photo ${i + 1} of ${photos.length}…`);

        const mime = photo.mimeType ?? 'image/jpeg';
        const ext = getMimeExtension(mime);
        const rawName = photo.fileName ?? `photo_${i + 1}.${ext}`;
        const safeName = sanitizeFileName(rawName);
        const storagePath = `${vendorId}/${listingId}/${safeName}`;

        // Fetch the local file as a blob
        const response = await fetch(photo.uri);
        const blob = await response.blob();

        const { error: uploadError } = await supabase.storage
          .from('service-listings')
          .upload(storagePath, blob, {
            contentType: mime,
            upsert: false,
          });

        if (uploadError) {
          throw new Error(`Failed to upload photo ${i + 1}: ${uploadError.message}`);
        }

        const { data: urlData } = supabase.storage
          .from('service-listings')
          .getPublicUrl(storagePath);

        publicUrls.push(urlData.publicUrl);
      }

      return publicUrls;
    },
    [photos, vendorId]
  );

  // ── Submit ──────────────────────────────────────────────────────────────────
  const handleSubmit = useCallback(async () => {
    if (!validate()) return;
    if (!vendorId || !sector) {
      Alert.alert('Error', 'Vendor profile not loaded. Please try again.');
      return;
    }

    setIsSubmitting(true);
    setUploadProgress(null);

    try {
      const parsedPrice = parseFloat(basePrice);

      // 1. INSERT the listing first (without photos) to get the listing ID
      const { data: insertedListing, error: insertError } = await supabase
        .from('service_listings')
        .insert({
          vendor_id: vendorId,
          sector,
          title: title.trim(),
          description: description.trim() || null,
          base_price: parsedPrice,
          price_unit: priceUnit,
          tags,
          photos: [], // will be updated after upload
          is_active: true,
        })
        .select('id')
        .single();

      if (insertError || !insertedListing) {
        throw new Error(insertError?.message ?? 'Failed to create listing.');
      }

      const listingId = insertedListing.id as string;

      // 2. Upload photos and get public URLs
      let photoUrls: string[] = [];
      if (photos.length > 0) {
        photoUrls = await uploadPhotos(listingId);
      }

      // 3. Update the listing with the uploaded photo URLs
      if (photoUrls.length > 0) {
        const { error: updateError } = await supabase
          .from('service_listings')
          .update({ photos: photoUrls })
          .eq('id', listingId);

        if (updateError) {
          // Non-fatal: listing exists but photos may be missing
          console.warn('[NewListing] Failed to update photos:', updateError.message);
        }
      }

      setUploadProgress(null);

      // 4. Navigate to the listing detail/preview screen
      router.replace(`/(vendor)/listing/${listingId}` as any);
    } catch (err: any) {
      setUploadProgress(null);
      Alert.alert('Error', err?.message ?? 'Something went wrong. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  }, [
    validate,
    vendorId,
    sector,
    title,
    description,
    basePrice,
    priceUnit,
    tags,
    photos,
    uploadPhotos,
    router,
  ]);

  // ── Render ──────────────────────────────────────────────────────────────────

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ headerShown: false }} />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <SafeAreaView style={styles.safeArea} edges={['top']}>
          {/* Header */}
          <View style={styles.header}>
            <AnimatedPressable onPress={() => router.back()} scaleValue={0.9} style={styles.backBtn}>
              <ArrowLeft size={22} color={Colors.text} />
            </AnimatedPressable>
            <View style={styles.headerCenter}>
              <Text style={styles.headerTitle}>New Listing</Text>
              {sectorConfig && (
                <View style={[styles.sectorBadge, { backgroundColor: sectorConfig.badgeColor + '22' }]}>
                  <Text style={[styles.sectorBadgeText, { color: sectorConfig.badgeColor }]}>
                    {sectorConfig.displayName}
                  </Text>
                </View>
              )}
            </View>
            <View style={styles.headerSpacer} />
          </View>

          <ScrollView
            style={styles.scroll}
            contentContainerStyle={styles.scrollContent}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            {/* ── Title ── */}
            <View style={styles.fieldGroup}>
              <Text style={styles.label}>
                Title <Text style={styles.required}>*</Text>
              </Text>
              <TextInput
                style={[styles.input, errors.title ? styles.inputError : null]}
                placeholder="e.g. Premium Wedding Photography Package"
                placeholderTextColor={Colors.textTertiary}
                value={title}
                onChangeText={(v) => {
                  setTitle(v);
                  if (errors.title) setErrors((p) => ({ ...p, title: undefined }));
                }}
                maxLength={200}
                returnKeyType="next"
              />
              <View style={styles.fieldFooter}>
                {errors.title ? (
                  <Text style={styles.errorText}>{errors.title}</Text>
                ) : (
                  <Text style={styles.charCount}>{title.length}/200</Text>
                )}
              </View>
            </View>

            {/* ── Description ── */}
            <View style={styles.fieldGroup}>
              <Text style={styles.label}>Description</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                placeholder="Describe your service, what's included, your experience…"
                placeholderTextColor={Colors.textTertiary}
                value={description}
                onChangeText={setDescription}
                maxLength={2000}
                multiline
                numberOfLines={5}
                textAlignVertical="top"
              />
              <Text style={[styles.charCount, { alignSelf: 'flex-end' }]}>
                {description.length}/2000
              </Text>
            </View>

            {/* ── Pricing ── */}
            <View style={styles.fieldGroup}>
              <Text style={styles.label}>
                Base Price (₹) <Text style={styles.required}>*</Text>
              </Text>
              <TextInput
                style={[styles.input, errors.base_price ? styles.inputError : null]}
                placeholder="0.00"
                placeholderTextColor={Colors.textTertiary}
                value={basePrice}
                onChangeText={(v) => {
                  // Allow only numeric + single decimal point
                  const cleaned = v.replace(/[^0-9.]/g, '');
                  const parts = cleaned.split('.');
                  const formatted =
                    parts.length > 2
                      ? parts[0] + '.' + parts.slice(1).join('')
                      : cleaned;
                  setBasePrice(formatted);
                  if (errors.base_price) setErrors((p) => ({ ...p, base_price: undefined }));
                }}
                keyboardType="decimal-pad"
                returnKeyType="done"
              />
              {errors.base_price && (
                <Text style={styles.errorText}>{errors.base_price}</Text>
              )}
            </View>

            {/* ── Price Unit ── */}
            <View style={styles.fieldGroup}>
              <Text style={styles.label}>Price Unit</Text>
              <View style={styles.pillRow}>
                {PRICE_UNITS.map((unit) => (
                  <TouchableOpacity
                    key={unit.value}
                    style={[
                      styles.pill,
                      priceUnit === unit.value && styles.pillActive,
                    ]}
                    onPress={() => setPriceUnit(unit.value)}
                    activeOpacity={0.75}
                  >
                    <Text
                      style={[
                        styles.pillText,
                        priceUnit === unit.value && styles.pillTextActive,
                      ]}
                    >
                      {unit.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* ── Tags ── */}
            <View style={styles.fieldGroup}>
              <Text style={styles.label}>Tags</Text>
              <Text style={styles.helperText}>
                Add keywords to help customers find your listing (comma-separated).
              </Text>
              <View style={styles.tagInputRow}>
                <TextInput
                  style={[styles.input, styles.tagInput]}
                  placeholder="e.g. outdoor, candid, drone"
                  placeholderTextColor={Colors.textTertiary}
                  value={tagInput}
                  onChangeText={setTagInput}
                  onSubmitEditing={addTag}
                  returnKeyType="done"
                  blurOnSubmit={false}
                />
                <TouchableOpacity style={styles.addTagBtn} onPress={addTag} activeOpacity={0.8}>
                  <Plus size={18} color={Colors.textOnPrimary} />
                </TouchableOpacity>
              </View>
              {tags.length > 0 && (
                <View style={styles.tagChips}>
                  {tags.map((tag) => (
                    <View key={tag} style={styles.chip}>
                      <Tag size={12} color={Colors.primary} />
                      <Text style={styles.chipText}>{tag}</Text>
                      <TouchableOpacity onPress={() => removeTag(tag)} hitSlop={8}>
                        <X size={12} color={Colors.textTertiary} />
                      </TouchableOpacity>
                    </View>
                  ))}
                </View>
              )}
            </View>

            {/* ── Photos ── */}
            <View style={styles.fieldGroup}>
              <Text style={styles.label}>
                Photos <Text style={styles.required}>*</Text>
              </Text>
              <Text style={styles.helperText}>
                Upload 1–10 photos (JPEG, PNG, or WebP, max 5 MB each).
              </Text>

              {errors.photos && (
                <Text style={[styles.errorText, { marginBottom: Spacing.xs }]}>
                  {errors.photos}
                </Text>
              )}

              <View style={styles.photoGrid}>
                {photos.map((photo, index) => (
                  <View key={`${photo.uri}-${index}`} style={styles.photoThumb}>
                    <Image source={{ uri: photo.uri }} style={styles.photoImage} />
                    <TouchableOpacity
                      style={styles.photoRemoveBtn}
                      onPress={() => removePhoto(index)}
                      hitSlop={4}
                    >
                      <X size={14} color="#FFFFFF" />
                    </TouchableOpacity>
                    {index === 0 && (
                      <View style={styles.primaryBadge}>
                        <Text style={styles.primaryBadgeText}>Primary</Text>
                      </View>
                    )}
                  </View>
                ))}

                {photos.length < MAX_PHOTOS && (
                  <TouchableOpacity
                    style={[
                      styles.photoThumb,
                      styles.addPhotoBtn,
                      errors.photos ? styles.addPhotoBtnError : null,
                    ]}
                    onPress={pickPhotos}
                    activeOpacity={0.75}
                  >
                    <Camera size={28} color={errors.photos ? Colors.error : Colors.textTertiary} />
                    <Text
                      style={[
                        styles.addPhotoText,
                        errors.photos ? { color: Colors.error } : null,
                      ]}
                    >
                      Add Photo
                    </Text>
                    <Text style={styles.addPhotoCount}>
                      {photos.length}/{MAX_PHOTOS}
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>

            {/* ── Submit ── */}
            <View style={styles.submitSection}>
              {uploadProgress && (
                <View style={styles.progressRow}>
                  <ActivityIndicator size="small" color={Colors.primary} />
                  <Text style={styles.progressText}>{uploadProgress}</Text>
                </View>
              )}

              <AnimatedPressable
                onPress={handleSubmit}
                scaleValue={0.97}
                disabled={isSubmitting}
              >
                <View style={[styles.submitBtn, isSubmitting && styles.submitBtnDisabled]}>
                  {isSubmitting && !uploadProgress ? (
                    <ActivityIndicator size="small" color={Colors.textOnPrimary} />
                  ) : (
                    <Text style={styles.submitBtnText}>
                      {isSubmitting ? 'Publishing…' : 'Publish Listing'}
                    </Text>
                  )}
                </View>
              </AnimatedPressable>

              <Text style={styles.submitNote}>
                Your listing will be visible to customers immediately after publishing.
              </Text>
            </View>
          </ScrollView>
        </SafeAreaView>
      </KeyboardAvoidingView>
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const PHOTO_THUMB_SIZE = 100;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  flex: { flex: 1 },
  safeArea: { flex: 1 },

  // Header
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
    ...Shadow.sm,
  },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: Radius.full,
    backgroundColor: Colors.ivory,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  headerCenter: {
    flex: 1,
    alignItems: 'center',
    gap: Spacing.xs,
  },
  headerTitle: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.bold,
    color: Colors.text,
  },
  sectorBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: Radius.full,
  },
  sectorBadgeText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.semibold,
  },
  headerSpacer: { width: 38 },

  // Scroll
  scroll: { flex: 1 },
  scrollContent: {
    padding: Spacing.lg,
    paddingBottom: Spacing.massive,
    gap: Spacing.lg,
  },

  // Field groups
  fieldGroup: {
    gap: Spacing.xs,
  },
  label: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.semibold,
    color: Colors.textSecondary,
  },
  required: {
    color: Colors.error,
  },
  helperText: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    lineHeight: 17,
  },
  fieldFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  charCount: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    alignSelf: 'flex-end',
  },

  // Inputs
  input: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    fontSize: FontSize.md,
    color: Colors.text,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  inputError: {
    borderColor: Colors.error,
    backgroundColor: Colors.errorLight,
  },
  textArea: {
    minHeight: 110,
    paddingTop: Spacing.md,
  },
  errorText: {
    fontSize: FontSize.xs,
    color: Colors.error,
    fontWeight: FontWeight.medium,
  },

  // Price unit pills
  pillRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
  },
  pill: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.full,
    borderWidth: 1.5,
    borderColor: Colors.border,
    backgroundColor: Colors.surface,
  },
  pillActive: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primaryFaded,
  },
  pillText: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.medium,
    color: Colors.textSecondary,
  },
  pillTextActive: {
    color: Colors.primary,
    fontWeight: FontWeight.semibold,
  },

  // Tags
  tagInputRow: {
    flexDirection: 'row',
    gap: Spacing.sm,
    alignItems: 'center',
  },
  tagInput: {
    flex: 1,
  },
  addTagBtn: {
    width: 44,
    height: 44,
    borderRadius: Radius.md,
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    ...Shadow.sm,
  },
  tagChips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
    marginTop: Spacing.xs,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: Radius.full,
    backgroundColor: Colors.primaryFaded,
    borderWidth: 1,
    borderColor: Colors.primaryFaded2,
  },
  chipText: {
    fontSize: FontSize.xs,
    color: Colors.primary,
    fontWeight: FontWeight.medium,
  },

  // Photos
  photoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
    marginTop: Spacing.xs,
  },
  photoThumb: {
    width: PHOTO_THUMB_SIZE,
    height: PHOTO_THUMB_SIZE,
    borderRadius: Radius.md,
    overflow: 'hidden',
    position: 'relative',
  },
  photoImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  photoRemoveBtn: {
    position: 'absolute',
    top: 4,
    right: 4,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  primaryBadge: {
    position: 'absolute',
    bottom: 4,
    left: 4,
    paddingHorizontal: 5,
    paddingVertical: 2,
    borderRadius: Radius.xs,
    backgroundColor: Colors.primary,
  },
  primaryBadgeText: {
    fontSize: 9,
    color: Colors.textOnPrimary,
    fontWeight: FontWeight.bold,
  },
  addPhotoBtn: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.ivory,
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderStyle: 'dashed',
    gap: 4,
  },
  addPhotoBtnError: {
    borderColor: Colors.error,
    backgroundColor: Colors.errorLight,
  },
  addPhotoText: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
  },
  addPhotoCount: {
    fontSize: 10,
    color: Colors.textTertiary,
  },

  // Submit
  submitSection: {
    gap: Spacing.md,
    marginTop: Spacing.sm,
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    justifyContent: 'center',
  },
  progressText: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
  },
  submitBtn: {
    backgroundColor: Colors.primary,
    paddingVertical: Spacing.lg,
    borderRadius: Radius.lg,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 52,
    ...Shadow.md,
  },
  submitBtnDisabled: {
    opacity: 0.65,
  },
  submitBtnText: {
    color: Colors.textOnPrimary,
    fontSize: FontSize.lg,
    fontWeight: FontWeight.bold,
  },
  submitNote: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    textAlign: 'center',
    lineHeight: 17,
  },
});
