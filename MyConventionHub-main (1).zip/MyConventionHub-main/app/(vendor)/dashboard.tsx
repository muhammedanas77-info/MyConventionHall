import React, { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import {
  CalendarDays,
  ChevronRight,
  IndianRupee,
  LayoutList,
  PlusCircle,
  TrendingUp,
  User,
} from 'lucide-react-native';

import { Colors, FontSize, FontWeight, Radius, Shadow, Spacing } from '@/constants/theme';
import { SECTOR_CONFIGS } from '@/constants/sectors';
import { useAuth } from '@/providers/AuthProvider';
import { useVendor } from '@/providers/VendorProvider';
import { supabase } from '@/utils/supabase';
import type { ServiceBooking, ServiceCommission } from '@/types';

function formatRupees(amount: number): string {
  return '₹' + amount.toLocaleString('en-IN', { maximumFractionDigits: 0 });
}

function getMonthRange(): { start: string; end: string } {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), 1);
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  const toISO = (d: Date) => d.toISOString().split('T')[0];
  return { start: toISO(start), end: toISO(end) };
}

function BookingRow({ booking }: { booking: ServiceBooking }) {
  const statusColor: Record<string, string> = {
    pending: Colors.warning,
    confirmed: Colors.success,
    cancelled: Colors.error,
    completed: Colors.info,
  };
  const color = statusColor[booking.status] ?? Colors.textTertiary;
  const eventDate = new Date(booking.event_date).toLocaleDateString('en-IN', {
    day: 'numeric', month: 'short',
  });

  return (
    <View style={styles.bookingRow}>
      <View style={[styles.bookingDot, { backgroundColor: color }]} />
      <View style={styles.bookingInfo}>
        <Text style={styles.bookingCustomer} numberOfLines={1}>
          {booking.customer?.full_name ?? 'Customer'}
        </Text>
        <Text style={styles.bookingDate}>{eventDate}</Text>
      </View>
      <Text style={styles.bookingAmount}>{formatRupees(booking.total_amount)}</Text>
    </View>
  );
}

export default function VendorDashboard() {
  const router = useRouter();
  const { user } = useAuth();
  const { vendorProfile, sector, bookings } = useVendor();

  const [commissionTotal, setCommissionTotal] = useState(0);
  const [commissionLoading, setCommissionLoading] = useState(true);

  const sectorConfig = sector ? SECTOR_CONFIGS[sector] : null;
  const accentColor = sectorConfig?.badgeColor ?? Colors.primary;
  const businessName = vendorProfile?.business_name?.trim() || user?.email?.split('@')[0] || 'Vendor';

  const { start: monthStart, end: monthEnd } = getMonthRange();

  const pendingCount = bookings.filter(b => b.status === 'pending').length;
  const confirmedCount = bookings.filter(
    b => b.status === 'confirmed' && b.event_date >= monthStart && b.event_date <= monthEnd
  ).length;
  const revenueThisMonth = bookings
    .filter(b => (b.status === 'confirmed' || b.status === 'completed') && b.event_date >= monthStart && b.event_date <= monthEnd)
    .reduce((sum, b) => sum + (b.total_amount ?? 0), 0);

  const recentBookings = [...bookings]
    .sort((a, b) => new Date(a.event_date).getTime() - new Date(b.event_date).getTime())
    .slice(0, 4);

  const fetchCommission = useCallback(async () => {
    if (!user?.id) return;
    setCommissionLoading(true);
    try {
      const { data } = await supabase
        .from('service_commissions')
        .select('commission_amount')
        .eq('vendor_id', user.id)
        .gte('created_at', monthStart + 'T00:00:00.000Z')
        .lte('created_at', monthEnd + 'T23:59:59.999Z');
      const total = (data as Pick<ServiceCommission, 'commission_amount'>[] ?? [])
        .reduce((sum, r) => sum + (r.commission_amount ?? 0), 0);
      setCommissionTotal(total);
    } finally {
      setCommissionLoading(false);
    }
  }, [user?.id, monthStart, monthEnd]);

  useEffect(() => { fetchCommission(); }, [fetchCommission]);

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'left', 'right']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>

        {/* Header */}
        <View style={[styles.header, { backgroundColor: accentColor }]}>
          <Text style={styles.greeting}>Welcome back</Text>
          <Text style={styles.businessName} numberOfLines={1}>{businessName}</Text>
          {sectorConfig && (
            <View style={styles.sectorBadge}>
              <Text style={styles.sectorText}>{sectorConfig.displayName}</Text>
            </View>
          )}
        </View>

        {/* Stats row */}
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <CalendarDays size={18} color={Colors.warning} />
            <Text style={styles.statValue}>{pendingCount}</Text>
            <Text style={styles.statLabel}>Pending</Text>
          </View>
          <View style={[styles.statCard, styles.statCardMiddle]}>
            <TrendingUp size={18} color={Colors.success} />
            <Text style={styles.statValue}>{confirmedCount}</Text>
            <Text style={styles.statLabel}>Confirmed</Text>
          </View>
          <View style={styles.statCard}>
            <IndianRupee size={18} color={accentColor} />
            <Text style={[styles.statValue, { fontSize: FontSize.md }]}>{formatRupees(revenueThisMonth)}</Text>
            <Text style={styles.statLabel}>Revenue</Text>
          </View>
        </View>

        {/* Recent bookings */}
        <Text style={styles.sectionTitle}>Recent Bookings</Text>
        <View style={styles.card}>
          {recentBookings.length === 0 ? (
            <Text style={styles.emptyText}>No bookings yet</Text>
          ) : (
            recentBookings.map((b, i) => (
              <React.Fragment key={b.id}>
                <BookingRow booking={b} />
                {i < recentBookings.length - 1 && <View style={styles.divider} />}
              </React.Fragment>
            ))
          )}
        </View>

        {/* Quick actions */}
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.card}>
          {[
            { label: 'Add Listing', icon: <PlusCircle size={18} color={accentColor} />, route: '/(vendor)/listing/new' },
            { label: 'Manage Profile', icon: <User size={18} color={accentColor} />, route: '/(vendor)/profile' },
            { label: 'View All Bookings', icon: <LayoutList size={18} color={accentColor} />, route: '/(vendor)/bookings' },
          ].map((action, i, arr) => (
            <React.Fragment key={action.label}>
              <Pressable
                style={({ pressed }) => [styles.action, pressed && { backgroundColor: Colors.primaryFaded }]}
                onPress={() => router.push(action.route as any)}
              >
                <View style={[styles.actionIcon, { backgroundColor: accentColor + '18' }]}>{action.icon}</View>
                <Text style={styles.actionLabel}>{action.label}</Text>
                <ChevronRight size={16} color={Colors.textTertiary} />
              </Pressable>
              {i < arr.length - 1 && <View style={styles.divider} />}
            </React.Fragment>
          ))}
        </View>

        <View style={{ height: Spacing.xxl }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.background },
  content: { paddingBottom: Spacing.xl },

  header: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.lg,
    paddingBottom: Spacing.xxl,
  },
  greeting: {
    fontSize: FontSize.sm,
    color: 'rgba(255,255,255,0.75)',
    fontWeight: FontWeight.medium,
  },
  businessName: {
    fontSize: FontSize.xxl,
    fontWeight: FontWeight.bold,
    color: '#FFFFFF',
    marginTop: 2,
  },
  sectorBadge: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: Radius.full,
    marginTop: Spacing.sm,
  },
  sectorText: {
    fontSize: FontSize.xs,
    color: '#FFFFFF',
    fontWeight: FontWeight.semibold,
  },

  statsRow: {
    flexDirection: 'row',
    marginHorizontal: Spacing.lg,
    marginTop: -Spacing.lg,
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    ...Shadow.md,
    overflow: 'hidden',
  },
  statCard: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: Spacing.md,
    gap: 4,
  },
  statCardMiddle: {
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: Colors.border,
  },
  statValue: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.bold,
    color: Colors.text,
  },
  statLabel: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontWeight: FontWeight.medium,
  },

  sectionTitle: {
    fontSize: FontSize.md,
    fontWeight: FontWeight.semibold,
    color: Colors.text,
    marginTop: Spacing.xl,
    marginBottom: Spacing.sm,
    marginHorizontal: Spacing.lg,
  },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    marginHorizontal: Spacing.lg,
    ...Shadow.sm,
    overflow: 'hidden',
  },
  divider: {
    height: 1,
    backgroundColor: Colors.border,
    marginHorizontal: Spacing.md,
  },

  bookingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    gap: Spacing.sm,
  },
  bookingDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  bookingInfo: { flex: 1 },
  bookingCustomer: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.medium,
    color: Colors.text,
  },
  bookingDate: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
  },
  bookingAmount: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.semibold,
    color: Colors.text,
  },
  emptyText: {
    fontSize: FontSize.sm,
    color: Colors.textTertiary,
    textAlign: 'center',
    paddingVertical: Spacing.xl,
  },

  action: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    gap: Spacing.md,
  },
  actionIcon: {
    width: 34,
    height: 34,
    borderRadius: Radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionLabel: {
    flex: 1,
    fontSize: FontSize.sm,
    fontWeight: FontWeight.medium,
    color: Colors.text,
  },
});
