import React, { useCallback, useState } from 'react';
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { LogOut, User } from 'lucide-react-native';
import { Colors, FontSize, FontWeight, Radius, Shadow, Spacing } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { useAuth } from '@/providers/AuthProvider';
import { useVendor } from '@/providers/VendorProvider';
import { useApp } from '@/providers/AppProvider';
import { SECTOR_CONFIGS } from '@/constants/sectors';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

export default function VendorProfileScreen() {
  const router = useRouter();
  const { user, profile } = useAuth();
  const { vendorProfile, sector } = useVendor();
  const { logout } = useApp();

  const [phone, setPhone] = useState(vendorProfile?.phone ?? '');
  const [isSaving, setIsSaving] = useState(false);

  const sectorConfig = sector ? SECTOR_CONFIGS[sector] : null;
  const accentColor = sectorConfig?.badgeColor ?? Colors.primary;

  const handleSave = useCallback(async () => {
    if (!vendorProfile?.id) return;
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('vendor_profiles')
        .update({ phone: phone.trim() || null, updated_at: new Date().toISOString() })
        .eq('id', vendorProfile.id);
      if (error) throw error;
      Alert.alert('Saved', 'Your profile has been updated.');
    } catch (err: any) {
      Alert.alert('Error', err?.message ?? 'Could not save. Please try again.');
    } finally {
      setIsSaving(false);
    }
  }, [vendorProfile?.id, phone]);

  const handleLogout = useCallback(() => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign Out',
        style: 'destructive',
        onPress: async () => {
          await supabase.auth.signOut();
          logout();
          router.replace('/role-select' as any);
        },
      },
    ]);
  }, [logout, router]);

  return (
    <View style={styles.screen}>
      <SafeAreaView edges={['top']} style={[styles.header, { backgroundColor: accentColor }]}>
        <Text style={styles.headerTitle}>Profile</Text>
      </SafeAreaView>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Avatar placeholder */}
        <View style={[styles.avatarCircle, { backgroundColor: accentColor + '22' }]}>
          <User size={40} color={accentColor} />
        </View>

        {sectorConfig && (
          <View style={[styles.sectorBadge, { backgroundColor: accentColor }]}>
            <Text style={styles.sectorBadgeText}>{sectorConfig.displayName}</Text>
          </View>
        )}

        {/* Info card */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Account</Text>

          <View style={styles.row}>
            <Text style={styles.rowLabel}>Email</Text>
            <Text style={styles.rowValue}>{user?.email ?? '—'}</Text>
          </View>

          <View style={styles.row}>
            <Text style={styles.rowLabel}>Name</Text>
            <Text style={styles.rowValue}>{profile?.full_name ?? '—'}</Text>
          </View>

          <View style={styles.row}>
            <Text style={styles.rowLabel}>Status</Text>
            <View style={[styles.statusBadge, vendorProfile?.is_approved ? styles.approved : styles.pending]}>
              <Text style={styles.statusText}>
                {vendorProfile?.is_approved ? 'Approved' : 'Pending Approval'}
              </Text>
            </View>
          </View>
        </View>

        {/* Editable fields */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Contact</Text>

          <Text style={styles.label}>Phone</Text>
          <TextInput
            style={styles.input}
            value={phone}
            onChangeText={setPhone}
            placeholder="+91 98765 43210"
            placeholderTextColor={Colors.textTertiary}
            keyboardType="phone-pad"
          />

          <AnimatedPressable onPress={handleSave} scaleValue={0.97} disabled={isSaving}>
            <View style={[styles.saveBtn, { backgroundColor: accentColor }]}>
              {isSaving
                ? <ActivityIndicator color="#FFFFFF" />
                : <Text style={styles.saveBtnText}>Save Changes</Text>
              }
            </View>
          </AnimatedPressable>
        </View>

        {/* Sign out */}
        <AnimatedPressable onPress={handleLogout} scaleValue={0.97}>
          <View style={styles.logoutBtn}>
            <LogOut size={18} color="#EF4444" />
            <Text style={styles.logoutText}>Sign Out</Text>
          </View>
        </AnimatedPressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    paddingHorizontal: Spacing.md,
    paddingBottom: Spacing.md,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: FontSize.lg,
    fontWeight: FontWeight.bold,
    color: '#FFFFFF',
  },
  content: {
    padding: Spacing.md,
    alignItems: 'center',
    gap: Spacing.md,
    paddingBottom: Spacing.xl,
  },
  avatarCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: Spacing.md,
  },
  sectorBadge: {
    paddingHorizontal: Spacing.md,
    paddingVertical: 4,
    borderRadius: Radius.full,
  },
  sectorBadgeText: {
    color: '#FFFFFF',
    fontSize: FontSize.sm,
    fontWeight: FontWeight.semibold,
  },
  card: {
    width: '100%',
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    gap: Spacing.sm,
    ...Shadow.sm,
  },
  sectionTitle: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
    color: Colors.textSecondary,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: Spacing.xs,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: Spacing.xs,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  rowLabel: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
  },
  rowValue: {
    fontSize: FontSize.sm,
    color: Colors.text,
    fontWeight: FontWeight.medium,
    flexShrink: 1,
    textAlign: 'right',
    marginLeft: Spacing.sm,
  },
  statusBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: Radius.full,
  },
  approved: { backgroundColor: '#D1FAE5' },
  pending: { backgroundColor: '#FEF3C7' },
  statusText: {
    fontSize: FontSize.xs,
    fontWeight: FontWeight.semibold,
    color: Colors.text,
  },
  label: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.medium,
    color: Colors.text,
  },
  input: {
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    fontSize: FontSize.sm,
    color: Colors.text,
    backgroundColor: Colors.background,
  },
  saveBtn: {
    height: 46,
    borderRadius: Radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: Spacing.xs,
  },
  saveBtnText: {
    color: '#FFFFFF',
    fontSize: FontSize.sm,
    fontWeight: FontWeight.bold,
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.xl,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: '#FCA5A5',
    backgroundColor: '#FEF2F2',
  },
  logoutText: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.semibold,
    color: '#EF4444',
  },
});
