import { Tabs } from 'expo-router';
import { CalendarDays, DollarSign, LayoutDashboard, LayoutList, User } from 'lucide-react-native';
import React, { useEffect } from 'react';
import { Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { Colors, FontWeight, Radius, Shadow, Spacing } from '@/constants/theme';
import { useAuth } from '@/providers/AuthProvider';
import { useApp } from '@/providers/AppProvider';
import { VendorProvider, useVendor } from '@/providers/VendorProvider';
import type { VendorSector } from '@/types';

// Valid vendor sectors — must stay in sync with the VendorSector union in @/types
const VALID_VENDOR_SECTORS: VendorSector[] = [
    'venue',
    'florist',
    'musician',
    'artist',
    'caterer',
    'photographer',
    'decorator',
    'other',
];

// ─── Inner layout (rendered inside VendorProvider) ────────────────────────────

function VendorTabLayout() {
    const { role: supabaseRole, isLoading } = useAuth();
    const { userRole: localRole } = useApp();
    const { vendorProfile, isApproved } = useVendor();
    const router = useRouter();

    const isVendor = supabaseRole === 'vendor' || localRole === 'vendor';

    // Guard 1: role check — redirect non-vendors to role-select
    useEffect(() => {
        if (isLoading) return;
        if (!isVendor) {
            router.replace('/role-select' as any);
        }
    }, [isVendor, isLoading, router]);

    // Guard 2: sector validation — redirect if sector is missing or invalid
    useEffect(() => {
        if (isLoading || !isVendor || vendorProfile === null) return;

        const sector = vendorProfile.vendor_sector;
        if (!sector || !VALID_VENDOR_SECTORS.includes(sector)) {
            console.warn(
                '[VendorLayout] Invalid or missing vendor_sector:',
                sector,
                '— redirecting to /role-select'
            );
            router.replace('/role-select' as any);
        }
    }, [isLoading, isVendor, vendorProfile, router]);

    // Guard 3: approval check — redirect unapproved vendors
    useEffect(() => {
        if (isLoading || !isVendor || vendorProfile === null) return;

        const sector = vendorProfile.vendor_sector;
        const sectorIsValid = sector && VALID_VENDOR_SECTORS.includes(sector);
        if (sectorIsValid && !isApproved) {
            router.replace('/vendor-pending-approval' as any);
        }
    }, [isLoading, isVendor, vendorProfile, isApproved, router]);

    if (isLoading || !isVendor) return null;

    return (
        <Tabs
            screenOptions={{
                tabBarActiveTintColor: Colors.primaryDark,
                tabBarInactiveTintColor: Colors.textTertiary,
                tabBarStyle: {
                    backgroundColor: Colors.surface,
                    borderTopColor: 'transparent',
                    height: Platform.OS === 'ios' ? 86 : 72,
                    paddingTop: Spacing.sm,
                    paddingBottom: Platform.OS === 'ios' ? Spacing.xl : Spacing.sm,
                    paddingHorizontal: Spacing.sm,
                    ...Shadow.lg,
                },
                tabBarLabelStyle: {
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                },
                tabBarItemStyle: {
                    borderRadius: Radius.lg,
                    paddingVertical: Spacing.xs,
                },
                headerShown: false,
            }}
        >
            <Tabs.Screen
                name="dashboard"
                options={{
                    title: 'Dashboard',
                    tabBarIcon: ({ color, size }) => <LayoutDashboard size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="listings"
                options={{
                    title: 'Listings',
                    tabBarIcon: ({ color, size }) => <LayoutList size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="bookings"
                options={{
                    title: 'Bookings',
                    tabBarIcon: ({ color, size }) => <CalendarDays size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="earnings"
                options={{
                    title: 'Earnings',
                    tabBarIcon: ({ color, size }) => <DollarSign size={size} color={color} />,
                }}
            />
            <Tabs.Screen
                name="profile"
                options={{
                    title: 'Profile',
                    tabBarIcon: ({ color, size }) => <User size={size} color={color} />,
                }}
            />
            <Tabs.Screen name="listing" options={{ href: null }} />
            <Tabs.Screen name="listing/[id]" options={{ href: null }} />
            <Tabs.Screen name="listing/new" options={{ href: null }} />
            <Tabs.Screen name="booking" options={{ href: null }} />
            <Tabs.Screen name="booking/[id]" options={{ href: null }} />
        </Tabs>
    );
}

// ─── Exported layout — wraps subtree in VendorProvider ────────────────────────

export default function VendorLayout() {
    return (
        <VendorProvider>
            <VendorTabLayout />
        </VendorProvider>
    );
}
