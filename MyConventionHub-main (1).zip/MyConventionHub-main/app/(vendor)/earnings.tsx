import React, { useCallback, useEffect, useState } from 'react';
import {
    ActivityIndicator,
    Platform,
    RefreshControl,
    ScrollView,
    StyleSheet,
    Text,
    View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
    AlertCircle,
    BadgeIndianRupee,
    CalendarDays,
    CircleDollarSign,
    TrendingDown,
    Wallet,
} from 'lucide-react-native';
import { Colors, FontSize, FontWeight, Radius, Shadow, Spacing } from '@/constants/theme';
import { useAuth } from '@/providers/AuthProvider';
import { useVendor } from '@/providers/VendorProvider';
import { SECTOR_CONFIGS } from '@/constants/sectors';
import { supabase } from '@/utils/supabase';
import { formatCurrencyFull } from '@/utils/currency';
import Badge from '@/components/ui/Badge';
import type { ServiceCommission } from '@/types';

// ─── Types ────────────────────────────────────────────────────────────────────

interface CommissionRow extends ServiceCommission {
    listing_title: string;
    event_date: string;
}

interface EarningsSummary {
    bookingCount: number;
    grossRevenue: number;
    platformCommission: number;
    netPayout: number;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const MONTH_NAMES = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
];

function getCurrentMonthLabel(): string {
    const now = new Date();
    return `${MONTH_NAMES[now.getMonth()]} ${now.getFullYear()}`;
}

function getMonthDateRange(): { start: string; end: string } {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    // First day of month
    const start = new Date(year, month, 1);
    // Last day of month
    const end = new Date(year, month + 1, 0);

    const pad = (n: number) => String(n).padStart(2, '0');
    const fmt = (d: Date) =>
        `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

    return { start: fmt(start), end: fmt(end) };
}

function formatEventDate(dateStr: string): string {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
    });
}

// ─── Summary Card ─────────────────────────────────────────────────────────────

interface SummaryCardProps {
    label: string;
    value: string;
    icon: React.ReactNode;
    accentColor: string;
    iconBg: string;
    subtext?: string;
}

function SummaryCard({ label, value, icon, accentColor, iconBg, subtext }: SummaryCardProps) {
    return (
        <View style={[styles.summaryCard, { borderLeftColor: accentColor }]}>
            <View style={[styles.summaryIconWrap, { backgroundColor: iconBg }]}>
                {icon}
            </View>
            <Text style={styles.summaryLabel}>{label}</Text>
            <Text style={styles.summaryValue}>{value}</Text>
            {subtext ? <Text style={styles.summarySubtext}>{subtext}</Text> : null}
        </View>
    );
}

// ─── Commission Row Item ───────────────────────────────────────────────────────

interface CommissionItemProps {
    row: CommissionRow;
}

function CommissionItem({ row }: CommissionItemProps) {
    return (
        <View style={styles.commissionCard}>
            {/* Left accent bar */}
            <View style={[styles.commissionAccent, { backgroundColor: row.is_capped ? Colors.warning : Colors.primary }]} />

            <View style={styles.commissionContent}>
                {/* Title row */}
                <View style={styles.commissionTitleRow}>
                    <Text style={styles.commissionTitle} numberOfLines={1}>
                        {row.listing_title}
                    </Text>
                    {row.is_capped && (
                        <Badge text="Capped" variant="warning" size="sm" />
                    )}
                </View>

                {/* Event date */}
                <View style={styles.commissionDateRow}>
                    <CalendarDays size={12} color={Colors.textTertiary} />
                    <Text style={styles.commissionDate}>{formatEventDate(row.event_date)}</Text>
                </View>

                {/* Amount breakdown */}
                <View style={styles.commissionAmounts}>
                    <View style={styles.amountItem}>
                        <Text style={styles.amountLabel}>Total</Text>
                        <Text style={styles.amountValue}>{formatCurrencyFull(row.total_amount)}</Text>
                    </View>
                    <View style={styles.amountDivider} />
                    <View style={styles.amountItem}>
                        <Text style={styles.amountLabel}>Commission</Text>
                        <Text style={[styles.amountValue, { color: Colors.error }]}>
                            -{formatCurrencyFull(row.commission_amount)}
                        </Text>
                    </View>
                    <View style={styles.amountDivider} />
                    <View style={styles.amountItem}>
                        <Text style={styles.amountLabel}>Payout</Text>
                        <Text style={[styles.amountValue, { color: Colors.success }]}>
                            {formatCurrencyFull(row.vendor_payout)}
                        </Text>
                    </View>
                </View>
            </View>
        </View>
    );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function EarningsScreen() {
    const { user } = useAuth();
    const { sector } = useVendor();
    const sectorConfig = sector ? SECTOR_CONFIGS[sector] : null;
    const accentColor = sectorConfig?.badgeColor ?? Colors.primary;
    const accentDark = accentColor;

    const [summary, setSummary] = useState<EarningsSummary>({
        bookingCount: 0,
        grossRevenue: 0,
        platformCommission: 0,
        netPayout: 0,
    });
    const [commissions, setCommissions] = useState<CommissionRow[]>([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const monthLabel = getCurrentMonthLabel();

    // ── Data fetching ──────────────────────────────────────────────────────────

    const fetchEarnings = useCallback(async () => {
        if (!user) return;

        setError(null);

        try {
            const { start, end } = getMonthDateRange();

            // Query service_commissions joined with service_bookings
            // Filter: vendor_id = current user, booking status IN ('confirmed','completed'),
            // event_date within current calendar month
            const { data, error: queryError } = await supabase
                .from('service_commissions')
                .select(
                    `
                    id,
                    booking_id,
                    vendor_id,
                    sector,
                    total_amount,
                    commission_amount,
                    vendor_payout,
                    is_capped,
                    status,
                    paid_at,
                    created_at,
                    booking:service_bookings!inner(
                        event_date,
                        status,
                        listing:service_listings(title)
                    )
                    `
                )
                .eq('vendor_id', user.id)
                .in('booking.status', ['confirmed', 'completed'])
                .gte('booking.event_date', start)
                .lte('booking.event_date', end)
                .order('created_at', { ascending: false });

            if (queryError) {
                console.warn('[EarningsScreen] query error:', queryError.message);
                setError('Failed to load earnings data. Please try again.');
                return;
            }

            const rows: CommissionRow[] = (data ?? []).map((item: any) => ({
                id: item.id,
                booking_id: item.booking_id,
                vendor_id: item.vendor_id,
                sector: item.sector,
                total_amount: item.total_amount ?? 0,
                commission_amount: item.commission_amount ?? 0,
                vendor_payout: item.vendor_payout ?? 0,
                is_capped: item.is_capped ?? false,
                status: item.status,
                paid_at: item.paid_at,
                created_at: item.created_at,
                listing_title: item.booking?.listing?.title ?? 'Untitled Listing',
                event_date: item.booking?.event_date ?? '',
            }));

            // Compute summary
            const bookingCount = rows.length;
            const grossRevenue = rows.reduce((sum, r) => sum + r.total_amount, 0);
            const platformCommission = rows.reduce((sum, r) => sum + r.commission_amount, 0);
            const netPayout = rows.reduce((sum, r) => sum + r.vendor_payout, 0);

            setSummary({ bookingCount, grossRevenue, platformCommission, netPayout });
            setCommissions(rows);
        } catch (err) {
            console.error('[EarningsScreen] unexpected error:', err);
            setError('An unexpected error occurred. Please try again.');
        }
    }, [user]);

    useEffect(() => {
        setLoading(true);
        fetchEarnings().finally(() => setLoading(false));
    }, [fetchEarnings]);

    const onRefresh = useCallback(async () => {
        setRefreshing(true);
        await fetchEarnings();
        setRefreshing(false);
    }, [fetchEarnings]);

    // ── Render ─────────────────────────────────────────────────────────────────

    return (
        <View style={styles.screen}>
            {/* Header gradient */}
            <LinearGradient
                colors={[accentDark, accentColor]}
                style={styles.headerGradient}
            >
                <SafeAreaView edges={['top']}>
                    <View style={styles.headerContent}>
                        <View style={styles.headerBadge}>
                            <Text style={styles.headerBadgeText}>EARNINGS</Text>
                        </View>
                        <Text style={styles.headerTitle}>My Earnings</Text>
                        <View style={styles.monthRow}>
                            <CalendarDays size={14} color="rgba(255,255,255,0.8)" />
                            <Text style={styles.monthLabel}>{monthLabel}</Text>
                        </View>
                    </View>
                </SafeAreaView>
            </LinearGradient>

            {/* Body */}
            {loading ? (
                <View style={styles.centered}>
                    <ActivityIndicator size="large" color={accentColor} />
                    <Text style={styles.loadingText}>Loading earnings…</Text>
                </View>
            ) : error ? (
                <View style={styles.centered}>
                    <AlertCircle size={40} color={Colors.error} />
                    <Text style={styles.errorText}>{error}</Text>
                </View>
            ) : (
                <ScrollView
                    contentContainerStyle={styles.scrollContent}
                    showsVerticalScrollIndicator={false}
                    refreshControl={
                        <RefreshControl
                            refreshing={refreshing}
                            onRefresh={onRefresh}
                            tintColor={accentColor}
                            colors={[accentColor]}
                        />
                    }
                >
                    {/* ── Summary Cards ── */}
                    <View style={styles.summaryGrid}>
                        <SummaryCard
                            label="BOOKINGS"
                            value={String(summary.bookingCount)}
                            icon={<BadgeIndianRupee size={20} color={accentColor} />}
                            accentColor={accentColor}
                            iconBg={accentColor + '18'}
                        />
                        <SummaryCard
                            label="GROSS REVENUE"
                            value={formatCurrencyFull(summary.grossRevenue)}
                            icon={<CircleDollarSign size={20} color={Colors.goldDark} />}
                            accentColor={Colors.goldDark}
                            iconBg={Colors.goldFaded}
                        />
                    </View>

                    <View style={styles.summaryGrid}>
                        <SummaryCard
                            label="COMMISSION"
                            value={formatCurrencyFull(summary.platformCommission)}
                            icon={<TrendingDown size={20} color={Colors.error} />}
                            accentColor={Colors.error}
                            iconBg={Colors.errorLight}
                            subtext="Platform deducted"
                        />
                        <SummaryCard
                            label="NET PAYOUT"
                            value={formatCurrencyFull(summary.netPayout)}
                            icon={<Wallet size={20} color={Colors.success} />}
                            accentColor={Colors.success}
                            iconBg={Colors.successLight}
                            subtext="You receive"
                        />
                    </View>

                    {/* ── Commission Rows ── */}
                    <View style={styles.section}>
                        <Text style={styles.sectionTitle}>Booking Breakdown</Text>

                        {commissions.length === 0 ? (
                            <View style={styles.emptyState}>
                                <Wallet size={40} color={Colors.textTertiary} />
                                <Text style={styles.emptyTitle}>No earnings yet</Text>
                                <Text style={styles.emptySubtext}>
                                    Confirmed and completed bookings for {monthLabel} will appear here.
                                </Text>
                            </View>
                        ) : (
                            commissions.map((row) => (
                                <CommissionItem key={row.id} row={row} />
                            ))
                        )}
                    </View>

                    <View style={{ height: Spacing.massive * 1.5 }} />
                </ScrollView>
            )}
        </View>
    );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const SERIF_FONT = Platform.select({
    ios: 'Georgia',
    android: 'serif',
    web: 'Georgia, serif',
    default: 'serif',
});

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        backgroundColor: Colors.background,
    },

    // Header
    headerGradient: {
        paddingBottom: Spacing.xl,
        borderBottomLeftRadius: Radius.xxl,
        borderBottomRightRadius: Radius.xxl,
    },
    headerContent: {
        paddingHorizontal: Spacing.xl,
        paddingTop: Spacing.xl,
        paddingBottom: Spacing.md,
    },
    headerBadge: {
        alignSelf: 'flex-start',
        backgroundColor: 'rgba(255,255,255,0.2)',
        paddingHorizontal: Spacing.md,
        paddingVertical: Spacing.xxs,
        borderRadius: Radius.xs,
        marginBottom: Spacing.sm,
    },
    headerBadgeText: {
        fontSize: FontSize.xs,
        color: '#FFF',
        fontWeight: FontWeight.bold,
        letterSpacing: 1.5,
    },
    headerTitle: {
        fontSize: 26,
        fontWeight: FontWeight.heavy,
        color: '#FFFFFF',
        fontFamily: SERIF_FONT,
        marginBottom: Spacing.xs,
    },
    monthRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xs,
    },
    monthLabel: {
        fontSize: FontSize.sm,
        color: 'rgba(255,255,255,0.85)',
        fontWeight: FontWeight.medium,
    },

    // Loading / Error
    centered: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        gap: Spacing.md,
        padding: Spacing.xxl,
    },
    loadingText: {
        fontSize: FontSize.sm,
        color: Colors.textSecondary,
        fontWeight: FontWeight.medium,
    },
    errorText: {
        fontSize: FontSize.sm,
        color: Colors.error,
        textAlign: 'center',
        fontWeight: FontWeight.medium,
    },

    // Scroll
    scrollContent: {
        padding: Spacing.xl,
    },

    // Summary grid
    summaryGrid: {
        flexDirection: 'row',
        gap: Spacing.md,
        marginBottom: Spacing.md,
    },
    summaryCard: {
        flex: 1,
        backgroundColor: Colors.surface,
        borderRadius: Radius.xl,
        padding: Spacing.lg,
        borderLeftWidth: 4,
        gap: Spacing.xs,
        ...Shadow.md,
        borderWidth: 1,
        borderColor: 'rgba(0,0,0,0.03)',
    },
    summaryIconWrap: {
        width: 36,
        height: 36,
        borderRadius: 18,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: Spacing.xs,
    },
    summaryLabel: {
        fontSize: 10,
        fontWeight: FontWeight.bold,
        color: Colors.textTertiary,
        letterSpacing: 1,
    },
    summaryValue: {
        fontSize: FontSize.lg,
        fontWeight: FontWeight.heavy,
        color: Colors.text,
    },
    summarySubtext: {
        fontSize: FontSize.xs,
        color: Colors.textTertiary,
    },

    // Section
    section: {
        marginTop: Spacing.xxl,
    },
    sectionTitle: {
        fontSize: FontSize.xl,
        fontWeight: FontWeight.bold,
        color: Colors.primaryDark,
        marginBottom: Spacing.lg,
    },

    // Empty state
    emptyState: {
        alignItems: 'center',
        paddingVertical: Spacing.massive,
        gap: Spacing.md,
    },
    emptyTitle: {
        fontSize: FontSize.lg,
        fontWeight: FontWeight.bold,
        color: Colors.textSecondary,
    },
    emptySubtext: {
        fontSize: FontSize.sm,
        color: Colors.textTertiary,
        textAlign: 'center',
        lineHeight: 20,
    },

    // Commission card
    commissionCard: {
        flexDirection: 'row',
        backgroundColor: Colors.surface,
        borderRadius: Radius.xl,
        overflow: 'hidden',
        marginBottom: Spacing.md,
        ...Shadow.sm,
        borderWidth: 1,
        borderColor: 'rgba(0,0,0,0.03)',
    },
    commissionAccent: {
        width: 4,
    },
    commissionContent: {
        flex: 1,
        padding: Spacing.lg,
        gap: Spacing.sm,
    },
    commissionTitleRow: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: Spacing.sm,
    },
    commissionTitle: {
        flex: 1,
        fontSize: FontSize.md,
        fontWeight: FontWeight.bold,
        color: Colors.text,
    },
    commissionDateRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xxs,
    },
    commissionDate: {
        fontSize: FontSize.xs,
        color: Colors.textTertiary,
        fontWeight: FontWeight.medium,
    },
    commissionAmounts: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: Spacing.xs,
        paddingTop: Spacing.sm,
        borderTopWidth: 1,
        borderTopColor: Colors.borderLight,
    },
    amountItem: {
        flex: 1,
        alignItems: 'center',
        gap: Spacing.xxs,
    },
    amountLabel: {
        fontSize: FontSize.xs,
        color: Colors.textTertiary,
        fontWeight: FontWeight.medium,
    },
    amountValue: {
        fontSize: FontSize.sm,
        fontWeight: FontWeight.bold,
        color: Colors.text,
    },
    amountDivider: {
        width: 1,
        height: 28,
        backgroundColor: Colors.borderLight,
    },
});
