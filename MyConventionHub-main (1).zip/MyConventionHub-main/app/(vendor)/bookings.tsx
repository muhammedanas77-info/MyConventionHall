import React, { useMemo } from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    TouchableOpacity,
    SectionList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { CalendarDays, WifiOff } from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { useVendor } from '@/providers/VendorProvider';
import { formatDateDisplay } from '@/utils/date';
import { formatCurrencyFull } from '@/utils/currency';
import Badge from '@/components/ui/Badge';
import type { ServiceBooking, ServiceBookingStatus } from '@/types';

// ─── Status config ─────────────────────────────────────────────────────────────

type StatusConfig = {
    label: string;
    variant: 'warning' | 'success' | 'neutral' | 'error';
    /** Background color for the left accent stripe on each card */
    accentColor: string;
};

const STATUS_CONFIG: Record<ServiceBookingStatus, StatusConfig> = {
    pending: {
        label: 'Pending',
        variant: 'warning',
        accentColor: Colors.warning,
    },
    confirmed: {
        label: 'Confirmed',
        variant: 'success',
        accentColor: Colors.success,
    },
    completed: {
        label: 'Completed',
        variant: 'neutral',
        accentColor: Colors.textTertiary,
    },
    cancelled: {
        label: 'Cancelled',
        variant: 'error',
        accentColor: Colors.error,
    },
};

/** Display order for status groups */
const STATUS_ORDER: ServiceBookingStatus[] = ['pending', 'confirmed', 'completed', 'cancelled'];

// ─── Booking row ───────────────────────────────────────────────────────────────

interface BookingRowProps {
    booking: ServiceBooking;
    onPress: (id: string) => void;
}

function BookingRow({ booking, onPress }: BookingRowProps) {
    const config = STATUS_CONFIG[booking.status] ?? STATUS_CONFIG.pending;
    const customerName = booking.customer?.full_name ?? 'Unknown Customer';
    const eventDate = formatDateDisplay(booking.event_date);
    const amount = formatCurrencyFull(booking.total_amount);

    // Capitalise event_type for display
    const eventTypeLabel =
        booking.event_type.charAt(0).toUpperCase() + booking.event_type.slice(1);

    return (
        <TouchableOpacity
            activeOpacity={0.75}
            onPress={() => onPress(booking.id)}
            style={styles.rowWrapper}
            accessibilityRole="button"
            accessibilityLabel={`Booking for ${customerName} on ${eventDate}`}
        >
            <View style={styles.row}>
                {/* Left accent stripe */}
                <View style={[styles.rowAccent, { backgroundColor: config.accentColor }]} />

                <View style={styles.rowContent}>
                    {/* Top: customer name + status badge */}
                    <View style={styles.rowHeader}>
                        <Text style={styles.customerName} numberOfLines={1}>
                            {customerName}
                        </Text>
                        <Badge text={config.label} variant={config.variant} size="sm" />
                    </View>

                    {/* Middle: event date + event type */}
                    <View style={styles.rowMeta}>
                        <View style={styles.metaItem}>
                            <CalendarDays size={12} color={Colors.textTertiary} />
                            <Text style={styles.metaText}>{eventDate}</Text>
                        </View>
                        <Text style={styles.metaDot}>·</Text>
                        <Text style={styles.metaText}>{eventTypeLabel}</Text>
                    </View>

                    {/* Bottom: amount */}
                    <Text style={styles.amount}>{amount}</Text>
                </View>
            </View>
        </TouchableOpacity>
    );
}

// ─── Section header ────────────────────────────────────────────────────────────

function SectionHeader({ title, count }: { title: string; count: number }) {
    return (
        <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>{title}</Text>
            <View style={styles.sectionCount}>
                <Text style={styles.sectionCountText}>{count}</Text>
            </View>
        </View>
    );
}

// ─── Empty state ───────────────────────────────────────────────────────────────

function EmptyState() {
    return (
        <View style={styles.emptyContainer}>
            <CalendarDays size={48} color={Colors.textTertiary} />
            <Text style={styles.emptyTitle}>No bookings yet</Text>
            <Text style={styles.emptySubtitle}>
                Your service bookings will appear here once customers start booking.
            </Text>
        </View>
    );
}

// ─── Main screen ───────────────────────────────────────────────────────────────

export default function VendorBookingsScreen() {
    const router = useRouter();
    const { bookings, realtimeStatus } = useVendor();

    const isLivePaused = realtimeStatus !== 'joined';

    /**
     * Group bookings by status in the defined display order.
     * Bookings within each group are already sorted by event_date ASC
     * (VendorProvider keeps them sorted on every Realtime event).
     */
    const sections = useMemo(() => {
        const grouped: Record<ServiceBookingStatus, ServiceBooking[]> = {
            pending: [],
            confirmed: [],
            completed: [],
            cancelled: [],
        };

        for (const booking of bookings) {
            const key = booking.status as ServiceBookingStatus;
            if (grouped[key]) {
                grouped[key].push(booking);
            }
        }

        return STATUS_ORDER
            .filter((status) => grouped[status].length > 0)
            .map((status) => ({
                title: STATUS_CONFIG[status].label,
                status,
                data: grouped[status],
            }));
    }, [bookings]);

    const handleRowPress = (id: string) => {
        router.push(`/(vendor)/booking/${id}` as any);
    };

    return (
        <View style={styles.screen}>
            {/* ── Header ── */}
            <SafeAreaView edges={['top']} style={styles.header}>
                <Text style={styles.title}>Bookings</Text>
            </SafeAreaView>

            {/* ── Live updates paused banner ── */}
            {isLivePaused && (
                <View style={styles.pausedBanner}>
                    <WifiOff size={14} color={Colors.warning} />
                    <Text style={styles.pausedText}>
                        Live updates paused — refreshing every 30 s
                    </Text>
                </View>
            )}

            {/* ── List ── */}
            {bookings.length === 0 ? (
                <EmptyState />
            ) : (
                <SectionList
                    sections={sections}
                    keyExtractor={(item) => item.id}
                    renderItem={({ item }) => (
                        <BookingRow booking={item} onPress={handleRowPress} />
                    )}
                    renderSectionHeader={({ section }) => (
                        <SectionHeader
                            title={section.title}
                            count={section.data.length}
                        />
                    )}
                    contentContainerStyle={styles.listContent}
                    showsVerticalScrollIndicator={false}
                    stickySectionHeadersEnabled={false}
                />
            )}
        </View>
    );
}

// ─── Styles ────────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        backgroundColor: Colors.background,
    },

    // Header
    header: {
        paddingHorizontal: Spacing.xl,
        paddingBottom: Spacing.lg,
        backgroundColor: Colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: Colors.borderLight,
        ...Shadow.sm,
    },
    title: {
        fontSize: FontSize.xxl,
        fontWeight: FontWeight.heavy,
        color: Colors.text,
        paddingTop: Spacing.sm,
    },

    // Paused banner
    pausedBanner: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xs,
        backgroundColor: Colors.warningLight,
        paddingHorizontal: Spacing.xl,
        paddingVertical: Spacing.sm,
        borderBottomWidth: 1,
        borderBottomColor: Colors.warning + '33',
    },
    pausedText: {
        fontSize: FontSize.xs,
        fontWeight: FontWeight.semibold,
        color: Colors.warning,
    },

    // List
    listContent: {
        paddingHorizontal: Spacing.xl,
        paddingTop: Spacing.lg,
        paddingBottom: Spacing.massive,
    },

    // Section header
    sectionHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.sm,
        marginBottom: Spacing.sm,
        marginTop: Spacing.lg,
    },
    sectionTitle: {
        fontSize: FontSize.sm,
        fontWeight: FontWeight.bold,
        color: Colors.textSecondary,
        textTransform: 'uppercase',
        letterSpacing: 0.5,
    },
    sectionCount: {
        backgroundColor: Colors.warmGray,
        borderRadius: Radius.full,
        minWidth: 20,
        height: 20,
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: Spacing.xs,
    },
    sectionCountText: {
        fontSize: FontSize.xs,
        fontWeight: FontWeight.bold,
        color: Colors.textSecondary,
    },

    // Booking row
    rowWrapper: {
        marginBottom: Spacing.sm,
    },
    row: {
        flexDirection: 'row',
        backgroundColor: Colors.surface,
        borderRadius: Radius.lg,
        overflow: 'hidden',
        ...Shadow.sm,
        borderWidth: 1,
        borderColor: Colors.borderLight,
    },
    rowAccent: {
        width: 4,
    },
    rowContent: {
        flex: 1,
        padding: Spacing.lg,
        gap: Spacing.xs,
    },
    rowHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: Spacing.sm,
    },
    customerName: {
        flex: 1,
        fontSize: FontSize.md,
        fontWeight: FontWeight.semibold,
        color: Colors.text,
    },
    rowMeta: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xs,
    },
    metaItem: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xxs,
    },
    metaText: {
        fontSize: FontSize.sm,
        color: Colors.textSecondary,
        fontWeight: FontWeight.medium,
    },
    metaDot: {
        fontSize: FontSize.sm,
        color: Colors.textTertiary,
    },
    amount: {
        fontSize: FontSize.lg,
        fontWeight: FontWeight.bold,
        color: Colors.primaryDark,
        marginTop: Spacing.xxs,
    },

    // Empty state
    emptyContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: Spacing.xxxl,
        gap: Spacing.md,
    },
    emptyTitle: {
        fontSize: FontSize.lg,
        fontWeight: FontWeight.bold,
        color: Colors.text,
    },
    emptySubtitle: {
        fontSize: FontSize.sm,
        color: Colors.textTertiary,
        textAlign: 'center',
        lineHeight: 20,
    },
});
