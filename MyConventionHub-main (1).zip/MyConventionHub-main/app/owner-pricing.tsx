import React, { useState, useMemo, useCallback, useEffect } from 'react';
import {
    View, Text, StyleSheet, ScrollView, TextInput, Alert, Platform,
} from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { ChevronLeft } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { SEASON_SLOT_MULTIPLIERS } from '@/constants/pricing';
import { useAuth } from '@/providers/AuthProvider';
import { supabase } from '@/utils/supabase';
import { formatCurrencyFull } from '@/utils/currency';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import type { SeasonType, SlotType } from '@/types';

const SEASONS: { key: SeasonType; label: string; months: string; color: string; desc: string }[] = [
    { key: 'off_season', label: 'Off Season', months: 'Jun — Sep', color: Colors.success, desc: 'Monsoon months, lower demand' },
    { key: 'shoulder', label: 'Shoulder', months: 'Mar, Oct', color: Colors.warning, desc: 'Moderate demand' },
    { key: 'peak', label: 'Peak Season', months: 'Nov — Feb, Apr — May', color: Colors.error, desc: 'Highest demand' },
];

const SLOTS: { key: SlotType; label: string }[] = [
    { key: 'morning', label: 'Morning' },
    { key: 'evening', label: 'Evening' },
    { key: 'full_day', label: 'Full Day' },
];

export default function OwnerPricingScreen() {
    const router = useRouter();
    const { user } = useAuth();
    const [basePrice, setBasePrice] = useState(0);

    useEffect(() => {
        const fetchHall = async () => {
            if (!user) return;
            const { data } = await supabase
                .from('halls')
                .select('price_per_day')
                .eq('owner_id', user.id)
                .limit(1)
                .single();
            if (data) setBasePrice(data.price_per_day ?? 0);
        };
        fetchHall();
    }, [user]);

    const recommendedPrices = useMemo(() => {
        const prices: Record<string, number> = {};
        SEASONS.forEach(s => {
            SLOTS.forEach(sl => {
                prices[`${s.key}-${sl.key}`] = Math.round(basePrice * SEASON_SLOT_MULTIPLIERS[s.key][sl.key]);
            });
        });
        return prices;
    }, [basePrice]);

    const [prices, setPrices] = useState<Record<string, string>>(() => {
        const initial: Record<string, string> = {};
        Object.entries(recommendedPrices).forEach(([key, val]) => {
            initial[key] = val.toString();
        });
        return initial;
    });

    const handlePriceChange = useCallback((key: string, value: string) => {
        setPrices(prev => ({ ...prev, [key]: value.replace(/\D/g, '') }));
    }, []);

    const handleUseRecommended = useCallback(() => {
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        const reset: Record<string, string> = {};
        Object.entries(recommendedPrices).forEach(([key, val]) => {
            reset[key] = val.toString();
        });
        setPrices(reset);
    }, [recommendedPrices]);

    const handleSave = useCallback(() => {
        if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        Alert.alert('Saved', 'All prices updated successfully');
    }, []);

    return (
        <View style={styles.screen}>
            <Stack.Screen options={{
                title: 'Set Prices',
                headerStyle: { backgroundColor: Colors.background },
                headerTintColor: Colors.primary,
                headerShadowVisible: false,
                headerLeft: () => (
                    <AnimatedPressable onPress={() => router.back()} scaleValue={0.8}>
                        <View style={{ padding: Spacing.sm, marginLeft: -Spacing.sm, marginRight: Spacing.sm }}>
                            <ChevronLeft size={28} color={Colors.primary} />
                        </View>
                    </AnimatedPressable>
                ),
            }} />

            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
                <Text style={styles.description}>
                    Your prices are automatically adjusted by season and time of day. Customise below or use our recommended rates.
                </Text>

                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.seasonCards}>
                    {SEASONS.map(s => (
                        <View key={s.key} style={[styles.seasonCard, { borderTopColor: s.color }]}>
                            <Text style={[styles.seasonLabel, { color: s.color }]}>{s.label}</Text>
                            <Text style={styles.seasonMonths}>{s.months}</Text>
                            <Text style={styles.seasonDesc}>{s.desc}</Text>
                        </View>
                    ))}
                </ScrollView>

                <View style={styles.pricingTable}>
                    <View style={styles.tableHeader}>
                        <View style={styles.tableHeaderCell}><Text style={styles.tableHeaderText}> </Text></View>
                        {SLOTS.map(sl => (
                            <View key={sl.key} style={styles.tableHeaderCell}>
                                <Text style={styles.tableHeaderText}>{sl.label}</Text>
                            </View>
                        ))}
                    </View>

                    {SEASONS.map(s => (
                        <View key={s.key} style={styles.tableRow}>
                            <View style={styles.tableLabelCell}>
                                <Text style={styles.tableLabelText}>{s.label.replace(' Season', '')}</Text>
                            </View>
                            {SLOTS.map(sl => {
                                const key = `${s.key}-${sl.key}`;
                                return (
                                    <View key={key} style={styles.tableInputCell}>
                                        <View style={styles.priceInput}>
                                            <Text style={styles.pricePrefix}>₹</Text>
                                            <TextInput
                                                style={styles.priceField}
                                                value={prices[key]}
                                                onChangeText={(v) => handlePriceChange(key, v)}
                                                keyboardType="number-pad"
                                                placeholder="0"
                                                placeholderTextColor={Colors.textTertiary}
                                            />
                                        </View>
                                    </View>
                                );
                            })}
                        </View>
                    ))}
                </View>

                <Text style={styles.recommendedNote}>
                    Recommended prices based on your base rate of {formatCurrencyFull(basePrice)}/day
                </Text>

                <AnimatedPressable onPress={handleUseRecommended} scaleValue={0.96}>
                    <View style={styles.outlinedButton}>
                        <Text style={styles.outlinedButtonText}>Use Recommended Prices</Text>
                    </View>
                </AnimatedPressable>

                <AnimatedPressable onPress={handleSave} scaleValue={0.96}>
                    <View style={styles.saveButton}>
                        <Text style={styles.saveButtonText}>Save All Prices</Text>
                    </View>
                </AnimatedPressable>
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    scrollContent: { padding: Spacing.xl, paddingBottom: Spacing.massive },
    description: { fontSize: FontSize.sm, color: Colors.textSecondary, lineHeight: 20, marginBottom: Spacing.xl },
    seasonCards: { gap: Spacing.sm, marginBottom: Spacing.xxl, paddingBottom: Spacing.xs },
    seasonCard: {
        width: 160, backgroundColor: Colors.surface, borderRadius: Radius.lg,
        padding: Spacing.lg, borderTopWidth: 3, ...Shadow.sm,
    },
    seasonLabel: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, marginBottom: Spacing.xs },
    seasonMonths: { fontSize: FontSize.xs, color: Colors.textSecondary, fontWeight: FontWeight.semibold, marginBottom: Spacing.xs },
    seasonDesc: { fontSize: FontSize.xs, color: Colors.textTertiary, lineHeight: 16 },
    pricingTable: {
        backgroundColor: Colors.surface, borderRadius: Radius.lg, overflow: 'hidden',
        borderWidth: 1, borderColor: Colors.borderLight, marginBottom: Spacing.lg,
    },
    tableHeader: { flexDirection: 'row', backgroundColor: Colors.cream },
    tableHeaderCell: { flex: 1, padding: Spacing.sm, alignItems: 'center' },
    tableHeaderText: {
        fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textSecondary,
        textTransform: 'uppercase' as const, letterSpacing: 0.5,
    },
    tableRow: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: Colors.borderLight },
    tableLabelCell: { flex: 1, padding: Spacing.sm, justifyContent: 'center' },
    tableLabelText: { fontSize: FontSize.xs, fontWeight: FontWeight.semibold, color: Colors.textSecondary },
    tableInputCell: { flex: 1, padding: Spacing.xs },
    priceInput: {
        flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.ivory,
        borderRadius: Radius.sm, paddingHorizontal: Spacing.xs, borderWidth: 1, borderColor: Colors.borderLight,
    },
    pricePrefix: { fontSize: FontSize.xs, color: Colors.primary, fontWeight: FontWeight.bold },
    priceField: { flex: 1, fontSize: FontSize.xs, color: Colors.text, paddingVertical: Spacing.sm, paddingHorizontal: 2 },
    recommendedNote: { fontSize: FontSize.xs, color: Colors.textTertiary, textAlign: 'center', marginBottom: Spacing.lg },
    outlinedButton: {
        borderWidth: 1.5, borderColor: Colors.primary, borderRadius: Radius.lg,
        paddingVertical: Spacing.md, alignItems: 'center', marginBottom: Spacing.md,
    },
    outlinedButtonText: { color: Colors.primary, fontSize: FontSize.md, fontWeight: FontWeight.bold },
    saveButton: {
        backgroundColor: Colors.primary, paddingVertical: Spacing.lg,
        borderRadius: Radius.lg, alignItems: 'center',
    },
    saveButtonText: { color: '#FFFFFF', fontSize: FontSize.md, fontWeight: FontWeight.bold },
});
