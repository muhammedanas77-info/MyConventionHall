import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
    View, Text, StyleSheet, TextInput, Animated, Platform, KeyboardAvoidingView, ScrollView,
} from 'react-native';
import { useRouter, Stack } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Shield, Lock, ArrowLeft } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import * as LocalAuthentication from 'expo-local-authentication';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { useApp } from '@/providers/AppProvider';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

const SERIF_FONT = Platform.select({ ios: 'Georgia', android: 'serif', web: 'Georgia, serif', default: 'serif' });

export default function AdminLoginScreen() {
    const router = useRouter();
    const { login } = useApp();
    const [email, setEmail] = useState('');
    const [otp, setOtp] = useState('');
    const [step, setStep] = useState<'email' | 'otp'>('email');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isBiometricSupported, setIsBiometricSupported] = useState(false);
    const fadeAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
        (async () => {
            const compatible = await LocalAuthentication.hasHardwareAsync();
            const enrolled = await LocalAuthentication.isEnrolledAsync();
            setIsBiometricSupported(compatible && enrolled);
        })();
    }, []);

    const handleSendOTP = async () => {
        if (!email.trim()) {
            setError('Please enter your admin email');
            return;
        }

        setIsLoading(true);
        setError(null);
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

        const { error } = await supabase.auth.signInWithOtp({
            email: email.trim(),
            options: {
                data: {
                    role: 'admin',
                }
            }
        });

        setIsLoading(false);

        if (error) {
            setError(error.message);
        } else {
            setStep('otp');
        }
    };

    const handleVerifyOTP = async () => {
        if (!otp || otp.length < 6) {
            setError('Please enter a valid verification code');
            return;
        }

        setIsLoading(true);
        setError(null);
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

        try {
            const { data, error } = await supabase.auth.verifyOtp({
                email: email.trim(),
                token: otp.trim(),
                type: 'email',
            });

            if (error) {
                setError(error.message || 'Invalid code. Please try again.');
                setIsLoading(false);
                return;
            }

            if (data?.session?.user) {
                // Fetch profile to verify admin role
                const { data: existingProfile, error: profileError } = await supabase
                    .from('profiles')
                    .select('id, role, full_name')
                    .eq('id', data.session.user.id)
                    .maybeSingle();

                if (profileError || !existingProfile) {
                    await supabase.auth.signOut();
                    setError('No account found. Please contact your administrator.');
                    setIsLoading(false);
                    return;
                }

                if (existingProfile.role !== 'admin') {
                    await supabase.auth.signOut();
                    setError('This email is not authorized for admin access.');
                    setIsLoading(false);
                    return;
                }

                login('admin', existingProfile.full_name || 'Admin');
            }

            setIsLoading(false);
            router.replace('/(admin)/admin-dashboard' as any);
        } catch (err) {
            setError('Verification failed. Please try again.');
            console.error('Admin OTP verify error:', err);
            setIsLoading(false);
        }
    };

    const handleBiometricAuth = async () => {
        try {
            const result = await LocalAuthentication.authenticateAsync({
                promptMessage: 'Authenticate to access Admin Portal',
                fallbackLabel: 'Use Email Instead',
                disableDeviceFallback: false,
            });

            if (result.success) {
                if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                // Biometric success — trust device owner as admin for demo/dev
                login('admin', 'Admin');
                router.replace('/(admin)/admin-dashboard' as any);
            }
        } catch (error) {
            console.error('Biometric Auth Error:', error);
        }
    };

    return (
        <View style={styles.container}>
            <Stack.Screen options={{ headerShown: false }} />
            <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
                <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
                    <SafeAreaView style={styles.safeArea}>
                        <Animated.View style={[styles.main, { opacity: fadeAnim }]}>
                            <View style={styles.topRow}>
                                <AnimatedPressable
                                    onPress={() => router.back()}
                                    style={styles.backButton}
                                    scaleValue={0.9}
                                >
                                    <ArrowLeft size={20} color={Colors.textTertiary} />
                                </AnimatedPressable>

                                <View style={styles.iconCircle}>
                                    <Shield size={32} color={Colors.primary} />
                                </View>
                                <View style={{ width: 40 }} />
                            </View>

                            <Text style={styles.title}>Admin Access</Text>
                            <Text style={styles.subtitle}>Restricted portal for ConventionHub internal management</Text>

                            <View style={styles.form}>
                                {error && (
                                    <View style={styles.errorBox}>
                                        <Text style={styles.errorText}>{error}</Text>
                                    </View>
                                )}

                                {step === 'email' ? (
                                    <>
                                        <View style={styles.inputGroup}>
                                            <Text style={styles.label}>Admin Email</Text>
                                            <TextInput
                                                style={styles.input}
                                                placeholder="admin@conventionhub.com"
                                                placeholderTextColor={Colors.textTertiary}
                                                value={email}
                                                onChangeText={setEmail}
                                                keyboardType="email-address"
                                                autoCapitalize="none"
                                            />
                                        </View>

                                        <AnimatedPressable onPress={handleSendOTP} scaleValue={0.96} disabled={isLoading}>
                                            <View style={[styles.button, !email.trim() && styles.buttonDisabled]}>
                                                <Text style={styles.buttonText}>
                                                    {isLoading ? 'Sending...' : 'Request Access'}
                                                </Text>
                                            </View>
                                        </AnimatedPressable>
                                    </>
                                ) : (
                                    <>
                                        <View style={styles.inputGroup}>
                                            <Text style={styles.label}>Secure Verification Code</Text>
                                            <View style={styles.passwordWrapper}>
                                                <TextInput
                                                    style={[styles.input, { flex: 1 }]}
                                                    placeholder="00000000"
                                                    placeholderTextColor={Colors.textTertiary}
                                                    value={otp}
                                                    onChangeText={setOtp}
                                                    keyboardType="number-pad"
                                                    maxLength={8}
                                                />
                                                <Lock size={20} color={Colors.textTertiary} style={styles.lockIcon} />
                                            </View>
                                        </View>

                                        <AnimatedPressable onPress={handleVerifyOTP} scaleValue={0.96} disabled={isLoading}>
                                            <View style={[styles.button, (!otp) && styles.buttonDisabled]}>
                                                <Text style={styles.buttonText}>
                                                    {isLoading ? 'Verifying...' : 'Authorize Access'}
                                                </Text>
                                            </View>
                                        </AnimatedPressable>
                                        <AnimatedPressable onPress={() => setStep('email')} scaleValue={0.98} style={{ alignItems: 'center', marginTop: Spacing.md }}>
                                            <Text style={styles.wrongEmailText}>Change Email?</Text>
                                        </AnimatedPressable>
                                    </>
                                )}

                                {isBiometricSupported && (
                                    <>
                                        <Text style={styles.orText}>OR</Text>
                                        <AnimatedPressable onPress={handleBiometricAuth} scaleValue={0.96}>
                                            <View style={styles.bioButton}>
                                                <Text style={styles.bioButtonText}>Use Face ID / Touch ID</Text>
                                            </View>
                                        </AnimatedPressable>
                                    </>
                                )}
                            </View>

                            <View style={styles.securityNote}>
                                <Text style={styles.securityNoteText}>
                                    Access to this portal is logged. Unauthorized entry is prohibited.
                                </Text>
                            </View>
                        </Animated.View>
                    </SafeAreaView>
                </ScrollView>
            </KeyboardAvoidingView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#FFFFFF' },
    flex: { flex: 1 },
    scrollContent: { flexGrow: 1 },
    safeArea: { flex: 1, paddingHorizontal: Spacing.xl },
    main: { flex: 1, paddingTop: Spacing.md, alignItems: 'center' },
    topRow: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        width: '100%',
        marginBottom: Spacing.xl,
    },
    backButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: Colors.ivory,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: Colors.borderLight,
    },
    iconCircle: {
        width: 80, height: 80, borderRadius: 40,
        backgroundColor: Colors.primaryFaded, justifyContent: 'center', alignItems: 'center',
    },
    title: {
        fontSize: 32, fontWeight: FontWeight.bold,
        color: Colors.text, fontFamily: SERIF_FONT, marginBottom: Spacing.sm,
    },
    subtitle: {
        fontSize: FontSize.md, color: Colors.textTertiary,
        textAlign: 'center', lineHeight: 22,
        marginBottom: Spacing.massive, maxWidth: '80%'
    },
    form: { width: '100%', gap: Spacing.xl },
    inputGroup: { gap: Spacing.xs },
    label: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textSecondary },
    input: {
        backgroundColor: Colors.background, borderRadius: Radius.lg,
        paddingHorizontal: Spacing.lg, paddingVertical: Spacing.lg,
        fontSize: FontSize.md, color: Colors.text, borderWidth: 1, borderColor: Colors.borderLight,
    },
    passwordWrapper: { flexDirection: 'row', alignItems: 'center' },
    lockIcon: { position: 'absolute', right: Spacing.lg },
    button: {
        backgroundColor: Colors.primary, paddingVertical: Spacing.lg,
        borderRadius: Radius.lg, alignItems: 'center', marginTop: Spacing.lg,
        ...Shadow.md,
    },
    buttonDisabled: { opacity: 0.5 },
    buttonText: { color: '#FFFFFF', fontSize: FontSize.lg, fontWeight: FontWeight.bold },
    orText: { textAlign: 'center', color: Colors.textTertiary, fontSize: FontSize.sm, fontWeight: FontWeight.bold, marginVertical: Spacing.sm },
    bioButton: {
        backgroundColor: Colors.surface, paddingVertical: Spacing.lg,
        borderRadius: Radius.lg, alignItems: 'center', borderWidth: 1, borderColor: Colors.primaryDark,
        ...Shadow.sm
    },
    bioButtonText: { color: Colors.primaryDark, fontSize: FontSize.lg, fontWeight: FontWeight.bold },
    securityNote: { marginTop: Spacing.massive, paddingHorizontal: Spacing.xl },
    securityNoteText: { fontSize: FontSize.xs, color: Colors.textTertiary, textAlign: 'center', lineHeight: 18, opacity: 0.7 },
    wrongEmailText: { fontSize: FontSize.sm, color: Colors.primary, fontWeight: FontWeight.semibold },
    errorBox: { backgroundColor: Colors.errorLight, padding: Spacing.md, borderRadius: Radius.md, borderWidth: 1, borderColor: 'rgba(197, 48, 48, 0.2)', marginBottom: Spacing.md },
    errorText: { color: Colors.error, fontSize: FontSize.sm, fontWeight: FontWeight.medium, textAlign: 'center' },
});
