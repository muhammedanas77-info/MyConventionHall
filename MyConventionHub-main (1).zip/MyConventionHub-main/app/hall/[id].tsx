import React, { useMemo, useRef, useCallback, useState } from 'react';
import {
    View, Text, StyleSheet, Animated, Pressable, Platform, Alert,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import { ArrowLeft, Heart, MapPin, Users, BadgeCheck, Star, Zap, ImageIcon } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import ImageViewing from 'react-native-image-viewing';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { useApp } from '@/providers/AppProvider';
import { useHall, useHallReviews } from '@/hooks/queries/useHalls';
import { formatCurrency, formatCurrencyFull } from '@/utils/currency';
import { getSeasonForDate } from '@/constants/seasons';
import { SEASON_LABELS, SLOT_LABELS } from '@/constants/pricing';
import { getSlotPrice } from '@/utils/pricing';
import Badge from '@/components/ui/Badge';
import RatingStars from '@/components/ui/RatingStars';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import ErrorState from '@/components/ui/ErrorState';
import ScreenLoader from '@/components/ui/ScreenLoader';
import type { SeasonType, SlotType } from '@/types';

export default function HallDetailScreen() {
    const { id } = useLocalSearchParams<{ id: string }>();
    const router = useRouter();
    const { toggleSaveHall, isHallSaved } = useApp();
    const scrollY = useRef(new Animated.Value(0)).current;
    const heartScale = useRef(new Animated.Value(1)).current;
    const [isGalleryVisible, setIsGalleryVisible] = useState(false);

    const { data: hall, isLoading, isError, refetch } = useHall(id);
    const { data: reviews = [] } = useHallReviews(id);

    const currentSeason = useMemo(() => getSeasonForDate(new Date()), []);
    const saved = hall ? isHallSaved(hall.id) : false;

    const handleSave = useCallback(() => {
        if (!hall) return;
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        Animated.sequence([
            Animated.spring(heartScale, { toValue: 1.4, useNativeDriver: true, speed: 50 }),
            Animated.spring(heartScale, { toValue: 1, useNativeDriver: true, speed: 30, bounciness: 10 }),
        ]).start();
        toggleSaveHall(hall.id);
    }, [hall, toggleSaveHall, heartScale]);

    const handleBookNow = useCallback(() => {
        if (!hall) return;
        router.push(`/booking/${hall.id}` as any);
    }, [hall, router]);

    const imageTranslate = scrollY.interpolate({
        inputRange: [-100, 0, 300], outputRange: [50, 0, -100], extrapolate: 'clamp',
    });
    const imageScale = scrollY.interpolate({
        inputRange: [-200, 0], outputRange: [1.5, 1], extrapolate: 'clamp',
    });

    if (isLoading) {
        return <ScreenLoader message="Loading venue..." />;
    }

    if (isError || !hall) {
        return (
            <View style={styles.errorContainer}>
                <ErrorState
                    title="Venue not found"
                    subtitle="This venue may no longer be available."
                    onRetry={refetch}
                    retryLabel="Try Again"
                />
                <AnimatedPressable onPress={() => router.back()}>
                    <Text style={styles.errorLink}>Go back</Text>
                </AnimatedPressable>
            </View>
        );
    }

    const getPriceForSlot = (season: SeasonType, slot: SlotType) => getSlotPrice(hall.price_per_day, season, slot);

    return (
        <View style={styles.screen}>
            <Stack.Screen options={{ headerShown: false }} />

            <SafeAreaView edges={['top']} style={styles.topBar}>
                <AnimatedPressable onPress={() => router.back()} scaleValue={0.85}>
                    <View style={styles.topBarButton}>
                        <ArrowLeft size={20} color="#FFFFFF" />
                    </View>
                </AnimatedPressable>
                <AnimatedPressable onPress={handleSave} scaleValue={0.85}>
                    <Animated.View style={[styles.topBarButton, { transform: [{ scale: heartScale }] }]}>
                        <Heart size={18} color={saved ? Colors.primary : '#FFFFFF'} fill={saved ? Colors.primary : 'transparent'} />
                    </Animated.View>
                </AnimatedPressable>
            </SafeAreaView>

            <Animated.ScrollView
                showsVerticalScrollIndicator={false}
                onScroll={Animated.event(
                    [{ nativeEvent: { contentOffset: { y: scrollY } } }],
                    { useNativeDriver: true }
                )}
                scrollEventThrottle={16}
            >
                <Pressable onPress={() => setIsGalleryVisible(true)}>
                    <Animated.View style={[styles.imageContainer, { transform: [{ translateY: imageTranslate }, { scale: imageScale }] }]}>
                        <Image source={{ uri: hall.photos[0] }} style={styles.heroImage} contentFit="cover" transition={300} />
                        <LinearGradient colors={['transparent', 'rgba(0,0,0,0.6)']} style={styles.imageGradient} />
                        {hall.photos.length > 1 && (
                            <View style={styles.photoCountBadge}>
                                <ImageIcon size={14} color="#FFFFFF" />
                                <Text style={styles.photoCountText}>1/{hall.photos.length}</Text>
                            </View>
                        )}
                    </Animated.View>
                </Pressable>

                <View style={styles.contentContainer}>
                    <View style={styles.headerSection}>
                        <View style={styles.badgeRow}>
                            {hall.is_featured && <Badge text="Featured" variant="gold" />}
                            {hall.is_verified && <Badge text="Verified" variant="success" icon={<BadgeCheck size={12} color={Colors.verified} />} />}
                            <Badge text={SEASON_LABELS[currentSeason]} variant="primary" />
                        </View>
                        <Text style={styles.hallName}>{hall.name}</Text>
                        <View style={styles.locationRow}>
                            <MapPin size={15} color={Colors.textTertiary} />
                            <Text style={styles.locationText}>{hall.address}</Text>
                        </View>
                        <View style={styles.quickStats}>
                            <View style={styles.statItem}>
                                <Star size={18} color={Colors.gold} fill={Colors.gold} />
                                <Text style={styles.statValue}>{hall.rating}</Text>
                                <Text style={styles.statLabel}>{hall.total_reviews} reviews</Text>
                            </View>
                            <View style={styles.statDivider} />
                            <View style={styles.statItem}>
                                <Users size={18} color={Colors.primary} />
                                <Text style={styles.statValue}>{hall.capacity_min}-{hall.capacity_max}</Text>
                                <Text style={styles.statLabel}>guests</Text>
                            </View>
                            <View style={styles.statDivider} />
                            <View style={styles.statItem}>
                                <Text style={styles.statValue}>{formatCurrency(hall.price_per_day)}</Text>
                                <Text style={styles.statLabel}>base/day</Text>
                            </View>
                        </View>
                    </View>

                    <View style={styles.section}>
                        <Text style={styles.sectionTitle}>About</Text>
                        <Text style={styles.description}>{hall.description}</Text>
                    </View>

                    <View style={styles.section}>
                        <Text style={styles.sectionTitle}>Amenities</Text>
                        <View style={styles.amenitiesGrid}>
                            {hall.amenities.map((amenity) => (
                                <View key={amenity} style={styles.amenityItem}>
                                    <Zap size={14} color={Colors.primary} />
                                    <Text style={styles.amenityText}>{amenity}</Text>
                                </View>
                            ))}
                        </View>
                    </View>

                    <View style={styles.section}>
                        <Text style={styles.sectionTitle}>Pricing</Text>
                        <View style={styles.pricingTable}>
                            <View style={styles.pricingHeaderRow}>
                                <View style={styles.pricingHeaderCell}><Text style={styles.pricingHeaderText}> </Text></View>
                                {(['morning', 'evening', 'full_day'] as SlotType[]).map((slot) => (
                                    <View key={slot} style={styles.pricingHeaderCell}>
                                        <Text style={styles.pricingHeaderText}>{SLOT_LABELS[slot]}</Text>
                                    </View>
                                ))}
                            </View>
                            {(['off_season', 'shoulder', 'peak'] as SeasonType[]).map((season) => (
                                <View key={season} style={styles.pricingRow}>
                                    <View style={styles.pricingLabelCell}>
                                        <Text style={styles.pricingLabelText}>{SEASON_LABELS[season].replace(' Season', '')}</Text>
                                    </View>
                                    {(['morning', 'evening', 'full_day'] as SlotType[]).map((slot) => {
                                        const isActive = season === currentSeason;
                                        return (
                                            <View key={`${season}-${slot}`} style={[styles.pricingCell, isActive && styles.pricingCellHighlight]}>
                                                <Text style={[styles.pricingCellText, isActive && styles.pricingCellTextHighlight]}>
                                                    {formatCurrency(getPriceForSlot(season, slot))}
                                                </Text>
                                            </View>
                                        );
                                    })}
                                </View>
                            ))}
                        </View>
                    </View>

                    <View style={styles.section}>
                        <Text style={styles.sectionTitle}>Reviews & Ratings</Text>
                        <View style={styles.ratingOverviewCard}>
                            <View style={styles.ratingLeft}>
                                <Text style={styles.ratingBigNumber}>{hall.rating}</Text>
                                <RatingStars rating={hall.rating} showCount={false} size={16} />
                                <Text style={styles.ratingBigCount}>{hall.total_reviews} reviews</Text>
                            </View>
                            <View style={styles.ratingRight}>
                                {[5, 4, 3, 2, 1].map((star) => {
                                    const count = reviews.filter(r => Math.round(r.rating) === star).length;
                                    const pct = reviews.length > 0 ? (count / reviews.length) * 100 : 0;
                                    return (
                                        <View key={star} style={styles.ratingBarRow}>
                                            <Text style={styles.ratingBarLabel}>{star}</Text>
                                            <Star size={10} color={Colors.gold} fill={Colors.gold} />
                                            <View style={styles.ratingBarTrack}>
                                                <View style={[styles.ratingBarFill, { width: `${pct}%` as any }]} />
                                            </View>
                                            <Text style={styles.ratingBarCount}>{count}</Text>
                                        </View>
                                    );
                                })}
                            </View>
                        </View>
                        {reviews.map((review) => (
                            <View key={review.id} style={styles.reviewCard}>
                                <View style={styles.reviewHeader}>
                                    <View style={styles.reviewAvatar}>
                                        <Text style={styles.reviewAvatarText}>{review.profile?.full_name?.charAt(0) ?? 'U'}</Text>
                                    </View>
                                    <View style={styles.reviewMeta}>
                                        <Text style={styles.reviewName}>{review.profile?.full_name ?? 'User'}</Text>
                                        <RatingStars rating={review.rating} showCount={false} size={12} />
                                    </View>
                                </View>
                                <Text style={styles.reviewComment}>{review.comment}</Text>
                            </View>
                        ))}
                    </View>
                    <View style={{ height: 120 }} />
                </View>
            </Animated.ScrollView>

            <View style={styles.bookingBar}>
                <View style={styles.bookingBarContent}>
                    <View>
                        <Text style={styles.bookingBarPrice}>{formatCurrencyFull(hall.price_per_day)}</Text>
                        <Text style={styles.bookingBarLabel}>base price / day</Text>
                    </View>
                    <AnimatedPressable
                        onPress={handleBookNow}
                        scaleValue={0.95}
                    >
                        <LinearGradient colors={[Colors.primary, Colors.primaryDark]} style={styles.bookButton} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
                            <Text style={styles.bookButtonText}>Book Now</Text>
                        </LinearGradient>
                    </AnimatedPressable>
                </View>
            </View>

            <ImageViewing
                images={hall.photos.map(uri => ({ uri }))}
                imageIndex={0}
                visible={isGalleryVisible}
                onRequestClose={() => setIsGalleryVisible(false)}
                animationType="fade"
                swipeToCloseEnabled={true}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    topBar: {
        position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10,
        flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
        paddingHorizontal: Spacing.lg, paddingBottom: Spacing.sm,
    },
    topBarButton: {
        width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.35)',
        justifyContent: 'center', alignItems: 'center',
    },
    imageContainer: { height: 360, overflow: 'hidden' },
    heroImage: { width: '100%', height: '100%' },
    imageGradient: { ...StyleSheet.absoluteFill, top: '50%' },
    photoCountBadge: {
        position: 'absolute', bottom: 40, right: Spacing.xl,
        backgroundColor: 'rgba(0,0,0,0.5)', flexDirection: 'row', alignItems: 'center',
        paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: Radius.full, gap: Spacing.xs,
    },
    photoCountText: { color: '#FFFFFF', fontSize: FontSize.sm, fontWeight: FontWeight.bold },
    contentContainer: {
        backgroundColor: Colors.background, borderTopLeftRadius: Radius.xxl,
        borderTopRightRadius: Radius.xxl, marginTop: -24, paddingTop: Spacing.xxl,
    },
    headerSection: { paddingHorizontal: Spacing.xl, gap: Spacing.sm },
    badgeRow: { flexDirection: 'row', gap: Spacing.sm, flexWrap: 'wrap' },
    hallName: { fontSize: FontSize.xxl, fontWeight: FontWeight.heavy, color: Colors.text, letterSpacing: -0.3 },
    locationRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
    locationText: { fontSize: FontSize.sm, color: Colors.textTertiary, flex: 1 },
    quickStats: {
        flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.surface,
        borderRadius: Radius.xl, padding: Spacing.lg, marginTop: Spacing.sm, ...Shadow.sm,
    },
    statItem: { flex: 1, alignItems: 'center', gap: Spacing.xxs },
    statValue: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text },
    statLabel: { fontSize: FontSize.xs, color: Colors.textTertiary },
    statDivider: { width: 1, height: 36, backgroundColor: Colors.border },
    section: { paddingHorizontal: Spacing.xl, paddingTop: Spacing.xxl },
    sectionTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: Spacing.sm },
    description: { fontSize: FontSize.md, color: Colors.textSecondary, lineHeight: 24 },
    amenitiesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
    amenityItem: {
        flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, backgroundColor: Colors.surface,
        paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderRadius: Radius.md,
        borderWidth: 1, borderColor: Colors.borderLight,
    },
    amenityText: { fontSize: FontSize.sm, color: Colors.text, fontWeight: FontWeight.medium },
    pricingTable: {
        backgroundColor: Colors.surface, borderRadius: Radius.lg, overflow: 'hidden',
        borderWidth: 1, borderColor: Colors.borderLight,
    },
    pricingHeaderRow: { flexDirection: 'row', backgroundColor: Colors.cream },
    pricingHeaderCell: { flex: 1, padding: Spacing.sm, alignItems: 'center' },
    pricingHeaderText: {
        fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textSecondary,
        textTransform: 'uppercase' as const, letterSpacing: 0.5,
    },
    pricingRow: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: Colors.borderLight },
    pricingLabelCell: { flex: 1, padding: Spacing.sm, justifyContent: 'center' },
    pricingLabelText: { fontSize: FontSize.xs, fontWeight: FontWeight.semibold, color: Colors.textSecondary },
    pricingCell: { flex: 1, padding: Spacing.sm, alignItems: 'center', justifyContent: 'center' },
    pricingCellHighlight: { backgroundColor: Colors.primaryFaded },
    pricingCellText: { fontSize: FontSize.xs, fontWeight: FontWeight.semibold, color: Colors.text },
    pricingCellTextHighlight: { color: Colors.primary, fontWeight: FontWeight.bold },
    ratingOverviewCard: {
        flexDirection: 'row', backgroundColor: Colors.surface, borderRadius: Radius.xl,
        padding: Spacing.xl, marginBottom: Spacing.lg, ...Shadow.md,
        borderWidth: 1, borderColor: 'rgba(0,0,0,0.03)', gap: Spacing.xl,
    },
    ratingLeft: { alignItems: 'center', justifyContent: 'center', gap: Spacing.xs, paddingRight: Spacing.lg, borderRightWidth: 1, borderRightColor: Colors.borderLight },
    ratingBigNumber: { fontSize: 40, fontWeight: FontWeight.heavy, color: Colors.text },
    ratingBigCount: { fontSize: FontSize.xs, color: Colors.textTertiary },
    ratingRight: { flex: 1, justifyContent: 'center', gap: Spacing.xs },
    ratingBarRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
    ratingBarLabel: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textSecondary, width: 12, textAlign: 'center' },
    ratingBarTrack: { flex: 1, height: 6, backgroundColor: Colors.cream, borderRadius: 3, overflow: 'hidden' },
    ratingBarFill: { height: '100%', backgroundColor: Colors.gold, borderRadius: 3 },
    ratingBarCount: { fontSize: FontSize.xs, color: Colors.textTertiary, width: 16, textAlign: 'right' },
    reviewCard: {
        backgroundColor: Colors.surface, borderRadius: Radius.lg, padding: Spacing.lg,
        marginBottom: Spacing.md, ...Shadow.sm, borderWidth: 1, borderColor: 'rgba(0,0,0,0.03)',
    },
    reviewHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, marginBottom: Spacing.sm },
    reviewAvatar: {
        width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.primaryFaded2,
        justifyContent: 'center', alignItems: 'center',
    },
    reviewAvatarText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.primary },
    reviewMeta: { flex: 1, gap: Spacing.xxs },
    reviewName: { fontSize: FontSize.md, fontWeight: FontWeight.semibold, color: Colors.text },
    reviewComment: { fontSize: FontSize.sm, color: Colors.textSecondary, lineHeight: 20 },
    bookingBar: {
        position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: Colors.surface,
        borderTopWidth: 1, borderTopColor: Colors.borderLight,
        paddingBottom: Platform.OS === 'ios' ? 34 : Spacing.lg,
        paddingTop: Spacing.md, paddingHorizontal: Spacing.xl, ...Shadow.lg,
    },
    bookingBarContent: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
    bookingBarPrice: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text },
    bookingBarLabel: { fontSize: FontSize.xs, color: Colors.textTertiary },
    bookButton: { paddingHorizontal: Spacing.xxl, paddingVertical: Spacing.md, borderRadius: Radius.lg },
    bookButtonText: { color: '#FFFFFF', fontSize: FontSize.md, fontWeight: FontWeight.bold },
    errorContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.background, gap: Spacing.md },
    errorText: { fontSize: FontSize.lg, color: Colors.text, fontWeight: FontWeight.semibold },
    errorLink: { fontSize: FontSize.md, color: Colors.primary, fontWeight: FontWeight.semibold },
});
