import React, { useRef, useEffect, useState } from 'react';
import {
    View, Text, StyleSheet, TextInput, Animated, Platform, KeyboardAvoidingView, ScrollView,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, Mail } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { useApp } from '@/providers/AppProvider';
import { supabase } from '@/utils/supabase';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

const SERIF_FONT = Platform.select({ ios: 'Georgia', android: 'serif', web: 'Georgia, serif', default: 'serif' });
const RESEND_COOLDOWN = 60;

export default function CustomerLoginScreen() {
    const router = useRouter();
    const { redirect } = useLocalSearchParams<{ redirect?: string }>();
    const { login } = useApp();
    const [email, setEmail] = useState('');
    const [otp, setOtp] = useState('');
    const [step, setStep] = useState<'email' | 'otp'>('email');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [resendCooldown, setResendCooldown] = useState(0);

    const fadeAnim = useRef(new Animated.Value(0)).current;
    const cooldownRef = useRef<ReturnType<typeof setInterval> | null>(null);

    useEffect(() => {
        Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
        return () => { if (cooldownRef.current) clearInterval(cooldownRef.current); };
    }, [fadeAnim]);

    const startCooldown = () => {
        setResendCooldown(RESEND_COOLDOWN);
        cooldownRef.current = setInterval(() => {
            setResendCooldown((prev) => {
                if (prev <= 1) {
                    clearInterval(cooldownRef.current!);
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);
    };

    const handleSendOTP = async () => {
        const trimmedEmail = email.trim().toLowerCase();
        if (!trimmedEmail || !trimmedEmail.includes('@')) {
            setError('Please enter a valid email address');
            return;
        }
        
        setIsLoading(true);
        setError(null);
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

        try {
            const { error: otpError } = await supabase.auth.signInWithOtp({
                email: trimmedEmail,
                options: {
                    data: {
                        role: 'customer',
                    }
                }
            });

            if (otpError) {
                setError(otpError.message || 'Failed to send OTP. Please try again.');
                setIsLoading(false);
                return;
            }

            setStep('otp');
            startCooldown();
        } catch (err) {
            setError('Network error. Please try again.');
            console.error('OTP send error:', err);
        } finally {
            setIsLoading(false);
        }
    };

    const handleResendOTP = () => {
        if (resendCooldown > 0) return;
        handleSendOTP();
    };

    const handleVerifyOTP = async () => {
        if (!otp || otp.length < 6) {
            setError('Please enter the 6-digit code');
            return;
        }

        setIsLoading(true);
        setError(null);
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

        try {
            const { data, error: verifyError } = await supabase.auth.verifyOtp({
                email: email.trim().toLowerCase(),
                token: otp.trim(),
                type: 'email',
            });

            if (verifyError) {
                setError(verifyError.message || 'Invalid code. Please try again.');
                setIsLoading(false);
                return;
            }

            if (data?.session?.user) {
                const displayName = email.trim().toLowerCase().split('@')[0];
                const userId = data.session.user.id;
                const userEmail = email.trim().toLowerCase();

                // Fetch existing profile
                const { data: existing } = await supabase
                    .from('profiles')
                    .select('id, full_name, role')
                    .eq('id', userId)
                    .maybeSingle();

                if (!existing) {
                    // New user — create profile
                    await supabase.from('profiles').insert([{
                        id: userId,
                        role: 'customer',
                        full_name: displayName,
                        email: userEmail,
                    }]);
                } else if (existing.role !== 'customer') {
                    // Existing profile has a stale role — update to customer so
                    // the customer tabs and booking flow work without redirecting.
                    await supabase
                        .from('profiles')
                        .update({ role: 'customer' })
                        .eq('id', userId);
                }

                login('customer', existing?.full_name || displayName);
            }

            setIsLoading(false);
            const resolvedRedirect = redirect ? decodeURIComponent(redirect) : '/(tabs)/discover';
            router.replace((resolvedRedirect || '/(tabs)/discover') as any);
        } catch (err) {
            console.error('OTP verify error:', err);
            setError('Verification failed. Please try again.');
            setIsLoading(false);
        }
    };

    return (
        <View style={styles.container}>
            <Stack.Screen options={{ headerShown: false }} />
            <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
                <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
                    <SafeAreaView style={styles.safeArea}>
                        <Animated.View style={[styles.main, { opacity: fadeAnim }]}>
                            <AnimatedPressable
                                onPress={step === 'otp' ? () => { setStep('email'); setOtp(''); setError(null); } : () => router.back()}
                                style={styles.backButton}
                                scaleValue={0.9}
                            >
                                <ArrowLeft size={24} color={Colors.text} />
                            </AnimatedPressable>

                            {step === 'email' ? (
                                <>
                                    <View style={styles.header}>
                                        <Text style={styles.brandTitle}>ConventionHub</Text>
                                        <Text style={styles.welcomeTitle}>Welcome Back</Text>
                                        <Text style={styles.subtitle}>Sign in or create an account to book venues</Text>
                                    </View>

                                    <View style={styles.form}>
                                        {error && (
                                            <View style={styles.errorBox}>
                                                <Text style={styles.errorText}>{error}</Text>
                                            </View>
                                        )}

                                        <View style={styles.inputGroup}>
                                            <Text style={styles.label}>Email Address</Text>
                                            <TextInput
                                                style={styles.input}
                                                placeholder="name@example.com"
                                                placeholderTextColor={Colors.textTertiary}
                                                value={email}
                                                onChangeText={(t) => { setEmail(t); setError(null); }}
                                                keyboardType="email-address"
                                                autoCapitalize="none"
                                                autoComplete="email"
                                                autoFocus
                                            />
                                            <Text style={styles.helperText}>
                                                We&apos;ll send a 6-digit code to this email.
                                            </Text>
                                        </View>

                                        <AnimatedPressable onPress={handleSendOTP} scaleValue={0.96} disabled={isLoading}>
                                            <View style={[styles.primaryButton, isLoading && styles.buttonDisabled]}>
                                                <Text style={styles.primaryButtonText}>
                                                    {isLoading ? 'Sending Code...' : 'Continue'}
                                                </Text>
                                            </View>
                                        </AnimatedPressable>

                                        <Text style={styles.disclaimer}>
                                            By continuing, you agree to our Terms of Service and Privacy Policy.
                                        </Text>
                                    </View>
                                </>
                            ) : (
                                <>
                                    <View style={styles.header}>
                                        <View style={styles.otpIconWrap}>
                                            <Mail size={32} color={Colors.primary} />
                                        </View>
                                        <Text style={styles.welcomeTitle}>Check your email</Text>
                                        <Text style={styles.subtitle}>
                                            We sent a 6-digit code to{'\n'}
                                            <Text style={styles.emailHighlight}>{email}</Text>
                                        </Text>
                                    </View>

                                    <View style={styles.form}>
                                        {error && (
                                            <View style={styles.errorBox}>
                                                <Text style={styles.errorText}>{error}</Text>
                                            </View>
                                        )}

                                        <View style={styles.inputGroup}>
                                            <Text style={styles.label}>Verification Code</Text>
                                            <TextInput
                                                style={[styles.input, styles.otpInput]}
                                                placeholder="000000"
                                                placeholderTextColor={Colors.textTertiary}
                                                value={otp}
                                                onChangeText={(t) => { setOtp(t.replace(/\D/g, '')); setError(null); }}
                                                keyboardType="number-pad"
                                                maxLength={6}
                                                autoFocus
                                            />
                                        </View>

                                        <AnimatedPressable onPress={handleVerifyOTP} scaleValue={0.96} disabled={isLoading}>
                                            <View style={[styles.primaryButton, isLoading && styles.buttonDisabled]}>
                                                <Text style={styles.primaryButtonText}>
                                                    {isLoading ? 'Verifying...' : 'Verify & Sign In'}
                                                </Text>
                                            </View>
                                        </AnimatedPressable>

                                        <View style={styles.resendRow}>
                                            <Text style={styles.resendLabel}>Didn&apos;t receive the code?</Text>
                                            <AnimatedPressable
                                                onPress={handleResendOTP}
                                                scaleValue={0.96}
                                                disabled={resendCooldown > 0 || isLoading}
                                            >
                                                <Text style={[styles.resendLink, resendCooldown > 0 && styles.resendDisabled]}>
                                                    {resendCooldown > 0 ? `Resend in ${resendCooldown}s` : 'Resend Code'}
                                                </Text>
                                            </AnimatedPressable>
                                        </View>
                                    </View>
                                </>
                            )}
                        </Animated.View>
                    </SafeAreaView>
                </ScrollView>
            </KeyboardAvoidingView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#FFFFFF' },
    flex: { flex: 1 },
    scrollContent: { flexGrow: 1 },
    safeArea: { flex: 1, paddingHorizontal: Spacing.xl },
    main: { flex: 1, paddingTop: Spacing.md },
    backButton: {
        width: 40, height: 40, borderRadius: 20,
        backgroundColor: Colors.ivory, justifyContent: 'center', alignItems: 'center',
        marginBottom: Spacing.xl, borderWidth: 1, borderColor: Colors.borderLight,
    },
    header: { marginBottom: Spacing.massive },
    brandTitle: {
        fontSize: 12, fontWeight: FontWeight.bold, color: Colors.primary,
        letterSpacing: 3, textTransform: 'uppercase', marginBottom: Spacing.md,
    },
    otpIconWrap: {
        width: 64, height: 64, borderRadius: 32,
        backgroundColor: Colors.primaryFaded, justifyContent: 'center', alignItems: 'center',
        marginBottom: Spacing.lg,
    },
    welcomeTitle: {
        fontSize: 36, fontWeight: FontWeight.bold, color: Colors.text,
        fontFamily: SERIF_FONT, marginBottom: Spacing.xs, letterSpacing: -0.5,
    },
    subtitle: { fontSize: FontSize.md, color: Colors.textTertiary, lineHeight: 22 },
    emailHighlight: { color: Colors.text, fontWeight: FontWeight.semibold },
    form: { gap: Spacing.lg },
    inputGroup: { gap: Spacing.xs },
    label: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textSecondary },
    input: {
        backgroundColor: Colors.ivory, borderRadius: Radius.lg,
        paddingHorizontal: Spacing.lg, paddingVertical: Spacing.lg,
        fontSize: FontSize.md, color: Colors.text,
        borderWidth: 1, borderColor: Colors.borderLight,
    },
    otpInput: {
        fontSize: 28, fontWeight: FontWeight.bold, letterSpacing: 8,
        textAlign: 'center', paddingVertical: Spacing.xl,
    },
    primaryButton: {
        backgroundColor: Colors.primary, paddingVertical: Spacing.lg,
        borderRadius: Radius.lg, alignItems: 'center', marginTop: Spacing.sm, ...Shadow.md,
    },
    buttonDisabled: { opacity: 0.65 },
    primaryButtonText: { color: '#FFFFFF', fontSize: FontSize.lg, fontWeight: FontWeight.bold },
    dividerRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, marginVertical: Spacing.md },
    dividerLine: { flex: 1, height: 1, backgroundColor: Colors.borderLight },
    dividerText: { fontSize: FontSize.xs, color: Colors.textTertiary, fontWeight: FontWeight.bold, letterSpacing: 1 },
    guestButton: {
        paddingVertical: Spacing.lg, borderRadius: Radius.lg, alignItems: 'center',
        borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.surface,
    },
    guestButtonText: { color: Colors.textSecondary, fontSize: FontSize.md, fontWeight: FontWeight.bold },
    resendRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: Spacing.xs, marginTop: Spacing.xs },
    resendLabel: { fontSize: FontSize.sm, color: Colors.textTertiary },
    resendLink: { fontSize: FontSize.sm, color: Colors.primary, fontWeight: FontWeight.bold },
    resendDisabled: { color: Colors.textTertiary },
    disclaimer: {
        fontSize: FontSize.xs, color: Colors.textTertiary, textAlign: 'center',
        lineHeight: 16, marginTop: Spacing.xl, paddingHorizontal: Spacing.lg,
    },
    helperText: { fontSize: FontSize.xs, color: Colors.textTertiary, marginTop: Spacing.xxs },
    errorBox: { backgroundColor: Colors.errorLight, padding: Spacing.md, borderRadius: Radius.md, borderWidth: 1, borderColor: 'rgba(197, 48, 48, 0.2)' },
    errorText: { color: Colors.error, fontSize: FontSize.sm, fontWeight: FontWeight.medium },
});
