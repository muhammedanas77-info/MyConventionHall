import React, { useRef, useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    Animated,
    Platform,
    ActivityIndicator,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
    Building2,
    Flower2,
    Music,
    Camera,
    UtensilsCrossed,
    Sparkles,
    Palette,
    MoreHorizontal,
    CalendarCheck,
    LayoutList,
    DollarSign,
    UserCog,
    LucideIcon,
} from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { SECTOR_CONFIGS, getSectorConfig } from '@/constants/sectors';
import { supabase } from '@/utils/supabase';
import type { VendorSector } from '@/types';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

// ─── Icon map: lucide icon name → component ──────────────────────────────────

const ICON_MAP: Record<string, LucideIcon> = {
    Building2,
    Flower2,
    Music,
    Camera,
    UtensilsCrossed,
    Sparkles,
    Palette,
    MoreHorizontal,
};

// ─── Feature highlights shown on every sector's onboarding ───────────────────

interface FeatureHighlight {
    Icon: LucideIcon;
    title: string;
    description: string;
}

const FEATURE_HIGHLIGHTS: FeatureHighlight[] = [
    {
        Icon: LayoutList,
        title: 'Manage Listings',
        description: 'Create and publish your service listings for customers to discover.',
    },
    {
        Icon: CalendarCheck,
        title: 'Track Bookings',
        description: 'Confirm or reject incoming bookings in real time.',
    },
    {
        Icon: DollarSign,
        title: 'View Earnings',
        description: 'See your revenue and platform commission breakdown.',
    },
    {
        Icon: UserCog,
        title: 'Edit Profile',
        description: 'Keep your sector-specific profile up to date.',
    },
];

// ─── Screen ───────────────────────────────────────────────────────────────────

const SERIF_FONT = Platform.select({
    ios: 'Georgia',
    android: 'serif',
    web: 'Georgia, serif',
    default: 'serif',
});

export default function VendorOnboardingScreen() {
    const router = useRouter();
    const { sector: sectorParam } = useLocalSearchParams<{ sector: string }>();

    // Resolved sector — starts from route param, falls back to DB lookup
    const [resolvedSector, setResolvedSector] = useState<VendorSector | null>(
        sectorParam && sectorParam in SECTOR_CONFIGS
            ? (sectorParam as VendorSector)
            : null
    );
    const [loadingSector, setLoadingSector] = useState(
        !(sectorParam && sectorParam in SECTOR_CONFIGS)
    );

    // If no valid sector in route params, fetch from vendor_profiles via auth.uid()
    useEffect(() => {
        if (resolvedSector) return;

        let cancelled = false;
        (async () => {
            try {
                const { data: { user } } = await supabase.auth.getUser();
                if (!user || cancelled) return;

                const { data, error } = await supabase
                    .from('vendor_profiles')
                    .select('vendor_sector')
                    .eq('id', user.id)
                    .single();

                if (cancelled) return;

                if (!error && data?.vendor_sector && data.vendor_sector in SECTOR_CONFIGS) {
                    setResolvedSector(data.vendor_sector as VendorSector);
                } else {
                    setResolvedSector('other');
                }
            } catch {
                if (!cancelled) setResolvedSector('other');
            } finally {
                if (!cancelled) setLoadingSector(false);
            }
        })();

        return () => { cancelled = true; };
    }, []);

    const sectorKey: VendorSector = resolvedSector ?? 'other';
    const config = getSectorConfig(sectorKey);

    // Resolve the sector icon component
    const SectorIcon: LucideIcon = ICON_MAP[config.iconName] ?? MoreHorizontal;

    // Entrance animations
    const headerAnim = useRef(new Animated.Value(0)).current;
    const featuresAnim = useRef(new Animated.Value(0)).current;
    const buttonAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        Animated.sequence([
            Animated.timing(headerAnim, {
                toValue: 1,
                duration: 450,
                useNativeDriver: true,
            }),
            Animated.timing(featuresAnim, {
                toValue: 1,
                duration: 350,
                useNativeDriver: true,
            }),
            Animated.timing(buttonAnim, {
                toValue: 1,
                duration: 300,
                useNativeDriver: true,
            }),
        ]).start();
    }, []);

    const slideUp = (anim: Animated.Value) => ({
        opacity: anim,
        transform: [
            {
                translateY: anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [24, 0],
                }),
            },
        ],
    });

    const handleGetStarted = () => {
        if (Platform.OS !== 'web') {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        }
        router.replace('/vendor-pending-approval' as any);
    };

    // Show a loading spinner while fetching sector from Supabase
    if (loadingSector) {
        return (
            <View style={styles.container}>
                <SafeAreaView style={[styles.safeArea, styles.loadingContainer]}>
                    <ActivityIndicator size="large" color={Colors.primary} />
                </SafeAreaView>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <SafeAreaView style={styles.safeArea}>
                <ScrollView
                    contentContainerStyle={styles.scrollContent}
                    showsVerticalScrollIndicator={false}
                    bounces={false}
                >
                    {/* ── Hero header ── */}
                    <Animated.View style={[styles.header, slideUp(headerAnim)]}>
                        {/* Sector icon badge */}
                        <View
                            style={[
                                styles.iconBadge,
                                { backgroundColor: config.badgeColor + '1A' }, // 10% opacity tint
                            ]}
                        >
                            <SectorIcon
                                size={40}
                                color={config.badgeColor}
                                strokeWidth={1.8}
                            />
                        </View>

                        <Text style={styles.welcomeLabel}>WELCOME,</Text>
                        <Text style={styles.sectorTitle}>{config.displayName}</Text>
                        <Text style={styles.sectorDescription}>{config.description}</Text>
                    </Animated.View>

                    {/* ── Feature highlights ── */}
                    <Animated.View style={[styles.featuresSection, slideUp(featuresAnim)]}>
                        <Text style={styles.featuresHeading}>What you can do</Text>

                        <View style={styles.featuresList}>
                            {FEATURE_HIGHLIGHTS.map((feature) => (
                                <View key={feature.title} style={styles.featureCard}>
                                    <View
                                        style={[
                                            styles.featureIconWrap,
                                            { backgroundColor: Colors.primaryFaded },
                                        ]}
                                    >
                                        <feature.Icon
                                            size={22}
                                            color={Colors.primary}
                                            strokeWidth={1.8}
                                        />
                                    </View>
                                    <View style={styles.featureText}>
                                        <Text style={styles.featureTitle}>{feature.title}</Text>
                                        <Text style={styles.featureDescription}>
                                            {feature.description}
                                        </Text>
                                    </View>
                                </View>
                            ))}
                        </View>
                    </Animated.View>

                    {/* ── Approval notice ── */}
                    <Animated.View style={[styles.noticeBox, slideUp(featuresAnim)]}>
                        <Text style={styles.noticeText}>
                            Your account will be reviewed by our team before you can start
                            accepting bookings. This usually takes 1–2 business days.
                        </Text>
                    </Animated.View>
                </ScrollView>

                {/* ── Get Started button (sticky footer) ── */}
                <Animated.View style={[styles.footer, slideUp(buttonAnim)]}>
                    <AnimatedPressable onPress={handleGetStarted} scaleValue={0.97}>
                        <View style={styles.getStartedButton}>
                            <Text style={styles.getStartedText}>Get Started</Text>
                        </View>
                    </AnimatedPressable>
                </Animated.View>
            </SafeAreaView>
        </View>
    );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.background,
    },
    safeArea: {
        flex: 1,
    },
    loadingContainer: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    scrollContent: {
        paddingHorizontal: Spacing.xl,
        paddingTop: Spacing.huge,
        paddingBottom: Spacing.xxl,
    },

    // Header
    header: {
        alignItems: 'center',
        marginBottom: Spacing.xxxl,
    },
    iconBadge: {
        width: 88,
        height: 88,
        borderRadius: Radius.xxl,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: Spacing.xl,
    },
    welcomeLabel: {
        fontSize: FontSize.xs,
        fontWeight: FontWeight.bold,
        color: Colors.textTertiary,
        letterSpacing: 3,
        marginBottom: Spacing.xs,
    },
    sectorTitle: {
        fontSize: FontSize.xxxl,
        fontWeight: FontWeight.heavy,
        color: Colors.text,
        fontFamily: SERIF_FONT,
        textAlign: 'center',
        marginBottom: Spacing.md,
    },
    sectorDescription: {
        fontSize: FontSize.md,
        color: Colors.textSecondary,
        textAlign: 'center',
        lineHeight: 24,
        paddingHorizontal: Spacing.md,
    },

    // Features section
    featuresSection: {
        marginBottom: Spacing.xxl,
    },
    featuresHeading: {
        fontSize: FontSize.lg,
        fontWeight: FontWeight.bold,
        color: Colors.text,
        marginBottom: Spacing.lg,
    },
    featuresList: {
        gap: Spacing.md,
    },
    featureCard: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        backgroundColor: Colors.surface,
        borderRadius: Radius.lg,
        padding: Spacing.lg,
        borderWidth: 1,
        borderColor: Colors.borderLight,
        ...Shadow.sm,
    },
    featureIconWrap: {
        width: 44,
        height: 44,
        borderRadius: Radius.md,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: Spacing.lg,
        flexShrink: 0,
    },
    featureText: {
        flex: 1,
    },
    featureTitle: {
        fontSize: FontSize.md,
        fontWeight: FontWeight.semibold,
        color: Colors.text,
        marginBottom: Spacing.xxs,
    },
    featureDescription: {
        fontSize: FontSize.sm,
        color: Colors.textSecondary,
        lineHeight: 20,
    },

    // Approval notice
    noticeBox: {
        backgroundColor: Colors.warningLight,
        borderRadius: Radius.md,
        padding: Spacing.lg,
        borderLeftWidth: 3,
        borderLeftColor: Colors.warning,
    },
    noticeText: {
        fontSize: FontSize.sm,
        color: Colors.warning,
        lineHeight: 20,
    },

    // Footer
    footer: {
        paddingHorizontal: Spacing.xl,
        paddingBottom: Spacing.xxl,
        paddingTop: Spacing.md,
        backgroundColor: Colors.background,
    },
    getStartedButton: {
        backgroundColor: Colors.primary,
        paddingVertical: Spacing.lg,
        borderRadius: Radius.lg,
        alignItems: 'center',
        ...Shadow.md,
    },
    getStartedText: {
        color: Colors.textOnPrimary,
        fontSize: FontSize.lg,
        fontWeight: FontWeight.bold,
    },
});
