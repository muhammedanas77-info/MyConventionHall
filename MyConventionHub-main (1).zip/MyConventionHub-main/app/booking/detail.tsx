import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { useRouter, useLocalSearchParams, Stack } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import { CalendarDays, Clock, MapPin, Users, ArrowLeft, CheckCircle2, XCircle, Wallet } from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { normalizeBooking, type NormalizedBooking } from '@/utils/booking';
import { formatCurrencyFull } from '@/utils/currency';
import { formatDateDisplay } from '@/utils/date';
import { SLOT_LABELS } from '@/constants/pricing';
import Badge from '@/components/ui/Badge';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import type { BookingStatus } from '@/types';

const STATUS_CONFIG: Record<BookingStatus, { variant: 'success' | 'warning' | 'error' | 'neutral'; label: string; color: string }> = {
  confirmed: { variant: 'success', label: 'Confirmed', color: Colors.success },
  pending: { variant: 'warning', label: 'Pending', color: Colors.warning },
  cancelled: { variant: 'error', label: 'Cancelled', color: Colors.error },
  completed: { variant: 'neutral', label: 'Completed', color: Colors.textTertiary },
};

export default function BookingDetailScreen() {
  const router = useRouter();
  const { bookingId } = useLocalSearchParams<{ bookingId: string }>();
  const [booking, setBooking] = useState<NormalizedBooking | null>(null);
  const [payment, setPayment] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const loadBooking = useCallback(async () => {
    if (!bookingId) return;
    setLoading(true);

    const { data: bookingData, error } = await supabase
      .from('bookings')
      .select('*, hall: halls(*)')
      .eq('id', bookingId)
      .single();

    if (error || !bookingData) {
      setLoading(false);
      Alert.alert('Error', 'Unable to load booking details.');
      return;
    }

    setBooking(normalizeBooking(bookingData));

    const { data: paymentData } = await supabase
      .from('payments')
      .select('*')
      .eq('booking_id', bookingId)
      .maybeSingle();

    if (paymentData) setPayment(paymentData);
    setLoading(false);
  }, [bookingId]);

  useEffect(() => {
    loadBooking();
  }, [loadBooking]);

  if (loading || !booking) {
    return (
      <View style={styles.centered}>
        <Stack.Screen options={{ headerShown: false }} />
        <Text style={styles.loadingText}>{loading ? 'Loading...' : 'Booking not found.'}</Text>
      </View>
    );
  }

  const statusInfo = STATUS_CONFIG[booking.status];
  const hall = booking.hall;

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ headerShown: false }} />
      <SafeAreaView style={styles.safeArea}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          {/* Header */}
          <View style={styles.headerRow}>
            <AnimatedPressable onPress={() => router.back()} scaleValue={0.9}>
              <View style={styles.backBtn}>
                <ArrowLeft size={22} color={Colors.text} />
              </View>
            </AnimatedPressable>
            <Text style={styles.headerTitle}>Booking Details</Text>
            <View style={{ width: 40 }} />
          </View>

          {/* Hall Image */}
          {hall?.photos?.[0] && (
            <Image source={{ uri: hall.photos[0] }} style={styles.hallImage} contentFit="cover" transition={200} />
          )}

          {/* Status Banner */}
          <View style={[styles.statusBanner, { backgroundColor: statusInfo.color + '15', borderColor: statusInfo.color + '40' }]}>
            <View style={[styles.statusDot, { backgroundColor: statusInfo.color }]} />
            <Text style={[styles.statusLabel, { color: statusInfo.color }]}>
              {statusInfo.label === 'Pending' ? 'Awaiting Admin Approval' : statusInfo.label}
            </Text>
          </View>

          {/* Venue Info */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Venue</Text>
            <Text style={styles.hallName}>{hall?.name ?? 'Venue'}</Text>
            {hall?.area && (
              <View style={styles.row}>
                <MapPin size={14} color={Colors.textTertiary} />
                <Text style={styles.rowText}>{hall.area}</Text>
              </View>
            )}
          </View>

          {/* Event Details */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Event Details</Text>
            <View style={styles.detailGrid}>
              <View style={styles.detailItem}>
                <CalendarDays size={18} color={Colors.primary} />
                <Text style={styles.detailLabel}>Date</Text>
                <Text style={styles.detailValue}>{formatDateDisplay(booking.date)}</Text>
              </View>
              <View style={styles.detailItem}>
                <Clock size={18} color={Colors.primary} />
                <Text style={styles.detailLabel}>Slot</Text>
                <Text style={styles.detailValue}>{SLOT_LABELS[booking.slot]}</Text>
              </View>
              <View style={styles.detailItem}>
                <Users size={18} color={Colors.primary} />
                <Text style={styles.detailLabel}>Guests</Text>
                <Text style={styles.detailValue}>{booking.guest_count}</Text>
              </View>
            </View>
          </View>

          {/* Payment Details */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Payment Summary</Text>
            <View style={styles.paymentRow}>
              <Text style={styles.paymentLabel}>Total Amount</Text>
              <Text style={styles.paymentValue}>{formatCurrencyFull(booking.total_amount)}</Text>
            </View>
            <View style={styles.paymentRow}>
              <Text style={styles.paymentLabel}>Advance Paid</Text>
              <Text style={styles.paymentValue}>{formatCurrencyFull(booking.advance_amount)}</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.paymentRow}>
              <Text style={styles.paymentLabelBold}>Remaining (Pay at Venue)</Text>
              <Text style={styles.paymentValueBold}>{formatCurrencyFull(booking.total_amount - booking.advance_amount)}</Text>
            </View>
          </View>

          {/* Payment Status */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Payment Status</Text>
            <View style={styles.paymentStatusRow}>
              {booking.payment_verified ? (
                <>
                  <CheckCircle2 size={20} color={Colors.success} />
                  <View style={styles.paymentStatusInfo}>
                    <Text style={[styles.paymentStatusText, { color: Colors.success }]}>Payment Verified</Text>
                    <Text style={styles.paymentStatusSub}>Your advance has been confirmed by admin</Text>
                  </View>
                </>
              ) : payment?.status === 'submitted' ? (
                <>
                  <Clock size={20} color={Colors.warning} />
                  <View style={styles.paymentStatusInfo}>
                    <Text style={[styles.paymentStatusText, { color: Colors.warning }]}>Under Review</Text>
                    <Text style={styles.paymentStatusSub}>Your payment proof is being verified by admin</Text>
                  </View>
                </>
              ) : (
                <>
                  <Wallet size={20} color={Colors.textTertiary} />
                  <View style={styles.paymentStatusInfo}>
                    <Text style={[styles.paymentStatusText, { color: Colors.textTertiary }]}>Pending Payment</Text>
                    <Text style={styles.paymentStatusSub}>Please complete the advance payment</Text>
                  </View>
                </>
              )}
            </View>

            {!booking.payment_verified && payment?.status !== 'submitted' && (
              <AnimatedPressable
                onPress={() => router.push(`/booking/payment-upi?bookingId=${booking.id}` as any)}
                scaleValue={0.96}
              >
                <View style={styles.payNowButton}>
                  <Wallet size={18} color="#FFFFFF" />
                  <Text style={styles.payNowText}>Pay Advance Now</Text>
                </View>
              </AnimatedPressable>
            )}
          </View>

          {/* Booking Reference */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Reference</Text>
            <Text style={styles.refText}>Booking ID: #{booking.id.slice(-8).toUpperCase()}</Text>
            <Text style={styles.refSub}>Created: {new Date(booking.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</Text>
          </View>

          {booking.special_requests && (
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Special Requests</Text>
              <Text style={styles.requestsText}>{booking.special_requests}</Text>
            </View>
          )}
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background },
  safeArea: { flex: 1 },
  scrollContent: { padding: Spacing.xl, paddingBottom: Spacing.massive },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.background },
  loadingText: { color: Colors.textSecondary, fontSize: FontSize.md },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: Spacing.lg },
  backBtn: { width: 40, height: 40, borderRadius: Radius.full, backgroundColor: Colors.surface, justifyContent: 'center', alignItems: 'center', ...Shadow.sm },
  headerTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  hallImage: { width: '100%', height: 200, borderRadius: Radius.xl, marginBottom: Spacing.lg, backgroundColor: Colors.cream },
  statusBanner: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, padding: Spacing.md, borderRadius: Radius.lg, borderWidth: 1, marginBottom: Spacing.lg },
  statusDot: { width: 10, height: 10, borderRadius: 5 },
  statusLabel: { fontSize: FontSize.md, fontWeight: FontWeight.bold },
  card: { backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.xl, marginBottom: Spacing.lg, ...Shadow.sm, borderWidth: 1, borderColor: Colors.borderLight },
  cardTitle: { fontSize: FontSize.xs, fontWeight: FontWeight.bold, color: Colors.textTertiary, textTransform: 'uppercase', letterSpacing: 1, marginBottom: Spacing.md },
  hallName: { fontSize: FontSize.xl, fontWeight: FontWeight.heavy, color: Colors.text, marginBottom: Spacing.sm },
  row: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  rowText: { fontSize: FontSize.sm, color: Colors.textSecondary },
  detailGrid: { flexDirection: 'row', justifyContent: 'space-between' },
  detailItem: { alignItems: 'center', gap: Spacing.xs, flex: 1 },
  detailLabel: { fontSize: FontSize.xs, color: Colors.textTertiary, fontWeight: FontWeight.medium },
  detailValue: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text },
  paymentRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: Spacing.sm },
  paymentLabel: { fontSize: FontSize.sm, color: Colors.textSecondary },
  paymentValue: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.text },
  paymentLabelBold: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text },
  paymentValueBold: { fontSize: FontSize.md, fontWeight: FontWeight.heavy, color: Colors.primaryDark },
  divider: { height: 1, backgroundColor: Colors.borderLight, marginVertical: Spacing.sm },
  paymentStatusRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  paymentStatusInfo: { flex: 1 },
  paymentStatusText: { fontSize: FontSize.md, fontWeight: FontWeight.bold },
  paymentStatusSub: { fontSize: FontSize.xs, color: Colors.textTertiary, marginTop: 2 },
  payNowButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm, backgroundColor: Colors.primary, paddingVertical: Spacing.md, borderRadius: Radius.xl, marginTop: Spacing.lg, ...Shadow.sm },
  payNowText: { color: '#FFFFFF', fontWeight: FontWeight.bold, fontSize: FontSize.md },
  refText: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.text },
  refSub: { fontSize: FontSize.xs, color: Colors.textTertiary, marginTop: Spacing.xs },
  requestsText: { fontSize: FontSize.sm, color: Colors.textSecondary, lineHeight: 20 },
});
