import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, TextInput, Platform, Alert, ScrollView, Linking } from 'react-native';
import { Image } from 'expo-image';
import { useRouter, Stack, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Clipboard, CheckCircle2, ArrowLeft } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { setStringAsync } from 'expo-clipboard';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { getPaymentByBookingId, submitPaymentProof } from '@/utils/payments';
import { formatCurrencyFull } from '@/utils/currency';

const UPI_ID = process.env.EXPO_PUBLIC_UPI_ID ?? '';
const UPI_NAME = 'ConventionHub Payments';
const UPI_QR_URL = process.env.EXPO_PUBLIC_UPI_QR_URL;

export default function PaymentUpiScreen() {
  const router = useRouter();
  const { bookingId } = useLocalSearchParams<{ bookingId: string }>();
  const [payment, setPayment] = useState<any>(null);
  const [booking, setBooking] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [note, setNote] = useState('');
  const [message, setMessage] = useState('');
  const [proofUri, setProofUri] = useState<string | null>(null);

  const fetchDetails = useCallback(async () => {
    if (!bookingId) return;

    // Try to load the payments row first
    const { data: paymentData, error } = await getPaymentByBookingId(bookingId);

    if (!error && paymentData) {
      setPayment(paymentData);
    }
    // If no payments row exists (non-fatal — payments insert may have failed),
    // we still load the booking and synthesise a payment object from it.

    const { data: bookingData, error: bookingError } = await supabase
      .from('bookings')
      .select('*, hall: halls(*)')
      .eq('id', bookingId)
      .single();

    if (bookingError || !bookingData) {
      setMessage('Unable to load booking details.');
      return;
    }

    setBooking(bookingData);

    // Synthesise a minimal payment object from the booking if no row exists
    if (error || !paymentData) {
      setPayment({
        id: null, // no real payments row — submitPaymentProof will be skipped
        booking_id: bookingId,
        advance_amount: bookingData.advance_amount,
        amount: bookingData.total_amount,
      });
    }
  }, [bookingId]);


  useEffect(() => {
    fetchDetails();
  }, [fetchDetails]);

  const copyUpi = async () => {
    try {
      if (Platform.OS === 'web') {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(UPI_ID);
          setMessage('UPI ID copied (Web)');
        } else {
          throw new Error('Clipboard API not available');
        }
      } else {
        await setStringAsync(UPI_ID);
        setMessage('UPI ID copied');
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error: any) {
      console.error('Copy failed:', error);
      setMessage(`Tap and hold the ID to copy: ${UPI_ID}`);
      Alert.alert('Copy Failed', 'Please manually copy the UPI ID if the button is not working.');
    }
  };

  const openUpiApp = async () => {
    const amount = (payment?.advance_amount ?? booking?.advance_amount ?? 0).toString();
    const transactionNote = encodeURIComponent(`ConventionHub booking ${bookingId}`);
    const pa = encodeURIComponent(UPI_ID);
    const pn = encodeURIComponent(UPI_NAME);
    const am = amount;
    
    // Build UPI URLs — Google Pay uses tez:// on both iOS and Android in India
    const tezUrl = `tez://upi/pay?pa=${pa}&pn=${pn}&am=${am}&cu=INR&tn=${transactionNote}`;
    const genericUpi = `upi://pay?pa=${pa}&pn=${pn}&am=${am}&cu=INR&tn=${transactionNote}`;
    
    // In Expo Go, canOpenURL always returns false for custom schemes.
    // So we skip the check and just try openURL directly — it will either
    // open the app or throw an error we can catch.
    try {
      await Linking.openURL(tezUrl);
      return; // Success — GPay opened
    } catch (e) {
      console.warn('tez:// failed, trying generic upi://', e);
    }

    // Fallback: generic upi:// — on Android this shows app chooser,
    // on iOS this may open any UPI-capable app
    try {
      await Linking.openURL(genericUpi);
    } catch (e) {
      console.warn('upi:// also failed', e);
      Alert.alert(
        'UPI App Not Found',
        'Could not open Google Pay. Please copy the UPI ID and pay manually using your UPI app.',
        [{ text: 'OK' }]
      );
    }
  };

  const handlePaymentSent = async () => {
    if (!payment) return;
    if (!proofUri) {
      Alert.alert('Screenshot Required', 'Please upload a payment screenshot first.');
      return;
    }
    
    setIsLoading(true);

    let uploadedProofUrl: string | null = null;
    if (proofUri) {
      try {
        const rawExtension = proofUri.split('.').pop()?.split('?')[0]?.toLowerCase() || 'jpg';
        const extension = rawExtension === 'jpeg' ? 'jpg' : rawExtension;
        const contentType = extension === 'png' ? 'image/png' : 'image/jpeg';
        const filePath = `${bookingId}-${Date.now()}.${extension}`;
        
        const { data: session } = await supabase.auth.getSession();
        const token = session?.session?.access_token || process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
        const uploadUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/storage/v1/object/payment-proofs/${filePath}`;
        
        const response = await FileSystem.uploadAsync(uploadUrl, proofUri, {
          httpMethod: 'POST',
          uploadType: FileSystem.FileSystemUploadType.BINARY_CONTENT,
          headers: {
            'Authorization': `Bearer ${token}`,
            'apikey': process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!,
            'x-upsert': 'true',
            'Content-Type': contentType,
          },
        });

        if (response.status < 200 || response.status >= 300) {
           throw new Error(response.body);
        }

        uploadedProofUrl = filePath;
      } catch (error: any) {
        setIsLoading(false);
        console.error('Upload failed details:', error);
        Alert.alert('Upload failed', error.message || 'Could not upload the payment proof. Please check your internet and try again.');
        return;
      }
    }

    // If we have a real payments row, update it
    if (payment.id) {
      const { error } = await submitPaymentProof(payment.id, uploadedProofUrl, note || 'Customer marked payment as completed.');
      setIsLoading(false);

      if (error) {
        Alert.alert('Unable to submit', error.message || 'Please try again.');
        return;
      }
    } else {
      // No payments row — create one now with the proof attached
      const { error } = await supabase.from('payments').insert([{
        booking_id: bookingId,
        amount: payment.amount,
        advance_amount: payment.advance_amount,
        payment_method: 'upi',
        status: 'submitted',
        verification_screenshot_url: uploadedProofUrl,
        customer_note: note || 'Customer marked payment as completed.',
      }]);
      setIsLoading(false);

      if (error) {
        // Even if this fails, let the customer proceed — admin can verify manually
        console.warn('Late payment row creation failed:', error.message);
      }
    }

    setMessage('Payment proof submitted successfully!');
    
    setTimeout(() => {
      router.replace(`/booking/thank-you?bookingId=${encodeURIComponent(bookingId)}` as any);
    }, 1000);
  };

  const pickPaymentProof = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]?.uri) {
      setProofUri(result.assets[0].uri);
      setMessage('Payment screenshot selected.');
    }
  };

  if (!bookingId) {
    return (
      <View style={styles.centered}>
        <Text style={styles.errorText}>Booking not found.</Text>
      </View>
    );
  }

  if (!UPI_ID) {
    return (
      <View style={styles.centered}>
        <Stack.Screen options={{ title: 'Payment', headerShown: false }} />
        <Text style={styles.errorText}>Payment is not configured yet.{'\n'}Please contact support.</Text>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ title: 'Payment', headerStyle: { backgroundColor: Colors.surface }, headerTintColor: Colors.text, headerShadowVisible: false }} />
      <SafeAreaView edges={['top']} style={styles.safeArea}>
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          <AnimatedPressable onPress={() => router.back()} scaleValue={0.9}>
            <View style={styles.backButton}>
              <ArrowLeft size={22} color={Colors.text} />
            </View>
          </AnimatedPressable>

          <View style={styles.card}>
            <Text style={styles.title}>Complete Payment</Text>
            <Text style={styles.subtitle}>Pay using UPI and mark payment for verification.</Text>

            {booking && (
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Venue</Text>
                <Text style={styles.detailValue}>{booking.hall?.name ?? 'Venue'}</Text>
              </View>
            )}
            {booking && (
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Date</Text>
                <Text style={styles.detailValue}>{new Date(booking.event_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</Text>
              </View>
            )}
            {booking && (
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Slot</Text>
                <Text style={styles.detailValue}>{booking.slot_type}</Text>
              </View>
            )}

            <View style={styles.amountBox}>
              <Text style={styles.amountHeading}>Advance Due</Text>
              <Text style={styles.amountValue}>{formatCurrencyFull(payment?.advance_amount ?? booking?.advance_amount ?? 0)}</Text>
            </View>

            <View style={styles.upiBox}>
              <Text style={styles.sectionLabel}>UPI ID</Text>
              {UPI_QR_URL ? <Image source={{ uri: UPI_QR_URL }} style={styles.qrImage} contentFit="contain" /> : null}
              <Text style={styles.upiText}>{UPI_ID}</Text>
              <AnimatedPressable onPress={openUpiApp} scaleValue={0.96}>
                <View style={styles.payButton}>
                  <Text style={styles.payButtonText}>Open UPI App</Text>
                </View>
              </AnimatedPressable>
              <AnimatedPressable onPress={copyUpi} scaleValue={0.96}>
                <View style={styles.copyButton}>
                  <Clipboard size={16} color={Colors.primaryDark} />
                  <Text style={styles.copyText}>Copy UPI ID</Text>
                </View>
              </AnimatedPressable>
            </View>

            <View style={styles.instructions}>
              <Text style={styles.sectionLabel}>Instructions</Text>
              <Text style={styles.instructionText}>Transfer the advance amount using your UPI app to the QR code or UPI ID above. After payment, enter the transaction ID or note and submit it for admin verification.</Text>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Payment Notes / Transaction ID</Text>
              <TextInput
                style={styles.input}
                value={note}
                onChangeText={setNote}
                placeholder="UPI transaction ID or notes"
                placeholderTextColor={Colors.textTertiary}
              />
            </View>

            <AnimatedPressable onPress={pickPaymentProof} scaleValue={0.96}>
              <View style={[styles.proofButton, proofUri && styles.proofButtonActive]}>
                <Text style={[styles.proofButtonText, proofUri && styles.proofButtonTextActive]}>
                  {proofUri ? 'Change Screenshot' : 'Upload Payment Screenshot'}
                </Text>
              </View>
            </AnimatedPressable>

            {proofUri ? (
              <View style={styles.proofPreviewContainer}>
                <Image source={{ uri: proofUri }} style={styles.proofPreview} contentFit="cover" />
                <View style={styles.proofSuccessBadge}>
                  <CheckCircle2 size={16} color="#FFFFFF" />
                  <Text style={styles.proofSuccessText}>Screenshot Attached</Text>
                </View>
              </View>
            ) : null}

            {message ? <Text style={styles.messageText}>{message}</Text> : null}

            <AnimatedPressable 
              onPress={handlePaymentSent} 
              scaleValue={0.96} 
              disabled={isLoading || !booking || !proofUri}
            >
              <View style={[
                styles.actionButton, 
                (isLoading || !proofUri) && styles.actionButtonDisabled
              ]}>
                <Text style={styles.actionButtonText}>
                  {isLoading ? 'Submitting...' : 'I have paid'}
                </Text>
              </View>
            </AnimatedPressable>

            <AnimatedPressable onPress={() => router.replace('/(tabs)/discover' as any)} scaleValue={0.96}>
              <View style={styles.secondaryButton}>
                <Text style={styles.secondaryButtonText}>Back to Discover</Text>
              </View>
            </AnimatedPressable>
          </View>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background },
  safeArea: { flex: 1 },
  content: { padding: Spacing.xl, paddingTop: Spacing.md },
  backButton: { width: 40, height: 40, borderRadius: Radius.full, backgroundColor: Colors.surface, justifyContent: 'center', alignItems: 'center', marginBottom: Spacing.lg, ...Shadow.sm },
  card: { backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.xl, ...Shadow.md, borderWidth: 1, borderColor: Colors.borderLight },
  title: { fontSize: FontSize.xxxl, fontWeight: FontWeight.heavy, color: Colors.text, marginBottom: Spacing.sm },
  subtitle: { fontSize: FontSize.sm, color: Colors.textSecondary, marginBottom: Spacing.lg },
  detailRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: Spacing.md },
  detailLabel: { fontSize: FontSize.sm, color: Colors.textTertiary, fontWeight: FontWeight.medium },
  detailValue: { fontSize: FontSize.sm, color: Colors.text, fontWeight: FontWeight.bold },
  amountBox: { backgroundColor: Colors.primaryFaded, padding: Spacing.md, borderRadius: Radius.lg, marginBottom: Spacing.lg },
  amountHeading: { fontSize: FontSize.sm, color: Colors.textSecondary, marginBottom: Spacing.xs },
  amountValue: { fontSize: FontSize.xxxl, fontWeight: FontWeight.heavy, color: Colors.primaryDark },
  upiBox: { backgroundColor: Colors.cream, borderRadius: Radius.lg, padding: Spacing.md, marginBottom: Spacing.lg },
  qrImage: { width: '100%', height: 220, backgroundColor: Colors.surface, borderRadius: Radius.lg, marginBottom: Spacing.md },
  sectionLabel: { fontSize: FontSize.sm, color: Colors.textSecondary, marginBottom: Spacing.xs, fontWeight: FontWeight.bold },
  upiText: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
  payButton: { alignItems: 'center', marginTop: Spacing.md, padding: Spacing.md, backgroundColor: Colors.primary, borderRadius: Radius.md, ...Shadow.sm },
  payButtonText: { color: '#FFFFFF', fontWeight: FontWeight.bold },
  copyButton: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, marginTop: Spacing.sm, padding: Spacing.sm, backgroundColor: Colors.surface, borderRadius: Radius.md, ...Shadow.sm },
  copyText: { color: Colors.primaryDark, fontWeight: FontWeight.bold },
  instructions: { marginBottom: Spacing.lg },
  instructionText: { color: Colors.textSecondary, fontSize: FontSize.sm, lineHeight: 20 },
  inputGroup: { marginBottom: Spacing.lg },
  inputLabel: { color: Colors.textSecondary, fontSize: FontSize.sm, marginBottom: Spacing.xs },
  input: { backgroundColor: Colors.background, borderRadius: Radius.lg, padding: Spacing.md, color: Colors.text, borderWidth: 1, borderColor: Colors.borderLight },
  proofButton: { alignItems: 'center', borderWidth: 1, borderColor: Colors.primary, borderRadius: Radius.lg, padding: Spacing.md, marginBottom: Spacing.md },
  proofButtonActive: { backgroundColor: Colors.primaryFaded, borderColor: Colors.primaryDark },
  proofButtonText: { color: Colors.primaryDark, fontWeight: FontWeight.bold },
  proofButtonTextActive: { color: Colors.primaryDark },
  proofPreviewContainer: { marginBottom: Spacing.md, position: 'relative' },
  proofPreview: { width: '100%', height: 160, borderRadius: Radius.lg, backgroundColor: Colors.background },
  proofSuccessBadge: { position: 'absolute', top: Spacing.sm, right: Spacing.sm, backgroundColor: Colors.success, flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 4, borderRadius: Radius.full, ...Shadow.sm },
  proofSuccessText: { color: '#FFFFFF', fontSize: 10, fontWeight: FontWeight.bold },
  actionButton: { backgroundColor: Colors.primary, padding: Spacing.md, borderRadius: Radius.xl, justifyContent: 'center', alignItems: 'center', marginBottom: Spacing.md },
  actionButtonDisabled: { opacity: 0.5, backgroundColor: Colors.textTertiary },
  actionButtonText: { color: '#FFFFFF', fontWeight: FontWeight.bold },
  secondaryButton: { alignItems: 'center', paddingVertical: Spacing.md },
  secondaryButtonText: { color: Colors.primaryDark, fontWeight: FontWeight.bold },
  messageText: { color: Colors.success, fontSize: FontSize.sm, marginBottom: Spacing.md, textAlign: 'center', fontWeight: FontWeight.bold },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: Spacing.xl },
  errorText: { color: Colors.error, fontSize: FontSize.md, textAlign: 'center' },
});
