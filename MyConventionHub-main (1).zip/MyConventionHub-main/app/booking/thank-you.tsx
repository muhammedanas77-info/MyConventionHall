import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, Animated } from 'react-native';
import { useRouter, Stack, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { CheckCircle2, Home, ArrowRight } from 'lucide-react-native';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';

export default function ThankYouScreen() {
  const router = useRouter();
  const { bookingId } = useLocalSearchParams<{ bookingId: string }>();

  const iconAnim = useRef(new Animated.Value(0)).current;
  const textAnim = useRef(new Animated.Value(0)).current;
  const cardAnim = useRef(new Animated.Value(0)).current;
  const buttonsAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.stagger(200, [
      Animated.spring(iconAnim, { toValue: 1, useNativeDriver: true, speed: 12, bounciness: 6 }),
      Animated.spring(textAnim, { toValue: 1, useNativeDriver: true, speed: 12, bounciness: 4 }),
      Animated.spring(cardAnim, { toValue: 1, useNativeDriver: true, speed: 12, bounciness: 4 }),
      Animated.spring(buttonsAnim, { toValue: 1, useNativeDriver: true, speed: 12, bounciness: 4 }),
    ]).start();
  }, []);

  const makeStyle = (anim: Animated.Value, translateY = 30) => ({
    opacity: anim,
    transform: [{ translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [translateY, 0] }) }],
  });

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ headerShown: false }} />
      <SafeAreaView style={styles.safeArea}>
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          <Animated.View style={[styles.successIconContainer, makeStyle(iconAnim, 40)]}>
            <View style={styles.iconCircle}>
              <CheckCircle2 size={60} color="#FFFFFF" strokeWidth={3} />
            </View>
          </Animated.View>

          <Animated.View style={[styles.textContainer, makeStyle(textAnim)]}>
            <Text style={styles.thankYouText}>Payment Submitted!</Text>
            <Text style={styles.subtitle}>
              Thank you for your payment. Our team will verify your transaction and confirm your booking shortly.
            </Text>
          </Animated.View>

          <Animated.View style={[styles.infoCard, makeStyle(cardAnim)]}>
            <Text style={styles.infoLabel}>Booking Reference</Text>
            <Text style={styles.infoValue}>#{bookingId?.slice(-8).toUpperCase() ?? 'N/A'}</Text>
            
            <View style={styles.divider} />
            
            <View style={styles.statusRow}>
              <View style={styles.statusDot} />
              <Text style={styles.statusText}>Verification in progress</Text>
            </View>
          </Animated.View>

          <Animated.View style={[styles.buttonContainer, makeStyle(buttonsAnim, -20)]}>
            <AnimatedPressable 
              onPress={() => router.replace('/(tabs)/discover' as any)} 
              scaleValue={0.96}
            >
              <View style={styles.primaryButton}>
                <Home size={20} color="#FFFFFF" />
                <Text style={styles.primaryButtonText}>Back to Home</Text>
              </View>
            </AnimatedPressable>

            <AnimatedPressable 
              onPress={() => router.replace('/(tabs)/bookings' as any)} 
              scaleValue={0.96}
            >
              <View style={styles.secondaryButton}>
                <Text style={styles.secondaryButtonText}>View My Bookings</Text>
                <ArrowRight size={18} color={Colors.primaryDark} />
              </View>
            </AnimatedPressable>
          </Animated.View>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background },
  safeArea: { flex: 1 },
  content: { flexGrow: 1, padding: Spacing.xl, justifyContent: 'center', alignItems: 'center' },
  successIconContainer: { marginBottom: Spacing.massive, alignItems: 'center' },
  iconCircle: { width: 120, height: 120, borderRadius: 60, backgroundColor: Colors.success, justifyContent: 'center', alignItems: 'center', ...Shadow.md },
  textContainer: { alignItems: 'center', marginBottom: Spacing.massive },
  thankYouText: { fontSize: FontSize.xxxl, fontWeight: FontWeight.heavy, color: Colors.text, textAlign: 'center', marginBottom: Spacing.md },
  subtitle: { fontSize: FontSize.md, color: Colors.textSecondary, textAlign: 'center', lineHeight: 24, paddingHorizontal: Spacing.lg },
  infoCard: { width: '100%', backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.xl, marginBottom: Spacing.massive, ...Shadow.md, borderWidth: 1, borderColor: Colors.borderLight },
  infoLabel: { fontSize: FontSize.xs, color: Colors.textTertiary, fontWeight: FontWeight.bold, textTransform: 'uppercase', letterSpacing: 1, marginBottom: Spacing.xs },
  infoValue: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: Spacing.md },
  divider: { height: 1, backgroundColor: Colors.borderLight, marginVertical: Spacing.md },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  statusDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.warning },
  statusText: { fontSize: FontSize.sm, color: Colors.warning, fontWeight: FontWeight.bold },
  buttonContainer: { width: '100%', gap: Spacing.md },
  primaryButton: { backgroundColor: Colors.primary, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm, paddingVertical: Spacing.lg, borderRadius: Radius.xl, ...Shadow.sm },
  primaryButtonText: { color: '#FFFFFF', fontSize: FontSize.md, fontWeight: FontWeight.bold },
  secondaryButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm, paddingVertical: Spacing.md },
  secondaryButtonText: { color: Colors.primaryDark, fontSize: FontSize.md, fontWeight: FontWeight.bold },
});
