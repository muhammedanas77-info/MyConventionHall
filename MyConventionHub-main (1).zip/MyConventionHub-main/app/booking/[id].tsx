import React, { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import {
    View, Text, StyleSheet, ScrollView, TextInput, Platform,
    Animated, Alert, ActivityIndicator,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import {
    ChevronRight, ChevronLeft, Sun, Sunset, Calendar,
    CheckCircle2, Shield, Users, Info, AlertTriangle, Sparkles,
    X, LogIn,
} from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { Image } from 'expo-image';
import { Colors, Spacing, FontSize, FontWeight, Shadow, Radius } from '@/constants/theme';
import { useAuth } from '@/providers/AuthProvider';
import { supabase } from '@/utils/supabase';
import { createBooking } from '@/utils/booking';
import { formatCurrencyFull } from '@/utils/currency';
import { calculatePriceBreakdown } from '@/utils/pricing';
import { getSeasonForDate } from '@/constants/seasons';
import { SEASON_LABELS, SLOT_LABELS } from '@/constants/pricing';
import { SECTOR_CONFIGS } from '@/constants/sectors';
import Badge from '@/components/ui/Badge';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import type { SlotType, VendorSector, ServiceListing } from '@/types';

const STEPS = ['Date', 'Slot', 'Details', 'Add-Ons', 'Payment'];
const SERIF_FONT = Platform.select({ ios: 'Georgia', android: 'serif', web: 'Georgia, serif', default: 'serif' });

// ─── Add-on types ─────────────────────────────────────────────────────────────

interface AddonListing extends ServiceListing {
    vendor_name: string | null;
    vendor_city: string | null;
}

type AddonSelections = Partial<Record<VendorSector, AddonListing>>;

const ADDON_SECTOR_ORDER: VendorSector[] = [
    'caterer', 'photographer', 'musician', 'florist', 'decorator', 'artist', 'other',
];

// ─── Resolve the current authenticated user ───────────────────────────────────
// Tries the auth context first (fast, reliable after initial load), then falls
// back to the API-based getUser() call (handles token refresh).
async function resolveSessionUser(): Promise<{ id: string; email: string | null } | null> {
    try {
        const { data: { user }, error } = await supabase.auth.getUser();
        if (user && !error) {
            return { id: user.id, email: user.email ?? null };
        }
    } catch { /* fall through */ }
    try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user) {
            return { id: session.user.id, email: session.user.email ?? null };
        }
    } catch { /* fall through */ }
    return null;
}

export default function BookingScreen() {
    const { id } = useLocalSearchParams<{ id: string }>();
    const router = useRouter();
    const { user: authUser, profile: authProfile, isLoading: authLoading } = useAuth();
    const [hall, setHall] = useState<any>(null);
    const [allBookings, setAllBookings] = useState<any[]>([]);
    const [isLoadingHall, setIsLoadingHall] = useState(true);
    const [showLoginPrompt, setShowLoginPrompt] = useState(false);

    // Store resolved user in a ref so handleNext can access it reliably
    // without worrying about stale closures or async timing.
    const currentUserRef = useRef<{ id: string; email: string | null } | null>(null);

    useEffect(() => {
        const resolve = async () => {
            // Prefer the auth context user (fast, always up-to-date)
            if (authUser?.id) {
                currentUserRef.current = { id: authUser.id, email: authUser.email ?? null };
                setShowLoginPrompt(false);
                return;
            }
            // Fallback to API call (handles edge cases where context hasn't settled)
            const sessionUser = await resolveSessionUser();
            if (sessionUser) {
                currentUserRef.current = sessionUser;
                setShowLoginPrompt(false);
            } else if (!authLoading) {
                // No user found and auth has settled — show the login prompt
                currentUserRef.current = null;
                setShowLoginPrompt(true);
            }
        };
        resolve();
    }, [authUser?.id, authUser?.email, authLoading]);

    useEffect(() => {
        const fetchHallAndBookings = async () => {
            if (!id) return;
            setIsLoadingHall(true);
            const { data: hData } = await supabase.from('halls').select('*').eq('id', id).single();
            if (hData) {
                setHall(hData);
            } else {
                setHall(null);
            }
            const { data: bData } = await supabase.from('bookings').select('*').eq('hall_id', id);
            if (bData) setAllBookings(bData);
            setIsLoadingHall(false);
        };
        fetchHallAndBookings();
    }, [id]);

    const [step, setStep] = useState(0);
    const [selectedDate, setSelectedDate] = useState('');
    const [selectedSlot, setSelectedSlot] = useState<SlotType | null>(null);
    const [customerName, setCustomerName] = useState('');
    const [customerEmail, setCustomerEmail] = useState('');
    const [customerPhone, setCustomerPhone] = useState('');
    const [guestCount, setGuestCount] = useState('');
    const [specialRequests, setSpecialRequests] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    // ── Add-on state ──────────────────────────────────────────────────────────
    const [addonListings, setAddonListings] = useState<AddonListing[]>([]);
    const [addonSelections, setAddonSelections] = useState<AddonSelections>({});
    const [isLoadingAddons, setIsLoadingAddons] = useState(false);
    const [addonError, setAddonError] = useState<string | null>(null);
    const addonsFetchedForDate = useRef<string | null>(null);

    const fetchAddons = useCallback(async (eventDate: string) => {
        if (!eventDate) return;
        setIsLoadingAddons(true);
        setAddonError(null);
        try {
            const { data, error } = await supabase
                .from('service_listings')
                .select(`
                    *,
                    vendor:vendor_profiles(
                        is_approved,
                        sector_data,
                        profiles(full_name)
                    )
                `)
                .eq('is_active', true)
                .neq('sector', 'venue')
                .limit(100);
            if (error) throw error;

            const { data: bookedOnDate } = await supabase
                .from('service_bookings')
                .select('listing_id')
                .eq('event_date', eventDate)
                .in('status', ['pending', 'confirmed', 'completed']);
            const bookedIds = new Set((bookedOnDate ?? []).map((b: any) => b.listing_id));

            const available: AddonListing[] = (data ?? [])
                .filter((item: any) => {
                    if (!item.vendor?.is_approved) return false;
                    if (bookedIds.has(item.id)) return false;
                    const blocked: { start_date: string; end_date: string }[] =
                        item.vendor?.sector_data?.blocked_dates ?? [];
                    return !blocked.some((r) => eventDate >= r.start_date && eventDate <= r.end_date);
                })
                .map((item: any) => ({
                    ...item,
                    vendor_name:
                        item.vendor?.profiles?.full_name ??
                        item.vendor?.sector_data?.business_name ??
                        item.vendor?.sector_data?.artist_name ??
                        item.vendor?.sector_data?.studio_name ??
                        null,
                    vendor_city: item.vendor?.sector_data?.city ?? null,
                }));
            setAddonListings(available);
            addonsFetchedForDate.current = eventDate;
        } catch (_err) {
            setAddonError('Could not load add-on services. You can skip and continue.');
        } finally {
            setIsLoadingAddons(false);
        }
    }, []);

    const addonsByCategory = useMemo(() => {
        const map: Partial<Record<VendorSector, AddonListing[]>> = {};
        for (const listing of addonListings) {
            const sector = listing.sector as VendorSector;
            if (!map[sector]) map[sector] = [];
            map[sector]!.push(listing);
        }
        return map;
    }, [addonListings]);

    const selectedAddonCount = useMemo(
        () => Object.keys(addonSelections).length,
        [addonSelections]
    );
    const addonTotalPrice = useMemo(
        () => Object.values(addonSelections).reduce((sum, l) => sum + (l?.base_price ?? 0), 0),
        [addonSelections]
    );

    const fadeAnim = useRef(new Animated.Value(1)).current;
    const hasPrefilledContact = useRef(false);

    // Pre-fill contact info from auth profile (best-effort)
    useEffect(() => {
        if (hasPrefilledContact.current) return;
        if (!authUser && !authProfile) return;
        const email = authUser?.email ?? '';
        const emailPrefix = email.split('@')[0];
        const profileName = authProfile?.full_name?.trim() ?? '';
        setCustomerName(profileName || emailPrefix || 'Customer');
        setCustomerPhone(authProfile?.phone ?? '');
        setCustomerEmail(email);
        hasPrefilledContact.current = true;
    }, [authProfile, authUser]);

    const today = useMemo(() => new Date(), []);
    const dates = useMemo(() => {
        const result: { date: string; label: string; day: string; month: string; isBooked?: boolean; isPartial?: boolean }[] = [];
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        for (let i = 0; i < 45; i++) {
            const d = new Date(today);
            d.setDate(d.getDate() + i);
            const dateStr = d.toISOString().split('T')[0];
            const hallBookings = (allBookings ?? []).filter((b: any) => b.hall_id === id);
            const bookedForDate = hallBookings.filter((b: any) => b.date === dateStr || b.event_date === dateStr);
            const isFullDay = bookedForDate.some((b: any) => b.slot === 'full_day' || b.slot_type === 'full_day');
            const hasMorning = bookedForDate.some((b: any) => b.slot === 'morning' || b.slot_type === 'morning');
            const hasEvening = bookedForDate.some((b: any) => b.slot === 'evening' || b.slot_type === 'evening');
            result.push({
                date: dateStr,
                label: `${d.getDate()}`,
                day: dayNames[d.getDay()],
                month: monthNames[d.getMonth()],
                isBooked: isFullDay || (hasMorning && hasEvening),
                isPartial: !isFullDay && (hasMorning || hasEvening),
            });
        }
        return result;
    }, [id, allBookings, today]);

    const season = useMemo(() => {
        return selectedDate ? getSeasonForDate(new Date(selectedDate)) : getSeasonForDate(today);
    }, [selectedDate, today]);

    const priceBreakdown = useMemo(() => {
        if (!hall || !selectedSlot) return null;
        return calculatePriceBreakdown(hall.price_per_day, season, selectedSlot);
    }, [hall, selectedSlot, season]);

    const canProceed = useCallback(() => {
        switch (step) {
            case 0: return !!selectedDate;
            case 1: return !!selectedSlot;
            case 2: {
                const count = parseInt(guestCount, 10);
                const hasContact = customerName.trim().length > 1 && customerEmail.includes('@');
                return hasContact && !isNaN(count) && hall ? count >= hall.capacity_min && count <= hall.capacity_max : false;
            }
            case 3: return !isLoadingAddons;
            case 4: return true;
            default: return false;
        }
    }, [step, selectedDate, selectedSlot, guestCount, hall, customerName, customerEmail, isLoadingAddons]);

    const animateStep = useCallback((toStep: number) => {
        Animated.timing(fadeAnim, { toValue: 0, duration: 150, useNativeDriver: true }).start(() => {
            setStep(toStep);
            Animated.timing(fadeAnim, { toValue: 1, duration: 250, useNativeDriver: true }).start();
        });
    }, [fadeAnim]);

    const handleNext = useCallback(async () => {
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

        // — Step advancement (steps 0-3) —
        if (step < 4) {
            if (step === 2 && addonsFetchedForDate.current !== selectedDate) {
                fetchAddons(selectedDate);
            }
            animateStep(step + 1);
            return;
        }

        // — Final submit (step 4) —
        if (!hall || !priceBreakdown || !selectedSlot) return;

        // Resolve the authenticated user — try context first, then API
        let resolvedUser = currentUserRef.current;
        if (!resolvedUser) {
            resolvedUser = await resolveSessionUser();
            currentUserRef.current = resolvedUser;
        }

        if (!resolvedUser) {
            setShowLoginPrompt(true);
            return;
        }

        setIsSubmitting(true);
        try {
            const result = await createBooking({
                hallId: hall.id,
                customerId: resolvedUser.id,
                date: selectedDate,
                slot: selectedSlot,
                customerName: customerName.trim() || resolvedUser.email?.split('@')[0] || 'Customer',
                customerEmail: customerEmail.trim().toLowerCase(),
                customerPhone: customerPhone.trim(),
                guestCount: parseInt(guestCount, 10),
                totalAmount: priceBreakdown.totalAmount,
                advanceAmount: priceBreakdown.advanceAmount,
                commission: priceBreakdown.commission,
                discount: priceBreakdown.discount,
                specialRequests: specialRequests || undefined,
            });

            if (!result.success || !result.bookingId) {
                Alert.alert('Booking Error', result.error || 'Failed to create booking. Please try again.');
                setIsSubmitting(false);
                return;
            }

            // Create add-on service bookings (best-effort)
            const selectedAddons = Object.values(addonSelections).filter(Boolean) as AddonListing[];
            for (const addon of selectedAddons) {
                try {
                    await supabase.from('service_bookings').insert([{
                        listing_id: addon.id,
                        vendor_id: addon.vendor_id,
                        customer_id: resolvedUser.id,
                        sector: addon.sector,
                        event_date: selectedDate,
                        event_type: 'wedding',
                        guest_count: parseInt(guestCount, 10) || null,
                        special_requests: specialRequests || null,
                        total_amount: 0,
                        advance_amount: 0,
                        status: 'pending',
                        venue_booking_id: result.bookingId,
                    }]);
                } catch { /* non-fatal */ }
            }

            setIsSubmitting(false);
            router.replace(`/booking/payment-upi?bookingId=${encodeURIComponent(result.bookingId)}` as any);
        } catch (err) {
            setIsSubmitting(false);
            Alert.alert('Error', 'Something went wrong. Please try again.');
            console.error('Booking error:', err);
        }
    }, [step, hall, priceBreakdown, selectedDate, selectedSlot, guestCount, specialRequests,
        customerName, customerEmail, customerPhone, id, router, animateStep, fetchAddons,
        addonSelections, addonsFetchedForDate, selectedAddonCount]);

    const handleBack = useCallback(() => {
        if (step > 0) animateStep(step - 1);
        else router.back();
    }, [step, router, animateStep]);

    const handleGoToLogin = useCallback(() => {
        router.push(`/customer-login?redirect=${encodeURIComponent(`/booking/${id}`)}` as any);
    }, [id, router]);

    if (isLoadingHall) {
        return (
            <View style={styles.errorContainer}>
                <Text style={styles.errorText}>Loading venue...</Text>
            </View>
        );
    }

    if (!hall) {
        return (
            <View style={styles.errorContainer}>
                <Text style={styles.errorText}>Venue not found</Text>
            </View>
        );
    }

    const ctaLabel = isSubmitting ? 'Booking...' : step === 4 ? 'Pay Advance' : step === 3 ? 'Continue' : 'Proceed';

    return (
        <View style={styles.screen}>
            <Stack.Screen options={{
                title: 'Book Venue',
                headerStyle: { backgroundColor: Colors.surface },
                headerTintColor: Colors.text,
                headerShadowVisible: false,
                headerLeft: () => (
                    <AnimatedPressable onPress={handleBack} style={{ marginLeft: -Spacing.sm }}>
                        <ChevronLeft size={24} color={Colors.text} />
                    </AnimatedPressable>
                )
            }} />

            <View style={styles.headerIndicator}>
                {STEPS.map((label, i) => (
                    <View key={label} style={styles.headerStepColumn}>
                        <View style={[
                            styles.stepBullet,
                            i <= step && styles.stepBulletActive,
                            i < step && styles.stepBulletDone
                        ]}>
                            {i < step ? <CheckCircle2 size={14} color="#FFFFFF" /> :
                                <Text style={[styles.bulletText, i <= step && styles.bulletTextActive]}>{i + 1}</Text>}
                        </View>
                        <Text style={[styles.stepLabelText, i <= step && styles.stepLabelActive]}>{label}</Text>
                        {i < STEPS.length - 1 && (
                            <View style={[styles.connector, i < step && styles.connectorActive]} />
                        )}
                    </View>
                ))}
            </View>

            <Animated.View style={[styles.container, { opacity: fadeAnim }]}>
                <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
                    {/* ── Login prompt banner ── */}
                    {showLoginPrompt && (
                        <View style={styles.loginBanner}>
                            <LogIn size={20} color={Colors.primary} />
                            <View style={styles.loginBannerContent}>
                                <Text style={styles.loginBannerTitle}>Sign in to continue booking</Text>
                                <Text style={styles.loginBannerSubtitle}>You'll be brought right back here after signing in.</Text>
                            </View>
                            <AnimatedPressable onPress={handleGoToLogin} scaleValue={0.95}>
                                <View style={styles.loginBannerButton}>
                                    <Text style={styles.loginBannerButtonText}>Sign In</Text>
                                </View>
                            </AnimatedPressable>
                        </View>
                    )}

                    {step === 0 && (
                        <View style={styles.stepBox}>
                            <View style={styles.sectionHeader}>
                                <Text style={styles.title}>Select a Date</Text>
                                <Text style={styles.subtitle}>Prices vary based on peak wedding seasons</Text>
                            </View>

                            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.datePickerScroll}>
                                {dates.map((d) => {
                                    const isSelected = d.date === selectedDate;
                                    const isBooked = d.isBooked;
                                    const isPartial = d.isPartial;
                                    return (
                                        <View key={d.date} style={styles.dateItemWrapper}>
                                            <AnimatedPressable
                                                onPress={() => !isBooked && setSelectedDate(d.date)}
                                                scaleValue={0.92}
                                                disabled={isBooked}
                                            >
                                                <View style={[
                                                    styles.dateBox,
                                                    isSelected && styles.dateBoxSelected,
                                                    isBooked && styles.dateBoxBooked,
                                                    isPartial && styles.dateBoxPartial
                                                ]}>
                                                    <Text style={[styles.dateD, isSelected && styles.dateTextSelected, isBooked && styles.dateTextDisabled]}>{d.day}</Text>
                                                    <Text style={[styles.dateN, isSelected && styles.dateTextSelected, isBooked && styles.dateTextDisabled]}>{d.label}</Text>
                                                    <Text style={[styles.dateM, isSelected && styles.dateTextSelected, isBooked && styles.dateTextDisabled]}>{d.month}</Text>
                                                    {isBooked && (
                                                        <View style={styles.bookedOverlay}>
                                                            <Text style={styles.bookedText}>FULL</Text>
                                                        </View>
                                                    )}
                                                    {isPartial && !isSelected && (
                                                        <View style={styles.partialDot} />
                                                    )}
                                                </View>
                                            </AnimatedPressable>
                                        </View>
                                    );
                                })}
                            </ScrollView>

                            <View style={styles.legend}>
                                <View style={styles.legendItem}><View style={[styles.legendColor, { backgroundColor: Colors.error }]} /><Text style={styles.legendText}>Booked</Text></View>
                                <View style={styles.legendItem}><View style={[styles.legendColor, { backgroundColor: Colors.warning }]} /><Text style={styles.legendText}>Partial</Text></View>
                                <View style={styles.legendItem}><View style={[styles.legendColor, { backgroundColor: '#FFFFFF', borderColor: Colors.border }]} /><Text style={styles.legendText}>Available</Text></View>
                            </View>

                            {selectedDate && (
                                <View style={styles.dynamicPriceCard}>
                                    <View style={styles.priceCardHeader}>
                                        <View style={styles.priceIconBox}>
                                            <Calendar size={20} color={Colors.primary} />
                                        </View>
                                        <View style={{ flex: 1 }}>
                                            <Text style={styles.priceCardTitle}>{new Date(selectedDate).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</Text>
                                            <Text style={styles.priceCardSeason}>{SEASON_LABELS[season]}</Text>
                                        </View>
                                        <Badge text={season === 'peak' ? 'Peak' : season === 'shoulder' ? 'High' : 'Off-Peak'} variant={season === 'peak' ? 'error' : season === 'shoulder' ? 'warning' : 'success'} />
                                    </View>
                                    <View style={styles.priceContent}>
                                        <Info size={14} color={Colors.textTertiary} />
                                        <Text style={styles.priceNote}>
                                            {season === 'peak' ? 'This is a high-demand auspicious date. Prices reflect seasonal surcharges.' :
                                                season === 'shoulder' ? 'Regular booking period. Standard pricing applies.' :
                                                    "Great choice! You're eligible for off-season discounts on this date."}
                                        </Text>
                                    </View>
                                </View>
                            )}

                            {!selectedDate && (
                                <View style={styles.emptyStateContainer}>
                                    <Sparkles size={40} color={Colors.primaryFaded2} />
                                    <Text style={styles.emptyStateTitle}>Choose your big day</Text>
                                    <Text style={styles.emptyStateSubtitle}>See real-time availability and season-based pricing instantly</Text>
                                </View>
                            )}
                        </View>
                    )}

                    {step === 1 && (
                        <View style={styles.stepBox}>
                            <View style={styles.sectionHeader}>
                                <Text style={styles.title}>Choose a Slot</Text>
                                <Text style={styles.subtitle}>Unlock lower rates with specific time blocks</Text>
                            </View>

                            {(['morning', 'evening', 'full_day'] as SlotType[]).map((slot) => {
                                const isSelected = selectedSlot === slot;
                                const breakdown = calculatePriceBreakdown(hall.price_per_day, season, slot);
                                const bookedForDate = (allBookings ?? []).filter((b: any) =>
                                    (b.date === selectedDate || b.event_date === selectedDate)
                                );
                                const isSlotDisabled = bookedForDate.some((b: any) =>
                                    (b.slot === slot || b.slot_type === slot) ||
                                    (b.slot === 'full_day' || b.slot_type === 'full_day')
                                );

                                return (
                                    <View key={slot} style={styles.slotWrapper}>
                                        <AnimatedPressable
                                            onPress={() => !isSlotDisabled && setSelectedSlot(slot)}
                                            scaleValue={0.96}
                                            disabled={isSlotDisabled}
                                        >
                                            <View style={[
                                                styles.premiumSlotCard,
                                                isSelected && styles.slotSelected,
                                                isSlotDisabled && styles.slotDisabled
                                            ]}>
                                                <View style={styles.slotLeft}>
                                                    <View style={[styles.slotIconCircle, isSelected && styles.slotIconCircleSelected]}>
                                                        {slot === 'morning' ? <Sun size={22} color={isSelected ? '#FFF' : Colors.primary} /> :
                                                            slot === 'evening' ? <Sunset size={22} color={isSelected ? '#FFF' : Colors.primary} /> :
                                                                <Calendar size={22} color={isSelected ? '#FFF' : Colors.primary} />}
                                                    </View>
                                                    <View>
                                                        <Text style={[styles.slotLabel, isSelected && styles.slotLabelActive]}>{SLOT_LABELS[slot]}</Text>
                                                        <Text style={styles.slotTiming}>
                                                            {slot === 'morning' ? '6 AM - 2 PM' : slot === 'evening' ? '4 PM - 12 AM' : '6 AM - 12 AM'}
                                                        </Text>
                                                    </View>
                                                </View>
                                                <View style={styles.slotRight}>
                                                    {isSlotDisabled ? (
                                                        <Badge text="Booked" variant="error" />
                                                    ) : (
                                                        <>
                                                            <Text style={[styles.slotPriceText, isSelected && styles.slotPriceSelected]}>{formatCurrencyFull(breakdown.slotPrice)}</Text>
                                                            {breakdown.discount > 0 && <Text style={styles.slotSaving}>Save {formatCurrencyFull(breakdown.discount)}</Text>}
                                                        </>
                                                    )}
                                                </View>
                                            </View>
                                        </AnimatedPressable>
                                    </View>
                                );
                            })}
                        </View>
                    )}

                    {step === 2 && (
                        <View style={styles.stepBox}>
                            <View style={styles.sectionHeader}>
                                <Text style={styles.title}>Guest Details</Text>
                                <Text style={styles.subtitle}>Help us prepare the hall for your event</Text>
                            </View>

                            <View style={styles.inputSection}>
                                <View style={styles.inputGroup}>
                                    <Text style={styles.lText}>Customer Name</Text>
                                    <View style={styles.inputFieldWrapper}>
                                        <TextInput
                                            style={styles.textInput}
                                            placeholder="Enter full name"
                                            placeholderTextColor={Colors.textTertiary}
                                            value={customerName}
                                            onChangeText={setCustomerName}
                                            autoCapitalize="words"
                                            editable={!isSubmitting}
                                        />
                                    </View>
                                </View>

                                <View style={styles.inputGroup}>
                                    <Text style={styles.lText}>Email Address</Text>
                                    <View style={styles.inputFieldWrapper}>
                                        <TextInput
                                            style={styles.textInput}
                                            placeholder="name@example.com"
                                            placeholderTextColor={Colors.textTertiary}
                                            value={customerEmail}
                                            onChangeText={setCustomerEmail}
                                            keyboardType="email-address"
                                            autoCapitalize="none"
                                            editable={!isSubmitting}
                                        />
                                    </View>
                                </View>

                                <View style={styles.inputGroup}>
                                    <Text style={styles.lText}>Phone Number (optional)</Text>
                                    <View style={styles.inputFieldWrapper}>
                                        <TextInput
                                            style={styles.textInput}
                                            placeholder="+91 98765 43210"
                                            placeholderTextColor={Colors.textTertiary}
                                            value={customerPhone}
                                            onChangeText={setCustomerPhone}
                                            keyboardType="phone-pad"
                                            editable={!isSubmitting}
                                        />
                                    </View>
                                </View>

                                <View style={styles.inputGroup}>
                                    <View style={styles.labelRow}>
                                        <Text style={styles.lText}>Expected Headcount</Text>
                                        <Text style={styles.lHint}>{hall.capacity_min}-{hall.capacity_max}</Text>
                                    </View>
                                    <View style={styles.inputFieldWrapper}>
                                        <Users size={18} color={Colors.textTertiary} style={styles.inputIcon} />
                                        <TextInput
                                            style={styles.textInput}
                                            placeholder="Enter guest count"
                                            placeholderTextColor={Colors.textTertiary}
                                            value={guestCount}
                                            onChangeText={setGuestCount}
                                            keyboardType="number-pad"
                                        />
                                    </View>
                                    {guestCount && (parseInt(guestCount) < hall.capacity_min || parseInt(guestCount) > hall.capacity_max) && (
                                        <View style={styles.errorBox}>
                                            <AlertTriangle size={12} color={Colors.error} />
                                            <Text style={styles.errorTextSmall}>Headcount must be within hall's capacity</Text>
                                        </View>
                                    )}
                                </View>

                                <View style={styles.inputGroup}>
                                    <Text style={styles.lText}>Special Requests</Text>
                                    <View style={[styles.inputFieldWrapper, styles.multiLineWrapper]}>
                                        <TextInput
                                            style={[styles.textInput, styles.multiLineInput]}
                                            placeholder="Decoration needs, catering setup, extra rooms..."
                                            placeholderTextColor={Colors.textTertiary}
                                            value={specialRequests}
                                            onChangeText={setSpecialRequests}
                                            multiline
                                            numberOfLines={4}
                                        />
                                    </View>
                                </View>
                            </View>
                        </View>
                    )}

                    {step === 3 && (
                        <View style={styles.stepBox}>
                            <View style={styles.sectionHeader}>
                                <Text style={styles.title}>Add-On Services</Text>
                                <Text style={styles.subtitle}>All optional — pick what you need for your event</Text>
                            </View>

                            {isLoadingAddons && (
                                <View style={styles.addonLoading}>
                                    <ActivityIndicator size="large" color={Colors.primary} />
                                    <Text style={styles.addonLoadingText}>Finding available services for {selectedDate}...</Text>
                                </View>
                            )}

                            {addonError && !isLoadingAddons && (
                                <View style={styles.addonErrorBox}>
                                    <AlertTriangle size={18} color={Colors.error} />
                                    <Text style={styles.addonErrorText}>{addonError}</Text>
                                    <AnimatedPressable onPress={() => fetchAddons(selectedDate)} scaleValue={0.95}>
                                        <Text style={styles.addonRetryText}>Retry</Text>
                                    </AnimatedPressable>
                                </View>
                            )}

                            {!isLoadingAddons && !addonError && addonListings.length === 0 && (
                                <View style={styles.addonEmpty}>
                                    <Sparkles size={36} color={Colors.textTertiary} />
                                    <Text style={styles.addonEmptyTitle}>No add-ons available</Text>
                                    <Text style={styles.addonEmptySubtitle}>No service vendors are available for this date. You can continue without add-ons.</Text>
                                </View>
                            )}

                            {!isLoadingAddons && addonListings.length > 0 && (
                                <>
                                    {selectedAddonCount > 0 && (
                                        <View style={styles.addonCountBadge}>
                                            <CheckCircle2 size={14} color={Colors.success} />
                                            <Text style={styles.addonCountText}>{selectedAddonCount} add-on{selectedAddonCount > 1 ? 's' : ''} selected</Text>
                                        </View>
                                    )}

                                    {ADDON_SECTOR_ORDER.filter(s => addonsByCategory[s]?.length).map(sector => {
                                        const listings = addonsByCategory[sector] ?? [];
                                        const config = SECTOR_CONFIGS[sector];
                                        const selected = addonSelections[sector];
                                        return (
                                            <View key={sector} style={styles.addonCategory}>
                                                <View style={styles.addonCategoryHeader}>
                                                    <View style={[styles.addonCategoryDot, { backgroundColor: config.badgeColor }]} />
                                                    <Text style={styles.addonCategoryTitle}>{config.displayName}</Text>
                                                    {selected && (
                                                        <AnimatedPressable
                                                            onPress={() => setAddonSelections(prev => {
                                                                const next = { ...prev };
                                                                delete next[sector];
                                                                return next;
                                                            })}
                                                            scaleValue={0.9}
                                                        >
                                                            <View style={styles.addonClearBtn}>
                                                                <X size={12} color={Colors.textTertiary} />
                                                            </View>
                                                        </AnimatedPressable>
                                                    )}
                                                </View>

                                                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.addonCardScroll}>
                                                    {listings.map(listing => {
                                                        const isSelected = selected?.id === listing.id;
                                                        return (
                                                            <AnimatedPressable
                                                                key={listing.id}
                                                                onPress={() => setAddonSelections(prev => ({
                                                                    ...prev,
                                                                    [sector]: isSelected ? undefined : listing,
                                                                }))}
                                                                scaleValue={0.95}
                                                            >
                                                                <View style={[styles.addonCard, isSelected && styles.addonCardSelected, { borderColor: isSelected ? config.badgeColor : Colors.border }]}>
                                                                    {listing.photos?.[0] ? (
                                                                        <Image source={{ uri: listing.photos[0] }} style={styles.addonCardImage} contentFit="cover" />
                                                                    ) : (
                                                                        <View style={[styles.addonCardImagePlaceholder, { backgroundColor: config.badgeColor + '22' }]}>
                                                                            <Text style={{ fontSize: 24 }}>🎪</Text>
                                                                        </View>
                                                                    )}
                                                                    {isSelected && (
                                                                        <View style={[styles.addonSelectedBadge, { backgroundColor: config.badgeColor }]}>
                                                                            <CheckCircle2 size={12} color="#FFF" />
                                                                        </View>
                                                                    )}
                                                                    <View style={styles.addonCardBody}>
                                                                        <Text style={styles.addonCardTitle} numberOfLines={1}>{listing.title}</Text>
                                                                        {listing.vendor_name && (
                                                                            <Text style={styles.addonCardVendor} numberOfLines={1}>{listing.vendor_name}</Text>
                                                                        )}
                                                                        <Text style={[styles.addonCardPrice, isSelected && { color: config.badgeColor }]}>
                                                                            {formatCurrencyFull(listing.base_price)}
                                                                        </Text>
                                                                        {listing.rating != null && (
                                                                            <Text style={styles.addonCardRating}>★ {listing.rating.toFixed(1)}</Text>
                                                                        )}
                                                                    </View>
                                                                </View>
                                                            </AnimatedPressable>
                                                        );
                                                    })}
                                                </ScrollView>
                                            </View>
                                        );
                                    })}

                                    {selectedAddonCount > 0 && priceBreakdown && (
                                        <View style={styles.addonSummaryCard}>
                                            <Text style={styles.addonSummaryTitle}>Cost Summary</Text>
                                            <View style={styles.addonSummaryRow}>
                                                <Text style={styles.addonSummaryLabel}>Venue ({SLOT_LABELS[selectedSlot!]})</Text>
                                                <Text style={styles.addonSummaryValue}>{formatCurrencyFull(priceBreakdown.totalAmount)}</Text>
                                            </View>
                                            {(Object.values(addonSelections).filter(Boolean) as AddonListing[]).map(addon => (
                                                <View key={addon.id} style={styles.addonSummaryRow}>
                                                    <Text style={styles.addonSummaryLabel} numberOfLines={1}>{addon.title}</Text>
                                                    <Text style={styles.addonSummaryValue}>{formatCurrencyFull(addon.base_price)}</Text>
                                                </View>
                                            ))}
                                            <View style={[styles.addonSummaryRow, styles.addonSummaryTotal]}>
                                                <Text style={styles.addonSummaryTotalLabel}>Grand Total</Text>
                                                <Text style={styles.addonSummaryTotalValue}>{formatCurrencyFull(priceBreakdown.totalAmount + addonTotalPrice)}</Text>
                                            </View>
                                        </View>
                                    )}
                                </>
                            )}
                        </View>
                    )}

                    {step === 4 && (
                        <View style={styles.stepBox}>
                            <View style={styles.sectionHeader}>
                                <Text style={styles.title}>Booking Summary</Text>
                                <Text style={styles.subtitle}>Review your details before payment</Text>
                            </View>

                            <View style={styles.finalCard}>
                                <View style={styles.finalHallHeader}>
                                    <View style={{ flex: 1 }}>
                                        <Text style={styles.finalHallName}>{hall.name}</Text>
                                        <Text style={styles.finalHallArea}>{hall.area}, {hall.city}</Text>
                                    </View>
                                    <View style={styles.verifiedBox}>
                                        <CheckCircle2 size={16} color={Colors.success} />
                                    </View>
                                </View>

                                <View style={styles.finalDetailsGrid}>
                                    <View style={styles.detailBox}>
                                        <Text style={styles.detailLabel}>Date</Text>
                                        <Text style={styles.detailValue}>{new Date(selectedDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</Text>
                                    </View>
                                    <View style={styles.detailBox}>
                                        <Text style={styles.detailLabel}>Slot</Text>
                                        <Text style={styles.detailValue}>{SLOT_LABELS[selectedSlot!]}</Text>
                                    </View>
                                    <View style={styles.detailBox}>
                                        <Text style={styles.detailLabel}>Guests</Text>
                                        <Text style={styles.detailValue}>{guestCount}</Text>
                                    </View>
                                </View>

                                <View style={styles.contactSummary}>
                                    <Text style={styles.contactSummaryName}>{customerName}</Text>
                                    <Text style={styles.contactSummaryMeta}>{customerPhone} · {customerEmail}</Text>
                                </View>

                                <View style={styles.finalPricing}>
                                    <View style={styles.pRow}><Text style={styles.pLabel}>Base Price</Text><Text style={styles.pValue}>{formatCurrencyFull(priceBreakdown!.slotPrice)}</Text></View>
                                    <View style={styles.pRow}><Text style={[styles.pLabel, { color: Colors.success }]}>ConventionHub Discount</Text><Text style={[styles.pValue, { color: Colors.success }]}>-{formatCurrencyFull(priceBreakdown!.discount)}</Text></View>
                                    <View style={styles.pTotalRow}><Text style={styles.pTotalLabel}>Total Pay</Text><Text style={styles.pTotalValue}>{formatCurrencyFull(priceBreakdown!.totalAmount)}</Text></View>
                                    <View style={styles.advanceNotice}>
                                        <Text style={styles.advanceNoticeText}>Advance Payable Today (30%)</Text>
                                        <Text style={styles.advanceNoticeAmount}>{formatCurrencyFull(priceBreakdown!.advanceAmount)}</Text>
                                    </View>
                                </View>
                            </View>

                            <View style={styles.safetyCard}>
                                <Shield size={20} color={Colors.success} />
                                <Text style={styles.safetyText}>Your booking is protected by ConventionHub Secure Guard</Text>
                            </View>
                        </View>
                    )}
                </ScrollView>
            </Animated.View>

            <View style={styles.stickyFooter}>
                <View style={styles.footerInner}>
                    <View style={styles.footerLeft}>
                        {priceBreakdown ? (
                            <View>
                                <Text style={styles.footerTotalLabel}>Advance Amount</Text>
                                <Text style={styles.footerTotalPrice}>{formatCurrencyFull(priceBreakdown.advanceAmount)}</Text>
                            </View>
                        ) : (
                            <View>
                                <Text style={styles.footerTotalLabel}>Steps Remaining</Text>
                                <Text style={styles.footerStepStatus}>{step + 1} of 4 Completed</Text>
                            </View>
                        )}
                    </View>
                    <AnimatedPressable onPress={handleNext} disabled={!canProceed() || isSubmitting} scaleValue={0.97}>
                        <LinearGradient
                            colors={(canProceed() && !isSubmitting) ? [Colors.primary, Colors.primaryDark] : [Colors.warmGray, Colors.warmGray]}
                            style={styles.ctaButton}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 0 }}
                        >
                            {isSubmitting ? (
                                <ActivityIndicator size="small" color="#FFFFFF" />
                            ) : (
                                <>
                                    <Text style={styles.ctaText}>{ctaLabel}</Text>
                                    <ChevronRight size={18} color="#FFFFFF" />
                                </>
                            )}
                        </LinearGradient>
                    </AnimatedPressable>
                </View>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.ivory },
    headerIndicator: {
        flexDirection: 'row',
        paddingHorizontal: Spacing.xl,
        paddingVertical: Spacing.xl,
        backgroundColor: Colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: Colors.borderLight,
        ...Shadow.sm
    },
    headerStepColumn: { flex: 1, alignItems: 'center', position: 'relative' },
    stepBullet: { width: 32, height: 32, borderRadius: 16, borderWidth: 2, borderColor: Colors.border, backgroundColor: '#FFFFFF', justifyContent: 'center', alignItems: 'center', zIndex: 2 },
    stepBulletActive: { borderColor: Colors.primary, backgroundColor: Colors.primary },
    stepBulletDone: { borderColor: Colors.success, backgroundColor: Colors.success },
    bulletText: { fontSize: 13, fontWeight: FontWeight.bold, color: Colors.textTertiary },
    bulletTextActive: { color: '#FFFFFF' },
    stepLabelText: { fontSize: 10, marginTop: 6, fontWeight: FontWeight.bold, color: Colors.textTertiary, textTransform: 'uppercase', letterSpacing: 0.5 },
    stepLabelActive: { color: Colors.primary },
    connector: { position: 'absolute', top: 16, right: '-50%', width: '100%', height: 2, backgroundColor: Colors.border, zIndex: 1 },
    connectorActive: { backgroundColor: Colors.success },

    container: { flex: 1 },
    scrollContent: { paddingBottom: 150 },
    stepBox: { padding: Spacing.xl },
    sectionHeader: { marginBottom: Spacing.xl },
    title: { fontSize: 28, fontWeight: FontWeight.bold, color: Colors.text, fontFamily: SERIF_FONT },
    subtitle: { fontSize: 14, color: Colors.textSecondary, marginTop: 4 },

    loginBanner: {
        flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
        backgroundColor: Colors.primaryFaded, marginHorizontal: Spacing.xl, marginTop: Spacing.lg,
        padding: Spacing.lg, borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.primary + '33',
        ...Shadow.sm,
    },
    loginBannerContent: { flex: 1 },
    loginBannerTitle: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.primaryDark },
    loginBannerSubtitle: { fontSize: FontSize.xs, color: Colors.textSecondary, marginTop: 2 },
    loginBannerButton: {
        backgroundColor: Colors.primary, paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm,
        borderRadius: Radius.md,
    },
    loginBannerButtonText: { color: '#FFFFFF', fontSize: FontSize.sm, fontWeight: FontWeight.bold },

    datePickerScroll: { paddingVertical: Spacing.md, gap: 12 },
    dateItemWrapper: { width: 70 },
    dateBox: { height: 90, borderRadius: 16, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, justifyContent: 'center', alignItems: 'center', position: 'relative', overflow: 'hidden' },
    dateBoxSelected: { backgroundColor: Colors.primary, borderColor: Colors.primary, ...Shadow.md },
    dateBoxBooked: { backgroundColor: '#F0F0F0', borderColor: '#EAEAEA', opacity: 0.6 },
    dateBoxPartial: { borderColor: Colors.warning, borderWidth: 2 },
    dateD: { fontSize: 10, color: Colors.textTertiary, textTransform: 'uppercase', fontWeight: FontWeight.bold },
    dateN: { fontSize: 24, fontWeight: FontWeight.heavy, color: Colors.text, marginVertical: 2 },
    dateM: { fontSize: 12, color: Colors.textTertiary, fontWeight: FontWeight.medium },
    dateTextSelected: { color: '#FFFFFF' },
    dateTextDisabled: { color: '#999' },
    bookedOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
    bookedText: { color: '#FFFFFF', fontSize: 10, fontWeight: FontWeight.heavy, backgroundColor: Colors.error, paddingHorizontal: 6, borderRadius: 4 },
    partialDot: { position: 'absolute', top: 6, right: 6, width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.warning },

    legend: { flexDirection: 'row', gap: Spacing.lg, marginTop: Spacing.md, marginBottom: Spacing.xxl },
    legendItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
    legendColor: { width: 12, height: 12, borderRadius: 3, borderWidth: 1 },
    legendText: { fontSize: 12, color: Colors.textSecondary, fontWeight: FontWeight.medium },

    dynamicPriceCard: { backgroundColor: Colors.surface, borderRadius: 20, padding: Spacing.lg, ...Shadow.md, borderLeftWidth: 4, borderLeftColor: Colors.primary },
    priceCardHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, paddingBottom: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.borderLight },
    priceIconBox: { width: 40, height: 40, borderRadius: 12, backgroundColor: Colors.primaryFaded, justifyContent: 'center', alignItems: 'center' },
    priceCardTitle: { fontSize: 15, fontWeight: FontWeight.bold, color: Colors.text },
    priceCardSeason: { fontSize: 12, color: Colors.textTertiary, marginTop: 1 },
    priceContent: { flexDirection: 'row', gap: Spacing.sm, marginTop: Spacing.md, alignItems: 'flex-start' },
    priceNote: { flex: 1, fontSize: 13, color: Colors.textSecondary, lineHeight: 18 },

    emptyStateContainer: { alignItems: 'center', marginTop: Spacing.massive, paddingHorizontal: Spacing.xl },
    emptyStateTitle: { fontSize: 18, fontWeight: FontWeight.bold, color: Colors.text, marginTop: Spacing.lg, fontFamily: SERIF_FONT },
    emptyStateSubtitle: { fontSize: 14, color: Colors.textTertiary, textAlign: 'center', marginTop: Spacing.xs, lineHeight: 20, maxWidth: 260 },
    slotWrapper: { marginBottom: Spacing.md },
    premiumSlotCard: { flexDirection: 'row', backgroundColor: Colors.surface, borderRadius: 16, padding: Spacing.lg, marginBottom: Spacing.md, borderWidth: 1.5, borderColor: Colors.border, justifyContent: 'space-between', alignItems: 'center' },
    slotSelected: { borderColor: Colors.primary, backgroundColor: Colors.primaryFaded, ...Shadow.sm },
    slotDisabled: { opacity: 0.5, backgroundColor: '#F9F9F9' },
    slotLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
    slotIconCircle: { width: 48, height: 48, borderRadius: 24, backgroundColor: Colors.ivory, justifyContent: 'center', alignItems: 'center' },
    slotIconCircleSelected: { backgroundColor: Colors.primary },
    slotLabel: { fontSize: 17, fontWeight: FontWeight.bold, color: Colors.text },
    slotLabelActive: { color: Colors.primary },
    slotTiming: { fontSize: 12, color: Colors.textTertiary, marginTop: 2 },
    slotRight: { alignItems: 'flex-end' },
    slotPriceText: { fontSize: 17, fontWeight: FontWeight.bold, color: Colors.text },
    slotPriceSelected: { color: Colors.primary },
    slotSaving: { fontSize: 11, color: Colors.success, fontWeight: FontWeight.bold, marginTop: 2 },

    inputSection: { gap: Spacing.xl },
    inputGroup: {},
    labelRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: Spacing.sm },
    lText: { fontSize: 14, fontWeight: FontWeight.bold, color: Colors.text },
    lHint: { fontSize: 12, color: Colors.textTertiary },
    inputFieldWrapper: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.surface, borderRadius: 12, paddingHorizontal: Spacing.lg, borderWidth: 1, borderColor: Colors.border },
    inputIcon: { marginRight: 10 },
    textInput: { flex: 1, height: 50, fontSize: 15, color: Colors.text },
    multiLineWrapper: { height: 120, paddingVertical: 10 },
    multiLineInput: { height: '100%', textAlignVertical: 'top' },
    errorBox: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6 },
    errorTextSmall: { fontSize: 11, color: Colors.error, fontWeight: FontWeight.medium },

    finalCard: { backgroundColor: Colors.surface, borderRadius: 24, padding: Spacing.xl, ...Shadow.lg },
    finalHallHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: Spacing.xl },
    finalHallName: { fontSize: 20, fontWeight: FontWeight.bold, color: Colors.text, fontFamily: SERIF_FONT },
    finalHallArea: { fontSize: 13, color: Colors.textTertiary, marginTop: 2 },
    verifiedBox: { width: 32, height: 32, borderRadius: 16, backgroundColor: Colors.successLight, justifyContent: 'center', alignItems: 'center' },
    finalDetailsGrid: { flexDirection: 'row', gap: 12, marginBottom: Spacing.xl },
    contactSummary: { backgroundColor: Colors.ivory, padding: 12, borderRadius: 12, marginBottom: Spacing.xl },
    contactSummaryName: { fontSize: 14, fontWeight: FontWeight.bold, color: Colors.text },
    contactSummaryMeta: { fontSize: 12, color: Colors.textSecondary, marginTop: 3 },
    detailBox: { flex: 1, backgroundColor: Colors.ivory, padding: 12, borderRadius: 12, alignItems: 'center' },
    detailLabel: { fontSize: 10, color: Colors.textTertiary, textTransform: 'uppercase', marginBottom: 4, fontWeight: FontWeight.bold },
    detailValue: { fontSize: 14, fontWeight: FontWeight.bold, color: Colors.text },
    finalPricing: { borderTopWidth: 1, borderTopColor: Colors.borderLight, paddingTop: Spacing.lg },
    pRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
    pLabel: { fontSize: 14, color: Colors.textSecondary },
    pValue: { fontSize: 14, fontWeight: FontWeight.semibold, color: Colors.text },
    pTotalRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8, marginBottom: Spacing.xl },
    pTotalLabel: { fontSize: 18, fontWeight: FontWeight.bold, color: Colors.text },
    pTotalValue: { fontSize: 22, fontWeight: FontWeight.heavy, color: Colors.primary },
    advanceNotice: { backgroundColor: Colors.primary, padding: 16, borderRadius: 16, alignItems: 'center', gap: 4 },
    advanceNoticeText: { color: 'rgba(255,255,255,0.8)', fontSize: 12, fontWeight: FontWeight.bold },
    advanceNoticeAmount: { color: '#FFFFFF', fontSize: 24, fontWeight: FontWeight.heavy },

    safetyCard: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: Spacing.xl, backgroundColor: Colors.successLight, padding: 12, borderRadius: 12 },
    safetyText: { fontSize: 12, color: Colors.success, fontWeight: FontWeight.semibold, flex: 1 },

    stickyFooter: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: Colors.surface, borderTopWidth: 1, borderTopColor: Colors.borderLight, paddingBottom: Platform.OS === 'ios' ? 34 : Spacing.lg, paddingTop: Spacing.md, paddingHorizontal: Spacing.xl, ...Shadow.lg },
    footerInner: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
    footerLeft: {},
    footerTotalLabel: { fontSize: 12, color: Colors.textTertiary, fontWeight: FontWeight.bold, textTransform: 'uppercase' },
    footerTotalPrice: { fontSize: 20, fontWeight: FontWeight.heavy, color: Colors.text },
    footerStepStatus: { fontSize: 14, fontWeight: FontWeight.bold, color: Colors.primary },
    ctaButton: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 28, height: 52, borderRadius: 14 },
    ctaText: { color: '#FFFFFF', fontSize: 16, fontWeight: FontWeight.bold },

    errorContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.background },
    errorText: { fontSize: FontSize.lg, color: Colors.text },

    addonLoading: { alignItems: 'center', paddingVertical: Spacing.massive, gap: Spacing.md },
    addonLoadingText: { fontSize: FontSize.sm, color: Colors.textSecondary, textAlign: 'center' },
    addonErrorBox: { backgroundColor: Colors.errorLight, borderRadius: Radius.lg, padding: Spacing.lg, gap: Spacing.sm, alignItems: 'center' },
    addonErrorText: { fontSize: FontSize.sm, color: Colors.error, textAlign: 'center' },
    addonRetryText: { fontSize: FontSize.sm, color: Colors.primary, fontWeight: FontWeight.bold },
    addonEmpty: { alignItems: 'center', paddingVertical: Spacing.massive, gap: Spacing.md, paddingHorizontal: Spacing.xl },
    addonEmptyTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
    addonEmptySubtitle: { fontSize: FontSize.sm, color: Colors.textSecondary, textAlign: 'center', lineHeight: 20 },
    addonCountBadge: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, backgroundColor: Colors.successLight, paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderRadius: Radius.full, alignSelf: 'flex-start', marginBottom: Spacing.lg },
    addonCountText: { fontSize: FontSize.sm, color: Colors.success, fontWeight: FontWeight.bold },
    addonCategory: { marginBottom: Spacing.xl },
    addonCategoryHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginBottom: Spacing.md },
    addonCategoryDot: { width: 10, height: 10, borderRadius: 5 },
    addonCategoryTitle: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text, flex: 1 },
    addonClearBtn: { width: 24, height: 24, borderRadius: 12, backgroundColor: Colors.cream, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
    addonCardScroll: { gap: Spacing.md, paddingRight: Spacing.md },
    addonCard: { width: 150, borderRadius: Radius.xl, backgroundColor: Colors.surface, borderWidth: 1.5, overflow: 'hidden', ...Shadow.sm },
    addonCardSelected: { ...Shadow.md },
    addonCardImage: { width: '100%', height: 90 },
    addonCardImagePlaceholder: { width: '100%', height: 90, justifyContent: 'center', alignItems: 'center' },
    addonSelectedBadge: { position: 'absolute', top: Spacing.xs, right: Spacing.xs, width: 22, height: 22, borderRadius: 11, justifyContent: 'center', alignItems: 'center' },
    addonCardBody: { padding: Spacing.sm, gap: 2 },
    addonCardTitle: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.text },
    addonCardVendor: { fontSize: 11, color: Colors.textTertiary },
    addonCardPrice: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.primary, marginTop: 2 },
    addonCardRating: { fontSize: 11, color: Colors.gold },
    addonSummaryCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.lg, marginTop: Spacing.lg, ...Shadow.sm, borderWidth: 1, borderColor: Colors.borderLight },
    addonSummaryTitle: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: Spacing.md },
    addonSummaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: Spacing.sm },
    addonSummaryLabel: { fontSize: FontSize.sm, color: Colors.textSecondary, flex: 1, marginRight: Spacing.sm },
    addonSummaryValue: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.text },
    addonSummaryTotal: { borderTopWidth: 1, borderTopColor: Colors.borderLight, paddingTop: Spacing.sm, marginTop: Spacing.xs },
    addonSummaryTotalLabel: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text },
    addonSummaryTotalValue: { fontSize: FontSize.lg, fontWeight: FontWeight.heavy, color: Colors.primary },
});
