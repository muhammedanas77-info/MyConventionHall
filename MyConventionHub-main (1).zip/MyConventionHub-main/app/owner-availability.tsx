import React, { useState, useMemo, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Platform, Alert } from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { ChevronLeft, ChevronRight } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

type SlotStatus = 'available' | 'booked' | 'blocked';

interface DayData {
    date: number;
    dateStr: string;
    isToday: boolean;
    isPast: boolean;
    slots: Record<string, SlotStatus>;
}

const SLOT_KEYS = ['morning', 'evening', 'full_day'] as const;
const SLOT_DISPLAY: Record<string, string> = { morning: 'Morning (6AM-2PM)', evening: 'Evening (6PM-11PM)', full_day: 'Full Day (6AM-11PM)' };
const WEEK_DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function generateMonthData(year: number, month: number): DayData[] {
    const today = new Date();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const days: DayData[] = [];
    for (let d = 1; d <= daysInMonth; d++) {
        const date = new Date(year, month, d);
        const isPast = date < new Date(today.getFullYear(), today.getMonth(), today.getDate());
        const rand = Math.random();
        days.push({
            date: d, dateStr: date.toISOString().split('T')[0],
            isToday: date.toDateString() === today.toDateString(), isPast,
            slots: isPast ? { morning: 'booked', evening: 'booked', full_day: 'booked' } : {
                morning: rand < 0.2 ? 'booked' : rand < 0.3 ? 'blocked' : 'available',
                evening: rand < 0.25 ? 'booked' : rand < 0.35 ? 'blocked' : 'available',
                full_day: rand < 0.15 ? 'booked' : 'available',
            },
        });
    }
    return days;
}

export default function OwnerAvailabilityScreen() {
    const router = useRouter();
    const today = new Date();
    const [currentMonth, setCurrentMonth] = useState(today.getMonth());
    const [currentYear, setCurrentYear] = useState(today.getFullYear());
    const [selectedDay, setSelectedDay] = useState<DayData | null>(null);
    const [daySlots, setDaySlots] = useState<Record<string, SlotStatus>>({});

    const monthData = useMemo(() => generateMonthData(currentYear, currentMonth), [currentYear, currentMonth]);
    const monthName = new Date(currentYear, currentMonth).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
    const firstDayOfWeek = new Date(currentYear, currentMonth, 1).getDay();

    const handlePrevMonth = () => { if (currentMonth === 0) { setCurrentMonth(11); setCurrentYear(currentYear - 1); } else setCurrentMonth(currentMonth - 1); };
    const handleNextMonth = () => { if (currentMonth === 11) { setCurrentMonth(0); setCurrentYear(currentYear + 1); } else setCurrentMonth(currentMonth + 1); };

    const handleDayPress = useCallback((day: DayData) => {
        if (day.isPast) return;
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        setSelectedDay(day);
        setDaySlots({ ...day.slots });
    }, []);

    const toggleSlot = useCallback((slot: string) => {
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        setDaySlots(prev => {
            if (prev[slot] === 'booked') { Alert.alert('Cannot Change', 'This slot has an active booking'); return prev; }
            const next: SlotStatus = prev[slot] === 'available' ? 'blocked' : 'available';
            const updated = { ...prev, [slot]: next };
            if (slot === 'full_day') { updated.morning = next; updated.evening = next; }
            return updated;
        });
    }, []);

    const getDayStyles = (day: DayData) => {
        if (day.isPast) return { bg: 'transparent', text: Colors.warmGray };
        const vals = Object.values(day.slots);
        if (vals.every(s => s === 'booked')) {
            return { bg: Colors.primary, text: '#FFFFFF', dot: 'transparent' };
        }
        if (vals.every(s => s === 'blocked')) {
            return { bg: Colors.surface, text: Colors.textTertiary, dot: 'transparent', blocked: true };
        }
        if (vals.some(s => s === 'booked')) {
            return { bg: Colors.ivory, text: Colors.primaryDark, dot: Colors.primary };
        }
        return { bg: Colors.surface, text: Colors.text, dot: Colors.success };
    };

    return (
        <View style={styles.screen}>
            <Stack.Screen options={{
                title: 'Manage Availability',
                headerStyle: { backgroundColor: Colors.background },
                headerTintColor: Colors.primary,
                headerShadowVisible: false,
            }} />
            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
                <View style={styles.monthNav}>
                    <AnimatedPressable onPress={handlePrevMonth} scaleValue={0.9}><View style={styles.navBtn}><ChevronLeft size={20} color={Colors.primary} /></View></AnimatedPressable>
                    <Text style={styles.monthTitle}>{monthName}</Text>
                    <AnimatedPressable onPress={handleNextMonth} scaleValue={0.9}><View style={styles.navBtn}><ChevronRight size={20} color={Colors.primary} /></View></AnimatedPressable>
                </View>
                <View style={styles.calendarCard}>
                    <View style={styles.weekHeader}>{WEEK_DAYS.map(d => <Text key={d} style={styles.weekDay}>{d}</Text>)}</View>
                    <View style={styles.grid}>
                        {Array.from({ length: firstDayOfWeek }).map((_, i) => (
                            <View key={`e-${i}`} style={styles.dayWrap}>
                                <View style={styles.dayCell} />
                            </View>
                        ))}
                        {monthData.map((day) => {
                            const stylesForDay = getDayStyles(day);
                            const sel = selectedDay?.dateStr === day.dateStr;
                            return (
                                <View key={day.dateStr} style={styles.dayWrap}>
                                    <AnimatedPressable onPress={() => handleDayPress(day)} scaleValue={0.9} disabled={day.isPast}>
                                        <View style={[
                                            styles.dayCell,
                                            { backgroundColor: stylesForDay.bg },
                                            stylesForDay.blocked && styles.dayBlocked,
                                            day.isToday && styles.dayCellToday,
                                            sel && styles.dayCellSel
                                        ]}>
                                            <Text style={[styles.dayText, { color: stylesForDay.text }, day.isPast && styles.dayPast]}>{day.date}</Text>
                                            {stylesForDay.dot !== 'transparent' && !day.isPast && (
                                                <View style={[styles.dayDot, { backgroundColor: stylesForDay.dot }]} />
                                            )}
                                        </View>
                                    </AnimatedPressable>
                                </View>
                            );
                        })}
                    </View>
                </View>
                <View style={styles.legend}>
                    <View style={styles.legendItem}>
                        <View style={[styles.legendDot, { backgroundColor: Colors.primary }]} />
                        <Text style={styles.legendText}>Fully Booked</Text>
                    </View>
                    <View style={styles.legendItem}>
                        <View style={[styles.legendDot, { backgroundColor: Colors.success }]} />
                        <Text style={styles.legendText}>Available</Text>
                    </View>
                    <View style={styles.legendItem}>
                        <View style={[styles.legendDot, { backgroundColor: Colors.textTertiary }]} />
                        <Text style={styles.legendText}>Blocked</Text>
                    </View>
                </View>
                {selectedDay && (
                    <View style={styles.slotSheet}>
                        <Text style={styles.slotTitle}>{new Date(selectedDay.dateStr).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</Text>
                        {SLOT_KEYS.map(slot => {
                            const status = daySlots[slot] || 'available';
                            return (
                                <View key={slot} style={styles.slotRow}>
                                    <View style={styles.slotInfo}>
                                        <Text style={styles.slotName}>{SLOT_DISPLAY[slot]}</Text>
                                        <Text style={[styles.slotStatus, { color: status === 'booked' ? Colors.primary : status === 'blocked' ? Colors.error : Colors.success }]}>
                                            {status === 'booked' ? 'Booked' : status === 'blocked' ? 'Blocked' : 'Available'}
                                        </Text>
                                    </View>
                                    <AnimatedPressable onPress={() => toggleSlot(slot)} scaleValue={0.9} disabled={status === 'booked'}>
                                        <View style={[styles.toggle, status === 'available' && styles.toggleOn, status === 'booked' && styles.toggleBooked]}>
                                            <View style={[styles.toggleThumb, status === 'available' && styles.toggleThumbOn]} />
                                        </View>
                                    </AnimatedPressable>
                                </View>
                            );
                        })}
                        <AnimatedPressable onPress={() => { if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); setSelectedDay(null); Alert.alert('Saved', 'Availability updated'); }} scaleValue={0.96}>
                            <View style={styles.saveBtn}><Text style={styles.saveBtnText}>Save Changes</Text></View>
                        </AnimatedPressable>
                    </View>
                )}
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    scrollContent: { paddingBottom: Spacing.massive, paddingHorizontal: Spacing.lg, paddingTop: Spacing.sm },
    monthNav: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.xl },
    navBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: Colors.surface, justifyContent: 'center', alignItems: 'center', ...Shadow.sm },
    monthTitle: { fontSize: FontSize.xxl, fontWeight: FontWeight.bold, color: Colors.text },
    calendarCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, paddingVertical: Spacing.xl, ...Shadow.md, marginBottom: Spacing.xl },
    weekHeader: { flexDirection: 'row', paddingHorizontal: Spacing.md, marginBottom: Spacing.sm },
    weekDay: { flex: 1, textAlign: 'center', fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.textTertiary, textTransform: 'uppercase', letterSpacing: 0.5 },
    grid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: Spacing.md },
    dayWrap: { width: `${100 / 7}%` as any, padding: 2 },
    dayCell: { width: '100%', aspectRatio: 1, justifyContent: 'center', alignItems: 'center', borderRadius: Radius.md },
    dayBlocked: { borderWidth: 1, borderColor: Colors.borderLight, borderStyle: 'dashed' },
    dayCellToday: { borderColor: Colors.success, borderWidth: 2 },
    dayCellSel: { borderColor: Colors.gold, borderWidth: 2, ...Shadow.md },
    dayText: { fontSize: FontSize.md, fontWeight: FontWeight.semibold },
    dayPast: { textDecorationLine: 'line-through' },
    dayDot: { width: 4, height: 4, borderRadius: 2, position: 'absolute', bottom: 6 },
    legend: { flexDirection: 'row', justifyContent: 'center', gap: Spacing.xxl, marginBottom: Spacing.xxl },
    legendItem: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
    legendDot: { width: 14, height: 14, borderRadius: 7 },
    legendText: { fontSize: FontSize.sm, color: Colors.textSecondary, fontWeight: FontWeight.medium },
    slotSheet: { backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.xl, ...Shadow.md, marginBottom: Spacing.xl },
    slotTitle: { fontSize: FontSize.lg, fontWeight: FontWeight.heavy, color: Colors.primaryDark, marginBottom: Spacing.xl },
    slotRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: Spacing.lg, borderBottomWidth: 1, borderBottomColor: Colors.borderLight },
    slotInfo: { flex: 1 },
    slotName: { fontSize: FontSize.md, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: 4 },
    slotStatus: { fontSize: FontSize.sm, fontWeight: FontWeight.medium },
    toggle: { width: 52, height: 32, borderRadius: 16, backgroundColor: Colors.warmGray, justifyContent: 'center', paddingHorizontal: 4 },
    toggleOn: { backgroundColor: Colors.success },
    toggleBooked: { backgroundColor: Colors.primaryFaded },
    toggleThumb: { width: 24, height: 24, borderRadius: 12, backgroundColor: '#FFFFFF', ...Shadow.sm },
    toggleThumbOn: { alignSelf: 'flex-end' as const },
    saveBtn: { backgroundColor: Colors.primary, paddingVertical: Spacing.xl, borderRadius: Radius.xl, alignItems: 'center', marginTop: Spacing.xxl, ...Shadow.sm },
    saveBtnText: { color: '#FFFFFF', fontSize: FontSize.lg, fontWeight: FontWeight.bold },
});
