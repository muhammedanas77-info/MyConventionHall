import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import React, { useEffect } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { AppProvider } from "@/providers/AppProvider";
import { AuthProvider, useAuth } from "@/providers/AuthProvider";
import SplashOverlay from "@/components/ui/SplashOverlay";
import { useApp } from "@/providers/AppProvider";

const queryClient = new QueryClient();

// Syncs the authenticated user's display name into AppProvider so screens
// that read `userName` (e.g. owner dashboard greeting) stay up to date.
function AuthStateSync() {
    const { user, profile, role, isLoading } = useAuth();
    const { login, logout } = useApp();

    useEffect(() => {
        if (isLoading) return;

        if (user && role) {
            login(role, profile?.full_name || user.email?.split('@')[0] || role);
        } else if (!user) {
            logout();
        }
    }, [isLoading, user, role, profile, login, logout]);

    return null;
}

function RootLayoutNav() {
    return (
        <Stack screenOptions={{ headerBackTitle: "Back" }}>
            <Stack.Screen name="index" options={{ headerShown: false, animation: 'none' }} />
            <Stack.Screen name="onboarding" options={{ headerShown: false, animation: 'fade' }} />
            <Stack.Screen name="role-select" options={{ headerShown: false, animation: 'fade' }} />
            <Stack.Screen name="customer-login" options={{ headerShown: false, animation: 'slide_from_right' }} />
            <Stack.Screen name="owner-login" options={{ headerShown: false, animation: 'slide_from_right' }} />
            <Stack.Screen name="admin-login" options={{ headerShown: false, animation: 'slide_from_right' }} />
            <Stack.Screen name="(tabs)" options={{ headerShown: false, animation: 'fade' }} />
            <Stack.Screen name="(owner)" options={{ headerShown: false, animation: 'fade' }} />
            <Stack.Screen name="(admin)" options={{ headerShown: false, animation: 'fade' }} />
            <Stack.Screen
                name="hall/[id]"
                options={{
                    headerShown: false,
                    animation: 'slide_from_right',
                }}
            />
            <Stack.Screen
                name="booking/[id]"
                options={{
                    title: 'Book Venue',
                    headerStyle: { backgroundColor: '#FBF7F0' },
                    headerTintColor: '#8B1A2B',
                    headerShadowVisible: false,
                    animation: 'slide_from_right',
                }}
            />
            <Stack.Screen
                name="booking/payment-upi"
                options={{
                    title: 'Payment',
                    headerShown: false,
                    animation: 'slide_from_right',
                }}
            />
            <Stack.Screen
                name="booking/thank-you"
                options={{
                    headerShown: false,
                    animation: 'fade',
                    presentation: 'modal',
                }}
            />
            <Stack.Screen
                name="booking/detail"
                options={{
                    headerShown: false,
                    animation: 'slide_from_right',
                }}
            />
            <Stack.Screen
                name="booking-success"
                options={{
                    headerShown: false,
                    presentation: 'modal',
                    animation: 'fade',
                }}
            />
            <Stack.Screen
                name="owner-availability"
                options={{
                    title: 'Manage Availability',
                    headerStyle: { backgroundColor: '#FBF7F0' },
                    headerTintColor: '#8B1A2B',
                    headerShadowVisible: false,
                    animation: 'slide_from_right',
                }}
            />
            <Stack.Screen
                name="owner-pricing"
                options={{
                    title: 'Set Prices',
                    headerStyle: { backgroundColor: '#FBF7F0' },
                    headerTintColor: '#8B1A2B',
                    headerShadowVisible: false,
                    animation: 'slide_from_right',
                }}
            />
            <Stack.Screen
                name="owner-analytics"
                options={{
                    title: 'Analytics',
                    headerStyle: { backgroundColor: '#FBF7F0' },
                    headerTintColor: '#8B1A2B',
                    headerShadowVisible: false,
                    animation: 'slide_from_right',
                }}
            />
            <Stack.Screen
                name="map"
                options={{
                    headerShown: false,
                    animation: 'slide_from_right',
                }}
            />
            <Stack.Screen
                name="terms"
                options={{
                    headerShown: false,
                    animation: 'slide_from_right',
                }}
            />
            <Stack.Screen
                name="help"
                options={{
                    headerShown: false,
                    animation: 'slide_from_right',
                }}
            />
            <Stack.Screen
                name="notifications"
                options={{
                    headerShown: false,
                    animation: 'slide_from_right',
                }}
            />
            <Stack.Screen
                name="service/[id]"
                options={{
                    headerShown: false,
                    animation: 'slide_from_right',
                }}
            />
            <Stack.Screen
                name="service-booking/[id]"
                options={{
                    headerShown: false,
                    animation: 'slide_from_right',
                }}
            />
            <Stack.Screen
                name="vendor-login"
                options={{ headerShown: false, animation: 'slide_from_right' }}
            />
            <Stack.Screen
                name="vendor-pending-approval"
                options={{ headerShown: false, animation: 'slide_from_right' }}
            />
            <Stack.Screen
                name="vendor-onboarding"
                options={{ headerShown: false, animation: 'slide_from_right' }}
            />
            <Stack.Screen
                name="(vendor)"
                options={{ headerShown: false, animation: 'fade' }}
            />
            <Stack.Screen
                name="service-listing-browse"
                options={{ headerShown: false, animation: 'slide_from_right' }}
            />
            <Stack.Screen
                name="profile-edit"
                options={{ headerShown: false, animation: 'slide_from_right' }}
            />
        </Stack>
    );
}

export default function RootLayout() {
    const [splashComplete, setSplashComplete] = React.useState(false);

    return (
        <QueryClientProvider client={queryClient}>
            <GestureHandlerRootView style={{ flex: 1 }}>
                <AuthProvider>
                    <AppProvider>
                        <AuthStateSync />
                        {<RootLayoutNav />}
                        {!splashComplete && (
                            <SplashOverlay onAnimationComplete={() => setSplashComplete(true)} />
                        )}
                    </AppProvider>
                </AuthProvider>
            </GestureHandlerRootView>
        </QueryClientProvider>
    );
}
