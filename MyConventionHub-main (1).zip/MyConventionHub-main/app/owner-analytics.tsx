import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Dimensions } from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { TrendingUp, TrendingDown, ChevronLeft } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { useAuth } from '@/providers/AuthProvider';
import { supabase } from '@/utils/supabase';
import { formatCurrencyCompact } from '@/utils/currency';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const TIME_FILTERS = ['This Week', 'This Month', '3 Months', 'This Year'] as const;

export default function OwnerAnalyticsScreen() {
    const router = useRouter();
    const { user } = useAuth();
    const [timeFilter, setTimeFilter] = useState<typeof TIME_FILTERS[number]>('This Month');
    const [monthlyEarnings, setMonthlyEarnings] = useState<{ month: string; amount: number }[]>([]);
    const [ownerStats, setOwnerStats] = useState({
        totalEarningsThisMonth: 0,
        totalBookings: 0,
        occupancyRate: 0,
    });

    useEffect(() => {
        const fetchAnalytics = async () => {
            if (!user) return;
            const { data: halls } = await supabase.from('halls').select('id').eq('owner_id', user.id);
            if (!halls || halls.length === 0) return;
            const hallIds = halls.map(h => h.id);

            const { data: allBookings } = await supabase
                .from('bookings')
                .select('event_date, date, total_amount, total_price, status')
                .in('hall_id', hallIds);

            if (!allBookings) return;

            const now = new Date();
            const thisMonth = now.getMonth();
            const thisYear = now.getFullYear();
            const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

            const earnings = [];
            for (let i = 5; i >= 0; i--) {
                const m = (thisMonth - i + 12) % 12;
                const y = thisMonth - i < 0 ? thisYear - 1 : thisYear;
                const monthBookings = allBookings.filter(b => {
                    const d = new Date(b.event_date ?? b.date);
                    return d.getMonth() === m && d.getFullYear() === y && b.status !== 'cancelled';
                });
                earnings.push({
                    month: MONTH_NAMES[m],
                    amount: monthBookings.reduce((s, b) => s + (b.total_amount ?? b.total_price ?? 0), 0),
                });
            }
            setMonthlyEarnings(earnings);

            const thisMonthTotal = allBookings
                .filter(b => {
                    const d = new Date(b.event_date ?? b.date);
                    return d.getMonth() === thisMonth && d.getFullYear() === thisYear && b.status !== 'cancelled';
                })
                .reduce((s, b) => s + (b.total_amount ?? b.total_price ?? 0), 0);

            const nonCancelled = allBookings.filter(b => b.status !== 'cancelled').length;
            const confirmed = allBookings.filter(b => b.status === 'confirmed' || b.status === 'completed').length;

            setOwnerStats({
                totalEarningsThisMonth: thisMonthTotal,
                totalBookings: allBookings.length,
                occupancyRate: allBookings.length > 0 ? Math.round((confirmed / allBookings.length) * 100) : 0,
            });
        };
        fetchAnalytics();
    }, [user]);

    const maxEarning = Math.max(...monthlyEarnings.map(e => e.amount), 1);

    const metrics = [
        { label: 'Total Revenue', value: formatCurrencyCompact(ownerStats.totalEarningsThisMonth), trend: '', up: true },
        { label: 'Bookings', value: ownerStats.totalBookings.toString(), trend: '', up: true },
        { label: 'Avg Value', value: ownerStats.totalBookings > 0 ? formatCurrencyCompact(Math.round(ownerStats.totalEarningsThisMonth / ownerStats.totalBookings)) : '₹0', trend: '', up: true },
        { label: 'Occupancy', value: `${ownerStats.occupancyRate}%`, trend: '', up: ownerStats.occupancyRate >= 50 },
    ];

    return (
        <View style={styles.screen}>
            <Stack.Screen options={{
                title: 'Analytics',
                headerStyle: { backgroundColor: Colors.background },
                headerTintColor: Colors.primary,
                headerShadowVisible: false,
                headerLeft: () => (
                    <AnimatedPressable onPress={() => router.back()} scaleValue={0.8}>
                        <View style={{ padding: Spacing.sm, marginLeft: -Spacing.sm, marginRight: Spacing.sm }}>
                            <ChevronLeft size={28} color={Colors.primary} />
                        </View>
                    </AnimatedPressable>
                ),
            }} />
            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterRow}>
                    {TIME_FILTERS.map(f => (
                        <AnimatedPressable key={f} onPress={() => setTimeFilter(f)} scaleValue={0.95}>
                            <View style={[styles.filterChip, timeFilter === f && styles.filterChipActive]}>
                                <Text style={[styles.filterChipText, timeFilter === f && styles.filterChipTextActive]}>{f}</Text>
                            </View>
                        </AnimatedPressable>
                    ))}
                </ScrollView>

                <View style={styles.metricsGrid}>
                    {metrics.map(m => (
                        <View key={m.label} style={styles.metricCard}>
                            <Text style={styles.metricLabel}>{m.label}</Text>
                            <Text style={styles.metricValue}>{m.value}</Text>
                            <View style={styles.metricTrend}>
                                {m.up ? <TrendingUp size={12} color={Colors.success} /> : <TrendingDown size={12} color={Colors.error} />}
                                <Text style={[styles.metricTrendText, { color: m.up ? Colors.success : Colors.error }]}>{m.trend}</Text>
                            </View>
                        </View>
                    ))}
                </View>

                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Revenue Trend</Text>
                    <View style={styles.chartContainer}>
                        {monthlyEarnings.map((item) => (
                            <View key={item.month} style={styles.chartBar}>
                                <Text style={styles.chartValue}>{formatCurrencyCompact(item.amount)}</Text>
                                <View style={styles.chartBarTrack}>
                                    <LinearGradient colors={[Colors.primary, Colors.primaryLight]} style={[styles.chartBarFill, { height: `${(item.amount / maxEarning) * 100}%` as any }]} />
                                </View>
                                <Text style={styles.chartLabel}>{item.month}</Text>
                            </View>
                        ))}
                    </View>
                </View>

                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Booking Breakdown</Text>
                    <View style={styles.breakdownCard}>
                        {[{ label: 'Morning', pct: 25, color: Colors.gold }, { label: 'Evening', pct: 48, color: Colors.primary }, { label: 'Full Day', pct: 27, color: Colors.primaryLight }].map(item => (
                            <View key={item.label} style={styles.breakdownRow}>
                                <View style={styles.breakdownLabel}>
                                    <View style={[styles.breakdownDot, { backgroundColor: item.color }]} />
                                    <Text style={styles.breakdownText}>{item.label}</Text>
                                </View>
                                <View style={styles.breakdownBarTrack}>
                                    <View style={[styles.breakdownBarFill, { width: `${item.pct}%` as any, backgroundColor: item.color }]} />
                                </View>
                                <Text style={styles.breakdownPct}>{item.pct}%</Text>
                            </View>
                        ))}
                    </View>
                </View>
                <View style={{ height: Spacing.massive }} />
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    scrollContent: { padding: Spacing.lg },
    filterRow: { gap: Spacing.sm, marginBottom: Spacing.xl, paddingBottom: Spacing.xs },
    filterChip: { paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm, borderRadius: Radius.full, backgroundColor: Colors.cream },
    filterChipActive: { backgroundColor: Colors.primary },
    filterChipText: { fontSize: FontSize.sm, fontWeight: FontWeight.semibold, color: Colors.textSecondary },
    filterChipTextActive: { color: '#FFFFFF' },
    metricsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, marginBottom: Spacing.lg },
    metricCard: { width: (SCREEN_WIDTH - Spacing.lg * 2 - Spacing.sm) / 2, backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.lg, ...Shadow.sm },
    metricLabel: { fontSize: FontSize.xs, color: Colors.textTertiary, marginBottom: Spacing.xs },
    metricValue: { fontSize: FontSize.xxl, fontWeight: FontWeight.heavy, color: Colors.text, marginBottom: Spacing.xs },
    metricTrend: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xxs },
    metricTrendText: { fontSize: FontSize.xs, fontWeight: FontWeight.semibold },
    section: { marginTop: Spacing.xl },
    sectionTitle: { fontSize: FontSize.xl, fontWeight: FontWeight.bold, color: Colors.text, marginBottom: Spacing.lg },
    chartContainer: { flexDirection: 'row', justifyContent: 'space-between', height: 180, alignItems: 'flex-end' },
    chartBar: { flex: 1, alignItems: 'center', gap: Spacing.xs },
    chartValue: { fontSize: 10, color: Colors.textTertiary, fontWeight: FontWeight.medium },
    chartBarTrack: { width: 28, flex: 1, backgroundColor: Colors.cream, borderRadius: Radius.sm, overflow: 'hidden', justifyContent: 'flex-end' },
    chartBarFill: { width: '100%', borderRadius: Radius.sm },
    chartLabel: { fontSize: FontSize.xs, color: Colors.textSecondary, fontWeight: FontWeight.medium },
    breakdownCard: { backgroundColor: Colors.surface, borderRadius: Radius.xl, padding: Spacing.xl, gap: Spacing.lg, ...Shadow.sm },
    breakdownRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
    breakdownLabel: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, width: 80 },
    breakdownDot: { width: 10, height: 10, borderRadius: 5 },
    breakdownText: { fontSize: FontSize.sm, color: Colors.text, fontWeight: FontWeight.medium },
    breakdownBarTrack: { flex: 1, height: 8, backgroundColor: Colors.cream, borderRadius: 4, overflow: 'hidden' },
    breakdownBarFill: { height: '100%', borderRadius: 4 },
    breakdownPct: { fontSize: FontSize.sm, fontWeight: FontWeight.bold, color: Colors.text, width: 36, textAlign: 'right' },
});
