import React, { useEffect, useState } from 'react';
import {
    View, Text, StyleSheet, TextInput, ScrollView, Alert,
    Platform, ActivityIndicator,
} from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import { ArrowLeft, Camera, User } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { supabase } from '@/utils/supabase';
import { useAuth } from '@/providers/AuthProvider';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

const SERIF_FONT = Platform.select({
    ios: 'Georgia', android: 'serif', web: 'Georgia, serif', default: 'serif',
});

export default function ProfileEditScreen() {
    const router = useRouter();
    const { user, profile } = useAuth();

    const [displayName, setDisplayName] = useState('');
    const [phone, setPhone] = useState('');
    const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
    const [localAvatar, setLocalAvatar] = useState<string | null>(null);
    const [isSaving, setIsSaving] = useState(false);
    const [isUploading, setIsUploading] = useState(false);

    useEffect(() => {
        if (profile) {
            setDisplayName(profile.full_name || '');
            setPhone(profile.phone || '');
            setAvatarUrl((profile as any).avatar_url || null);
        }
    }, [profile]);

    const pickAvatar = async () => {
        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== 'granted') {
            Alert.alert('Permission Required', 'We need permission to access your photo library.');
            return;
        }

        const result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: true,
            aspect: [1, 1],
            quality: 0.8,
        });

        if (!result.canceled && result.assets[0]?.uri) {
            setLocalAvatar(result.assets[0].uri);
            if (Platform.OS !== 'web') {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            }
        }
    };

    const uploadAvatar = async (localUri: string): Promise<string | null> => {
        if (!user) return null;
        setIsUploading(true);
        try {
            const ext = localUri.split('.').pop()?.split('?')[0]?.toLowerCase() || 'jpg';
            const extension = ext === 'jpeg' ? 'jpg' : ext;
            const contentType = extension === 'png' ? 'image/png' : 'image/jpeg';
            const filePath = `${user.id}/avatar-${Date.now()}.${extension}`;

            const { data: { session } } = await supabase.auth.getSession();
            const token = session?.access_token || process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;
            const uploadUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/storage/v1/object/avatars/${filePath}`;

            const response = await FileSystem.uploadAsync(uploadUrl, localUri, {
                httpMethod: 'POST',
                uploadType: FileSystem.FileSystemUploadType.BINARY_CONTENT,
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'apikey': process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!,
                    'x-upsert': 'true',
                    'Content-Type': contentType,
                },
            });

            if (response.status < 200 || response.status >= 300) {
                throw new Error(response.body || 'Upload failed');
            }

            // Build the public URL
            const { data: publicUrlData } = supabase.storage.from('avatars').getPublicUrl(filePath);
            return publicUrlData.publicUrl;
        } catch (error: any) {
            Alert.alert('Upload Failed', error?.message || 'Could not upload your photo. Please try again.');
            return null;
        } finally {
            setIsUploading(false);
        }
    };

    const handleSave = async () => {
        if (!user) return;
        const trimmedName = displayName.trim();
        if (trimmedName.length < 1) {
            Alert.alert('Display Name Required', 'Please enter a display name.');
            return;
        }
        if (trimmedName.length > 60) {
            Alert.alert('Display Name Too Long', 'Display name must be 60 characters or fewer.');
            return;
        }

        setIsSaving(true);

        let finalAvatarUrl = avatarUrl;
        if (localAvatar) {
            const uploaded = await uploadAvatar(localAvatar);
            if (uploaded) {
                finalAvatarUrl = uploaded;
            } else {
                setIsSaving(false);
                return;
            }
        }

        const { error } = await supabase
            .from('profiles')
            .update({
                full_name: trimmedName,
                phone: phone.trim() || null,
                avatar_url: finalAvatarUrl,
                updated_at: new Date().toISOString(),
            })
            .eq('id', user.id);

        setIsSaving(false);

        if (error) {
            Alert.alert('Save Failed', error.message);
            return;
        }

        if (Platform.OS !== 'web') {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        }
        Alert.alert('Saved', 'Your profile has been updated.', [
            { text: 'OK', onPress: () => router.back() },
        ]);
    };

    const displayedAvatar = localAvatar || avatarUrl;

    return (
        <View style={styles.screen}>
            <Stack.Screen options={{ headerShown: false }} />
            <SafeAreaView edges={['top']} style={styles.header}>
                <AnimatedPressable onPress={() => router.back()} scaleValue={0.9}>
                    <View style={styles.backBtn}>
                        <ArrowLeft size={22} color={Colors.text} />
                    </View>
                </AnimatedPressable>
                <Text style={styles.headerTitle}>Edit Profile</Text>
                <View style={{ width: 40 }} />
            </SafeAreaView>

            <ScrollView
                style={styles.scroll}
                contentContainerStyle={styles.content}
                showsVerticalScrollIndicator={false}
                keyboardShouldPersistTaps="handled"
            >
                {/* Avatar */}
                <View style={styles.avatarSection}>
                    <View style={styles.avatarContainer}>
                        {displayedAvatar ? (
                            <Image source={{ uri: displayedAvatar }} style={styles.avatar} contentFit="cover" />
                        ) : (
                            <View style={styles.avatarPlaceholder}>
                                <User size={48} color={Colors.textTertiary} />
                            </View>
                        )}
                        <AnimatedPressable onPress={pickAvatar} scaleValue={0.9} disabled={isUploading}>
                            <View style={styles.cameraButton}>
                                {isUploading
                                    ? <ActivityIndicator size="small" color="#FFFFFF" />
                                    : <Camera size={18} color="#FFFFFF" />
                                }
                            </View>
                        </AnimatedPressable>
                    </View>
                    <Text style={styles.avatarHint}>Tap the camera to change your photo</Text>
                </View>

                {/* Form */}
                <View style={styles.formSection}>
                    <View style={styles.field}>
                        <Text style={styles.label}>Display Name</Text>
                        <TextInput
                            style={styles.input}
                            value={displayName}
                            onChangeText={setDisplayName}
                            placeholder="How you want to be addressed"
                            placeholderTextColor={Colors.textTertiary}
                            maxLength={60}
                            autoCapitalize="words"
                        />
                        <Text style={styles.hint}>This is shown on your profile and bookings.</Text>
                    </View>

                    <View style={styles.field}>
                        <Text style={styles.label}>Email</Text>
                        <View style={[styles.input, styles.disabledInput]}>
                            <Text style={styles.disabledText}>{user?.email ?? '—'}</Text>
                        </View>
                        <Text style={styles.hint}>Email cannot be changed.</Text>
                    </View>

                    <View style={styles.field}>
                        <Text style={styles.label}>Phone Number</Text>
                        <TextInput
                            style={styles.input}
                            value={phone}
                            onChangeText={setPhone}
                            placeholder="+91 98765 43210"
                            placeholderTextColor={Colors.textTertiary}
                            keyboardType="phone-pad"
                            maxLength={20}
                        />
                    </View>
                </View>

                <AnimatedPressable onPress={handleSave} scaleValue={0.97} disabled={isSaving || isUploading}>
                    <View style={[styles.saveBtn, (isSaving || isUploading) && styles.saveBtnDisabled]}>
                        {isSaving
                            ? <ActivityIndicator color="#FFFFFF" />
                            : <Text style={styles.saveBtnText}>Save Changes</Text>
                        }
                    </View>
                </AnimatedPressable>
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: Colors.background },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: Spacing.lg,
        paddingBottom: Spacing.md,
        backgroundColor: Colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: Colors.borderLight,
    },
    backBtn: {
        width: 40, height: 40, borderRadius: 20,
        backgroundColor: Colors.cream,
        justifyContent: 'center', alignItems: 'center',
    },
    headerTitle: {
        fontSize: FontSize.lg,
        fontWeight: FontWeight.bold,
        color: Colors.text,
        fontFamily: SERIF_FONT,
    },
    scroll: { flex: 1 },
    content: { padding: Spacing.xl, paddingBottom: Spacing.massive },
    avatarSection: {
        alignItems: 'center',
        marginBottom: Spacing.xxl,
    },
    avatarContainer: {
        position: 'relative',
        marginBottom: Spacing.md,
    },
    avatar: {
        width: 120,
        height: 120,
        borderRadius: 60,
        backgroundColor: Colors.cream,
    },
    avatarPlaceholder: {
        width: 120,
        height: 120,
        borderRadius: 60,
        backgroundColor: Colors.cream,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 2,
        borderColor: Colors.border,
    },
    cameraButton: {
        position: 'absolute',
        bottom: 0,
        right: 0,
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: Colors.primary,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 3,
        borderColor: Colors.surface,
        ...Shadow.md,
    },
    avatarHint: {
        fontSize: FontSize.sm,
        color: Colors.textTertiary,
    },
    formSection: {
        gap: Spacing.lg,
        marginBottom: Spacing.xxl,
    },
    field: {
        gap: Spacing.xs,
    },
    label: {
        fontSize: FontSize.sm,
        fontWeight: FontWeight.bold,
        color: Colors.text,
    },
    input: {
        backgroundColor: Colors.surface,
        borderRadius: Radius.lg,
        paddingHorizontal: Spacing.lg,
        paddingVertical: Spacing.md,
        fontSize: FontSize.md,
        color: Colors.text,
        borderWidth: 1,
        borderColor: Colors.border,
        minHeight: 50,
        justifyContent: 'center',
    },
    disabledInput: {
        backgroundColor: Colors.cream,
    },
    disabledText: {
        fontSize: FontSize.md,
        color: Colors.textSecondary,
    },
    hint: {
        fontSize: FontSize.xs,
        color: Colors.textTertiary,
        marginTop: Spacing.xxs,
    },
    saveBtn: {
        backgroundColor: Colors.primary,
        paddingVertical: Spacing.lg,
        borderRadius: Radius.lg,
        alignItems: 'center',
        ...Shadow.md,
    },
    saveBtnDisabled: {
        opacity: 0.6,
    },
    saveBtnText: {
        color: '#FFFFFF',
        fontSize: FontSize.md,
        fontWeight: FontWeight.bold,
    },
});
