﻿/**
 * app/vendor-login.tsx
 *
 * Unified vendor login and registration screen.
 *
 * Flow:
 *   Step 1 (email)   - Enter email; query vendor_profiles to detect returning vendor.
 *   Step 2a (otp)    - Returning vendor: send OTP immediately, verify, route via AuthProvider.
 *   Step 2b (sector) - New vendor: show 8-tile sector picker.
 *   Step 3 (details) - New vendor: sector-specific minimal-fields form.
 *   Step 4 (otp)     - New vendor: send OTP with metadata, verify, INSERT vendor_profiles.
 *
 * Requirements: 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 3.1, 11.2
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Animated,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  ArrowLeft,
  Building2,
  Camera,
  CheckCircle,
  Flower2,
  Mail,
  MoreHorizontal,
  Music,
  Palette,
  RefreshCw,
  Sparkles,
  UtensilsCrossed,
} from 'lucide-react-native';
import type { LucideIcon } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';

import { Colors, FontSize, FontWeight, Radius, Shadow, Spacing } from '@/constants/theme';
import { SECTOR_CONFIGS, SECTOR_LIST } from '@/constants/sectors';
import { validateSectorData } from '@/utils/sectorValidation';
import { supabase } from '@/utils/supabase';
import { useApp } from '@/providers/AppProvider';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import type { VendorSector } from '@/types';

// ─── Constants ────────────────────────────────────────────────────────────────

const SERIF_FONT = Platform.select({
  ios: 'Georgia',
  android: 'serif',
  web: 'Georgia, serif',
  default: 'serif',
});

const RESEND_COOLDOWN_SECS = 60;

// ─── Icon map ─────────────────────────────────────────────────────────────────

const ICON_MAP: Record<string, LucideIcon> = {
  Building2,
  Flower2,
  Music,
  Camera,
  UtensilsCrossed,
  Sparkles,
  Palette,
  MoreHorizontal,
};

// ─── Step type ────────────────────────────────────────────────────────────────

type Step = 'email' | 'sector' | 'details' | 'otp';

// ─── Minimal registration fields per sector ───────────────────────────────────

interface RegistrationFields {
  /** business_name or artist_name depending on sector */
  primaryName: string;
  city: string;
  phone: string;
}

/** Returns the label for the primary name field based on sector. */
function getPrimaryNameLabel(sector: VendorSector): string {
  switch (sector) {
    case 'musician':
    case 'artist':
      return 'Artist / Band Name';
    case 'photographer':
      return 'Studio / Artist Name';
    default:
      return 'Business Name';
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

async function deleteOrphanUser(uid: string): Promise<void> {
  try {
    const { error } = await supabase.functions.invoke('send-vendor-notification', {
      body: { action: 'delete_orphan_user', uid },
    });
    if (error) console.warn('[vendor-login] deleteOrphanUser error:', error.message);
  } catch (err) {
    console.warn('[vendor-login] deleteOrphanUser network error:', err);
  }
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function VendorLoginScreen() {
  const router = useRouter();
  const { login } = useApp();

  // ── State ─────────────────────────────────────────────────────────────────

  const [step, setStep] = useState<Step>('email');
  const [email, setEmail] = useState('');
  const [selectedSector, setSelectedSector] = useState<VendorSector | null>(null);
  const [fields, setFields] = useState<RegistrationFields>({ primaryName: '', city: '', phone: '' });
  const [otp, setOtp] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isReturningVendor, setIsReturningVendor] = useState(false);
  const [otpDeliveryFailed, setOtpDeliveryFailed] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);

  const fadeAnim = useRef(new Animated.Value(1)).current;
  const cooldownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const haptic = useCallback(() => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    }
  }, []);

  const startCooldown = useCallback(() => {
    setResendCooldown(RESEND_COOLDOWN_SECS);
    if (cooldownRef.current) clearInterval(cooldownRef.current);
    cooldownRef.current = setInterval(() => {
      setResendCooldown((prev) => {
        if (prev <= 1) {
          clearInterval(cooldownRef.current!);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }, []);

  useEffect(() => {
    return () => { if (cooldownRef.current) clearInterval(cooldownRef.current); };
  }, []);

  // ── Step 1: Email check ───────────────────────────────────────────────────

  const handleEmailContinue = useCallback(async () => {
    const trimmedEmail = email.trim().toLowerCase();
    if (!trimmedEmail || !trimmedEmail.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }

    setIsLoading(true);
    setError(null);
    haptic();

    try {
      // Query vendor_profiles joined with profiles by email to detect returning vendor.
      // profiles.email is the canonical email column set during auth user creation.
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('id, role, email')
        .eq('email', trimmedEmail)
        .maybeSingle();

      if (profileError) {
        console.warn('[vendor-login] profile lookup error:', profileError.message);
      }

      if (profileData) {
        // Email exists in profiles — check if it's a vendor or another role.
        if (profileData.role === 'vendor') {
          // Returning vendor: skip sector picker, go straight to OTP.
          setIsReturningVendor(true);
          await sendOtp(trimmedEmail, null, true);
        } else {
          // Email belongs to a non-vendor account (customer, owner, admin).
          // Requirement 1.5: show email-already-in-use error with Sign In CTA.
          setError(
            'This email is already associated with a ' +
            profileData.role +
            ' account. Please sign in instead.'
          );
          setIsLoading(false);
          return;
        }
      } else {
        // New email — proceed to sector picker.
        setIsReturningVendor(false);
        setStep('sector');
        setIsLoading(false);
      }
    } catch (err) {
      setError('Network error. Please try again.');
      console.error('[vendor-login] handleEmailContinue error:', err);
      setIsLoading(false);
    }
  }, [email]);

  // ── Step 2b: Sector selection ─────────────────────────────────────────────

  const handleSectorSelect = useCallback((sector: VendorSector) => {
    haptic();
    setSelectedSector(sector);
    setStep('details');
  }, []);

  // ── OTP send (shared for both paths) ─────────────────────────────────────

  /**
   * Sends OTP via Supabase Auth.
   * For new vendors, passes metadata { role: 'vendor', sector }.
   * Requirement 1.8: on delivery failure, show inline Resend OTP with no partial DB writes.
   */
  const sendOtp = useCallback(
    async (
      emailAddr: string,
      sector: VendorSector | null,
      isReturning: boolean
    ): Promise<void> => {
      setIsLoading(true);
      setError(null);
      setOtpDeliveryFailed(false);

      try {
        // For new vendors, do NOT pass role:'vendor' in metadata — the
        // handle_new_user trigger would try to insert it into profiles, which
        // fails if the DB constraint hasn't been migrated yet. The role is
        // set correctly by the upsert in handleVerifyOtp after OTP confirmation.
        const otpOptions = { email: emailAddr };

        const { error: otpError } = await supabase.auth.signInWithOtp(otpOptions);

        if (otpError) {
          // Requirement 1.8: delivery failure — show Resend OTP, no partial writes.
          setOtpDeliveryFailed(true);
          setError(
            otpError.message ||
            'Failed to send verification code. Please try again.'
          );
          setIsLoading(false);
          return;
        }

        setStep('otp');
        startCooldown();
      } catch (err) {
        setOtpDeliveryFailed(true);
        setError('Network error. Please try again.');
        console.error('[vendor-login] sendOtp error:', err);
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  // ── Step 3: Details form continue ─────────────────────────────────────────

  const handleDetailsContinue = useCallback(async () => {
    if (!selectedSector) return;

    const trimmedName = fields.primaryName.trim();
    const trimmedCity = fields.city.trim();

    if (!trimmedName) {
      setError(getPrimaryNameLabel(selectedSector) + ' is required');
      return;
    }
    if (!trimmedCity) {
      setError('City is required');
      return;
    }

    setError(null);
    haptic();
    await sendOtp(email.trim().toLowerCase(), selectedSector, false);
  }, [selectedSector, fields, email, sendOtp]);

  // ── Step 4: OTP verify ────────────────────────────────────────────────────

  const handleVerifyOtp = useCallback(async () => {
    if (!otp || otp.length < 6) {
      setError('Please enter the 6-digit verification code');
      return;
    }

    setIsLoading(true);
    setError(null);
    haptic();

    try {
      const { data, error: verifyError } = await supabase.auth.verifyOtp({
        email: email.trim().toLowerCase(),
        token: otp.trim(),
        type: 'email',
      });

      if (verifyError) {
        setError(verifyError.message || 'Invalid code. Please try again.');
        setIsLoading(false);
        return;
      }

      const authUser = data?.session?.user;
      if (!authUser) {
        setError('Verification failed. Please try again.');
        setIsLoading(false);
        return;
      }

      if (isReturningVendor) {
        const displayName =
          authUser.user_metadata?.full_name ||
          email.trim().toLowerCase().split('@')[0];
        login('vendor', displayName);
        setIsLoading(false);
        router.replace('/(vendor)/dashboard' as any);
        return;
      }

      // ── New vendor: INSERT vendor_profiles ──────────────────────────────
      // Requirement 1.4: set profile_completion_status based on validateSectorData.
      // Requirement 1.7: set is_approved = false.

      const sector = selectedSector ?? 'other';
      const primaryNameKey =
        sector === 'musician' || sector === 'artist'
          ? 'artist_name'
          : sector === 'photographer'
          ? 'studio_name'
          : 'business_name';

      const partialSectorData: Record<string, unknown> = {
        [primaryNameKey]: fields.primaryName.trim(),
        city: fields.city.trim(),
      };

      const validationResult = validateSectorData(sector, partialSectorData);
      const completionStatus = validationResult.success ? 'complete' : 'incomplete';

      const { error: insertError } = await supabase.from('vendor_profiles').insert([
        {
          id: authUser.id,
          vendor_sector: sector,
          business_name: fields.primaryName.trim() || null,
          phone: fields.phone.trim() || null,
          is_approved: false,
          profile_completion_status: completionStatus,
          sector_data: partialSectorData,
        },
      ]);

      if (insertError) {
        // Requirement 1.9: INSERT failed — call delete_orphan_user and surface retry alert.
        console.error('[vendor-login] vendor_profiles INSERT error:', insertError.message);
        await deleteOrphanUser(authUser.id);

        Alert.alert(
          'Registration Failed',
          'We could not save your profile. Please try again.',
          [{ text: 'Retry', style: 'default' }]
        );
        setIsLoading(false);
        return;
      }

      // Also ensure profiles row has role = 'vendor'.
      await supabase
        .from('profiles')
        .upsert([
          {
            id: authUser.id,
            role: 'vendor',
            full_name: fields.primaryName.trim() || email.trim().toLowerCase().split('@')[0],
            email: email.trim().toLowerCase(),
          },
        ]);

      const displayName = fields.primaryName.trim() || email.trim().toLowerCase().split('@')[0];
      login('vendor', displayName);

      setIsLoading(false);

      // Route to onboarding → pending-approval.
      router.replace(`/vendor-onboarding?sector=${encodeURIComponent(sector)}` as any);
    } catch (err) {
      setError('Verification failed. Please try again.');
      console.error('[vendor-login] handleVerifyOtp error:', err);
      setIsLoading(false);
    }
  }, [otp, email, isReturningVendor, selectedSector, fields, login, router]);

  const handleResendOtp = useCallback(() => {
    if (resendCooldown > 0 || isLoading) return;
    sendOtp(email.trim().toLowerCase(), selectedSector, isReturningVendor);
  }, [resendCooldown, isLoading, email, selectedSector, isReturningVendor, sendOtp]);

  const handleBack = useCallback(() => {
    setError(null);
    switch (step) {
      case 'sector':
        setStep('email');
        break;
      case 'details':
        setStep('sector');
        break;
      case 'otp':
        if (isReturningVendor) {
          setStep('email');
        } else {
          setStep('details');
        }
        setOtp('');
        break;
      default:
        router.back();
    }
  }, [step, isReturningVendor, router]);

  // ── Render helpers ────────────────────────────────────────────────────────

  const renderError = () => {
    if (!error) return null;
    const isEmailInUse = error.includes('already associated');
    return (
      <View style={styles.errorBox}>
        <Text style={styles.errorText}>{error}</Text>
        {isEmailInUse && (
          <TouchableOpacity
            onPress={() => router.replace('/customer-login' as any)}
            style={styles.signInCta}
          >
            <Text style={styles.signInCtaText}>Sign In Instead</Text>
          </TouchableOpacity>
        )}
      </View>
    );
  };

  const renderStepIndicator = () => {
    const steps: Step[] = isReturningVendor
      ? ['email', 'otp']
      : ['email', 'sector', 'details', 'otp'];
    const currentIndex = steps.indexOf(step);
    return (
      <View style={styles.stepRow}>
        {steps.map((s, i) => (
          <View
            key={s}
            style={[
              styles.stepDot,
              i <= currentIndex && styles.stepDotActive,
            ]}
          />
        ))}
      </View>
    );
  };

  // ── Step renderers ────────────────────────────────────────────────────────

  const renderEmailStep = () => (
    <>
      <View style={styles.header}>
        <Text style={styles.brandTitle}>ConventionHub</Text>
        <Text style={styles.welcomeTitle}>Vendor Portal</Text>
        <Text style={styles.subtitle}>
          List your services and reach thousands of customers.
        </Text>
      </View>

      <View style={styles.form}>
        {renderError()}

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Business Email</Text>
          <View style={styles.inputShell}>
            <Mail size={18} color={Colors.textTertiary} />
            <TextInput
              style={styles.emailInput}
              placeholder='vendor@example.com'
              placeholderTextColor={Colors.textTertiary}
              value={email}
              onChangeText={(t) => { setEmail(t); setError(null); }}
              keyboardType='email-address'
              autoCapitalize='none'
              autoComplete='email'
              autoFocus
            />
          </View>
          <Text style={styles.helperText}>
            We will send a verification code to this email.
          </Text>
        </View>

        <AnimatedPressable onPress={handleEmailContinue} scaleValue={0.96} disabled={isLoading}>
          <View style={[styles.primaryButton, isLoading && styles.buttonDisabled]}>
            {isLoading ? (
              <ActivityIndicator size='small' color='#FFFFFF' />
            ) : (
              <Text style={styles.primaryButtonText}>Continue</Text>
            )}
          </View>
        </AnimatedPressable>
      </View>
    </>
  );

  const renderSectorStep = () => (
    <>
      <View style={styles.header}>
        <Text style={styles.brandTitle}>Step 2 of 4</Text>
        <Text style={styles.welcomeTitle}>Your Sector</Text>
        <Text style={styles.subtitle}>
          Choose the category that best describes your service.
        </Text>
      </View>

      <View style={styles.sectorGrid}>
        {SECTOR_LIST.map((sector) => {
          const config = SECTOR_CONFIGS[sector];
          const SectorIcon = ICON_MAP[config.iconName] ?? MoreHorizontal;
          return (
            <AnimatedPressable
              key={sector}
              onPress={() => handleSectorSelect(sector)}
              scaleValue={0.94}
              style={styles.sectorTileWrapper}
            >
              <View
                style={[
                  styles.sectorTile,
                  { borderColor: config.badgeColor + '44' },
                ]}
              >
                <View
                  style={[
                    styles.sectorIconWrap,
                    { backgroundColor: config.badgeColor + '1A' },
                  ]}
                >
                  <SectorIcon size={28} color={config.badgeColor} strokeWidth={1.8} />
                </View>
                <Text style={styles.sectorTileLabel}>{config.displayName}</Text>
              </View>
            </AnimatedPressable>
          );
        })}
      </View>
    </>
  );

  const renderDetailsStep = () => {
    if (!selectedSector) return null;
    const config = SECTOR_CONFIGS[selectedSector];
    const SectorIcon = ICON_MAP[config.iconName] ?? MoreHorizontal;
    const nameLabel = getPrimaryNameLabel(selectedSector);

    return (
      <>
        <View style={styles.header}>
          <View style={[styles.sectorBadgeSmall, { backgroundColor: config.badgeColor + '1A' }]}>
            <SectorIcon size={16} color={config.badgeColor} strokeWidth={1.8} />
            <Text style={[styles.sectorBadgeText, { color: config.badgeColor }]}>
              {config.displayName}
            </Text>
          </View>
          <Text style={styles.brandTitle}>Step 3 of 4</Text>
          <Text style={styles.welcomeTitle}>Your Details</Text>
          <Text style={styles.subtitle}>
            Just the basics for now. You can complete your profile after approval.
          </Text>
        </View>

        <View style={styles.form}>
          {renderError()}

          <View style={styles.inputGroup}>
            <Text style={styles.label}>{nameLabel} *</Text>
            <TextInput
              style={styles.input}
              placeholder={'Enter your ' + nameLabel.toLowerCase()}
              placeholderTextColor={Colors.textTertiary}
              value={fields.primaryName}
              onChangeText={(t) => { setFields((f) => ({ ...f, primaryName: t })); setError(null); }}
              autoCapitalize='words'
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>City *</Text>
            <TextInput
              style={styles.input}
              placeholder='e.g. Mumbai'
              placeholderTextColor={Colors.textTertiary}
              value={fields.city}
              onChangeText={(t) => { setFields((f) => ({ ...f, city: t })); setError(null); }}
              autoCapitalize='words'
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Phone (Optional)</Text>
            <TextInput
              style={styles.input}
              placeholder='+91 98765 43210'
              placeholderTextColor={Colors.textTertiary}
              value={fields.phone}
              onChangeText={(t) => setFields((f) => ({ ...f, phone: t }))}
              keyboardType='phone-pad'
            />
          </View>

          <AnimatedPressable onPress={handleDetailsContinue} scaleValue={0.96} disabled={isLoading}>
            <View style={[styles.primaryButton, isLoading && styles.buttonDisabled]}>
              {isLoading ? (
                <ActivityIndicator size='small' color='#FFFFFF' />
              ) : (
                <Text style={styles.primaryButtonText}>Send Verification Code</Text>
              )}
            </View>
          </AnimatedPressable>
        </View>
      </>
    );
  };

  const renderOtpStep = () => (
    <>
      <View style={styles.header}>
        <View style={styles.otpIconWrap}>
          <Mail size={32} color={Colors.primary} />
        </View>
        <Text style={styles.welcomeTitle}>Check your email</Text>
        <Text style={styles.subtitle}>
          {'We sent a 6-digit code to\n'}
          <Text style={styles.emailHighlight}>{email.trim().toLowerCase()}</Text>
        </Text>
      </View>

      <View style={styles.form}>
        {renderError()}

        {otpDeliveryFailed && (
          <View style={styles.deliveryFailedBox}>
            <Text style={styles.deliveryFailedText}>
              The verification code could not be delivered.
            </Text>
            <TouchableOpacity
              onPress={handleResendOtp}
              disabled={resendCooldown > 0 || isLoading}
              style={styles.resendInlineButton}
            >
              <RefreshCw size={14} color={Colors.primary} />
              <Text style={styles.resendInlineText}>Resend OTP</Text>
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Verification Code</Text>
          <TextInput
            style={[styles.input, styles.otpInput]}
            placeholder='000000'
            placeholderTextColor={Colors.textTertiary}
            value={otp}
            onChangeText={(t) => { setOtp(t.replace(/\\D/g, '')); setError(null); }}
            keyboardType='number-pad'
            maxLength={6}
            autoFocus
          />
        </View>

        <AnimatedPressable onPress={handleVerifyOtp} scaleValue={0.96} disabled={isLoading}>
          <View style={[styles.primaryButton, isLoading && styles.buttonDisabled]}>
            {isLoading ? (
              <ActivityIndicator size='small' color='#FFFFFF' />
            ) : (
              <Text style={styles.primaryButtonText}>Verify & Continue</Text>
            )}
          </View>
        </AnimatedPressable>

        {!otpDeliveryFailed && (
          <View style={styles.resendRow}>
            <Text style={styles.resendLabel}>Didn't receive the code?</Text>
            <TouchableOpacity
              onPress={handleResendOtp}
              disabled={resendCooldown > 0 || isLoading}
            >
              <Text
                style={[
                  styles.resendLink,
                  (resendCooldown > 0 || isLoading) && styles.resendDisabled,
                ]}
              >
                {resendCooldown > 0 ? 'Resend in ' + resendCooldown + 's' : 'Resend Code'}
              </Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </>
  );

  // ── Main render ───────────────────────────────────────────────────────────

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ headerShown: false }} />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps='handled'
        >
          <SafeAreaView style={styles.safeArea}>
            <Animated.View style={[styles.main, { opacity: fadeAnim }]}>
              <View style={styles.topRow}>
                <AnimatedPressable
                  onPress={step === 'email' ? () => router.back() : handleBack}
                  style={styles.backButton}
                  scaleValue={0.9}
                >
                  <ArrowLeft size={24} color={Colors.text} />
                </AnimatedPressable>
                {renderStepIndicator()}
              </View>

              {step === 'email' && renderEmailStep()}
              {step === 'sector' && renderSectorStep()}
              {step === 'details' && renderDetailsStep()}
              {step === 'otp' && renderOtpStep()}
            </Animated.View>
          </SafeAreaView>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  container: { flex: 1, backgroundColor: Colors.background },
  scrollContent: { flexGrow: 1 },
  safeArea: { flex: 1 },
  main: { flex: 1, paddingHorizontal: Spacing.lg, paddingBottom: Spacing.xl },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: Spacing.md,
    marginBottom: Spacing.xl,
  },
  backButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  stepDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.border,
  },
  stepDotActive: {
    backgroundColor: Colors.primary,
    width: 20,
    borderRadius: 4,
  },
  header: { marginBottom: Spacing.xl },
  welcomeTitle: {
    fontSize: FontSize.xxl,
    fontWeight: FontWeight.bold,
    color: Colors.text,
    marginBottom: Spacing.xs,
  },
  brandTitle: {
    fontSize: FontSize.xxl,
    fontWeight: FontWeight.bold,
    color: Colors.primary,
  },
  subtitle: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    marginTop: Spacing.xs,
  },
  form: { gap: Spacing.md },
  inputGroup: { gap: Spacing.xs },
  label: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.medium,
    color: Colors.text,
  },
  inputShell: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderRadius: Radius.md,
    paddingHorizontal: Spacing.md,
    backgroundColor: Colors.surface,
    gap: Spacing.sm,
  },
  input: {
    flex: 1,
    height: 50,
    fontSize: FontSize.sm,
    color: Colors.text,
  },
  emailInput: {
    height: 50,
    fontSize: FontSize.sm,
    color: Colors.text,
    flex: 1,
  },
  otpInput: {
    textAlign: 'center',
    letterSpacing: 6,
    fontSize: FontSize.lg,
    fontWeight: FontWeight.bold,
  },
  helperText: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
  },
  errorBox: {
    backgroundColor: '#FEE2E2',
    borderRadius: Radius.md,
    padding: Spacing.md,
  },
  errorText: {
    fontSize: FontSize.sm,
    color: '#DC2626',
  },
  deliveryFailedBox: {
    backgroundColor: '#FEF3C7',
    borderRadius: Radius.md,
    padding: Spacing.md,
  },
  deliveryFailedText: {
    fontSize: FontSize.sm,
    color: '#92400E',
    marginBottom: Spacing.xs,
  },
  resendInlineButton: { alignSelf: 'flex-start' },
  resendInlineText: {
    fontSize: FontSize.sm,
    color: Colors.primary,
    fontWeight: FontWeight.semibold,
    textDecorationLine: 'underline',
  },
  primaryButton: {
    backgroundColor: Colors.primary,
    borderRadius: Radius.md,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: Spacing.md,
  },
  buttonDisabled: { opacity: 0.5 },
  primaryButtonText: {
    color: '#FFFFFF',
    fontSize: FontSize.md,
    fontWeight: FontWeight.semibold,
  },
  resendRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.xs,
    marginTop: Spacing.sm,
  },
  resendLabel: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
  },
  resendLink: {
    fontSize: FontSize.sm,
    color: Colors.primary,
    fontWeight: FontWeight.semibold,
  },
  resendDisabled: { opacity: 0.4 },
  signInCta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: Spacing.xl,
    gap: 4,
  },
  signInCtaText: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
  },
  emailHighlight: {
    fontWeight: FontWeight.semibold,
    color: Colors.text,
  },
  sectorGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
    marginTop: Spacing.md,
  },
  sectorTileWrapper: { width: '47%' },
  sectorTile: {
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    alignItems: 'center',
    gap: Spacing.sm,
  },
  sectorIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sectorTileLabel: {
    fontSize: FontSize.sm,
    fontWeight: FontWeight.semibold,
    color: Colors.text,
    textAlign: 'center',
  },
  sectorBadgeSmall: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: Radius.full,
    alignSelf: 'flex-start',
    marginBottom: Spacing.xs,
  },
  sectorBadgeText: {
    color: '#FFFFFF',
    fontSize: FontSize.xs,
    fontWeight: FontWeight.semibold,
  },
  otpIconWrap: {
    alignSelf: 'center',
    marginBottom: Spacing.lg,
  },
});
