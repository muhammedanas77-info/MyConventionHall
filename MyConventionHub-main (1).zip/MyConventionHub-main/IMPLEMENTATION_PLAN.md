# ConventionHub: Full Platform Implementation Plan

**Date**: May 5, 2026  
**Status**: Planning Phase - No Changes Yet  
**Scope**: Full wedding venue booking platform with auth, bookings, payments, partner dashboards, and monetization

---

## EXECUTIVE SUMMARY

This document outlines a phased implementation plan to transform the ConventionHub app from a mock proof-of-concept into a fully functional wedding venue booking platform with:
- **Supabase-backed authentication** with OTP-based login
- **Robust booking system** with double-booking prevention and slot management
- **UPI payment integration** with manual verification and payment gateway options
- **Venue partner dashboard** for booking management
- **Admin dashboard** for platform operations and revenue tracking
- **Email notifications** for OTP, confirmations, and updates
- **Monetization strategy** based on commission models and venue partnerships

---

## PART 1: CURRENT STATE ANALYSIS

### 1.1 What Exists

#### Authentication
- ✅ `app/customer-login.tsx` — UI-complete but **non-functional**
  - Accepts any email with `@` symbol
  - Uses hardcoded OTP `123456` (dev mode only)
  - Stores session to `AsyncStorage` via `AppProvider.login()`
  - Does NOT use Supabase auth
  
- ✅ `app/owner-login.tsx` — **Partially integrated**
  - Calls `supabase.auth.signInWithOtp()` correctly
  - Calls `supabase.auth.verifyOtp()` with email token
  - Profile creation logic included
  - BUT: Not fully wired to AuthProvider; customer login bypasses this
  
- ✅ `app/admin-login.tsx` — UI-complete, mock dev flow
  - Similar to customer login (hardcoded OTP)
  
- ✅ `providers/AuthProvider.tsx` — Session management exists
  - Listens to `supabase.auth.onAuthStateChange()`
  - Fetches profile and role
  - BUT: Not used by customer/admin flows; they use `AppProvider` only

#### Bookings
- ✅ `app/booking/[id].tsx` — UI-complete, 4-step flow
  - Step 0: Date picker with availability visualization
  - Step 1: Slot selection (morning/evening/full_day)
  - Step 2: Guest count & special requests
  - Step 3: Payment step (UI only, no actual payment)
  - Inserts booking to Supabase with status `confirmed` immediately
  - **No double-booking prevention**
  - **No real payment verification**
  - **No confirmation emails**
  
- ✅ `app/(tabs)/bookings.tsx` — Customer bookings list (works with mock data)
- ✅ `app/booking-success.tsx` — Confirmation screen (UI complete)

#### Venue Partner Dashboard
- ✅ `app/(owner)/owner-bookings.tsx` — Bookings list view (mock data)
  - Shows customer name, phone, date, slot, amount
  - WhatsApp integration button
  - Filter by status (all/confirmed/pending/completed/cancelled)
  - **Does NOT connect to Supabase real-time**
  - **No booking confirmation/rejection actions**
  - **No internal notes**

- ✅ `app/(owner)/dashboard.tsx` — Partner dashboard (mock)
- ✅ `app/(owner)/owner-analytics.tsx` — Analytics view (mock)
- ✅ `app/(owner)/owner-payouts.tsx` — Payout tracking (mock)

#### Admin Dashboard
- ✅ `app/(admin)/admin-dashboard.tsx` — Command center (mock data)
  - Stats: total halls, active bookings, today's revenue, pending approvals
  - Platform revenue chart
  - Monthly revenue visualization
  - Top performing halls
  - Recent activity timeline
  - **All mock data; no Supabase integration**
  
- ✅ `app/(admin)/approvals.tsx` — Hall approval management (likely mock)
- ✅ `app/(admin)/commissions.tsx` — Commission tracking (likely mock)

#### Database
- ✅ `scripts/setup_database.sql` — Schema with:
  - `profiles` table (id, email, full_name, role, avatar_url, phone)
  - `halls` table (owner_id, name, address, capacity, price, amenities, approval status)
  - `bookings` table (hall_id, customer_id, date, slot, guests, status, notes)
  - RLS policies for profiles, halls, bookings
  - **Missing**: payments table, payment verification, commission tracking, booking uniqueness constraints
  
- ✅ `types/index.ts` — Type definitions
  - `Booking` type includes: `payment_id`, `advance_amount`, `commission_amount`, `discount_amount`
  - `PriceBreakdown` type for pricing logic
  - But **payment table not in schema**

#### Pricing & Utilities
- ✅ `utils/pricing.ts` — Price calculation
- ✅ `constants/pricing.ts` — Season/slot multipliers
- ✅ `utils/currency.ts` — Currency formatting
- ✅ `utils/date.ts` — Date utilities
- ✅ `constants/seasons.ts` — Season definitions

#### Mock Data
- ✅ `mocks/halls.ts` — 10 seed halls
- ✅ `mocks/admin.ts` — Admin dashboard mock data
- ✅ `mocks/owner.ts` — Owner bookings mock data

### 1.2 What's Missing

#### Authentication
- ❌ **Real Supabase OTP flow** for customers (currently mock)
- ❌ **Email sending** via Supabase or SendGrid
- ❌ **Session persistence** across customer/owner/admin roles
- ❌ **Role-based routing** (currently hardcoded paths)
- ❌ **Logout functionality** (customer login doesn't call Supabase logout)

#### Bookings & Availability
- ❌ **Double-booking prevention** — No uniqueness constraint on (hall_id, date, slot)
- ❌ **Real-time availability sync** from Supabase
- ❌ **Booking status history** — No audit trail
- ❌ **Payment verification before confirmation** — Currently auto-confirms
- ❌ **Advance vs full payment logic** — Not implemented

#### Payment System
- ❌ **UPI integration** — No QR code generation, no manual verification
- ❌ **Payment gateway** — No Razorpay/Stripe integration
- ❌ **Payment verification flow** — No mechanism to confirm payment received
- ❌ **Payment status tracking** — No payment table in DB
- ❌ **Refund mechanism** — No refund logic
- ❌ **Commission calculation** — Logic exists but not persisted

#### Email System
- ❌ **OTP emails** — No email sending infrastructure
- ❌ **Confirmation emails** — No booking confirmation notifications
- ❌ **Partner notifications** — No alerts for new bookings
- ❌ **Payment emails** — No payment status emails
- ❌ **Email template system** — No templating engine

#### Venue Partner Features
- ❌ **Real-time booking updates** — Currently mock data
- ❌ **Booking approval workflow** — No confirm/reject actions
- ❌ **Internal notes** — No field to store partner notes
- ❌ **Analytics** — Mock only, no real data
- ❌ **Payout management** — No real payout tracking
- ❌ **Venue profile management** — Limited venue setup

#### Admin Features
- ❌ **Real-time data** — All mock dashboard
- ❌ **Payment management** — No payment view
- ❌ **Dispute resolution** — No dispute handling
- ❌ **Commission tracking** — No real tracking
- ❌ **Reporting** — No export/reporting features
- ❌ **Commission payouts to partners** — No automation

#### Monetization
- ❌ **Commission model implementation** — Not in code
- ❌ **Discount automation** — Manual only
- ❌ **Revenue tracking** — No real calculations
- ❌ **Partner payout automation** — No logic
- ❌ **Terms & conditions enforcement** — Not implemented

---

## PART 2: PROPOSED ARCHITECTURE

### 2.1 System Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    ConventionHub App                         │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │  Customer    │  │    Venue     │  │    Admin     │     │
│  │   Login      │  │   Partner    │  │    Login     │     │
│  │              │  │   Login      │  │              │     │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘     │
│         │                  │                  │              │
│         └──────────────────┼──────────────────┘              │
│                            │                                 │
│         ┌──────────────────▼──────────────────┐             │
│         │    Supabase Auth (OTP Magic Link)  │             │
│         │  - Email verification              │             │
│         │  - Session management              │             │
│         └──────────────────┬──────────────────┘             │
│                            │                                 │
│  ┌──────────────┐  ┌──────▼───────┐  ┌──────────────┐     │
│  │  Booking     │  │  Payment     │  │   Partner    │     │
│  │  System      │  │  System      │  │  Dashboard   │     │
│  │  - Double    │  │  - UPI QR    │  │  - Manage    │     │
│  │    booking   │  │  - Manual    │  │    bookings  │     │
│  │  prevention  │  │    verify    │  │  - Confirm   │     │
│  │  - Slot      │  │  - Razorpay  │  │    bookings  │     │
│  │    management│  │    (optional)│  │  - Analytics │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │            Email System (SendGrid/Supabase)         │   │
│  │  - OTP delivery                                     │   │
│  │  - Booking confirmations                           │   │
│  │  - Payment notifications                           │   │
│  │  - Partner alerts                                  │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
                            │
             ┌──────────────▼──────────────┐
             │      Supabase Backend       │
             ├─────────────────────────────┤
             │  - Database (PostgreSQL)   │
             │  - Auth (Supabase Auth)    │
             │  - Storage (S3)            │
             │  - Realtime subscriptions  │
             │  - Row Level Security      │
             └─────────────────────────────┘
                            │
             ┌──────────────┼──────────────┐
             │              │              │
        ┌────▼─────┐  ┌─────▼────┐  ┌────▼─────┐
        │  UPI/    │  │  SendGrid│  │  Admin   │
        │Razorpay  │  │  Email   │  │  Payouts│
        │  API     │  │  Service │  │   Job   │
        └──────────┘  └──────────┘  └─────────┘
```

### 2.2 Database Schema Design

#### Tables to Create/Modify

```sql
-- 1. PROFILES (exists, needs role management)
CREATE TABLE profiles (
  id UUID PRIMARY KEY,
  email TEXT UNIQUE,
  full_name TEXT,
  phone TEXT,
  role TEXT CHECK (role IN ('customer', 'owner', 'admin')),
  avatar_url TEXT,
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);

-- 2. HALLS (exists, good)
CREATE TABLE halls (
  id UUID PRIMARY KEY,
  owner_id UUID REFERENCES profiles(id),
  name TEXT NOT NULL,
  description TEXT,
  address TEXT,
  area TEXT,
  city TEXT,
  latitude DECIMAL,
  longitude DECIMAL,
  capacity_min INT,
  capacity_max INT,
  price_per_day NUMERIC,
  photos TEXT[],
  amenities TEXT[],
  is_approved BOOLEAN DEFAULT FALSE,
  is_featured BOOLEAN DEFAULT FALSE,
  is_verified BOOLEAN DEFAULT FALSE,
  rating NUMERIC,
  total_reviews INT,
  created_at TIMESTAMP
);

-- 3. BOOKINGS (exists, modify to add constraints)
CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  hall_id UUID REFERENCES halls(id),
  customer_id UUID REFERENCES profiles(id),
  date DATE NOT NULL,
  slot TEXT NOT NULL CHECK (slot IN ('morning', 'evening', 'full_day')),
  guest_count INT,
  total_amount NUMERIC,
  advance_amount NUMERIC,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
  payment_verified BOOLEAN DEFAULT FALSE,
  notes TEXT,
  created_at TIMESTAMP,
  
  -- UNIQUE constraint to prevent double booking
  UNIQUE (hall_id, date, slot)
);

-- 4. PAYMENTS (NEW - Critical)
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID REFERENCES bookings(id),
  customer_id UUID REFERENCES profiles(id),
  amount NUMERIC NOT NULL,
  advance_amount NUMERIC,
  payment_method TEXT CHECK (payment_method IN ('upi', 'razorpay', 'card')),
  upi_transaction_id TEXT UNIQUE,
  razorpay_order_id TEXT UNIQUE,
  razorpay_payment_id TEXT UNIQUE,
  verification_screenshot_url TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'verified', 'failed', 'refunded')),
  verified_at TIMESTAMP,
  verified_by_admin UUID REFERENCES profiles(id),
  created_at TIMESTAMP
);

-- 5. BOOKING_STATUS_HISTORY (NEW - for audit trail)
CREATE TABLE booking_status_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID REFERENCES bookings(id),
  old_status TEXT,
  new_status TEXT,
  changed_by UUID REFERENCES profiles(id),
  reason TEXT,
  created_at TIMESTAMP
);

-- 6. COMMISSIONS (NEW - track earnings)
CREATE TABLE commissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID REFERENCES bookings(id),
  owner_id UUID REFERENCES profiles(id),
  admin_commission NUMERIC, -- Amount ConventionHub earns
  owner_payout NUMERIC,     -- Amount owner receives
  discount NUMERIC,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'calculated', 'paid')),
  created_at TIMESTAMP
);

-- 7. PARTNER_ANALYTICS (NEW - for partner dashboard)
CREATE TABLE partner_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID REFERENCES profiles(id),
  month INT,
  year INT,
  total_bookings INT,
  total_revenue NUMERIC,
  platform_commission NUMERIC,
  owner_earnings NUMERIC,
  created_at TIMESTAMP,
  UNIQUE (owner_id, month, year)
);
```

### 2.3 Row Level Security (RLS) Policies

```sql
-- Profiles: Users see own profile, admins see all
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY profiles_view ON profiles FOR SELECT
  USING (
    auth.uid() = id 
    OR (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
  );

CREATE POLICY profiles_update ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- Halls: Anyone sees approved halls, owners manage own
ALTER TABLE halls ENABLE ROW LEVEL SECURITY;

CREATE POLICY halls_select ON halls FOR SELECT
  USING (is_approved = TRUE OR owner_id = auth.uid() OR 
         (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');

CREATE POLICY halls_manage_owner ON halls FOR ALL
  USING (owner_id = auth.uid());

-- Bookings: Customers see own, owners see for their halls
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY bookings_customer_view ON bookings FOR SELECT
  USING (customer_id = auth.uid());

CREATE POLICY bookings_owner_view ON bookings FOR SELECT
  USING (
    EXISTS (SELECT 1 FROM halls WHERE halls.id = hall_id AND halls.owner_id = auth.uid())
  );

CREATE POLICY bookings_admin_all ON bookings FOR ALL
  USING ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');

-- Payments: Customers see own, admins see all for verification
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY payments_customer_view ON payments FOR SELECT
  USING (customer_id = auth.uid());

CREATE POLICY payments_admin_all ON payments FOR ALL
  USING ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');

-- Commissions: Owners see own, admins see all
ALTER TABLE commissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY commissions_owner_view ON commissions FOR SELECT
  USING (owner_id = auth.uid());

CREATE POLICY commissions_admin_all ON commissions FOR ALL
  USING ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');
```

---

## PART 3: PHASED IMPLEMENTATION ROADMAP

### Phase 1: Foundation (Weeks 1-2)

**Goal**: Establish secure authentication and basic booking flow

#### Phase 1.1: Supabase Auth Integration
- [ ] Update `app/customer-login.tsx` to call `supabase.auth.signInWithOtp()`
- [ ] Update OTP verification to call `supabase.auth.verifyOtp()`
- [ ] Auto-create customer profile on first signup
- [ ] Connect `AuthProvider` to all login flows
- [ ] Implement persistent session across app reloads
- [ ] Add logout functionality

#### Phase 1.2: Database Schema Expansion
- [ ] Execute new schema additions (payments, commissions, booking_status_history)
- [ ] Add uniqueness constraint on bookings (hall_id, date, slot)
- [ ] Implement RLS policies for all tables
- [ ] Test RLS enforcement

#### Phase 1.3: Double-Booking Prevention
- [ ] Add availability checking before slot selection in booking flow
- [ ] Query Supabase for existing bookings on selected date
- [ ] Disable already-booked slots in UI
- [ ] Add server-side validation (constraint)
- [ ] Test conflict scenarios

**Deliverables**:
- ✅ Real Supabase OTP login
- ✅ Session persistence
- ✅ Updated database schema
- ✅ Double-booking prevention
- ✅ Test cases

---

### Phase 2: Payment System (Weeks 3-4)

**Goal**: Implement UPI payment and manual verification flow

#### Phase 2.1: UPI Payment Page
- [ ] Create `app/booking/payment-upi.tsx`
- [ ] Generate UPI QR code (library: `react-native-qr-code-svg`)
- [ ] Display UPI ID: `rayyan182003-1@okaxis`
- [ ] Add UPI app links (Google Pay, PhonePe, Paytm)
- [ ] Add screenshot upload for manual verification
- [ ] Store payment screenshot to Supabase Storage

#### Phase 2.2: Payment Verification Flow
- [ ] Create `app/(admin)/payments.tsx` for manual verification
- [ ] Admin reviews payment screenshots
- [ ] Admin marks payment as verified/rejected
- [ ] Update `payments` table status
- [ ] Trigger booking confirmation on verification
- [ ] Send confirmation email

#### Phase 2.3: Payment Gateway Option (Razorpay)
- [ ] Set up Razorpay account (optional for later)
- [ ] Create `utils/razorpay.ts` for payment processing
- [ ] Implement payment status polling
- [ ] Auto-verify payments from Razorpay

#### Phase 2.4: Booking Status Flow
- [ ] Update booking status: pending → payment_pending → confirmed
- [ ] Create `booking_status_history` for audit trail
- [ ] Track status changes with timestamps and reasons

**Deliverables**:
- ✅ UPI payment UI
- ✅ Manual payment verification page
- ✅ Payment storage in database
- ✅ Booking status workflow
- ✅ Razorpay integration (optional)

---

### Phase 3: Email System (Week 5)

**Goal**: Implement automated email notifications

#### Phase 3.1: Email Infrastructure Setup
- [ ] Set up SendGrid account
- [ ] Add SendGrid API key to environment
- [ ] Create `utils/email.ts` with email templates
- [ ] Implement Supabase Edge Functions for email sending (or use SendGrid directly)

#### Phase 3.2: Email Templates
- [ ] OTP email template
- [ ] Booking confirmation email
- [ ] Payment received email
- [ ] Payment verification pending email
- [ ] Booking confirmed email (to partner)
- [ ] Booking cancelled email

#### Phase 3.3: Trigger Email Sending
- [ ] Trigger OTP email on login
- [ ] Trigger confirmation email on booking creation
- [ ] Trigger partner notification on new booking
- [ ] Trigger payment notification on verification
- [ ] Trigger cancellation emails on booking cancellation

**Deliverables**:
- ✅ Email service configured
- ✅ Email templates created
- ✅ Email triggers implemented
- ✅ Test emails sent and verified

---

### Phase 4: Venue Partner Dashboard (Week 6)

**Goal**: Real-time booking management for venue owners

#### Phase 4.1: Real-Time Booking Updates
- [ ] Replace mock data with Supabase real-time subscriptions
- [ ] `app/(owner)/owner-bookings.tsx` subscribes to bookings
- [ ] Update UI on booking changes
- [ ] Implement Supabase `.on('*')` listener

#### Phase 4.2: Booking Management Actions
- [ ] Add "Confirm Booking" button
- [ ] Add "Reject Booking" button with reason modal
- [ ] Add "Mark as Contacted" toggle
- [ ] Add "Internal Notes" text field
- [ ] Update booking status in database
- [ ] Send customer notifications on status change

#### Phase 4.3: Partner Analytics
- [ ] Replace mock analytics with real data
- [ ] Query monthly bookings and revenue
- [ ] Calculate commissions and payouts
- [ ] Display trends over time
- [ ] Add export functionality

**Deliverables**:
- ✅ Real-time booking updates
- ✅ Booking confirmation/rejection workflow
- ✅ Internal notes system
- ✅ Real analytics dashboard

---

### Phase 5: Admin Dashboard Enhancement (Week 7)

**Goal**: Full platform management for admins

#### Phase 5.1: Real-Time Admin Metrics
- [ ] Replace all mock data with Supabase queries
- [ ] Real-time stats: total halls, active bookings, revenue
- [ ] Revenue calculations from commissions table
- [ ] Payment status overview

#### Phase 5.2: Payment Management
- [ ] Create `app/(admin)/payments-review.tsx`
- [ ] Display pending UPI payments
- [ ] Implement screenshot review UI
- [ ] One-click verification workflow
- [ ] Payment history and reports

#### Phase 5.3: Hall Approvals
- [ ] Real-time pending hall approvals
- [ ] Approval/rejection workflow
- [ ] Featured listing management
- [ ] Hall verification tracking

#### Phase 5.4: Commission Management
- [ ] View real commission calculations
- [ ] Payout history to venue owners
- [ ] Payout automation (scheduled job)
- [ ] Dispute resolution interface

**Deliverables**:
- ✅ Real-time admin dashboard
- ✅ Payment verification interface
- ✅ Commission tracking and payouts
- ✅ Hall approval workflow

---

### Phase 6: Monetization & Optimization (Week 8)

**Goal**: Implement monetization strategy and optimize for revenue

#### Phase 6.1: Commission Model Implementation
- [ ] Implement commission calculation in `utils/pricing.ts`
- [ ] Commission options:
  - **Fixed Model**: ₹2,000-5,000 per booking
  - **Percentage Model**: 10-15% of total booking amount
  - **Hybrid Model**: Fixed + percentage (e.g., ₹1,000 + 5%)
- [ ] Calculate owner payout: total_amount - commission - discount
- [ ] Store calculations in `commissions` table

#### Phase 6.2: Discount Management
- [ ] Create `app/(admin)/discounts.tsx`
- [ ] Define discount rules (% off, fixed amount, seasonal)
- [ ] Apply discounts at booking time
- [ ] Track discount impact on revenue
- [ ] Ensure platform still profits after discounts

#### Phase 6.3: Advance Payment Logic
- [ ] Require 30-50% advance for booking confirmation
- [ ] Store advance_amount in bookings table
- [ ] Track remaining balance due
- [ ] Send payment reminders before event date
- [ ] Implement final payment collection flow

#### Phase 6.4: Revenue Tracking & Reporting
- [ ] Create detailed revenue reports
- [ ] Track revenue by: venue, partner, period, payment method
- [ ] Calculate net revenue after commissions and discounts
- [ ] Export reports for accounting

**Deliverables**:
- ✅ Commission calculation system
- ✅ Discount management interface
- ✅ Advance payment tracking
- ✅ Revenue reporting and analytics

---

## PART 4: MONETIZATION STRATEGY

### 4.1 Recommended Commission Model

**HYBRID MODEL: ₹2,000 Fixed + 8% Percentage**

```
Example Booking:
- Hall: Palace Grounds
- Price: ₹500,000
- Guest Count: 200
- Slot: Evening (1x multiplier)
- Discount Offered: 5% (₹25,000)
- Customer Pays: ₹475,000

ConventionHub Earns:
- Fixed Commission: ₹2,000
- Percentage Commission: 8% × ₹475,000 = ₹38,000
- Total Commission: ₹40,000

Owner (Venue) Gets:
- Total Booking: ₹475,000
- Minus Commission: ₹40,000
- Owner Payout: ₹435,000

ConventionHub Profit Margin: 8.4% (₹40,000 / ₹475,000)
```

### 4.2 Competitive Positioning

| Model | Pros | Cons | Best For |
|-------|------|------|----------|
| **Fixed Fee Only** | Predictable, simple | Low revenue on high-value bookings | Startup phase, volume play |
| **Percentage Only** | Scales with value | Varies too much, hard to budget | Established platforms (WeddingWire) |
| **Hybrid (Recommended)** | Balanced, predictable + scalable | Slightly complex | Our use case |
| **Subscription (Venues)** | Recurring revenue | Requires critical mass | Later phase |
| **Featured Listing** | High margins | Optional uptake | Upgrade revenue |

### 4.3 Pricing Strategy for Different Venues

```
₹100K-₹200K venues:
  Commission: ₹1,500 + 6% = ~₹10,000 per booking

₹200K-₹500K venues:
  Commission: ₹2,000 + 8% = ~₹40,000 per booking

₹500K+ venues:
  Commission: ₹3,000 + 10% = ~₹53,000 per booking
```

### 4.4 Example Revenue Calculations

**Scenario 1: 20 bookings/month average**

```
10 × ₹300K venue bookings (₹2,000 + 8%):
  Revenue: 10 × ₹26,000 = ₹260,000

10 × ₹150K venue bookings (₹1,500 + 6%):
  Revenue: 10 × ₹10,500 = ₹105,000

Monthly Revenue: ₹365,000
Annual Revenue: ₹4,380,000
```

**Scenario 2: 50 bookings/month (scaled)**

```
25 × ₹350K average bookings:
  Revenue: 25 × ₹30,000 = ₹750,000

25 × ₹120K average bookings:
  Revenue: 25 × ₹9,200 = ₹230,000

Monthly Revenue: ₹980,000
Annual Revenue: ₹11,760,000
```

### 4.5 How to Convince Venues to Join

**Value Proposition for Venue Partners**:

1. **Lead Generation**: "We bring new customers you wouldn't find otherwise"
2. **No Upfront Cost**: "Pay only commission when you get a booking"
3. **Professional Platform**: "Professional inquiry system beats phone spam"
4. **Payment Security**: "We collect payment upfront, you get guaranteed revenue"
5. **Marketing**: "Featured listings for top performers" (upsell opportunity)
6. **Analytics**: "Dashboard shows your performance and bookings"

**Example Pitch**:
> "Palace Grounds gets ~₹435,000 net per ₹475,000 booking. That's revenue you wouldn't have had. Our commission is 8-10% industry standard. Plus, we handle payment collection, so you're never chasing customers for money."

### 4.6 How to Prevent Venue Bypass

**Legal & Technical Safeguards**:

1. **Terms & Conditions**: Strict clause preventing direct deals for 12 months
2. **Booking Lock-in**: Customer email only available after payment
3. **Platform-Only Communication**: No phone numbers/emails visible until booking confirmed
4. **Breach Penalties**: ₹50K-100K penalty if venue directly contacts customer
5. **Smart Detection**: Monitor for patterns of customers contacting same venue repeatedly

### 4.7 Terms & Conditions to Include

```
1. Exclusivity: Customer must not contact venue directly for 12 months post-booking
2. Commission: Non-negotiable and due within 7 days of booking
3. Cancellation: Platform handles refunds; venue responsible for customer satisfaction
4. Fraud: 100% refund to customer if venue cancels after payment
5. Dispute: Binding arbitration; ConventionHub decides in case of conflict
6. Data: Venue cannot store/reuse customer data without consent
7. Termination: We can remove venue for terms violation; no refunds
```

---

## PART 5: IMPLEMENTATION DETAILS

### 5.1 File Structure After Implementation

```
app/
  ├── (admin)/
  │   ├── _layout.tsx (updated with real auth)
  │   ├── admin-dashboard.tsx (real-time data)
  │   ├── approvals.tsx (real workflow)
  │   ├── commissions.tsx (real data)
  │   └── payments-review.tsx (NEW)
  │
  ├── (owner)/
  │   ├── _layout.tsx (updated with real auth)
  │   ├── dashboard.tsx (real analytics)
  │   ├── owner-bookings.tsx (real-time subscriptions)
  │   ├── owner-analytics.tsx (real data)
  │   ├── owner-payouts.tsx (real payouts)
  │   └── owner-pricing.tsx (exists)
  │
  ├── (tabs)/
  │   ├── bookings.tsx (updated)
  │   ├── discover.tsx (updated)
  │   └── ...
  │
  ├── booking/
  │   ├── [id].tsx (updated - integrate payment)
  │   ├── payment-upi.tsx (NEW)
  │   └── payment-gateway.tsx (NEW - Razorpay)
  │
  ├── customer-login.tsx (updated - real Supabase)
  ├── owner-login.tsx (updated - complete integration)
  ├── admin-login.tsx (updated - real Supabase)
  ├── booking-success.tsx (updated - send confirmation emails)
  └── ...

utils/
  ├── email.ts (NEW - email service)
  ├── payment.ts (NEW - payment logic)
  ├── pricing.ts (updated - commission calculation)
  ├── razorpay.ts (NEW - optional payment gateway)
  ├── upi.ts (NEW - UPI QR generation)
  └── ...

components/
  ├── PaymentUPICard.tsx (NEW)
  ├── PaymentGatewayCard.tsx (NEW)
  ├── BookingConfirmation.tsx (NEW)
  └── ...

types/
  └── index.ts (updated - add payment types)

constants/
  ├── commission.ts (NEW - commission rules)
  ├── email.ts (NEW - email templates)
  └── ...

scripts/
  ├── setup_database.sql (updated - new tables)
  └── seed_payments.ts (NEW - for testing)
```

### 5.2 Key Functions to Implement

#### Authentication
```typescript
// utils/auth.ts (NEW)
export async function loginWithOTP(email: string): Promise<void>
export async function verifyOTP(email: string, token: string): Promise<Session>
export async function getCurrentUser(): Promise<User | null>
export async function logout(): Promise<void>
export async function getRole(): Promise<'customer' | 'owner' | 'admin' | null>
```

#### Booking
```typescript
// utils/booking.ts (NEW)
export async function checkAvailability(hallId: string, date: string, slot: SlotType): Promise<boolean>
export async function createBooking(params: BookingParams): Promise<Booking>
export async function confirmBooking(bookingId: string): Promise<void>
export async function cancelBooking(bookingId: string, reason: string): Promise<void>
export async function getBookingHistory(customerId: string): Promise<Booking[]>
```

#### Payment
```typescript
// utils/payment.ts (NEW)
export async function generateUPIQRCode(amount: number, upiId: string): Promise<string>
export async function uploadPaymentScreenshot(file: File): Promise<string>
export async function createPaymentRecord(bookingId: string, amount: number): Promise<Payment>
export async function verifyPayment(paymentId: string): Promise<void>
export async function calculateCommission(bookingAmount: number): Promise<Commission>
```

#### Email
```typescript
// utils/email.ts (NEW)
export async function sendOTPEmail(email: string, otp: string): Promise<void>
export async function sendBookingConfirmation(booking: Booking): Promise<void>
export async function sendPartnerNotification(booking: Booking): Promise<void>
export async function sendPaymentVerification(payment: Payment): Promise<void>
```

---

## PART 6: TESTING STRATEGY

### 6.1 Test Cases by Phase

#### Phase 1: Authentication
- [ ] Customer login with new email → profile created
- [ ] OTP sent to email
- [ ] OTP verification succeeds with correct code
- [ ] OTP verification fails with wrong code
- [ ] Session persists across app reload
- [ ] Logout clears session

#### Phase 2: Bookings & Double-Booking
- [ ] Book morning slot on date X
- [ ] Book evening slot on date X (should succeed)
- [ ] Book morning slot again on date X (should fail - already booked)
- [ ] UI shows booked slots as disabled
- [ ] Database constraint prevents double-booking

#### Phase 3: Payment Flow
- [ ] Generate UPI QR code for amount
- [ ] Upload payment screenshot
- [ ] Admin reviews and marks verified
- [ ] Booking status changes to confirmed
- [ ] Confirmation email sent

#### Phase 4: Partner Dashboard
- [ ] Partner logs in → sees their bookings
- [ ] New booking created → appears in real-time
- [ ] Partner confirms booking → customer gets email
- [ ] Partner adds internal notes → saved in database
- [ ] Partner views analytics → real data displayed

---

## PART 7: ROLLOUT & DEPLOYMENT

### 7.1 Deployment Checklist

- [ ] Database migrations executed
- [ ] Supabase RLS policies enabled
- [ ] Environment variables set (SendGrid, API keys)
- [ ] Email templates configured
- [ ] UPI QR generation tested
- [ ] Payment flow end-to-end tested
- [ ] Partner workflows tested
- [ ] Admin dashboard tested
- [ ] Performance tested (load testing)
- [ ] Security audit completed
- [ ] Data migration from mock to real data

### 7.2 Soft Launch

1. **Week 1**: Internal testing with ConventionHub team
2. **Week 2**: Beta with 5-10 venue partners
3. **Week 3**: Gradual rollout to 25 venues
4. **Week 4**: Full public launch

---

## PART 8: RISK ASSESSMENT & RECOMMENDATIONS

### Risks & Mitigation

| Risk | Impact | Mitigation |
|------|--------|-----------|
| **Payment fraud** | High | Admin verification + Razorpay integration later |
| **Double-booking race condition** | High | Database constraint + row-level locking |
| **Venue bypass** | Medium | Terms, email obfuscation, penalty clauses |
| **Email delivery** | Medium | SendGrid with bounced email handling |
| **RLS misconfiguration** | High | Thorough testing + security audit |
| **Commission disputes** | Medium | Clear T&Cs + audit trail in database |

### Recommendations

1. **Start with UPI manual verification** — Fast to implement, good for MVP
2. **Add Razorpay later** — When volume justifies payment gateway fees
3. **Use SendGrid** — More reliable than Supabase email (if available)
4. **Start with 10% commission** — Room to negotiate down if needed
5. **Build admin payment verification UI first** — Critical for revenue
6. **Monitor RLS policies closely** — Security is paramount

---

## NEXT STEPS

### Immediate Actions
1. ✅ **This Document**: Approved implementation plan
2. ⏳ **Phase 1 Implementation**: Start with auth + booking fundamentals
3. ⏳ **Database Migration**: Run schema updates
4. ⏳ **Testing**: Build test cases alongside implementation

### Success Metrics
- 100% successful OTP logins
- 0 double-bookings
- 95%+ email delivery rate
- <5s payment verification
- $365K+ monthly revenue at scale

---

**Document Version**: 1.0  
**Last Updated**: May 5, 2026  
**Status**: Ready for Implementation
