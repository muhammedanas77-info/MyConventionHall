import type { BlockedDateRange } from '@/types';

/**
 * Checks whether a given date is available for booking.
 *
 * A date is unavailable if:
 * - It falls within any blocked date range (inclusive of start and end), OR
 * - It matches any confirmed booking's event_date
 *
 * @param blockedRanges  - Array of blocked date ranges from vendor profile sector_data
 * @param confirmedBookings - Array of confirmed bookings with event_date strings
 * @param date - ISO date string to check (e.g. "2025-08-15")
 * @returns true if the date is available, false if it is blocked or already booked
 *
 * Validates: Requirements 6.2, 6.3
 */
export function isDateAvailable(
  blockedRanges: BlockedDateRange[],
  confirmedBookings: { event_date: string }[],
  date: string
): boolean {
  // Check against confirmed bookings
  for (const booking of confirmedBookings) {
    if (booking.event_date === date) {
      return false;
    }
  }

  // Check against blocked date ranges (inclusive)
  for (const range of blockedRanges) {
    if (date >= range.start_date && date <= range.end_date) {
      return false;
    }
  }

  return true;
}

/**
 * Returns all unavailable ISO date strings between fromDate and toDate (inclusive).
 * Used for calendar rendering to mark non-selectable dates.
 *
 * @param blockedRanges - Array of blocked date ranges from vendor profile sector_data
 * @param confirmedBookings - Array of confirmed bookings with event_date strings
 * @param fromDate - Start of the date range to check (ISO date string, e.g. "2025-08-01")
 * @param toDate - End of the date range to check (ISO date string, e.g. "2026-08-01")
 * @returns Array of ISO date strings that are unavailable within the given range
 *
 * Validates: Requirements 6.2, 6.3
 */
export function getUnavailableDates(
  blockedRanges: BlockedDateRange[],
  confirmedBookings: { event_date: string }[],
  fromDate: string,
  toDate: string
): string[] {
  const unavailable: string[] = [];

  // Build a Set of confirmed booking dates for O(1) lookup
  const bookedDates = new Set(confirmedBookings.map((b) => b.event_date));

  // Iterate day by day from fromDate to toDate
  const current = new Date(fromDate);
  const end = new Date(toDate);

  while (current <= end) {
    const dateStr = current.toISOString().slice(0, 10); // "YYYY-MM-DD"

    if (!isDateAvailable(blockedRanges, [], dateStr) || bookedDates.has(dateStr)) {
      unavailable.push(dateStr);
    }

    current.setDate(current.getDate() + 1);
  }

  return unavailable;
}
