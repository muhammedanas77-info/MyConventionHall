import { supabase } from '@/utils/supabase';

export type NotificationType =
  | 'booking_created'
  | 'payment_submitted'
  | 'payment_verified'
  | 'payment_rejected'
  | 'partner_confirmed'
  | 'partner_rejected'
  | 'partner_contacted';

export async function sendBookingNotification(type: NotificationType, bookingId: string) {
  try {
    const { error } = await supabase.functions.invoke('send-booking-email', {
      body: { type, bookingId },
    });

    if (error) {
      console.log('Notification function error:', error.message);
    }
  } catch (error) {
    console.log('Notification function unavailable:', error);
  }
}
