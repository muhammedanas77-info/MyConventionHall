import { supabase } from '@/utils/supabase';
import { sendBookingNotification } from '@/utils/notifications';

export interface PaymentReviewItem {
  id: string;
  booking_id: string;
  customer_id: string;
  amount: number;
  advance_amount: number;
  payment_method: string;
  status: string;
  verification_screenshot_url: string | null;
  verified_at: string | null;
  verified_by_admin: string | null;
  created_at: string;
  booking?: any;
}

export async function getPaymentByBookingId(bookingId: string) {
  const { data, error } = await supabase
    .from('payments')
    .select('*')
    .eq('booking_id', bookingId)
    .single();

  return { data, error };
}

export async function submitPaymentProof(paymentId: string, proofUrl?: string | null, note?: string) {
  const { data, error } = await supabase
    .from('payments')
    .update({
      verification_screenshot_url: proofUrl ?? null,
      customer_note: note ?? null,
      status: 'submitted',
    })
    .eq('id', paymentId)
    .select()
    .single();

  return { data, error };
}

export async function fetchPendingPayments() {
  const { data, error } = await supabase
    .from('payments')
    .select('*')
    .in('status', ['pending', 'submitted'])
    .order('created_at', { ascending: false });

  return { data, error };
}

export async function verifyPayment(paymentId: string, adminId: string) {
  const { data: paymentData, error: paymentError } = await supabase
    .from('payments')
    .select('*')
    .eq('id', paymentId)
    .single();

  if (paymentError || !paymentData) {
    return { success: false, error: paymentError?.message || 'Payment not found' };
  }

  const bookingId = paymentData.booking_id;
  const now = new Date().toISOString();

  // Update payment status to verified
  const { error: paymentUpdateError } = await supabase
    .from('payments')
    .update({
      status: 'verified',
      verified_at: now,
      verified_by_admin: adminId,
    })
    .eq('id', paymentId);

  if (paymentUpdateError) {
    return { success: false, error: paymentUpdateError.message };
  }

  const { data: bookingData, error: bookingFetchError } = await supabase
    .from('bookings')
    .select('id, hall_id, total_amount, discount_amount')
    .eq('id', bookingId)
    .single();

  if (bookingFetchError || !bookingData) {
    return { success: false, error: bookingFetchError?.message || 'Booking not found' };
  }

  // Step 1: Update payment_verified fields (safe — no check constraint)
  const { error: verifyError } = await supabase
    .from('bookings')
    .update({
      payment_verified: true,
      payment_verified_at: now,
    })
    .eq('id', bookingId);

  if (verifyError) {
    return { success: false, error: verifyError.message };
  }

  // Step 2: Try to update status separately — if constraint fails, that's OK
  const { error: statusError } = await supabase
    .from('bookings')
    .update({ status: 'confirmed' })
    .eq('id', bookingId);

  if (statusError) {
    console.warn('Status update failed (check constraint), booking still marked as verified:', statusError.message);
  }

  // Record status history
  await supabase.from('booking_status_history').insert([
    {
      booking_id: bookingId,
      old_status: 'pending',
      new_status: 'confirmed',
      changed_by: adminId,
      reason: 'Payment verified by admin',
    }
  ]);

  // Calculate commission
  const { data: hallData } = await supabase
    .from('halls')
    .select('owner_id')
    .eq('id', bookingData.hall_id)
    .single();

  const commission = Math.round((bookingData.total_amount || paymentData.amount || 0) * 0.08);
  const discount = bookingData.discount_amount || 0;
  await supabase.from('commissions').upsert([
    {
      booking_id: bookingId,
      owner_id: hallData?.owner_id ?? null,
      admin_commission: commission,
      owner_payout: (bookingData.total_amount || paymentData.amount || 0) - commission,
      discount,
      status: 'calculated',
    }
  ], { onConflict: 'booking_id' });

  sendBookingNotification('payment_verified', bookingId).catch(console.log);

  return { success: true };
}

export async function rejectPayment(paymentId: string, adminId: string, reason: string) {
  const { data, error } = await supabase
    .from('payments')
    .update({
      status: 'failed',
      verification_screenshot_url: reason,
      verified_by_admin: adminId,
    })
    .eq('id', paymentId)
    .select()
    .single();

  if (!error && data?.booking_id) {
    sendBookingNotification('payment_rejected', data.booking_id).catch(console.log);
  }

  return { data, error };
}
