import { supabase } from '@/utils/supabase';
import { sendBookingNotification } from '@/utils/notifications';
import type { BookingStatus, SlotType } from '@/types';

export interface NormalizedBooking {
  id: string;
  hall_id: string;
  customer_id: string;
  date: string;
  slot: SlotType;
  guest_count: number;
  total_amount: number;
  advance_amount: number;
  commission_amount: number;
  discount_amount: number;
  payment_id: string | null;
  refund_id: string | null;
  refund_status: string | null;
  status: BookingStatus;
  payment_verified: boolean;
  payment_verified_at?: string | null;
  special_requests: string | null;
  created_at: string;
  hall?: any;
}

export function normalizeBooking(raw: any): NormalizedBooking {
  return {
    ...raw,
    date: raw.event_date ?? raw.date,
    slot: raw.slot_type ?? raw.slot,
    status: (raw.payment_verified && raw.status === 'pending') ? 'confirmed' : (raw.status as BookingStatus),
    special_requests: raw.special_requests ?? raw.notes ?? null,
    payment_verified: raw.payment_verified ?? false,
    payment_verified_at: raw.payment_verified_at ?? null,
    commission_amount: raw.commission_amount ?? raw.admin_commission ?? 0,
    discount_amount: raw.discount_amount ?? raw.discount ?? 0,
    payment_id: raw.payment_id ?? null,
    refund_id: raw.refund_id ?? null,
    refund_status: raw.refund_status ?? null,
  };
}

/**
 * Check if a specific slot is available for booking.
 * Queries both old (date/slot) and new (event_date/slot_type) column names
 * to work regardless of which DB migration state is active.
 */
export async function checkSlotAvailability(
  hallId: string,
  date: string,
  slot: SlotType
): Promise<boolean> {
  try {
    const conflictSlots = slot === 'full_day'
      ? ['morning', 'evening', 'full_day']
      : [slot, 'full_day'];

    // Query using new column names (post-migration)
    const { data: newData, error: newError } = await supabase
      .from('bookings')
      .select('id')
      .eq('hall_id', hallId)
      .eq('event_date', date)
      .in('slot_type', conflictSlots)
      .in('status', ['pending', 'confirmed'])
      .maybeSingle();

    if (!newError && newData) return false; // slot taken

    // Fallback: query using old column names (pre-migration)
    const { data: oldData, error: oldError } = await supabase
      .from('bookings')
      .select('id')
      .eq('hall_id', hallId)
      .eq('date', date)
      .in('slot', conflictSlots)
      .in('status', ['pending', 'confirmed'])
      .maybeSingle();

    if (!oldError && oldData) return false; // slot taken

    return true; // available
  } catch (err) {
    console.error('Availability check failed:', err);
    return false;
  }
}

/**
 * Get all booked slots for a specific hall and date.
 * Handles both old (date/slot) and new (event_date/slot_type) column names.
 */
export async function getBookedSlots(
  hallId: string,
  date: string
): Promise<SlotType[]> {
  try {
    // Try new column names first
    const { data: newData, error: newError } = await supabase
      .from('bookings')
      .select('slot_type')
      .eq('hall_id', hallId)
      .eq('event_date', date)
      .in('status', ['pending', 'confirmed']);

    if (!newError && newData && newData.length > 0) {
      return newData.map((b: any) => b.slot_type).filter(Boolean);
    }

    // Fallback to old column names
    const { data: oldData, error: oldError } = await supabase
      .from('bookings')
      .select('slot')
      .eq('hall_id', hallId)
      .eq('date', date)
      .in('status', ['pending', 'confirmed']);

    if (oldError) {
      console.error('Error fetching booked slots:', oldError);
      return [];
    }

    return (oldData ?? []).map((b: any) => b.slot).filter(Boolean);
  } catch (err) {
    console.error('Failed to fetch booked slots:', err);
    return [];
  }
}

/**
 * Create a new booking with payment verification requirement
 */
export async function createBooking(params: {
  hallId: string;
  customerId: string;
  date: string;
  slot: SlotType;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  guestCount: number;
  totalAmount: number;
  advanceAmount: number;
  commission: number;
  discount: number;
  specialRequests?: string;
}): Promise<{ success: boolean; bookingId?: string; error?: string }> {
  try {
    const isAvailable = await checkSlotAvailability(params.hallId, params.date, params.slot);
    if (!isAvailable) {
      return { success: false, error: 'This slot is no longer available. Please select another.' };
    }

    const { data: hallData, error: hallError } = await supabase
      .from('halls')
      .select('owner_id')
      .eq('id', params.hallId)
      .single();

    if (hallError || !hallData) {
      return { success: false, error: 'Unable to find venue owner. Please try again.' };
    }

    const bookingPayload: Record<string, any> = {
      hall_id: params.hallId,
      customer_id: params.customerId,
      event_date: params.date,
      slot_type: params.slot,
      customer_name: params.customerName,
      customer_email: params.customerEmail,
      customer_phone: params.customerPhone,
      guest_count: params.guestCount,
      total_amount: params.totalAmount,
      advance_amount: params.advanceAmount,
      commission_amount: params.commission,
      discount_amount: params.discount,
      status: 'pending',
      payment_verified: false,
    };

    // Also write legacy column names if they exist in the schema
    // (setup_database.sql used 'date', 'slot', 'total_price' — Phase 1 added the new names)
    // We attempt both; Supabase will ignore unknown columns gracefully via upsert,
    // but insert will fail on unknown columns — so we catch and retry without them.
    const legacyFields: Record<string, any> = {
      date: params.date,
      slot: params.slot,
      total_price: params.totalAmount,
    };

    // Try inserting with legacy fields first (for DBs that still have old columns)
    let data: any = null;
    let error: any = null;

    const withLegacy = await supabase
      .from('bookings')
      .insert([{ ...bookingPayload, ...legacyFields }])
      .select()
      .single();

    if (withLegacy.error) {
      // If it failed due to unknown column, retry without legacy fields
      const isColumnError = withLegacy.error.message?.includes('column') ||
        withLegacy.error.code === '42703' ||
        withLegacy.error.message?.includes('schema cache');

      if (isColumnError) {
        const withoutLegacy = await supabase
          .from('bookings')
          .insert([bookingPayload])
          .select()
          .single();
        data = withoutLegacy.data;
        error = withoutLegacy.error;
      } else {
        data = withLegacy.data;
        error = withLegacy.error;
      }
    } else {
      data = withLegacy.data;
      error = withLegacy.error;
    }

    if (error || !data) {
      return { success: false, error: error?.message ?? 'Unable to create booking.' };
    }

    // Attempt to create the payments row — this is best-effort.
    // If the payments table doesn't exist or has a schema mismatch we still
    // let the booking succeed so the customer reaches the payment screen.
    const { error: paymentError } = await supabase.from('payments').insert([
      {
        booking_id: data.id,
        customer_id: params.customerId,
        amount: params.totalAmount,
        advance_amount: params.advanceAmount,
        payment_method: 'upi',
        status: 'pending',
      }
    ]);

    if (paymentError) {
      // Log but do NOT cancel the booking — the payment screen can still work
      // by looking up the booking directly if no payments row exists.
      console.warn('Payment row creation failed (non-fatal):', paymentError.message);
    }

    sendBookingNotification('booking_created', data.id).catch(console.log);

    return { success: true, bookingId: data.id };
  } catch (err) {
    console.error('Booking creation failed:', err);
    return { success: false, error: 'Failed to create booking. Please try again.' };
  }
}

/**
 * Cancel a booking and free up the slot
 */
export async function cancelBooking(
  bookingId: string,
  reason: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { data: existingBooking, error: fetchError } = await supabase
      .from('bookings')
      .select('status')
      .eq('id', bookingId)
      .single();

    if (fetchError) {
      return { success: false, error: fetchError.message };
    }

    const oldStatus = existingBooking?.status ?? 'pending';

    const { error } = await supabase
      .from('bookings')
      .update({ status: 'cancelled' })
      .eq('id', bookingId);

    if (error) {
      return { success: false, error: error.message };
    }

    await supabase.from('booking_status_history').insert([
      {
        booking_id: bookingId,
        old_status: oldStatus,
        new_status: 'cancelled',
        reason,
      }
    ]);

    return { success: true };
  } catch (err) {
    console.error('Booking cancellation failed:', err);
    return { success: false, error: 'Failed to cancel booking.' };
  }
}
