/**
 * utils/sectorValidation.ts
 *
 * Per-sector Zod validation schemas for vendor profile sector_data.
 * Enforces all field bounds defined in Requirements 2.1–2.8.
 *
 * NOTE: Requires `zod` to be installed:
 *   npx expo install zod
 *   — or —
 *   npm install zod
 */

import { z } from 'zod';
import type { VendorSector } from '@/types';

// ─── Shared sub-schema ────────────────────────────────────────────────────────

/**
 * Validates a blocked date range.
 * Both dates must be valid ISO date strings and start_date must be ≤ end_date.
 */
export const blockedDateRangeSchema = z
  .object({
    start_date: z
      .string()
      .refine((d) => !Number.isNaN(Date.parse(d)), {
        message: 'start_date must be a valid ISO date string',
      }),
    end_date: z
      .string()
      .refine((d) => !Number.isNaN(Date.parse(d)), {
        message: 'end_date must be a valid ISO date string',
      }),
  })
  .refine((r) => r.start_date <= r.end_date, {
    message: 'start_date must be on or before end_date',
    path: ['start_date'],
  });

// ─── Sector schemas ───────────────────────────────────────────────────────────

/**
 * Requirement 2.1 — venue
 */
export const venueSectorSchema = z
  .object({
    business_name: z.string().min(1).max(100),
    address: z.string().min(1).max(200),
    city: z.string().min(1).max(100),
    capacity_min: z.number().int().min(1).max(100_000),
    capacity_max: z.number().int().min(1).max(100_000),
    price_per_day: z.number().min(1).max(10_000_000),
    photos: z.array(z.string().url()).min(1).max(20),
    amenities: z.array(z.string().max(100)).max(50),
    blocked_dates: z.array(blockedDateRangeSchema),
  })
  .refine((d) => d.capacity_max >= d.capacity_min, {
    message: 'capacity_max must be ≥ capacity_min',
    path: ['capacity_max'],
  });

/**
 * Requirement 2.2 — florist
 */
export const floristSectorSchema = z
  .object({
    business_name: z.string().min(1).max(100),
    city: z.string().min(1).max(100),
    service_area: z.string().min(1).max(200),
    specialty_styles: z.array(z.string().max(50)).min(1).max(10),
    price_range_min: z.number().min(1).max(10_000_000),
    price_range_max: z.number().min(1).max(10_000_000),
    portfolio_photos: z.array(z.string().url()).min(0).max(20),
    blocked_dates: z.array(blockedDateRangeSchema),
  })
  .refine((d) => d.price_range_max >= d.price_range_min, {
    message: 'price_range_max must be ≥ price_range_min',
    path: ['price_range_max'],
  });

/**
 * Requirement 2.3 — musician
 */
export const musicianSectorSchema = z.object({
  artist_name: z.string().min(1).max(100),
  city: z.string().min(1).max(100),
  genre_tags: z.array(z.string().max(50)).min(1).max(10),
  performance_durations_min: z.array(z.number().int().min(15).max(480)).min(1).max(10),
  price_per_event: z.number().min(1).max(10_000_000),
  demo_links: z.array(z.string().url().max(500)).min(0).max(5),
  blocked_dates: z.array(blockedDateRangeSchema),
});

/**
 * Requirement 2.4 — photographer
 */
export const photographerSectorSchema = z.object({
  studio_name: z.string().min(1).max(100),
  city: z.string().min(1).max(100),
  photography_styles: z.array(z.string().max(50)).min(1).max(10),
  packages: z
    .array(
      z.object({
        name: z.string().min(1).max(100),
        price: z.number().min(1).max(10_000_000),
      })
    )
    .min(1)
    .max(20),
  portfolio_media: z.array(z.string().url()).min(0).max(20),
  blocked_dates: z.array(blockedDateRangeSchema),
});

/**
 * Requirement 2.5 — caterer
 */
export const catererSectorSchema = z
  .object({
    business_name: z.string().min(1).max(100),
    city: z.string().min(1).max(100),
    cuisine_types: z.array(z.string().max(50)).min(1).max(10),
    service_capacity_min: z.number().int().min(1).max(100_000),
    service_capacity_max: z.number().int().min(1).max(100_000),
    price_per_plate_min: z.number().min(1).max(100_000),
    price_per_plate_max: z.number().min(1).max(100_000),
    menu_highlights: z.string().max(500),
    blocked_dates: z.array(blockedDateRangeSchema),
  })
  .refine((d) => d.service_capacity_max >= d.service_capacity_min, {
    message: 'service_capacity_max must be ≥ service_capacity_min',
    path: ['service_capacity_max'],
  })
  .refine((d) => d.price_per_plate_max >= d.price_per_plate_min, {
    message: 'price_per_plate_max must be ≥ price_per_plate_min',
    path: ['price_per_plate_max'],
  });

/**
 * Requirement 2.6 — decorator
 */
export const decoratorSectorSchema = z
  .object({
    business_name: z.string().min(1).max(100),
    city: z.string().min(1).max(100),
    decoration_themes: z.array(z.string().max(50)).min(1).max(10),
    price_range_min: z.number().min(1).max(10_000_000),
    price_range_max: z.number().min(1).max(10_000_000),
    portfolio_photos: z.array(z.string().url()).min(0).max(20),
    blocked_dates: z.array(blockedDateRangeSchema),
  })
  .refine((d) => d.price_range_max >= d.price_range_min, {
    message: 'price_range_max must be ≥ price_range_min',
    path: ['price_range_max'],
  });

/**
 * Requirement 2.7 — artist
 */
export const artistSectorSchema = z.object({
  artist_name: z.string().min(1).max(100),
  city: z.string().min(1).max(100),
  art_types: z.array(z.string().max(50)).min(1).max(10),
  price_per_event: z.number().min(1).max(10_000_000),
  portfolio_photos: z.array(z.string().url()).min(0).max(20),
  blocked_dates: z.array(blockedDateRangeSchema),
});

/**
 * Requirement 2.8 — other
 */
export const otherSectorSchema = z
  .object({
    business_name: z.string().min(1).max(100),
    city: z.string().min(1).max(100),
    service_description: z.string().min(1).max(500),
    price_range_min: z.number().min(1).max(10_000_000),
    price_range_max: z.number().min(1).max(10_000_000),
    blocked_dates: z.array(blockedDateRangeSchema),
  })
  .refine((d) => d.price_range_max >= d.price_range_min, {
    message: 'price_range_max must be ≥ price_range_min',
    path: ['price_range_max'],
  });

// ─── Schema registry ──────────────────────────────────────────────────────────

/**
 * Map from VendorSector to its Zod schema.
 * Import this to validate sector_data for any sector dynamically.
 */
export const sectorSchemas: Record<VendorSector, z.ZodSchema> = {
  venue: venueSectorSchema,
  florist: floristSectorSchema,
  musician: musicianSectorSchema,
  photographer: photographerSectorSchema,
  caterer: catererSectorSchema,
  decorator: decoratorSectorSchema,
  artist: artistSectorSchema,
  other: otherSectorSchema,
};

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Validates `data` against the schema for the given `sector`.
 * Returns a Zod SafeParseReturnType — never throws.
 *
 * Usage:
 *   const result = validateSectorData('venue', formValues);
 *   if (!result.success) console.log(result.error.flatten());
 */
export function validateSectorData(
  sector: VendorSector,
  data: unknown
): z.SafeParseReturnType<unknown, unknown> {
  return sectorSchemas[sector].safeParse(data);
}

// ─── Mandatory fields per sector ─────────────────────────────────────────────

/**
 * Returns the list of field names that are considered mandatory for a sector.
 * Used by the profile_completion_status logic (Requirement 1.4):
 *   - if all mandatory fields are present and valid → 'complete'
 *   - otherwise → 'incomplete'
 *
 * Fields that are optional (min(0) arrays, nullable strings) are excluded.
 */
const MANDATORY_FIELDS: Record<VendorSector, string[]> = {
  venue: [
    'business_name',
    'address',
    'city',
    'capacity_min',
    'capacity_max',
    'price_per_day',
    'photos',       // min 1
    'amenities',    // can be empty array but field must exist
  ],
  florist: [
    'business_name',
    'city',
    'service_area',
    'specialty_styles', // min 1
    'price_range_min',
    'price_range_max',
  ],
  musician: [
    'artist_name',
    'city',
    'genre_tags',               // min 1
    'performance_durations_min', // min 1
    'price_per_event',
  ],
  photographer: [
    'studio_name',
    'city',
    'photography_styles', // min 1
    'packages',           // min 1
  ],
  caterer: [
    'business_name',
    'city',
    'cuisine_types',        // min 1
    'service_capacity_min',
    'service_capacity_max',
    'price_per_plate_min',
    'price_per_plate_max',
  ],
  decorator: [
    'business_name',
    'city',
    'decoration_themes', // min 1
    'price_range_min',
    'price_range_max',
  ],
  artist: [
    'artist_name',
    'city',
    'art_types',      // min 1
    'price_per_event',
  ],
  other: [
    'business_name',
    'city',
    'service_description',
    'price_range_min',
    'price_range_max',
  ],
};

/**
 * Returns the list of required field names for the given sector.
 * Used to compute `profile_completion_status` on the vendor_profiles record.
 */
export function getMandatoryFields(sector: VendorSector): string[] {
  return MANDATORY_FIELDS[sector];
}
