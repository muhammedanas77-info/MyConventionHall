export function formatCurrency(amount: number): string {
    if (amount >= 100000) {
        const lakhs = amount / 100000;
        const formatted = lakhs % 1 === 0 ? lakhs.toFixed(0) : lakhs.toFixed(1);
        return `₹${formatted}L`;
    }
    return `₹${amount.toLocaleString('en-IN')}`;
}

export function formatCurrencyFull(amount: number): string {
    return `₹${amount.toLocaleString('en-IN')}`;
}

export function formatCurrencyCompact(amount: number): string {
    if (amount >= 10000000) {
        return `₹${(amount / 10000000).toFixed(1)}Cr`;
    }
    if (amount >= 100000) {
        return `₹${(amount / 100000).toFixed(1)}L`;
    }
    if (amount >= 1000) {
        return `₹${(amount / 1000).toFixed(0)}K`;
    }
    return `₹${amount}`;
}
