import type { SectorCommissionRate } from '@/types';

export interface CommissionResult {
  commission: number;
  vendorPayout: number;
  isCapped: boolean;
}

/**
 * Calculates the platform commission and vendor payout for a booking.
 *
 * Formula: commission = fixed_fee + (percentage_rate / 100) * totalAmount
 * Cap: if commission > 50% of totalAmount, cap at 50% and set isCapped = true
 * vendorPayout = totalAmount - commission
 *
 * Requirements: 9.2, 9.3, 9.6
 */
export function calculateCommission(
  rate: SectorCommissionRate,
  totalAmount: number
): CommissionResult {
  let commission = rate.fixed_fee + (rate.percentage_rate / 100) * totalAmount;
  let isCapped = false;

  const cap = totalAmount * 0.5;
  if (commission > cap) {
    commission = cap;
    isCapped = true;
  }

  commission = Math.round(commission * 100) / 100;
  const vendorPayout = Math.round((totalAmount - commission) * 100) / 100;

  return { commission, vendorPayout, isCapped };
}
