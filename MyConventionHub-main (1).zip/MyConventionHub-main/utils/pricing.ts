import { COMMISSION_RATE, ADVANCE_RATE, DISCOUNT_TIERS, SEASON_SLOT_MULTIPLIERS } from '@/constants/pricing';
import type { SeasonType, SlotType, PriceBreakdown } from '@/types';

export function getSlotPrice(basePrice: number, season: SeasonType, slot: SlotType): number {
    const multiplier = SEASON_SLOT_MULTIPLIERS[season][slot];
    return Math.round(basePrice * multiplier);
}

export function getDiscount(price: number): number {
    for (const tier of DISCOUNT_TIERS) {
        if (price <= tier.maxPrice) {
            return tier.discount;
        }
    }
    return DISCOUNT_TIERS[DISCOUNT_TIERS.length - 1].discount;
}

export function calculatePriceBreakdown(
    basePrice: number,
    season: SeasonType,
    slot: SlotType
): PriceBreakdown {
    const slotPrice = getSlotPrice(basePrice, season, slot);
    const commission = Math.round(slotPrice * COMMISSION_RATE);
    const discount = getDiscount(slotPrice);
    const totalAmount = slotPrice - discount;
    const advanceAmount = Math.round(totalAmount * ADVANCE_RATE);
    const ownerGets = slotPrice;

    return {
        basePrice,
        season,
        slot,
        slotPrice,
        commission,
        discount,
        totalAmount,
        advanceAmount,
        ownerGets,
    };
}
