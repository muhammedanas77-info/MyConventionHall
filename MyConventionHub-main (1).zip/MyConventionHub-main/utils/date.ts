const MONTHS_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function formatDateDisplay(dateStr: string): string {
    const date = new Date(dateStr);
    return `${date.getDate()} ${MONTHS_FULL[date.getMonth()]} ${date.getFullYear()}`;
}

export function formatDateShort(dateStr: string): string {
    const date = new Date(dateStr);
    return `${date.getDate()} ${MONTHS_SHORT[date.getMonth()]}`;
}

function startOfDayMs(d: Date): number {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
}

export function isDateInPast(dateStr: string): boolean {
    return startOfDayMs(new Date(dateStr)) < startOfDayMs(new Date());
}

export function isDateInFuture(dateStr: string): boolean {
    return startOfDayMs(new Date(dateStr)) > startOfDayMs(new Date());
}

export function getDaysUntil(dateStr: string): number {
    const ms = startOfDayMs(new Date(dateStr)) - startOfDayMs(new Date());
    return Math.round(ms / 86400000);
}

export function getRefundPercentage(dateStr: string): number {
    const daysUntil = getDaysUntil(dateStr);
    if (daysUntil >= 30) return 100;
    if (daysUntil >= 15) return 50;
    return 0;
}

export function formatTimeAgo(dateStr: string): string {
    const now = new Date();
    const date = new Date(dateStr);
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return `${date.getDate()} ${MONTHS_SHORT[date.getMonth()]}`;
}
