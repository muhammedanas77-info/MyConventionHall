# Phase 1 Migration: Database & Authentication Setup

## Overview

This guide walks through deploying Phase 1 database migrations and verifying the new authentication system.

**Status**: Pre-deployment  
**Changes**: Database schema + Authentication refactor  
**Duration**: ~15 minutes

---

## Step 1: Run Database Migration

### Option A: Supabase Dashboard (Recommended)

1. Go to [Supabase Console](https://app.supabase.com)
2. Select your ConventionHub project
3. Navigate to **SQL Editor**
4. Click **New Query**
5. Copy the contents of `scripts/phase1_migration.sql`
6. Paste into the query editor
7. Click **Run**
8. Verify: "Migration completed successfully" or check tables in **Table Editor**

### Option B: Supabase CLI

```bash
cd d:\MyConventionHub
supabase db push
```

(Note: Ensure `.env` has `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`)

### Option C: Direct psql (Advanced)

```bash
psql -h db.XXXX.supabase.co -U postgres -d postgres < scripts/phase1_migration.sql
```

---

## Step 2: Verify Migration Success

Run these queries in Supabase SQL Editor to confirm:

```sql
-- Check new tables exist
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN ('payments', 'booking_status_history', 'commissions', 'partner_analytics');

-- Check uniqueness constraint on bookings
SELECT constraint_name FROM information_schema.table_constraints 
WHERE table_name = 'bookings' AND constraint_type = 'UNIQUE';

-- Check indexes created
SELECT indexname FROM pg_indexes WHERE tablename IN ('payments', 'commissions', 'booking_status_history');
```

**Expected Output**: All queries should return results with new tables, constraints, and indexes.

---

## Step 3: Test Authentication Flow

### Test Customer Login (Real OTP)

1. Open the app and navigate to **Customer Login**
2. Enter an email address (e.g., `test@example.com`)
3. Click **Continue**
4. Check your email inbox for OTP (sent via Supabase)
5. Enter OTP in the app
6. Verify: Redirected to Discover tab
7. Check Supabase: New profile created in `profiles` table with role='customer'

### Test Owner Login (Real OTP)

1. Navigate to **Owner Login**
2. Enter email + full name
3. Click **Request Access**
4. Check email for OTP
5. Enter OTP
6. Verify: Redirected to Owner Dashboard
7. Check Supabase: New profile created with role='owner'

### Test Admin Login (Real OTP)

1. Navigate to **Admin Login**
2. Enter email
3. Click **Request Access**
4. Check email for OTP
5. Enter OTP
6. Verify: Redirected to Admin Dashboard
7. Check Supabase: New profile created with role='admin'

---

## Step 4: Test Double-Booking Prevention

1. **Scenario**: Try booking the same venue, date, and slot twice
2. **Test Flow**:
   - User A: Book Palace Grounds, May 20, Evening slot
   - Payment verification pending...
   - User B: Try to book Palace Grounds, May 20, Evening slot (should fail or show unavailable)

3. **Expected**: 
   - Database constraint prevents duplicate (hall_id, event_date, slot_type)
   - UI shows slot as unavailable/booked
   - Error message: "This slot is no longer available"

---

## Step 5: Verify RLS Policies

Test that RLS policies are enforced:

```bash
# Test 1: Customer can only see own bookings
# Login as Customer A, fetch bookings → should see only their bookings

# Test 2: Owner can see bookings for their halls
# Login as Owner, fetch bookings → should see only bookings for their halls

# Test 3: Admin can see all bookings
# Login as Admin, fetch bookings → should see all bookings
```

---

## Step 6: Environment Variables Checklist

Ensure these are set in `.env.local`:

```env
EXPO_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGc... (for migrations/admin)
EXPO_PUBLIC_UPI_ID=rayyan182003-1@okaxis
EXPO_PUBLIC_UPI_QR_URL=https://xxxx.supabase.co/storage/v1/object/public/payment-assets/upi-qr.png
UPI_QR_LOCAL_PATH=./assets/payment/upi-qr.png
RESEND_API_KEY=re_xxx
NOTIFICATION_FROM_EMAIL=ConventionHub <noreply@yourdomain.com>
ADMIN_NOTIFICATION_EMAIL=admin@yourdomain.com
```

---

## Step 6A: Storage Buckets

Create these Supabase Storage buckets before testing the payment flow:

- `payment-proofs` for customer payment screenshots.
- `payment-assets` for the public UPI QR image.

Recommended MVP policy:

```sql
-- Public read for QR/payment assets if you host the QR in Supabase.
CREATE POLICY "Public can read payment assets"
ON storage.objects FOR SELECT
USING (bucket_id = 'payment-assets');

-- Authenticated users can upload payment proof files.
CREATE POLICY "Authenticated users can upload payment proofs"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'payment-proofs' AND auth.role() = 'authenticated');
```

---

## Step 6B: Automated Storage/QR Setup

After adding `SUPABASE_SERVICE_ROLE_KEY` and `UPI_QR_LOCAL_PATH`, run:

```bash
npm run setup:phase1-remote
```

This creates `payment-proofs` and `payment-assets`, uploads the QR image to `payment-assets`, and prints the public QR URL to paste into `EXPO_PUBLIC_UPI_QR_URL`.

---

## Step 6C: Booking Notification Emails

Deploy the Edge Function and set email secrets:

```bash
supabase functions deploy send-booking-email
supabase secrets set RESEND_API_KEY=re_xxx
supabase secrets set NOTIFICATION_FROM_EMAIL="ConventionHub <noreply@yourdomain.com>"
supabase secrets set ADMIN_NOTIFICATION_EMAIL=admin@yourdomain.com
```

The app invokes this function for booking creation, payment submission, payment verification/rejection, and venue partner actions.

---

## Step 7: Production Readiness Checks

- [ ] Migration runs without errors
- [ ] New tables and constraints exist
- [ ] Indexes created for performance
- [ ] RLS policies enabled and tested
- [ ] Customer OTP login works end-to-end
- [ ] Owner OTP login works end-to-end
- [ ] Admin OTP login works end-to-end
- [ ] Double-booking prevention works (database + UI)
- [ ] Existing bookings still visible (backward compatible)
- [ ] Supabase realtime enabled for new tables

---

## Troubleshooting

### "UNIQUE constraint already exists"
**Cause**: Migration ran twice  
**Fix**: Drop old constraint: `ALTER TABLE bookings DROP CONSTRAINT IF EXISTS bookings_unique_slot;`

### "Email not arriving"
**Cause**: Supabase email settings not configured  
**Fix**: 
1. Go to Supabase Console → Authentication → Email Templates
2. Verify templates are enabled
3. Check spam folder
4. Verify sender email is authorized

### "RLS policy denies access"
**Cause**: Wrong role or user not in profiles table  
**Fix**: 
1. Create profile for user: `INSERT INTO profiles (id, email, role) VALUES (user_id, 'test@test.com', 'customer');`
2. Clear app cache
3. Re-login

### "Payment table showing 403 permission denied"
**Cause**: RLS policy too restrictive  
**Fix**: Check admin is fetching with admin role in profiles

---

## Rollback Plan

If migration fails critically:

```sql
-- Drop new tables (CAREFUL - data loss)
DROP TABLE IF EXISTS public.partner_analytics CASCADE;
DROP TABLE IF EXISTS public.commissions CASCADE;
DROP TABLE IF EXISTS public.booking_status_history CASCADE;
DROP TABLE IF EXISTS public.payments CASCADE;

-- Remove constraint
ALTER TABLE public.bookings DROP CONSTRAINT IF EXISTS bookings_unique_slot;

-- Remove column
ALTER TABLE public.bookings DROP COLUMN IF EXISTS payment_verified;
ALTER TABLE public.bookings DROP COLUMN IF EXISTS payment_verified_at;
```

---

## Next Steps (Phase 2)

Once Phase 1 is verified:

- [ ] Implement UPI payment page (`app/booking/payment-upi.tsx`)
- [ ] Implement payment verification flow (admin dashboard)
- [ ] Send OTP emails via SendGrid
- [ ] Send confirmation emails
- [ ] Build partner real-time dashboard

---

**Document Version**: 1.0  
**Created**: May 5, 2026  
**Status**: Pre-Migration
