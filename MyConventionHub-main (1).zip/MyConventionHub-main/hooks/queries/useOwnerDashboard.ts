/**
 * useOwnerDashboard — aggregated stats derived from owner bookings
 *
 * SOLID:
 *  S — single responsibility: compute dashboard stats from raw bookings
 *  O — new stat fields can be added without changing the hook signature
 */
import { useMemo } from 'react';
import { useOwnerBookings } from './useBookings';
import type { NormalizedBooking } from '@/utils/booking';

const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function sumAmount(bookings: NormalizedBooking[]): number {
  return bookings.reduce((s, b) => s + (b.total_amount ?? 0), 0);
}

function bookingsForMonth(bookings: NormalizedBooking[], month: number, year: number) {
  return bookings.filter((b) => {
    const d = new Date(b.date);
    return d.getMonth() === month && d.getFullYear() === year && b.status !== 'cancelled';
  });
}

export function useOwnerDashboard(userId: string | undefined) {
  const query = useOwnerBookings(userId);

  const stats = useMemo(() => {
    const all = query.data ?? [];
    const now = new Date();
    const thisMonth = now.getMonth();
    const thisYear = now.getFullYear();
    const lastMonth = thisMonth === 0 ? 11 : thisMonth - 1;
    const lastMonthYear = thisMonth === 0 ? thisYear - 1 : thisYear;

    const thisMonthTotal = sumAmount(bookingsForMonth(all, thisMonth, thisYear));
    const lastMonthTotal = sumAmount(bookingsForMonth(all, lastMonth, lastMonthYear));

    // Last 6 months earnings for chart
    const monthlyEarnings = Array.from({ length: 6 }, (_, i) => {
      const offset = 5 - i;
      const m = (thisMonth - offset + 12) % 12;
      const y = thisMonth - offset < 0 ? thisYear - 1 : thisYear;
      return { month: MONTH_NAMES[m], amount: sumAmount(bookingsForMonth(all, m, y)) };
    });

    // Upcoming bookings (next 3, future dates only)
    const today = new Date().toISOString().split('T')[0];
    const upcoming = all
      .filter((b) => b.date >= today && (b.status === 'confirmed' || b.status === 'pending'))
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(0, 3);

    return {
      totalEarningsThisMonth: thisMonthTotal,
      lastMonthEarnings: lastMonthTotal,
      growthPct: lastMonthTotal > 0
        ? Math.round(((thisMonthTotal - lastMonthTotal) / lastMonthTotal) * 100)
        : 0,
      confirmedBookings: all.filter((b) => b.status === 'confirmed').length,
      pendingBookings: all.filter((b) => b.status === 'pending').length,
      cancelledBookings: all.filter((b) => b.status === 'cancelled').length,
      monthlyEarnings,
      upcomingBookings: upcoming,
    };
  }, [query.data]);

  return { ...query, stats };
}
