/**
 * useBookings — React Query hooks for booking data
 *
 * SOLID:
 *  S — each hook fetches exactly one slice of booking data
 *  I — customer hooks and owner hooks are separate (interface segregation)
 *  D — screens depend on hooks, not on supabase directly
 */
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/utils/supabase';
import { normalizeBooking, type NormalizedBooking } from '@/utils/booking';

// ─── Query key factory ───────────────────────────────────────────────────────
export const bookingKeys = {
  all: ['bookings'] as const,
  customer: (userId: string) => [...bookingKeys.all, 'customer', userId] as const,
  owner: (userId: string) => [...bookingKeys.all, 'owner', userId] as const,
  hall: (hallId: string, date: string) => [...bookingKeys.all, 'hall', hallId, date] as const,
};

// ─── Fetchers ────────────────────────────────────────────────────────────────
export async function fetchCustomerBookings(userId: string): Promise<NormalizedBooking[]> {
  const { data, error } = await supabase
    .from('bookings')
    .select('*, hall:halls(*)')
    .eq('customer_id', userId)
    .order('event_date', { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []).map(normalizeBooking);
}

export async function fetchOwnerBookings(userId: string): Promise<NormalizedBooking[]> {
  const { data: halls, error: hallsError } = await supabase
    .from('halls')
    .select('id')
    .eq('owner_id', userId);
  if (hallsError) throw new Error(hallsError.message);
  if (!halls || halls.length === 0) return [];

  const hallIds = halls.map((h) => h.id);
  const { data, error } = await supabase
    .from('bookings')
    .select('*')
    .in('hall_id', hallIds)
    .order('event_date', { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []).map(normalizeBooking);
}

export async function fetchBookedSlotsForDate(hallId: string, date: string): Promise<string[]> {
  const { data, error } = await supabase
    .from('bookings')
    .select('slot_type')
    .eq('hall_id', hallId)
    .eq('event_date', date)
    .in('status', ['pending', 'confirmed']);
  if (error) throw new Error(error.message);
  return (data ?? []).map((b) => b.slot_type);
}

// ─── Hooks ───────────────────────────────────────────────────────────────────
export function useCustomerBookings(userId: string | undefined) {
  return useQuery({
    queryKey: bookingKeys.customer(userId ?? ''),
    queryFn: () => fetchCustomerBookings(userId!),
    enabled: !!userId,
    staleTime: 60 * 1000, // 1 min — bookings change more often
  });
}

export function useOwnerBookings(userId: string | undefined) {
  return useQuery({
    queryKey: bookingKeys.owner(userId ?? ''),
    queryFn: () => fetchOwnerBookings(userId!),
    enabled: !!userId,
    staleTime: 60 * 1000,
  });
}

export function useBookedSlots(hallId: string | undefined, date: string | undefined) {
  return useQuery({
    queryKey: bookingKeys.hall(hallId ?? '', date ?? ''),
    queryFn: () => fetchBookedSlotsForDate(hallId!, date!),
    enabled: !!hallId && !!date,
    staleTime: 30 * 1000, // 30s — availability is time-sensitive
  });
}
