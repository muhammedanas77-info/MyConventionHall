/**
 * useHalls — React Query hooks for hall data
 *
 * SOLID:
 *  S — each hook has one responsibility (fetch one resource)
 *  O — new filters can be added without modifying existing hooks
 *  D — screens depend on this abstraction, not on supabase directly
 */
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/utils/supabase';
import type { Hall } from '@/types';

// ─── Query key factory (keeps keys consistent across the app) ────────────────
export const hallKeys = {
  all: ['halls'] as const,
  list: () => [...hallKeys.all, 'list'] as const,
  detail: (id: string) => [...hallKeys.all, 'detail', id] as const,
  reviews: (id: string) => [...hallKeys.all, 'reviews', id] as const,
  saved: (ids: string[]) => [...hallKeys.all, 'saved', ids] as const,
};

// ─── Fetchers (pure async functions — easy to unit-test) ─────────────────────
export async function fetchHalls(): Promise<Hall[]> {
  const { data, error } = await supabase
    .from('halls')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
}

export async function fetchHallById(id: string): Promise<Hall> {
  const { data, error } = await supabase
    .from('halls')
    .select('*')
    .eq('id', id)
    .single();
  if (error) throw new Error(error.message);
  return data;
}

export async function fetchHallReviews(hallId: string) {
  const { data, error } = await supabase
    .from('reviews')
    .select('*, profile:profiles(full_name)')
    .eq('hall_id', hallId)
    .order('created_at', { ascending: false })
    .limit(10);
  if (error) throw new Error(error.message);
  return data ?? [];
}

export async function fetchSavedHalls(ids: string[]): Promise<Hall[]> {
  if (ids.length === 0) return [];
  const { data, error } = await supabase
    .from('halls')
    .select('*')
    .in('id', ids);
  if (error) throw new Error(error.message);
  return data ?? [];
}

// ─── Hooks ───────────────────────────────────────────────────────────────────
export function useHalls() {
  return useQuery({
    queryKey: hallKeys.list(),
    queryFn: fetchHalls,
    staleTime: 5 * 60 * 1000, // 5 min — halls don't change often
  });
}

export function useHall(id: string | undefined) {
  return useQuery({
    queryKey: hallKeys.detail(id ?? ''),
    queryFn: () => fetchHallById(id!),
    enabled: !!id,
    staleTime: 5 * 60 * 1000,
  });
}

export function useHallReviews(hallId: string | undefined) {
  return useQuery({
    queryKey: hallKeys.reviews(hallId ?? ''),
    queryFn: () => fetchHallReviews(hallId!),
    enabled: !!hallId,
    staleTime: 10 * 60 * 1000,
  });
}

export function useSavedHalls(ids: string[]) {
  return useQuery({
    queryKey: hallKeys.saved(ids),
    queryFn: () => fetchSavedHalls(ids),
    staleTime: 5 * 60 * 1000,
  });
}
