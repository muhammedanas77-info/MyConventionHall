/**
 * useAdminDashboard — React Query hook for admin platform stats
 *
 * SOLID:
 *  S — one hook, one concern: admin platform overview data
 *  D — admin screen depends on this abstraction, not raw supabase calls
 */
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/utils/supabase';

export const adminKeys = {
  dashboard: ['admin', 'dashboard'] as const,
  payments: ['admin', 'payments'] as const,
};

export interface AdminDashboardData {
  totalHalls: number;
  activeBookings: number;
  todayRevenue: number;
  pendingApprovals: number;
  netRevenue: number;
  totalCommission: number;
  totalDiscounts: number;
  monthlyRevenue: { month: string; commission: number }[];
  topHalls: { id: string; name: string; monthlyBookings: number; monthlyRevenue: number }[];
  recentActivity: { id: string; text: string; time: string }[];
}

async function fetchAdminDashboard(): Promise<AdminDashboardData> {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [
    hallsCount,
    pendingHallsCount,
    activeBookingsCount,
    todayPayments,
    commissions,
    recentBookings,
  ] = await Promise.all([
    supabase.from('halls').select('id', { count: 'exact', head: true }),
    supabase.from('halls').select('id', { count: 'exact', head: true }).eq('is_approved', false),
    supabase.from('bookings').select('id', { count: 'exact', head: true }).in('status', ['pending', 'confirmed']),
    supabase.from('payments').select('advance_amount, amount').eq('status', 'verified').gte('verified_at', today.toISOString()),
    supabase.from('commissions').select('admin_commission, discount, created_at, booking:bookings(hall_id, hall:halls(id, name))'),
    supabase.from('bookings').select('id, customer_name, event_date, created_at, hall:halls(name)').order('created_at', { ascending: false }).limit(8),
  ]);

  const commissionRows = commissions.data ?? [];
  const totalCommission = commissionRows.reduce((s: number, r: any) => s + Number(r.admin_commission ?? 0), 0);
  const totalDiscounts = commissionRows.reduce((s: number, r: any) => s + Number(r.discount ?? 0), 0);
  const todayRevenue = (todayPayments.data ?? []).reduce((s: number, r: any) => s + Number(r.advance_amount ?? r.amount ?? 0), 0);

  // Monthly revenue map
  const monthMap = new Map<string, number>();
  const hallMap = new Map<string, { id: string; name: string; monthlyBookings: number; monthlyRevenue: number }>();

  commissionRows.forEach((item: any) => {
    const month = new Date(item.created_at).toLocaleDateString('en-IN', { month: 'short' });
    const commission = Number(item.admin_commission ?? 0);
    monthMap.set(month, (monthMap.get(month) ?? 0) + commission);

    const hall = item.booking?.hall;
    if (hall?.id) {
      const existing = hallMap.get(hall.id) ?? { id: hall.id, name: hall.name, monthlyBookings: 0, monthlyRevenue: 0 };
      existing.monthlyBookings += 1;
      existing.monthlyRevenue += commission;
      hallMap.set(hall.id, existing);
    }
  });

  return {
    totalHalls: hallsCount.count ?? 0,
    activeBookings: activeBookingsCount.count ?? 0,
    todayRevenue,
    pendingApprovals: pendingHallsCount.count ?? 0,
    netRevenue: totalCommission - totalDiscounts,
    totalCommission,
    totalDiscounts,
    monthlyRevenue: Array.from(monthMap.entries()).map(([month, commission]) => ({ month, commission })).slice(-6),
    topHalls: Array.from(hallMap.values()).sort((a, b) => b.monthlyRevenue - a.monthlyRevenue).slice(0, 5),
    recentActivity: (recentBookings.data ?? []).map((b: any) => ({
      id: b.id,
      text: `${b.customer_name ?? 'Customer'} requested ${b.hall?.name ?? 'a venue'} for ${b.event_date}`,
      time: b.created_at,
    })),
  };
}

export function useAdminDashboard() {
  return useQuery({
    queryKey: adminKeys.dashboard,
    queryFn: fetchAdminDashboard,
    staleTime: 2 * 60 * 1000, // 2 min
    refetchOnWindowFocus: true,
  });
}
