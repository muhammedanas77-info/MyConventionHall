import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/utils/supabase';
import { useAuth } from '@/providers/AuthProvider';
import type { ServiceFavourite } from '@/types';

interface UseFavouritesReturn {
    favourites: ServiceFavourite[];
    isFavourited: (listingId: string) => boolean;
    toggleFavourite: (listingId: string) => Promise<void>;
    isLoading: boolean;
    togglingId: string | null;
}

export function useFavourites(): UseFavouritesReturn {
    const { user } = useAuth();
    const [favourites, setFavourites] = useState<ServiceFavourite[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [togglingId, setTogglingId] = useState<string | null>(null);

    useEffect(() => {
        if (!user) {
            setFavourites([]);
            return;
        }

        setIsLoading(true);
        supabase
            .from('service_favourites')
            .select('*')
            .eq('customer_id', user.id)
            .then(({ data, error }) => {
                if (!error && data) {
                    setFavourites(data as ServiceFavourite[]);
                }
                setIsLoading(false);
            });
    }, [user?.id]);

    const isFavourited = useCallback(
        (listingId: string): boolean => {
            return favourites.some((f) => f.listing_id === listingId);
        },
        [favourites]
    );

    const toggleFavourite = useCallback(
        async (listingId: string): Promise<void> => {
            if (!user) return;

            const alreadyFavourited = favourites.some((f) => f.listing_id === listingId);

            setTogglingId(listingId);
            try {
                if (alreadyFavourited) {
                    // Optimistic removal
                    setFavourites((prev) => prev.filter((f) => f.listing_id !== listingId));

                    const { error } = await supabase
                        .from('service_favourites')
                        .delete()
                        .eq('customer_id', user.id)
                        .eq('listing_id', listingId);

                    if (error) {
                        // Revert on failure
                        setFavourites((prev) => {
                            const reverted: ServiceFavourite = {
                                id: '',
                                customer_id: user.id,
                                listing_id: listingId,
                                created_at: new Date().toISOString(),
                            };
                            return [...prev, reverted];
                        });
                    }
                } else {
                    // Optimistic add
                    const optimistic: ServiceFavourite = {
                        id: '',
                        customer_id: user.id,
                        listing_id: listingId,
                        created_at: new Date().toISOString(),
                    };
                    setFavourites((prev) => [...prev, optimistic]);

                    const { data, error } = await supabase
                        .from('service_favourites')
                        .insert({ customer_id: user.id, listing_id: listingId })
                        .select()
                        .single();

                    if (error) {
                        // Revert on failure
                        setFavourites((prev) => prev.filter((f) => f.listing_id !== listingId));
                    } else if (data) {
                        // Replace optimistic entry with real row
                        setFavourites((prev) =>
                            prev.map((f) =>
                                f.listing_id === listingId && f.id === '' ? (data as ServiceFavourite) : f
                            )
                        );
                    }
                }
            } finally {
                setTogglingId(null);
            }
        },
        [user, favourites]
    );

    return { favourites, isFavourited, toggleFavourite, isLoading, togglingId };
}
