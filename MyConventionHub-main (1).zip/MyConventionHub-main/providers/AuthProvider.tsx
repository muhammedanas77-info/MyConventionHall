import React, { createContext, useContext, useEffect, useState } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/utils/supabase';
import type { Profile } from '@/types';

type AuthContextType = {
    session: Session | null;
    user: User | null;
    profile: Profile | null;
    role: 'customer' | 'owner' | 'admin' | 'vendor' | null;
    isLoading: boolean;
};

const AuthContext = createContext<AuthContextType>({
    session: null,
    user: null,
    profile: null,
    role: null,
    isLoading: true,
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
    const [session, setSession] = useState<Session | null>(null);
    const [user, setUser] = useState<User | null>(null);
    const [profile, setProfile] = useState<Profile | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    const fetchProfile = async (authUser: User) => {
        try {
            const { data, error } = await supabase
                .from('profiles')
                .select('*')
                .eq('id', authUser.id)
                .maybeSingle();

            if (error) {
                console.log('Profile fetch error or missing profile:', error.message);
                setProfile(null);
            } else if (data) {
                setProfile(data as Profile | null);
            } else {
                const metadataRole = authUser.user_metadata?.role;
                const role = ['customer', 'owner', 'admin', 'vendor'].includes(metadataRole)
                    ? metadataRole
                    : 'customer';
                const fullName = authUser.user_metadata?.full_name
                    || authUser.email?.split('@')[0]
                    || 'Customer';

                const { data: createdProfile, error: createError } = await supabase
                    .from('profiles')
                    .upsert([{
                        id: authUser.id,
                        email: authUser.email,
                        full_name: fullName,
                        role,
                    }], { onConflict: 'id' })
                    .select('*')
                    .maybeSingle();

                if (createError) {
                    console.log('Profile auto-create failed:', createError.message);
                    setProfile(null);
                } else {
                    setProfile(createdProfile as Profile | null);
                }
            }
        } catch (e) {
            console.error(e);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        // Get initial session
        supabase.auth.getSession().then(({ data: { session } }) => {
            setSession(session);
            setUser(session?.user ?? null);
            if (session?.user) {
                fetchProfile(session.user).then(() => setIsLoading(false));
            } else {
                setIsLoading(false);
            }
        });

        // Listen for changes
        const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
            setSession(session);
            setUser(session?.user ?? null);
            if (session?.user) {
                setIsLoading(true); // block guards until profile is fetched
                fetchProfile(session.user);
            } else {
                setProfile(null);
                setIsLoading(false);
            }
        });

        return () => subscription.unsubscribe();
    }, []);

    return (
        <AuthContext.Provider
            value={{
                session,
                user,
                profile,
                role: profile?.role ?? null,
                isLoading,
            }}
        >
            {children}
        </AuthContext.Provider>
    );
};
