import React, { useState, useCallback, useEffect, useMemo } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import createContextHook from '@nkzw/create-context-hook';
import type { Booking, BookingStatus, UserRole } from '@/types';

// UserRole = 'customer' | 'owner' | 'admin' | 'vendor'
// 'guest' is a local-only pseudo-role (not persisted to DB) used for unauthenticated browsing.

const SAVED_HALLS_KEY = 'conventionhub_saved_halls';
const BOOKINGS_KEY = 'conventionhub_bookings';
const AUTH_ROLE_KEY = 'conventionhub_user_role';
const AUTH_NAME_KEY = 'conventionhub_user_name';
const ONBOARDING_KEY = 'conventionhub_onboarding_seen';

export const [AppProvider, useApp] = createContextHook(() => {
    const [savedHallIds, setSavedHallIds] = useState<string[]>([]);
    const [bookings, setBookings] = useState<Booking[]>([]);
    const [isLoaded, setIsLoaded] = useState(false);
    const [userRole, setUserRole] = useState<UserRole | 'guest' | null>(null);
    const [userName, setUserName] = useState<string>('');
    const [hasSeenOnboarding, setHasSeenOnboarding] = useState<boolean | null>(null);

    useEffect(() => {
        const loadData = async () => {
            try {
                const [savedRaw, bookingsRaw, role, name, onboarding] = await Promise.all([
                    AsyncStorage.getItem(SAVED_HALLS_KEY),
                    AsyncStorage.getItem(BOOKINGS_KEY),
                    AsyncStorage.getItem(AUTH_ROLE_KEY),
                    AsyncStorage.getItem(AUTH_NAME_KEY),
                    AsyncStorage.getItem(ONBOARDING_KEY),
                ]);
                if (savedRaw) setSavedHallIds(JSON.parse(savedRaw));
                if (bookingsRaw) setBookings(JSON.parse(bookingsRaw));
                if (role) setUserRole(role as UserRole | 'guest');
                if (name) setUserName(name);
                setHasSeenOnboarding(onboarding === 'true');
            } catch (e) {
                console.log('Error loading app data:', e);
            } finally {
                setIsLoaded(true);
            }
        };
        loadData();
    }, []);

    const toggleSaveHall = useCallback((hallId: string) => {
        setSavedHallIds((prev) => {
            const next = prev.includes(hallId)
                ? prev.filter((id) => id !== hallId)
                : [...prev, hallId];
            AsyncStorage.setItem(SAVED_HALLS_KEY, JSON.stringify(next)).catch(console.log);
            return next;
        });
    }, []);

    const isHallSaved = useCallback((hallId: string) => {
        return savedHallIds.includes(hallId);
    }, [savedHallIds]);

    const savedHalls = useMemo(() => {
        return savedHallIds; // IDs only — saved.tsx fetches full hall data from Supabase
    }, [savedHallIds]);

    const addBooking = useCallback((booking: Booking) => {
        setBookings((prev) => {
            const next = [booking, ...prev];
            AsyncStorage.setItem(BOOKINGS_KEY, JSON.stringify(next)).catch(console.log);
            return next;
        });
    }, []);

    const updateBookingStatus = useCallback((bookingId: string, status: BookingStatus) => {
        setBookings((prev) => {
            const next = prev.map((b) =>
                b.id === bookingId ? { ...b, status } : b
            );
            AsyncStorage.setItem(BOOKINGS_KEY, JSON.stringify(next)).catch(console.log);
            return next;
        });
    }, []);

    const upcomingBookings = useMemo(() => {
        return bookings.filter(
            (b) => b.status === 'confirmed' || b.status === 'pending'
        );
    }, [bookings]);

    const pastBookings = useMemo(() => {
        return bookings.filter(
            (b) => b.status === 'completed' || b.status === 'cancelled'
        );
    }, [bookings]);

    const login = useCallback((role: UserRole | 'guest', name: string) => {
        setUserRole(role);
        setUserName(name);
        // Persist all authenticated roles (customer, owner, admin, vendor) to AsyncStorage.
        // 'guest' is a local-only pseudo-role and is intentionally not persisted.
        if (role !== 'guest') {
            AsyncStorage.setItem(AUTH_ROLE_KEY, role).catch(console.log);
            AsyncStorage.setItem(AUTH_NAME_KEY, name).catch(console.log);
        }
    }, []);

    const logout = useCallback(() => {
        setUserRole(null);
        setUserName('');
        AsyncStorage.removeItem(AUTH_ROLE_KEY).catch(console.log);
        AsyncStorage.removeItem(AUTH_NAME_KEY).catch(console.log);
    }, []);

    const completeOnboarding = useCallback(() => {
        setHasSeenOnboarding(true);
        AsyncStorage.setItem(ONBOARDING_KEY, 'true').catch(console.log);
    }, []);

    return {
        savedHallIds,
        savedHalls: savedHallIds, // string[] of IDs — consumers fetch full data from Supabase
        toggleSaveHall,
        isHallSaved,
        bookings,
        addBooking,
        updateBookingStatus,
        upcomingBookings,
        pastBookings,
        isLoaded,
        userRole,
        userName,
        hasSeenOnboarding,
        login,
        logout,
        completeOnboarding,
    };
});
