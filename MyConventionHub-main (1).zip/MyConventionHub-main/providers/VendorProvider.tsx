import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import type { RealtimeChannel } from '@supabase/supabase-js';
import { supabase } from '@/utils/supabase';
import { useAuth } from '@/providers/AuthProvider';
import type { ServiceBooking, VendorProfile, VendorSector } from '@/types';

// ─── Types ────────────────────────────────────────────────────────────────────

type RealtimeStatus = 'joined' | 'paused';

type VendorContextType = {
  /** The vendor's full profile row from vendor_profiles, or null if not loaded yet. */
  vendorProfile: VendorProfile | null;
  /** Shorthand for vendorProfile.vendor_sector, or null. */
  sector: VendorSector | null;
  /** Shorthand for vendorProfile.is_approved, false when profile is null. */
  isApproved: boolean;
  /** Re-fetches the vendor_profiles row from Supabase. */
  refreshProfile: () => Promise<void>;
  /** Live feed of service_bookings for this vendor, kept in sync via Realtime. */
  bookings: ServiceBooking[];
  /**
   * 'joined'  – Realtime channel is active; bookings update automatically.
   * 'paused'  – Channel failed; falling back to 30-second polling.
   */
  realtimeStatus: RealtimeStatus;
};

// ─── Context ──────────────────────────────────────────────────────────────────

const VendorContext = createContext<VendorContextType>({
  vendorProfile: null,
  sector: null,
  isApproved: false,
  refreshProfile: async () => {},
  bookings: [],
  realtimeStatus: 'paused',
});

export const useVendor = () => useContext(VendorContext);

// ─── Provider ─────────────────────────────────────────────────────────────────

const POLL_INTERVAL_MS = 30_000;

export const VendorProvider = ({ children }: { children: React.ReactNode }) => {
  const { user, role } = useAuth();

  const [vendorProfile, setVendorProfile] = useState<VendorProfile | null>(null);
  const [bookings, setBookings] = useState<ServiceBooking[]>([]);
  const [realtimeStatus, setRealtimeStatus] = useState<RealtimeStatus>('paused');

  const channelRef = useRef<RealtimeChannel | null>(null);
  const pollTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ── Helpers ────────────────────────────────────────────────────────────────

  const fetchProfile = useCallback(async (userId: string): Promise<void> => {
    const { data, error } = await supabase
      .from('vendor_profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (error) {
      console.warn('[VendorProvider] fetchProfile error:', error.message);
      return;
    }
    setVendorProfile(data as VendorProfile | null);
  }, []);

  const fetchBookings = useCallback(async (userId: string): Promise<void> => {
    const { data, error } = await supabase
      .from('service_bookings')
      .select(
        '*, listing:service_listings(*), customer:profiles(id, full_name, phone)'
      )
      .eq('vendor_id', userId)
      .order('event_date', { ascending: true });

    if (error) {
      console.warn('[VendorProvider] fetchBookings error:', error.message);
      return;
    }
    setBookings((data as ServiceBooking[]) ?? []);
  }, []);

  // ── Realtime event handler ─────────────────────────────────────────────────

  const applyRealtimeEvent = useCallback(
    (payload: { eventType: string; new: Record<string, unknown>; old: Record<string, unknown> }) => {
      const { eventType, new: newRow, old: oldRow } = payload;

      setBookings((prev) => {
        switch (eventType) {
          case 'INSERT': {
            // Avoid duplicates (e.g. if initial fetch and INSERT race)
            const exists = prev.some((b) => b.id === (newRow as unknown as ServiceBooking).id);
            if (exists) return prev;
            return [...prev, newRow as unknown as ServiceBooking].sort(
              (a, b) =>
                new Date(a.event_date).getTime() - new Date(b.event_date).getTime()
            );
          }
          case 'UPDATE': {
            return prev.map((b) =>
              b.id === (newRow as unknown as ServiceBooking).id
                ? { ...b, ...(newRow as unknown as ServiceBooking) }
                : b
            );
          }
          case 'DELETE': {
            return prev.filter((b) => b.id !== (oldRow as unknown as ServiceBooking).id);
          }
          default:
            return prev;
        }
      });
    },
    []
  );

  // ── Polling fallback ───────────────────────────────────────────────────────

  const startPolling = useCallback(
    (userId: string) => {
      if (pollTimerRef.current) return; // already polling
      pollTimerRef.current = setInterval(() => {
        fetchBookings(userId);
      }, POLL_INTERVAL_MS);
    },
    [fetchBookings]
  );

  const stopPolling = useCallback(() => {
    if (pollTimerRef.current) {
      clearInterval(pollTimerRef.current);
      pollTimerRef.current = null;
    }
  }, []);

  // ── Realtime subscription ──────────────────────────────────────────────────

  const subscribeRealtime = useCallback(
    (userId: string) => {
      // Clean up any existing channel first
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }

      const channel = supabase
        .channel(`vendor-bookings-${userId}`)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'service_bookings',
            filter: `vendor_id=eq.${userId}`,
          },
          (payload) => {
            applyRealtimeEvent(
              payload as {
                eventType: string;
                new: Record<string, unknown>;
                old: Record<string, unknown>;
              }
            );
          }
        )
        .subscribe((status) => {
          if (status === 'SUBSCRIBED') {
            setRealtimeStatus('joined');
            stopPolling(); // channel is healthy; stop any active poll
          } else if (
            status === 'CHANNEL_ERROR' ||
            status === 'TIMED_OUT' ||
            status === 'CLOSED'
          ) {
            setRealtimeStatus('paused');
            startPolling(userId); // fall back to polling
          }
        });

      channelRef.current = channel;
    },
    [applyRealtimeEvent, startPolling, stopPolling]
  );

  // ── Mount / unmount ────────────────────────────────────────────────────────

  useEffect(() => {
    // Only activate for authenticated vendor users
    if (!user || role !== 'vendor') {
      // Reset state when the user is not a vendor
      setVendorProfile(null);
      setBookings([]);
      setRealtimeStatus('paused');
      return;
    }

    const userId = user.id;

    // Initial data load
    fetchProfile(userId);
    fetchBookings(userId);

    // Subscribe to Realtime; polling fallback is triggered inside subscribeRealtime
    // if the channel fails to connect.
    subscribeRealtime(userId);

    return () => {
      // Unsubscribe Realtime channel
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
      // Clear polling timer
      stopPolling();
    };
  }, [user?.id, role]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Public refreshProfile ──────────────────────────────────────────────────

  const refreshProfile = useCallback(async (): Promise<void> => {
    if (!user) return;
    await fetchProfile(user.id);
  }, [user, fetchProfile]);

  // ── Derived values ─────────────────────────────────────────────────────────

  const sector = vendorProfile?.vendor_sector ?? null;
  const isApproved = vendorProfile?.is_approved ?? false;

  return (
    <VendorContext.Provider
      value={{
        vendorProfile,
        sector,
        isApproved,
        refreshProfile,
        bookings,
        realtimeStatus,
      }}
    >
      {children}
    </VendorContext.Provider>
  );
};
