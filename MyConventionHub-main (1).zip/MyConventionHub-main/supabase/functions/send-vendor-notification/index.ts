// @ts-nocheck
// supabase/functions/send-vendor-notification/index.ts
// Handles all multi-vendor notification emails + delete_orphan_user admin endpoint.
// Requirements: 1.9, 10.1–10.9
import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.49.1';

// ─── Types ────────────────────────────────────────────────────────────────────

type NotificationPayload =
  | { type: 'booking_received_customer'; booking_id: string }
  | { type: 'booking_received_vendor';   booking_id: string }
  | { type: 'booking_confirmed';         booking_id: string }
  | { type: 'booking_rejected';          booking_id: string }
  | { type: 'vendor_approved';           vendor_id: string }
  | { type: 'vendor_rejected';           vendor_id: string; reason: string }
  | { type: 'booking_cancelled';         booking_id: string; cancelled_by: 'customer' | 'vendor'; reason?: string };

type DeleteOrphanPayload = { action: 'delete_orphan_user'; uid: string };

// ─── Environment ──────────────────────────────────────────────────────────────

const RESEND_API_KEY       = Deno.env.get('RESEND_API_KEY');
const FROM_EMAIL           = Deno.env.get('NOTIFICATION_FROM_EMAIL') ?? 'ConventionHub <noreply@conventionhub.app>';
const SUPABASE_URL         = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

// ─── CORS headers ─────────────────────────────────────────────────────────────

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// ─── Retry constants ──────────────────────────────────────────────────────────

/** Maximum total attempts (1 initial + up to 3 retries = 4 total, but spec says 3 retries). */
const MAX_RETRY_ATTEMPTS = 3;
/** Retry delays in ms: 30 s, 60 s, 120 s (Requirement 10.9). */
const RETRY_DELAYS_MS = [30_000, 60_000, 120_000];

// ─── Data loaders ─────────────────────────────────────────────────────────────

/**
 * Load a service_booking with its listing, vendor profile, and customer profile.
 *
 * Note: service_bookings.vendor_id → vendor_profiles.id (not profiles.id),
 * so we cannot use a direct FK join to profiles for the vendor email.
 * We load the vendor email separately via loadVendorEmail().
 */
async function loadBooking(bookingId: string) {
  const { data, error } = await supabase
    .from('service_bookings')
    .select(`
      id,
      vendor_id,
      customer_id,
      event_date,
      event_type,
      guest_count,
      total_amount,
      advance_amount,
      special_requests,
      rejection_reason,
      status,
      listing:service_listings ( id, title, base_price, price_unit ),
      vendor:vendor_profiles ( id, business_name, vendor_sector ),
      customer:profiles!service_bookings_customer_id_fkey ( id, full_name, email )
    `)
    .eq('id', bookingId)
    .single();

  if (error || !data) {
    throw new Error(`Booking not found: ${bookingId} — ${error?.message ?? 'no data'}`);
  }
  return data;
}

/**
 * Load vendor email from profiles table using the vendor's auth UID.
 * vendor_profiles.id = profiles.id = auth.users.id
 */
async function loadVendorEmail(vendorId: string): Promise<string | null> {
  const { data } = await supabase
    .from('profiles')
    .select('email')
    .eq('id', vendorId)
    .maybeSingle();
  return data?.email ?? null;
}

/**
 * Load a vendor_profiles row plus the vendor's email from profiles.
 */
async function loadVendorProfile(vendorId: string) {
  const { data, error } = await supabase
    .from('vendor_profiles')
    .select('id, business_name, vendor_sector, rejection_reason, sector_data')
    .eq('id', vendorId)
    .single();

  if (error || !data) {
    throw new Error(`Vendor profile not found: ${vendorId} — ${error?.message ?? 'no data'}`);
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('email, full_name')
    .eq('id', vendorId)
    .maybeSingle();

  return { ...data, email: profile?.email ?? null, full_name: profile?.full_name ?? null };
}

// ─── Currency formatter ───────────────────────────────────────────────────────

function formatINR(amount: number | null | undefined): string {
  if (amount == null) return '₹0.00';
  return `₹${Number(amount).toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

// ─── HTML email templates ─────────────────────────────────────────────────────

function htmlWrapper(title: string, body: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${title}</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; padding: 0; }
    .container { max-width: 600px; margin: 32px auto; background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
    .header { background: #1a1a2e; color: #fff; padding: 24px 32px; }
    .header h1 { margin: 0; font-size: 20px; }
    .body { padding: 24px 32px; color: #333; line-height: 1.6; }
    .field { margin-bottom: 12px; }
    .label { font-weight: bold; color: #555; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; }
    .value { font-size: 15px; color: #111; margin-top: 2px; }
    .highlight { background: #f0f7ff; border-left: 4px solid #2563eb; padding: 12px 16px; border-radius: 4px; margin: 16px 0; }
    .footer { background: #f9f9f9; padding: 16px 32px; font-size: 12px; color: #888; border-top: 1px solid #eee; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header"><h1>ConventionHub</h1></div>
    <div class="body">${body}</div>
    <div class="footer">This is an automated message from ConventionHub. Please do not reply to this email.</div>
  </div>
</body>
</html>`;
}

function field(label: string, value: string | number | null | undefined): string {
  if (value === null || value === undefined || value === '') return '';
  return `<div class="field"><div class="label">${label}</div><div class="value">${String(value)}</div></div>`;
}

// ── Requirement 10.1 — booking_received_customer ──────────────────────────────
// Email to customer: booking ID, vendor name, listing title, event date,
// event type, total amount, advance amount.
function renderBookingReceivedCustomer(booking: any): { subject: string; html: string } {
  const vendorName   = booking.vendor?.business_name ?? 'Vendor';
  const listingTitle = booking.listing?.title ?? 'Service';
  const subject      = `Booking Received — ${listingTitle}`;
  const body = `
    <p>Your booking request has been received. The vendor will review and confirm shortly.</p>
    <div class="highlight">
      ${field('Booking ID', booking.id)}
      ${field('Vendor', vendorName)}
      ${field('Service', listingTitle)}
      ${field('Event Date', booking.event_date)}
      ${field('Event Type', booking.event_type)}
      ${field('Total Amount', formatINR(booking.total_amount))}
      ${field('Advance Amount Due', formatINR(booking.advance_amount))}
    </div>
    <p>You will receive another email once the vendor confirms or rejects your booking.</p>
  `;
  return { subject, html: htmlWrapper(subject, body) };
}

// ── Requirement 10.2 — booking_received_vendor ────────────────────────────────
// Email to vendor: booking ID, customer full name, event date, event type,
// guest count (if present), special requests (if present).
function renderBookingReceivedVendor(booking: any): { subject: string; html: string } {
  const customerName = booking.customer?.full_name ?? 'Customer';
  const listingTitle = booking.listing?.title ?? 'Service';
  const subject      = `New Booking Request — ${listingTitle}`;
  const body = `
    <p>You have received a new booking request. Please review and confirm or reject it from your dashboard.</p>
    <div class="highlight">
      ${field('Booking ID', booking.id)}
      ${field('Customer', customerName)}
      ${field('Service', listingTitle)}
      ${field('Event Date', booking.event_date)}
      ${field('Event Type', booking.event_type)}
      ${booking.guest_count != null ? field('Guest Count', booking.guest_count) : ''}
      ${booking.special_requests ? field('Special Requests', booking.special_requests) : ''}
    </div>
    <p>Log in to your vendor dashboard to confirm or reject this booking.</p>
  `;
  return { subject, html: htmlWrapper(subject, body) };
}

// ── Requirement 10.3 — booking_confirmed ─────────────────────────────────────
// Email to customer: booking ID, vendor name, listing title, event date,
// advance amount due.
function renderBookingConfirmed(booking: any): { subject: string; html: string } {
  const vendorName   = booking.vendor?.business_name ?? 'Vendor';
  const listingTitle = booking.listing?.title ?? 'Service';
  const subject      = `Booking Confirmed — ${listingTitle}`;
  const body = `
    <p>Great news! Your booking has been confirmed by the vendor.</p>
    <div class="highlight">
      ${field('Booking ID', booking.id)}
      ${field('Vendor', vendorName)}
      ${field('Service', listingTitle)}
      ${field('Event Date', booking.event_date)}
      ${field('Advance Amount Due', formatINR(booking.advance_amount))}
    </div>
    <p>Please ensure the advance payment is made as per the vendor's instructions.</p>
  `;
  return { subject, html: htmlWrapper(subject, body) };
}

// ── Requirement 10.4 — booking_rejected ──────────────────────────────────────
// Email to customer: booking ID, vendor name, listing title, event date,
// rejection reason.
function renderBookingRejected(booking: any): { subject: string; html: string } {
  const vendorName      = booking.vendor?.business_name ?? 'Vendor';
  const listingTitle    = booking.listing?.title ?? 'Service';
  const rejectionReason = booking.rejection_reason ?? 'No reason provided';
  const subject         = `Booking Not Confirmed — ${listingTitle}`;
  const body = `
    <p>We're sorry, the vendor was unable to confirm your booking.</p>
    <div class="highlight">
      ${field('Booking ID', booking.id)}
      ${field('Vendor', vendorName)}
      ${field('Service', listingTitle)}
      ${field('Event Date', booking.event_date)}
      ${field('Rejection Reason', rejectionReason)}
    </div>
    <p>You can browse other available vendors on ConventionHub.</p>
  `;
  return { subject, html: htmlWrapper(subject, body) };
}

// ── Requirement 10.5 — vendor_approved ───────────────────────────────────────
// Email to vendor: business name, instruction to log in and complete profile.
function renderVendorApproved(vendor: any): { subject: string; html: string } {
  const businessName = vendor.business_name ?? vendor.full_name ?? 'Your business';
  const subject      = `Your ConventionHub Vendor Account is Approved!`;
  const body = `
    <p>Congratulations! Your vendor account has been approved by the ConventionHub team.</p>
    <div class="highlight">
      ${field('Business Name', businessName)}
      ${field('Sector', vendor.vendor_sector)}
    </div>
    <p>You can now log in to your vendor dashboard to complete your profile, create listings, and start receiving bookings.</p>
    <p>Open <strong>ConventionHub</strong> and select "List Your Services" to get started.</p>
  `;
  return { subject, html: htmlWrapper(subject, body) };
}

// ── Requirement 10.6 — vendor_rejected ───────────────────────────────────────
// Email to vendor: business name, rejection reason.
function renderVendorRejected(vendor: any, reason: string): { subject: string; html: string } {
  const businessName = vendor.business_name ?? vendor.full_name ?? 'Your business';
  const subject      = `ConventionHub Vendor Application Update`;
  const body = `
    <p>Thank you for applying to ConventionHub. After review, we are unable to approve your vendor account at this time.</p>
    <div class="highlight">
      ${field('Business Name', businessName)}
      ${field('Rejection Reason', reason)}
    </div>
    <p>If you believe this is an error or would like to appeal, please contact our support team.</p>
  `;
  return { subject, html: htmlWrapper(subject, body) };
}

// ── Requirement 10.7 — booking_cancelled ─────────────────────────────────────
// Email to both customer and vendor: booking ID, listing title, event date,
// cancellation reason (if provided).
function renderBookingCancelled(
  booking: any,
  cancelledBy: 'customer' | 'vendor',
  reason?: string,
): { subject: string; html: string } {
  const listingTitle   = booking.listing?.title ?? 'Service';
  const cancellerLabel = cancelledBy === 'customer' ? 'the customer' : 'the vendor';
  const subject        = `Booking Cancelled — ${listingTitle}`;
  const body = `
    <p>The following booking has been cancelled by ${cancellerLabel}.</p>
    <div class="highlight">
      ${field('Booking ID', booking.id)}
      ${field('Service', listingTitle)}
      ${field('Event Date', booking.event_date)}
      ${reason ? field('Cancellation Reason', reason) : ''}
    </div>
    <p>If you have any questions, please contact ConventionHub support.</p>
  `;
  return { subject, html: htmlWrapper(subject, body) };
}

// ─── Resend email sender ──────────────────────────────────────────────────────

/**
 * Send an HTML email via Resend.
 * Throws on HTTP failure so the caller can schedule a retry.
 * Requirement 10.8: uses Resend with RESEND_API_KEY / NOTIFICATION_FROM_EMAIL.
 */
async function sendEmail(to: string[], subject: string, html: string): Promise<void> {
  if (!RESEND_API_KEY) {
    // Dev/test mode: log instead of sending.
    console.warn('[send-vendor-notification] RESEND_API_KEY not set — skipping send.', { to, subject });
    return;
  }

  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ from: FROM_EMAIL, to, subject, html }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Resend API error ${res.status}: ${errText}`);
  }
}

// ─── Retry queue helpers ──────────────────────────────────────────────────────

/**
 * Insert a retry row into notification_retry_queue.
 * attempt is the retry number (1 = first retry after 30 s, 2 = 60 s, 3 = 120 s).
 * Requirement 10.9: retries at 30 s / 60 s / 120 s.
 */
async function scheduleRetry(payload: NotificationPayload, attempt: number): Promise<void> {
  if (attempt > MAX_RETRY_ATTEMPTS) return;
  const delayMs    = RETRY_DELAYS_MS[attempt - 1] ?? 120_000;
  const nextRetryAt = new Date(Date.now() + delayMs).toISOString();

  const { error } = await supabase
    .from('notification_retry_queue')
    .insert({ payload, attempt, next_retry_at: nextRetryAt });

  if (error) {
    console.error('[send-vendor-notification] Failed to schedule retry:', error.message);
  } else {
    console.log(`[send-vendor-notification] Retry #${attempt} scheduled at ${nextRetryAt} for type=${payload.type}`);
  }
}

/**
 * Write a permanent failure record to notification_failures.
 * Must complete within 10 s of the final failed attempt (Requirement 10.9).
 */
async function recordFailure(
  recipientEmail: string,
  notificationType: string,
  bookingId: string | null,
  vendorId: string | null,
  errorMessage: string,
  attempts: number,
): Promise<void> {
  const { error } = await supabase
    .from('notification_failures')
    .insert({
      recipient_email: recipientEmail,
      notification_type: notificationType,
      booking_id: bookingId ?? null,
      vendor_id: vendorId ?? null,
      error_message: errorMessage,
      attempts,
      failed_at: new Date().toISOString(),
    });

  if (error) {
    console.error('[send-vendor-notification] Failed to record notification failure:', error.message);
  }
}

/**
 * Extract a best-effort recipient email from a payload for failure logging.
 * Falls back to 'unknown' if the email cannot be determined without a DB call.
 */
function extractRecipientHint(payload: NotificationPayload): string {
  // We don't have the email in the payload itself; return a placeholder.
  // The notification_failures table stores booking_id / vendor_id for traceability.
  return 'unknown';
}

// ─── Core dispatch ────────────────────────────────────────────────────────────

/**
 * Dispatch a single notification payload: load data, render HTML, send email.
 * Throws on any failure so the caller can schedule a retry.
 */
async function dispatch(payload: NotificationPayload): Promise<void> {
  switch (payload.type) {

    // Requirement 10.1
    case 'booking_received_customer': {
      const booking      = await loadBooking(payload.booking_id);
      const customerEmail = booking.customer?.email;
      if (!customerEmail) throw new Error('Customer email not found for booking ' + payload.booking_id);
      const { subject, html } = renderBookingReceivedCustomer(booking);
      await sendEmail([customerEmail], subject, html);
      break;
    }

    // Requirement 10.2
    case 'booking_received_vendor': {
      const booking     = await loadBooking(payload.booking_id);
      const vendorEmail = await loadVendorEmail(booking.vendor_id);
      if (!vendorEmail) throw new Error('Vendor email not found for booking ' + payload.booking_id);
      const { subject, html } = renderBookingReceivedVendor(booking);
      await sendEmail([vendorEmail], subject, html);
      break;
    }

    // Requirement 10.3
    case 'booking_confirmed': {
      const booking      = await loadBooking(payload.booking_id);
      const customerEmail = booking.customer?.email;
      if (!customerEmail) throw new Error('Customer email not found for booking ' + payload.booking_id);
      const { subject, html } = renderBookingConfirmed(booking);
      await sendEmail([customerEmail], subject, html);
      break;
    }

    // Requirement 10.4
    case 'booking_rejected': {
      const booking      = await loadBooking(payload.booking_id);
      const customerEmail = booking.customer?.email;
      if (!customerEmail) throw new Error('Customer email not found for booking ' + payload.booking_id);
      const { subject, html } = renderBookingRejected(booking);
      await sendEmail([customerEmail], subject, html);
      break;
    }

    // Requirement 10.5
    case 'vendor_approved': {
      const vendor = await loadVendorProfile(payload.vendor_id);
      if (!vendor.email) throw new Error('Vendor email not found for vendor ' + payload.vendor_id);
      const { subject, html } = renderVendorApproved(vendor);
      await sendEmail([vendor.email], subject, html);
      break;
    }

    // Requirement 10.6
    case 'vendor_rejected': {
      const vendor = await loadVendorProfile(payload.vendor_id);
      if (!vendor.email) throw new Error('Vendor email not found for vendor ' + payload.vendor_id);
      const { subject, html } = renderVendorRejected(vendor, payload.reason);
      await sendEmail([vendor.email], subject, html);
      break;
    }

    // Requirement 10.7
    case 'booking_cancelled': {
      const booking      = await loadBooking(payload.booking_id);
      const customerEmail = booking.customer?.email;
      const vendorEmail   = await loadVendorEmail(booking.vendor_id);
      const recipients    = [customerEmail, vendorEmail].filter(Boolean) as string[];
      if (recipients.length === 0) {
        throw new Error('No recipients found for cancellation email for booking ' + payload.booking_id);
      }
      const { subject, html } = renderBookingCancelled(booking, payload.cancelled_by, payload.reason);
      await sendEmail(recipients, subject, html);
      break;
    }

    default:
      throw new Error(`Unknown notification type: ${(payload as any).type}`);
  }
}

// ─── Retry queue processor ────────────────────────────────────────────────────

/**
 * Process any due retry rows from notification_retry_queue.
 * Called at the start of every invocation so a single function handles both
 * fresh sends and retries — no separate pg_cron job required.
 *
 * Requirement 10.9: after 3 failed attempts, INSERT into notification_failures
 * within 10 s of the final failure.
 */
async function processDueRetries(): Promise<void> {
  const { data: rows, error } = await supabase
    .from('notification_retry_queue')
    .select('*')
    .lte('next_retry_at', new Date().toISOString())
    .order('next_retry_at', { ascending: true })
    .limit(20);

  if (error) {
    console.error('[send-vendor-notification] Failed to query retry queue:', error.message);
    return;
  }
  if (!rows?.length) return;

  for (const row of rows) {
    // Delete the row first to prevent double-processing on concurrent invocations.
    const { error: delErr } = await supabase
      .from('notification_retry_queue')
      .delete()
      .eq('id', row.id);

    if (delErr) {
      // Another invocation may have already processed this row — skip it.
      console.warn(`[send-vendor-notification] Could not delete retry row ${row.id}: ${delErr.message}`);
      continue;
    }

    const payload: NotificationPayload = row.payload;
    const attempt: number              = row.attempt;

    try {
      await dispatch(payload);
      console.log(`[send-vendor-notification] Retry #${attempt} succeeded for type=${payload.type}`);
    } catch (err) {
      const errMsg = String(err);
      console.error(`[send-vendor-notification] Retry #${attempt} failed for type=${payload.type}: ${errMsg}`);

      if (attempt < MAX_RETRY_ATTEMPTS) {
        // Schedule the next retry.
        await scheduleRetry(payload, attempt + 1);
      } else {
        // All retries exhausted — record failure within 10 s (Requirement 10.9).
        const bookingId = 'booking_id' in payload ? (payload as any).booking_id : null;
        const vendorId  = 'vendor_id'  in payload ? (payload as any).vendor_id  : null;
        await recordFailure(
          extractRecipientHint(payload),
          payload.type,
          bookingId ?? null,
          vendorId  ?? null,
          errMsg,
          attempt,
        );
      }
    }
  }
}

// ─── delete_orphan_user handler ───────────────────────────────────────────────

/**
 * Deletes a Supabase Auth user that was created but whose vendor_profiles
 * INSERT subsequently failed (Requirement 1.9).
 *
 * Safety check: only deletes if no vendor_profiles row exists for the UID.
 * Called by vendor-login.tsx recovery path via { action: 'delete_orphan_user', uid }.
 */
async function deleteOrphanUser(uid: string): Promise<Response> {
  if (!uid) {
    return new Response(JSON.stringify({ error: 'uid is required' }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  // Only delete true orphans — users with no vendor_profiles row.
  const { data: existing } = await supabase
    .from('vendor_profiles')
    .select('id')
    .eq('id', uid)
    .maybeSingle();

  if (existing) {
    return new Response(
      JSON.stringify({ error: 'User has a vendor_profiles record; not an orphan' }),
      { status: 409, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }

  const { error } = await supabase.auth.admin.deleteUser(uid);
  if (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  console.log(`[send-vendor-notification] Deleted orphan auth user: ${uid}`);
  return new Response(JSON.stringify({ ok: true, deleted_uid: uid }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

// ─── Main handler ─────────────────────────────────────────────────────────────

serve(async (req: Request) => {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  // Process any due retries on every invocation (piggy-backs on incoming traffic).
  // Errors here are non-fatal — we still handle the current request.
  try {
    await processDueRetries();
  } catch (retryErr) {
    console.error('[send-vendor-notification] processDueRetries error:', String(retryErr));
  }

  // Parse request body
  let body: NotificationPayload | DeleteOrphanPayload;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: 'Invalid JSON body' }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  // ── delete_orphan_user endpoint (Requirement 1.9) ────────────────────────
  if ((body as DeleteOrphanPayload).action === 'delete_orphan_user') {
    return deleteOrphanUser((body as DeleteOrphanPayload).uid);
  }

  // ── Notification dispatch ────────────────────────────────────────────────
  const payload = body as NotificationPayload;

  if (!payload.type) {
    return new Response(JSON.stringify({ error: 'type is required' }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  try {
    await dispatch(payload);
    return new Response(JSON.stringify({ ok: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    const errMsg = String(err);
    console.error(`[send-vendor-notification] Initial send failed for type=${payload.type}: ${errMsg}`);

    // Schedule first retry (attempt 1 → fires after 30 s).
    // Requirement 10.9: retries at 30 s / 60 s / 120 s.
    await scheduleRetry(payload, 1);

    // Return 202 Accepted — the notification will be retried asynchronously.
    return new Response(
      JSON.stringify({ ok: false, scheduled_retry: true, error: errMsg }),
      { status: 202, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }
});
