// @ts-nocheck
import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.49.1';

type NotificationType =
  | 'booking_created'
  | 'payment_submitted'
  | 'payment_verified'
  | 'payment_rejected'
  | 'partner_confirmed'
  | 'partner_rejected'
  | 'partner_contacted';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
const FROM_EMAIL = Deno.env.get('NOTIFICATION_FROM_EMAIL') || 'ConventionHub <noreply@conventionhub.app>';
const ADMIN_EMAIL = Deno.env.get('ADMIN_NOTIFICATION_EMAIL');
const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

function slotLabel(slot?: string) {
  if (slot === 'morning') return 'Morning to Afternoon';
  if (slot === 'evening') return 'Evening to Night';
  return slot || 'Selected slot';
}

function subjectFor(type: NotificationType, venueName: string) {
  const subjects: Record<NotificationType, string> = {
    booking_created: `New booking request for ${venueName}`,
    payment_submitted: `Payment submitted for ${venueName}`,
    payment_verified: `Booking confirmed for ${venueName}`,
    payment_rejected: `Payment needs attention for ${venueName}`,
    partner_confirmed: `Venue confirmed your booking for ${venueName}`,
    partner_rejected: `Venue could not confirm your booking for ${venueName}`,
    partner_contacted: `Venue partner contacted customer for ${venueName}`,
  };
  return subjects[type];
}

function bodyFor(type: NotificationType, booking: any, venue: any) {
  const intro: Record<NotificationType, string> = {
    booking_created: 'A new booking request has been created in ConventionHub.',
    payment_submitted: 'The customer has submitted UPI payment details for admin verification.',
    payment_verified: 'Payment has been verified and the booking is now confirmed.',
    payment_rejected: 'The submitted payment could not be verified. Please contact support or retry payment.',
    partner_confirmed: 'The venue partner has confirmed this booking.',
    partner_rejected: 'The venue partner rejected this booking. Please contact support for next steps.',
    partner_contacted: 'The venue partner marked this customer as contacted.',
  };

  return [
    intro[type],
    '',
    `Booking ID: ${booking.id}`,
    `Venue: ${venue?.name || 'Venue'}`,
    `Date: ${booking.event_date || booking.date}`,
    `Slot: ${slotLabel(booking.slot_type || booking.slot)}`,
    `Customer: ${booking.customer_name || 'Customer'}`,
    `Phone: ${booking.customer_phone || 'Not provided'}`,
    `Payment status: ${booking.payment_verified ? 'Verified' : 'Pending verification'}`,
    `Venue confirmation: ${booking.venue_confirmation_status || 'pending'}`,
  ].join('\n');
}

async function sendEmail(to: string[], subject: string, text: string) {
  if (!RESEND_API_KEY) {
    console.log('RESEND_API_KEY missing. Email payload:', { to, subject, text });
    return;
  }

  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ from: FROM_EMAIL, to, subject, text }),
  });

  if (!response.ok) {
    throw new Error(await response.text());
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const { type, bookingId } = await req.json() as { type: NotificationType; bookingId: string };
    if (!type || !bookingId) {
      return new Response(JSON.stringify({ error: 'type and bookingId are required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { data: booking, error } = await supabase
      .from('bookings')
      .select('*, hall:halls(*, owner:profiles!halls_owner_id_fkey(email, full_name))')
      .eq('id', bookingId)
      .single();

    if (error || !booking) {
      return new Response(JSON.stringify({ error: error?.message || 'Booking not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const venue = booking.hall;
    const recipients = new Set<string>();
    if (booking.customer_email) recipients.add(booking.customer_email);
    if (venue?.owner?.email) recipients.add(venue.owner.email);
    if (ADMIN_EMAIL) recipients.add(ADMIN_EMAIL);

    await sendEmail(Array.from(recipients), subjectFor(type, venue?.name || 'ConventionHub venue'), bodyFor(type, booking, venue));

    return new Response(JSON.stringify({ ok: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: String(error) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
