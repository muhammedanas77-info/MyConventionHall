import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(__dirname, '../.env') });

const supabaseUrl = 'http://127.0.0.1:4000';
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

const supabase = createClient(supabaseUrl, supabaseKey);

async function minimalSeed() {
    console.log('Attempting minimal seed...');
    const { data, error } = await supabase.from('halls').insert([
        {
            name: 'Palace Grounds — Nalpad Pavilion',
            owner_id: '00000000-0000-0000-0000-000000000000',
            description: 'The crown jewel of Bangalore\'s wedding venues',
            city: 'Bangalore',
            capacity_min: 1000,
            capacity_max: 5000,
            price_per_day: 500000
        }
    ]);

    if (error) {
        console.error('Insert failed:', error);
    } else {
        console.log('Insert success!', data);
    }
}

minimalSeed();
