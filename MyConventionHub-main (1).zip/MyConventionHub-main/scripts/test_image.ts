import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import { resolve } from 'path';

dotenv.config({ path: resolve(__dirname, '../.env') });

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;
const supabase = createClient(supabaseUrl, supabaseKey);

async function testFetch() {
  const { data, error } = await supabase.from('payments').select('verification_screenshot_url').not('verification_screenshot_url', 'is', null).limit(1);
  if (data && data.length > 0) {
      const url = data[0].verification_screenshot_url;
      console.log("URL from DB:", url);
      try {
          const res = await fetch(url);
          console.log("Status:", res.status, res.statusText);
          const text = await res.text();
          console.log("Body preview:", text.substring(0, 100));
      } catch(e) {
          console.log("Fetch error:", e);
      }
  } else {
      console.log("No URLs found", error);
  }
}

testFetch();
