import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import { resolve } from 'path';

dotenv.config({ path: resolve(__dirname, '../.env') });

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;
const supabase = createClient(supabaseUrl, supabaseKey);

async function testUpdate() {
  // First login as the user who created the booking or admin
  const { data: auth, error: authErr } = await supabase.auth.signInWithPassword({
    email: 'rayyan182003@gmail.com', // Let's try to sign in as user, or maybe admin?
    password: 'password123'
  });
  if (authErr) {
    console.log("Auth error:", authErr.message);
    return;
  }
  
  // Find a booking
  const { data: bData } = await supabase.from('bookings').select('id, status').limit(1);
  if (!bData || bData.length === 0) {
      console.log("No bookings found");
      return;
  }
  const id = bData[0].id;
  console.log("Found booking:", id, "current status:", bData[0].status);
  
  const { data, error } = await supabase.from('bookings').update({ status: 'confirmed' }).eq('id', id).select();
  console.log("Update result:", data);
  console.log("Update error:", error);
}

testUpdate();
