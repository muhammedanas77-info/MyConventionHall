-- ============================================================
-- ConventionHub — Add venue_booking_id to service_bookings
-- Links add-on service bookings back to the originating venue booking.
-- Idempotent — safe to run multiple times.
-- ============================================================

ALTER TABLE public.service_bookings
ADD COLUMN IF NOT EXISTS venue_booking_id uuid
  REFERENCES public.bookings(id)
  ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_service_bookings_venue_booking
  ON public.service_bookings(venue_booking_id)
  WHERE venue_booking_id IS NOT NULL;
