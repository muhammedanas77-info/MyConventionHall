-- Fix for payment-proofs bucket to make it fully public

-- 1. Ensure the bucket is marked as public
UPDATE storage.buckets
SET public = true
WHERE id = 'payment-proofs';

-- 2. Drop existing SELECT policies just in case
DROP POLICY IF EXISTS "Public can view payment proofs" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can read payment-proofs" ON storage.objects;

-- 3. Create a policy allowing anyone to read the bucket objects
CREATE POLICY "Public can view payment proofs"
ON storage.objects FOR SELECT
USING ( bucket_id = 'payment-proofs' );
