const fs = require('fs');
const path = require('path');
const target = 'd:/MyConventionHub/app/service-booking/[id].tsx';
const code = ``;
fs.writeFileSync(target, code, 'utf8');
console.log('done');