-- ============================================================
-- Fix profile roles that may have been overwritten
-- Run this in Supabase SQL Editor → New Query
-- ============================================================

-- Step 1: Check what role your email currently has
-- Replace 'your@email.com' with your actual admin email
SELECT id, email, full_name, role 
FROM public.profiles 
WHERE email = 'your@email.com';

-- Step 2: If role shows 'customer' instead of 'admin', run this:
-- Replace 'your@email.com' with your actual admin email
UPDATE public.profiles 
SET role = 'admin' 
WHERE email = 'your@email.com';

-- Step 3: For owner accounts that got overwritten, run this:
-- Replace 'owner@email.com' with the owner's actual email
UPDATE public.profiles 
SET role = 'owner' 
WHERE email = 'owner@email.com';

-- Step 4: Verify the fix
SELECT id, email, full_name, role 
FROM public.profiles 
ORDER BY created_at DESC;
