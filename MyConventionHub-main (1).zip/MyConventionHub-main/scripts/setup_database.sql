-- ============================================================
-- ConventionHub — Full Database Setup (idempotent, safe to re-run)
-- ============================================================

-- 1. PROFILES TABLE
create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  email       text,
  full_name   text,
  role        text not null default 'customer' check (role in ('customer', 'owner', 'admin')),
  avatar_url  text,
  phone       text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- Auto-create profile on new user signup
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'role', 'customer')
  )
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 2. HALLS TABLE
create table if not exists public.halls (
  id              uuid primary key default gen_random_uuid(),
  owner_id        uuid references public.profiles(id) on delete set null,
  name            text not null,
  description     text,
  address         text,
  area            text,
  city            text default 'Bangalore',
  latitude        double precision,
  longitude       double precision,
  capacity_min    int default 0,
  capacity_max    int default 0,
  price_per_day   numeric default 0,
  photos          text[] default '{}',
  amenities       text[] default '{}',
  is_approved     boolean default false,
  is_featured     boolean default false,
  is_verified     boolean default false,
  rating          numeric default 0,
  total_reviews   int default 0,
  created_at      timestamptz not null default now()
);

-- 3. BOOKINGS TABLE
create table if not exists public.bookings (
  id              uuid primary key default gen_random_uuid(),
  hall_id         uuid references public.halls(id) on delete cascade,
  customer_id     uuid references public.profiles(id) on delete set null,
  event_date      date not null,
  slot_type       text,
  guests          int,
  total_price     numeric,
  status          text not null default 'pending' check (status in ('pending','confirmed','cancelled','completed')),
  notes           text,
  created_at      timestamptz not null default now()
);

-- 4. ROW LEVEL SECURITY

-- Profiles
alter table public.profiles enable row level security;

drop policy if exists "Users can view their own profile" on public.profiles;
create policy "Users can view their own profile"
  on public.profiles for select
  using (auth.uid() = id);

drop policy if exists "Users can update their own profile" on public.profiles;
create policy "Users can update their own profile"
  on public.profiles for update
  using (auth.uid() = id);

drop policy if exists "Service role can do everything on profiles" on public.profiles;
create policy "Service role can do everything on profiles"
  on public.profiles for all
  using (true)
  with check (true);

-- Halls
alter table public.halls enable row level security;

drop policy if exists "Anyone can view approved halls" on public.halls;
create policy "Anyone can view approved halls"
  on public.halls for select
  using (is_approved = true);

drop policy if exists "Owners can manage their halls" on public.halls;
create policy "Owners can manage their halls"
  on public.halls for all
  using (auth.uid() = owner_id);

drop policy if exists "Admins can manage all halls" on public.halls;
create policy "Admins can manage all halls"
  on public.halls for all
  using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

drop policy if exists "Public can view approved halls (anon)" on public.halls;
create policy "Public can view approved halls (anon)"
  on public.halls for select
  to anon
  using (is_approved = true);

-- Bookings
alter table public.bookings enable row level security;

drop policy if exists "Customers see their own bookings" on public.bookings;
create policy "Customers see their own bookings"
  on public.bookings for select
  using (auth.uid() = customer_id);

drop policy if exists "Customers can create bookings" on public.bookings;
create policy "Customers can create bookings"
  on public.bookings for insert
  with check (auth.uid() = customer_id);

drop policy if exists "Customers can cancel their bookings" on public.bookings;
create policy "Customers can cancel their bookings"
  on public.bookings for update
  using (auth.uid() = customer_id);

drop policy if exists "Owners see bookings for their halls" on public.bookings;
create policy "Owners see bookings for their halls"
  on public.bookings for select
  using (
    exists (select 1 from public.halls where id = hall_id and owner_id = auth.uid())
  );
