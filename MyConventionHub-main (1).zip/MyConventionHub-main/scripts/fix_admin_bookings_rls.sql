-- ============================================================
-- ConventionHub — Fix: Add Admin RLS Policy for Bookings
-- Without this, admins cannot approve/reject bookings
-- ============================================================

-- Allow admins full access to all bookings (SELECT, UPDATE, DELETE, INSERT)
DROP POLICY IF EXISTS "Admins can manage all bookings" ON public.bookings;
CREATE POLICY "Admins can manage all bookings"
  ON public.bookings FOR ALL
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Also ensure admins can view all bookings (explicit SELECT for safety)
DROP POLICY IF EXISTS "Admins can view all bookings" ON public.bookings;
CREATE POLICY "Admins can view all bookings"
  ON public.bookings FOR SELECT
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Allow admins to insert into booking_status_history
DROP POLICY IF EXISTS "Admins can insert booking status history" ON public.booking_status_history;
CREATE POLICY "Admins can insert booking status history"
  ON public.booking_status_history FOR INSERT
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Done
