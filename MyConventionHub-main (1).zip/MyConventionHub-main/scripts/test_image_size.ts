import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import { resolve } from 'path';

dotenv.config({ path: resolve(__dirname, '../.env') });

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;
const supabase = createClient(supabaseUrl, supabaseKey);

async function testFetch() {
  const { data, error } = await supabase.from('payments').select('verification_screenshot_url').not('verification_screenshot_url', 'is', null).order('created_at', { ascending: false }).limit(1);
  if (data && data.length > 0) {
      const url = data[0].verification_screenshot_url;
      console.log("URL from DB:", url);
      try {
          const res = await fetch(url);
          console.log("Status:", res.status, res.statusText);
          const buf = await res.arrayBuffer();
          console.log("File size in bytes:", buf.byteLength);
      } catch(e) {
          console.log("Fetch error:", e);
      }
  } else {
      console.log("No URLs found. Did the admin RLS policy allow anonymous reading? If no URLs found, the image might be empty in DB.", error);
  }
}

testFetch();
