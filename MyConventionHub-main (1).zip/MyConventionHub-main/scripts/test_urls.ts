import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import { resolve } from 'path';

dotenv.config({ path: resolve(__dirname, '../.env') });

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;
const supabase = createClient(supabaseUrl, supabaseKey);

async function test() {
  const { data, error } = await supabase.from('payments').select('id, verification_screenshot_url').not('verification_screenshot_url', 'is', null);
  console.log("PAYMENTS:", JSON.stringify(data, null, 2));

  if (data && data.length > 0) {
      const url = data[0].verification_screenshot_url;
      const match = url.match(/payment-proofs\/(.+)$/);
      console.log("MATCH:", match);
      if (match) {
        const { data: signed } = await supabase.storage.from('payment-proofs').createSignedUrl(match[1], 3600);
        console.log("SIGNED:", signed);
      }
  }
}

test();
