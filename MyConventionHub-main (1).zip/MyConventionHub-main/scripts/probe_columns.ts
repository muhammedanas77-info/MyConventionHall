import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(__dirname, '../.env') });

const supabaseUrl = 'http://127.0.0.1:4000';
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

const supabase = createClient(supabaseUrl, supabaseKey);

async function checkColumns() {
    console.log('Probing columns...');
    const testColumns = ['name', 'owner_id', 'description', 'address', 'area', 'city', 'capacity_min', 'capacity_max', 'price_per_day', 'photos', 'amenities'];

    for (const col of testColumns) {
        const { error } = await supabase.from('halls').select(col).limit(1);
        if (error) {
            console.log(`❌ Column [${col}] is MISSING or inaccessible: ${error.message}`);
        } else {
            console.log(`✅ Column [${col}] exists!`);
        }
    }
}

checkColumns();
