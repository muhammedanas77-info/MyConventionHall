-- ============================================================
-- ConventionHub — Phase 1 Database Migration
-- Adds: payments, commissions, booking_status_history tables
-- Adds: Uniqueness constraint on bookings to prevent double-booking
-- ============================================================

-- 1. PAYMENTS TABLE (NEW)
CREATE TABLE IF NOT EXISTS public.payments (
  id              uuid primary key default gen_random_uuid(),
  booking_id      uuid references public.bookings(id) on delete cascade,
  customer_id     uuid references public.profiles(id) on delete set null,
  amount          numeric not null,
  advance_amount  numeric,
  payment_method  text check (payment_method in ('upi', 'razorpay', 'card')),
  upi_transaction_id text unique,
  razorpay_order_id text unique,
  razorpay_payment_id text unique,
  verification_screenshot_url text,
  customer_note   text,
  status          text not null default 'pending' check (status in ('pending', 'submitted', 'verified', 'failed', 'refunded')),
  verified_at     timestamptz,
  verified_by_admin uuid references public.profiles(id) on delete set null,
  created_at      timestamptz not null default now()
);

-- 2. BOOKING_STATUS_HISTORY TABLE (NEW)
CREATE TABLE IF NOT EXISTS public.booking_status_history (
  id              uuid primary key default gen_random_uuid(),
  booking_id      uuid references public.bookings(id) on delete cascade,
  old_status      text,
  new_status      text,
  changed_by      uuid references public.profiles(id) on delete set null,
  reason          text,
  created_at      timestamptz not null default now()
);

-- 3. COMMISSIONS TABLE (NEW)
CREATE TABLE IF NOT EXISTS public.commissions (
  id              uuid primary key default gen_random_uuid(),
  booking_id      uuid references public.bookings(id) on delete cascade,
  owner_id        uuid references public.profiles(id) on delete set null,
  admin_commission numeric,
  owner_payout    numeric,
  discount        numeric default 0,
  status          text not null default 'pending' check (status in ('pending', 'calculated', 'paid')),
  created_at      timestamptz not null default now()
);

-- 4. PARTNER_ANALYTICS TABLE (NEW)
CREATE TABLE IF NOT EXISTS public.partner_analytics (
  id              uuid primary key default gen_random_uuid(),
  owner_id        uuid references public.profiles(id) on delete cascade,
  month           int not null,
  year            int not null,
  total_bookings  int default 0,
  total_revenue   numeric default 0,
  platform_commission numeric default 0,
  owner_earnings  numeric default 0,
  created_at      timestamptz not null default now(),
  unique (owner_id, month, year)
);

-- 5. ALTER BOOKINGS TABLE - ADD PAYMENT VERIFICATION COLUMN
ALTER TABLE public.bookings 
ADD COLUMN IF NOT EXISTS payment_verified boolean default false,
ADD COLUMN IF NOT EXISTS payment_verified_at timestamptz,
ADD COLUMN IF NOT EXISTS event_date date,
ADD COLUMN IF NOT EXISTS slot_type text,
ADD COLUMN IF NOT EXISTS customer_name text,
ADD COLUMN IF NOT EXISTS customer_email text,
ADD COLUMN IF NOT EXISTS customer_phone text,
ADD COLUMN IF NOT EXISTS guest_count int,
ADD COLUMN IF NOT EXISTS total_amount numeric,
ADD COLUMN IF NOT EXISTS advance_amount numeric,
ADD COLUMN IF NOT EXISTS commission_amount numeric default 0,
ADD COLUMN IF NOT EXISTS discount_amount numeric default 0,
ADD COLUMN IF NOT EXISTS partner_contacted boolean default false,
ADD COLUMN IF NOT EXISTS partner_contacted_at timestamptz,
ADD COLUMN IF NOT EXISTS venue_confirmation_status text default 'pending' check (venue_confirmation_status in ('pending', 'confirmed', 'rejected')),
ADD COLUMN IF NOT EXISTS notes text,
ADD COLUMN IF NOT EXISTS internal_notes text;

-- Backfill from older schema variants only when those columns exist.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'bookings' AND column_name = 'guests'
  ) THEN
    EXECUTE 'UPDATE public.bookings SET guest_count = COALESCE(guest_count, guests) WHERE guest_count IS NULL';
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'bookings' AND column_name = 'total_price'
  ) THEN
    EXECUTE 'UPDATE public.bookings SET total_amount = COALESCE(total_amount, total_price) WHERE total_amount IS NULL';
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'bookings' AND column_name = 'date'
  ) THEN
    EXECUTE 'UPDATE public.bookings SET event_date = COALESCE(event_date, date::date) WHERE event_date IS NULL AND date IS NOT NULL';
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'bookings' AND column_name = 'slot'
  ) THEN
    EXECUTE 'UPDATE public.bookings SET slot_type = COALESCE(slot_type, slot) WHERE slot_type IS NULL AND slot IS NOT NULL';
  END IF;
END $$;

ALTER TABLE public.payments
ADD COLUMN IF NOT EXISTS customer_note text;

ALTER TABLE public.payments
DROP CONSTRAINT IF EXISTS payments_status_check;

ALTER TABLE public.payments
ADD CONSTRAINT payments_status_check
CHECK (status in ('pending', 'submitted', 'verified', 'failed', 'refunded'));

-- 6. ADD UNIQUENESS CONSTRAINT TO BOOKINGS (Double-booking prevention)
-- PostgreSQL does not support partial UNIQUE constraints via ALTER TABLE.
-- Use a partial unique index instead so cancelled bookings free the slot.
ALTER TABLE public.bookings
DROP CONSTRAINT IF EXISTS bookings_unique_slot;

DROP INDEX IF EXISTS bookings_unique_active_slot;

CREATE UNIQUE INDEX IF NOT EXISTS bookings_unique_active_slot
ON public.bookings (hall_id, event_date, slot_type)
WHERE status <> 'cancelled';

-- 7. ROW LEVEL SECURITY FOR NEW TABLES

-- Payments table
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Customers can view their payments" ON public.payments;
CREATE POLICY "Customers can view their payments"
  ON public.payments FOR SELECT
  USING (auth.uid() = customer_id);

DROP POLICY IF EXISTS "Customers can create their payments" ON public.payments;
CREATE POLICY "Customers can create their payments"
  ON public.payments FOR INSERT
  WITH CHECK (auth.uid() = customer_id);

DROP POLICY IF EXISTS "Customers can submit payment proof" ON public.payments;
CREATE POLICY "Customers can submit payment proof"
  ON public.payments FOR UPDATE
  USING (auth.uid() = customer_id AND status IN ('pending', 'submitted'))
  WITH CHECK (auth.uid() = customer_id AND status IN ('pending', 'submitted'));

DROP POLICY IF EXISTS "Admins can manage all payments" ON public.payments;
CREATE POLICY "Admins can manage all payments"
  ON public.payments FOR ALL
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Booking Status History
ALTER TABLE public.booking_status_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view booking status history" ON public.booking_status_history;
CREATE POLICY "Users can view booking status history"
  ON public.booking_status_history FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.bookings
      WHERE id = booking_id AND customer_id = auth.uid()
    )
    OR
    EXISTS (
      SELECT 1 FROM public.halls
      JOIN public.bookings ON bookings.hall_id = halls.id
      WHERE bookings.id = booking_id AND halls.owner_id = auth.uid()
    )
    OR
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Commissions table
ALTER TABLE public.commissions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Owners can view their commissions" ON public.commissions;
CREATE POLICY "Owners can view their commissions"
  ON public.commissions FOR SELECT
  USING (auth.uid() = owner_id);

DROP POLICY IF EXISTS "Admins can manage all commissions" ON public.commissions;
CREATE POLICY "Admins can manage all commissions"
  ON public.commissions FOR ALL
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- Owner partner workflow fields on their own venue bookings.
DROP POLICY IF EXISTS "Owners can update partner booking fields" ON public.bookings;
CREATE POLICY "Owners can update partner booking fields"
  ON public.bookings FOR UPDATE
  USING (
    EXISTS (SELECT 1 FROM public.halls WHERE id = hall_id AND owner_id = auth.uid())
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.halls WHERE id = hall_id AND owner_id = auth.uid())
  );

-- Partner Analytics
ALTER TABLE public.partner_analytics ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Owners can view their analytics" ON public.partner_analytics;
CREATE POLICY "Owners can view their analytics"
  ON public.partner_analytics FOR SELECT
  USING (auth.uid() = owner_id);

DROP POLICY IF EXISTS "Admins can view all analytics" ON public.partner_analytics;
CREATE POLICY "Admins can view all analytics"
  ON public.partner_analytics FOR ALL
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- 8. CREATE INDEXES FOR PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_payments_booking_id ON public.payments(booking_id);
CREATE INDEX IF NOT EXISTS idx_payments_customer_id ON public.payments(customer_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON public.payments(status);
CREATE INDEX IF NOT EXISTS idx_booking_status_history_booking_id ON public.booking_status_history(booking_id);
CREATE INDEX IF NOT EXISTS idx_commissions_booking_id ON public.commissions(booking_id);
CREATE INDEX IF NOT EXISTS idx_commissions_owner_id ON public.commissions(owner_id);
CREATE INDEX IF NOT EXISTS idx_partner_analytics_owner_id ON public.partner_analytics(owner_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_commissions_booking_unique ON public.commissions(booking_id);

-- 9. ENABLE REALTIME FOR NEW TABLES
DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.payments;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.booking_status_history;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.commissions;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- 10. STORAGE POLICIES FOR PAYMENT ASSETS/PROOFS
DROP POLICY IF EXISTS "Public can read payment assets" ON storage.objects;
CREATE POLICY "Public can read payment assets"
ON storage.objects FOR SELECT
USING (bucket_id = 'payment-assets');

DROP POLICY IF EXISTS "Authenticated users can upload payment proofs" ON storage.objects;
CREATE POLICY "Authenticated users can upload payment proofs"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'payment-proofs' AND auth.role() = 'authenticated');

DROP POLICY IF EXISTS "Users can read their uploaded payment proofs" ON storage.objects;
CREATE POLICY "Users can read their uploaded payment proofs"
ON storage.objects FOR SELECT
USING (bucket_id = 'payment-proofs' AND auth.role() = 'authenticated');

-- Migration complete
