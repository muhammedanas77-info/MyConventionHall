-- ============================================================
-- ConventionHub — Notification Triggers via pg_net
-- Wires AFTER INSERT / AFTER UPDATE triggers on service_bookings
-- and vendor_profiles to the send-vendor-notification edge function
-- using pg_net.http_post.
--
-- Prerequisites:
--   • pg_net extension must be enabled in the Supabase project.
--   • Run AFTER multi_vendor_migration.sql.
--   • Inject the edge function base URL at deploy time:
--       ALTER DATABASE postgres
--         SET app.edge_function_url = 'https://<project-ref>.supabase.co/functions/v1';
--     Or pass it per-session before running this script:
--       SET app.edge_function_url = '...';
--
-- Idempotent: safe to re-run.
-- Requirements: 10.1, 10.2, 10.3, 10.4, 10.5, 10.6, 10.7
-- ============================================================

-- ============================================================
-- HELPER: ensure pg_net is available
-- ============================================================
CREATE EXTENSION IF NOT EXISTS pg_net;

-- ============================================================
-- 1. fn_notify_booking_insert
--    Fires on AFTER INSERT on service_bookings.
--    Sends two notifications in parallel:
--      • booking_received_customer  (Req 10.1)
--      • booking_received_vendor    (Req 10.2)
-- ============================================================
CREATE OR REPLACE FUNCTION public.fn_notify_booking_insert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_base_url  text;
  v_func_url  text;
  v_headers   jsonb;
BEGIN
  -- Resolve the edge function base URL injected at deploy time.
  -- Returns NULL (not an error) when the setting is absent so the
  -- trigger degrades gracefully in local dev without pg_net.
  v_base_url := current_setting('app.edge_function_url', true);

  IF v_base_url IS NULL OR v_base_url = '' THEN
    RETURN NEW;
  END IF;

  v_func_url := v_base_url || '/send-vendor-notification';

  v_headers := jsonb_build_object(
    'Content-Type', 'application/json'
  );

  -- booking_received_customer — Req 10.1
  PERFORM pg_net.http_post(
    url     := v_func_url,
    headers := v_headers,
    body    := jsonb_build_object(
                 'type',       'booking_received_customer',
                 'booking_id', NEW.id
               )::text
  );

  -- booking_received_vendor — Req 10.2
  PERFORM pg_net.http_post(
    url     := v_func_url,
    headers := v_headers,
    body    := jsonb_build_object(
                 'type',       'booking_received_vendor',
                 'booking_id', NEW.id
               )::text
  );

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS service_bookings_notify_insert ON public.service_bookings;
CREATE TRIGGER service_bookings_notify_insert
  AFTER INSERT ON public.service_bookings
  FOR EACH ROW
  EXECUTE FUNCTION public.fn_notify_booking_insert();

-- ============================================================
-- 2. fn_notify_booking_status_update
--    Fires on AFTER UPDATE on service_bookings when status changes.
--    Routes to the correct notification type:
--      • pending  → confirmed  : booking_confirmed   (Req 10.3)
--      • pending  → cancelled  : booking_rejected    (Req 10.4)
--        (vendor-initiated cancellation with rejection_reason)
--      • any      → cancelled  : booking_cancelled   (Req 10.7)
--        (customer-initiated or admin cancellation)
--    The edge function distinguishes vendor-reject vs customer-cancel
--    by inspecting rejection_reason and the changed_by context it
--    can derive from service_booking_status_history.
-- ============================================================
CREATE OR REPLACE FUNCTION public.fn_notify_booking_status_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_base_url    text;
  v_func_url    text;
  v_headers     jsonb;
  v_notif_type  text;
BEGIN
  -- Only act when status actually changed
  IF OLD.status IS NOT DISTINCT FROM NEW.status THEN
    RETURN NEW;
  END IF;

  v_base_url := current_setting('app.edge_function_url', true);

  IF v_base_url IS NULL OR v_base_url = '' THEN
    RETURN NEW;
  END IF;

  v_func_url := v_base_url || '/send-vendor-notification';

  v_headers := jsonb_build_object(
    'Content-Type', 'application/json'
  );

  -- Determine notification type based on the status transition
  IF OLD.status = 'pending' AND NEW.status = 'confirmed' THEN
    -- Vendor confirmed the booking — Req 10.3
    v_notif_type := 'booking_confirmed';

    PERFORM pg_net.http_post(
      url     := v_func_url,
      headers := v_headers,
      body    := jsonb_build_object(
                   'type',       v_notif_type,
                   'booking_id', NEW.id
                 )::text
    );

  ELSIF OLD.status = 'pending' AND NEW.status = 'cancelled'
        AND NEW.rejection_reason IS NOT NULL THEN
    -- Vendor rejected the booking (rejection_reason is set) — Req 10.4
    v_notif_type := 'booking_rejected';

    PERFORM pg_net.http_post(
      url     := v_func_url,
      headers := v_headers,
      body    := jsonb_build_object(
                   'type',       v_notif_type,
                   'booking_id', NEW.id
                 )::text
    );

  ELSIF NEW.status = 'cancelled' THEN
    -- Customer or admin cancelled — Req 10.7
    v_notif_type := 'booking_cancelled';

    PERFORM pg_net.http_post(
      url     := v_func_url,
      headers := v_headers,
      body    := jsonb_build_object(
                   'type',       v_notif_type,
                   'booking_id', NEW.id
                 )::text
    );

  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS service_bookings_notify_status_update ON public.service_bookings;
CREATE TRIGGER service_bookings_notify_status_update
  AFTER UPDATE OF status ON public.service_bookings
  FOR EACH ROW
  EXECUTE FUNCTION public.fn_notify_booking_status_update();

-- ============================================================
-- 3. fn_notify_vendor_approval_update
--    Fires on AFTER UPDATE on vendor_profiles when is_approved changes.
--      • false → true  : vendor_approved   (Req 10.5)
--      • true  → false : vendor_rejected   (Req 10.6)
--        (admin set is_approved = false and wrote rejection_reason)
-- ============================================================
CREATE OR REPLACE FUNCTION public.fn_notify_vendor_approval_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_base_url    text;
  v_func_url    text;
  v_headers     jsonb;
  v_notif_type  text;
  v_body        jsonb;
BEGIN
  -- Only act when is_approved actually changed
  IF OLD.is_approved IS NOT DISTINCT FROM NEW.is_approved THEN
    RETURN NEW;
  END IF;

  v_base_url := current_setting('app.edge_function_url', true);

  IF v_base_url IS NULL OR v_base_url = '' THEN
    RETURN NEW;
  END IF;

  v_func_url := v_base_url || '/send-vendor-notification';

  v_headers := jsonb_build_object(
    'Content-Type', 'application/json'
  );

  IF NEW.is_approved = true THEN
    -- Admin approved the vendor — Req 10.5
    v_notif_type := 'vendor_approved';
    v_body := jsonb_build_object(
                'type',      v_notif_type,
                'vendor_id', NEW.id
              );

  ELSE
    -- Admin rejected / revoked the vendor — Req 10.6
    v_notif_type := 'vendor_rejected';
    v_body := jsonb_build_object(
                'type',      v_notif_type,
                'vendor_id', NEW.id,
                'reason',    COALESCE(NEW.rejection_reason, '')
              );

  END IF;

  PERFORM pg_net.http_post(
    url     := v_func_url,
    headers := v_headers,
    body    := v_body::text
  );

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS vendor_profiles_notify_approval ON public.vendor_profiles;
CREATE TRIGGER vendor_profiles_notify_approval
  AFTER UPDATE OF is_approved ON public.vendor_profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.fn_notify_vendor_approval_update();

-- ============================================================
-- Triggers registered:
--   service_bookings_notify_insert          (AFTER INSERT)
--   service_bookings_notify_status_update   (AFTER UPDATE OF status)
--   vendor_profiles_notify_approval         (AFTER UPDATE OF is_approved)
-- ============================================================
