﻿const fs = require('fs');
const path = require('path');

const content = fs.readFileSync(path.join(__dirname, 'vendor_login_content.txt'), 'utf8');
fs.writeFileSync(path.join(__dirname, '..', 'app', 'vendor-login.tsx'), content, 'utf8');
console.log('Written successfully, size:', content.length);
