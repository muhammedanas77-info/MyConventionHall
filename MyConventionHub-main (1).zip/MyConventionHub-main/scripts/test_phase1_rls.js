const { createClient } = require('@supabase/supabase-js');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.resolve(__dirname, '../.env') });

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !anonKey) {
  throw new Error('EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY are required.');
}

const supabase = createClient(supabaseUrl, anonKey);

async function check(name, query) {
  const { error } = await query;
  if (error) {
    console.log(`FAIL ${name}: ${error.message}`);
    return false;
  }
  console.log(`PASS ${name}`);
  return true;
}

async function main() {
  const results = [
    await check('anon can read approved halls', supabase.from('halls').select('id').eq('is_approved', true).limit(1)),
    await check('anon payments read is policy-filtered', supabase.from('payments').select('id').limit(1)),
    await check('anon commissions read is policy-filtered', supabase.from('commissions').select('id').limit(1)),
  ];

  if (results.some((result) => !result)) process.exit(1);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
