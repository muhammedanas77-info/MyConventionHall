-- ============================================================
-- ConventionHub — STEP 1: Run multi_vendor_migration.sql first
-- STEP 2: Then run this seed file.
--
-- OR: paste BOTH files together in one SQL Editor session.
-- This file assumes the migration tables already exist.
-- ============================================================

-- ────────────────────────────────────────────────────────────
-- 0. EXTEND profiles_role_check TO INCLUDE 'vendor'
-- ────────────────────────────────────────────────────────────
ALTER TABLE public.profiles
DROP CONSTRAINT IF EXISTS profiles_role_check;

ALTER TABLE public.profiles
ADD CONSTRAINT profiles_role_check
CHECK (role IN ('customer', 'owner', 'admin', 'vendor'));

-- ────────────────────────────────────────────────────────────
-- 1. FAKE AUTH USERS  (bypasses email OTP for seed data)
-- ────────────────────────────────────────────────────────────
INSERT INTO auth.users (
  id, email, encrypted_password, email_confirmed_at,
  raw_user_meta_data, created_at, updated_at,
  aud, role, confirmation_token, recovery_token
)
VALUES
  ('a1000000-0000-0000-0000-000000000001', 'vendor.florist1@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', ''),
  ('a1000000-0000-0000-0000-000000000002', 'vendor.florist2@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', ''),
  ('a2000000-0000-0000-0000-000000000001', 'vendor.musician1@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', ''),
  ('a2000000-0000-0000-0000-000000000002', 'vendor.musician2@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', ''),
  ('a2000000-0000-0000-0000-000000000003', 'vendor.dj1@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', ''),
  ('a3000000-0000-0000-0000-000000000001', 'vendor.caterer1@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', ''),
  ('a3000000-0000-0000-0000-000000000002', 'vendor.caterer2@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', ''),
  ('a4000000-0000-0000-0000-000000000001', 'vendor.photo1@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', ''),
  ('a4000000-0000-0000-0000-000000000002', 'vendor.photo2@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', ''),
  ('a5000000-0000-0000-0000-000000000001', 'vendor.decor1@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', ''),
  ('a5000000-0000-0000-0000-000000000002', 'vendor.decor2@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', ''),
  ('a6000000-0000-0000-0000-000000000001', 'vendor.artist1@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', ''),
  ('a6000000-0000-0000-0000-000000000002', 'vendor.artist2@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', ''),
  ('a7000000-0000-0000-0000-000000000001', 'vendor.other1@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', ''),
  ('a7000000-0000-0000-0000-000000000002', 'vendor.other2@seed.dev', '', now(), '{"role":"vendor"}', now(), now(), 'authenticated', 'authenticated', '', '')
ON CONFLICT (id) DO NOTHING;

-- ────────────────────────────────────────────────────────────
-- 2. PUBLIC PROFILES
-- ────────────────────────────────────────────────────────────
INSERT INTO public.profiles (id, email, full_name, role)
VALUES
  ('a1000000-0000-0000-0000-000000000001', 'vendor.florist1@seed.dev',  'Priya Patel',          'vendor'),
  ('a1000000-0000-0000-0000-000000000002', 'vendor.florist2@seed.dev',  'Ritu Sharma',          'vendor'),
  ('a2000000-0000-0000-0000-000000000001', 'vendor.musician1@seed.dev', 'Arjun Mehta',          'vendor'),
  ('a2000000-0000-0000-0000-000000000002', 'vendor.musician2@seed.dev', 'Sitar & Strings Co',   'vendor'),
  ('a2000000-0000-0000-0000-000000000003', 'vendor.dj1@seed.dev',       'DJ Rahul Beats',       'vendor'),
  ('a3000000-0000-0000-0000-000000000001', 'vendor.caterer1@seed.dev',  'Spice Route Caterers', 'vendor'),
  ('a3000000-0000-0000-0000-000000000002', 'vendor.caterer2@seed.dev',  'Royal Feast Events',   'vendor'),
  ('a4000000-0000-0000-0000-000000000001', 'vendor.photo1@seed.dev',    'Kapoor Photography',   'vendor'),
  ('a4000000-0000-0000-0000-000000000002', 'vendor.photo2@seed.dev',    'Moments by Sneha',     'vendor'),
  ('a5000000-0000-0000-0000-000000000001', 'vendor.decor1@seed.dev',    'Dream Décor Studio',   'vendor'),
  ('a5000000-0000-0000-0000-000000000002', 'vendor.decor2@seed.dev',    'Glam Events Decor',    'vendor'),
  ('a6000000-0000-0000-0000-000000000001', 'vendor.artist1@seed.dev',   'Mehndi by Fatima',     'vendor'),
  ('a6000000-0000-0000-0000-000000000002', 'vendor.artist2@seed.dev',   'Seema Beauty Studio',  'vendor'),
  ('a7000000-0000-0000-0000-000000000001', 'vendor.other1@seed.dev',    'Grand Event Planners', 'vendor'),
  ('a7000000-0000-0000-0000-000000000002', 'vendor.other2@seed.dev',    'Starlight Rentals',    'vendor')
ON CONFLICT (id) DO NOTHING;

-- ────────────────────────────────────────────────────────────
-- 3. VENDOR PROFILES
-- ────────────────────────────────────────────────────────────
INSERT INTO public.vendor_profiles (
  id, vendor_sector, business_name, phone, is_approved,
  profile_completion_status, sector_data
)
VALUES
  ('a1000000-0000-0000-0000-000000000001', 'florist', 'Priya Florals', '+91 98765 11001', true, 'complete',
   '{"business_name":"Priya Florals","city":"Bangalore","specialties":["wedding","centrepieces","arches"],"years_experience":8}'::jsonb),

  ('a1000000-0000-0000-0000-000000000002', 'florist', 'Ritu Blooms', '+91 98765 11002', true, 'complete',
   '{"business_name":"Ritu Blooms","city":"Mumbai","specialties":["bouquets","car decoration","stage floral"],"years_experience":5}'::jsonb),

  ('a2000000-0000-0000-0000-000000000001', 'musician', 'Arjun Mehta Live', '+91 98765 22001', true, 'complete',
   '{"artist_name":"Arjun Mehta","city":"Delhi","genres":["Bollywood","Classical","Sufi"],"instruments":["guitar","vocals"],"years_experience":10}'::jsonb),

  ('a2000000-0000-0000-0000-000000000002', 'musician', 'Sitar & Strings Co', '+91 98765 22002', true, 'complete',
   '{"artist_name":"Sitar & Strings","city":"Bangalore","genres":["Classical","Instrumental"],"instruments":["sitar","tabla","flute"],"years_experience":15}'::jsonb),

  ('a2000000-0000-0000-0000-000000000003', 'musician', 'DJ Rahul Beats', '+91 98765 22003', true, 'complete',
   '{"artist_name":"DJ Rahul Beats","city":"Hyderabad","genres":["EDM","Bollywood","Hip-Hop","Bhangra"],"instruments":["DJ equipment","lighting rig"],"years_experience":7}'::jsonb),

  ('a3000000-0000-0000-0000-000000000001', 'caterer', 'Spice Route Caterers', '+91 98765 33001', true, 'complete',
   '{"business_name":"Spice Route Caterers","city":"Bangalore","cuisine_types":["North Indian","South Indian","Chinese","Continental"],"min_guests":50,"max_guests":2000}'::jsonb),

  ('a3000000-0000-0000-0000-000000000002', 'caterer', 'Royal Feast Events', '+91 98765 33002', true, 'complete',
   '{"business_name":"Royal Feast Events","city":"Mumbai","cuisine_types":["Mughlai","Rajasthani","Pan-Asian","Jain"],"min_guests":100,"max_guests":5000}'::jsonb),

  ('a4000000-0000-0000-0000-000000000001', 'photographer', 'Kapoor Photography', '+91 98765 44001', true, 'complete',
   '{"studio_name":"Kapoor Photography","city":"Bangalore","photography_types":["wedding","pre-wedding","portrait"],"years_experience":12}'::jsonb),

  ('a4000000-0000-0000-0000-000000000002', 'photographer', 'Moments by Sneha', '+91 98765 44002', true, 'complete',
   '{"studio_name":"Moments by Sneha","city":"Pune","photography_types":["candid","cinematic","drone"],"years_experience":6}'::jsonb),

  ('a5000000-0000-0000-0000-000000000001', 'decorator', 'Dream Décor Studio', '+91 98765 55001', true, 'complete',
   '{"business_name":"Dream Décor Studio","city":"Bangalore","decoration_types":["floral","balloon","theme","mandap"],"years_experience":9}'::jsonb),

  ('a5000000-0000-0000-0000-000000000002', 'decorator', 'Glam Events Decor', '+91 98765 55002', true, 'complete',
   '{"business_name":"Glam Events Decor","city":"Chennai","decoration_types":["lighting","fabric draping","luxury","outdoor"],"years_experience":11}'::jsonb),

  ('a6000000-0000-0000-0000-000000000001', 'artist', 'Mehndi by Fatima', '+91 98765 66001', true, 'complete',
   '{"artist_name":"Mehndi by Fatima","city":"Bangalore","art_types":["bridal mehndi","Arabic","Rajasthani","party mehndi"],"years_experience":10}'::jsonb),

  ('a6000000-0000-0000-0000-000000000002', 'artist', 'Seema Beauty Studio', '+91 98765 66002', true, 'complete',
   '{"artist_name":"Seema Beauty Studio","city":"Mumbai","art_types":["bridal makeup","hair styling","party makeup","airbrush"],"years_experience":8}'::jsonb),

  ('a7000000-0000-0000-0000-000000000001', 'other', 'Grand Event Planners', '+91 98765 77001', true, 'complete',
   '{"business_name":"Grand Event Planners","city":"Bangalore","service_description":"Full-service wedding and corporate event planning."}'::jsonb),

  ('a7000000-0000-0000-0000-000000000002', 'other', 'Starlight Rentals', '+91 98765 77002', true, 'complete',
   '{"business_name":"Starlight Rentals","city":"Hyderabad","service_description":"Premium event furniture, tent, stage, and audio-visual equipment rental."}'::jsonb)

ON CONFLICT (id) DO NOTHING;

-- ────────────────────────────────────────────────────────────
-- 4. COMMISSION RATES (required for booking trigger to work)
-- ────────────────────────────────────────────────────────────
INSERT INTO public.sector_commission_rates (sector, fixed_fee, percentage_rate, effective_from)
VALUES
  ('florist',      500,  10, '2024-01-01'),
  ('musician',     1000, 12, '2024-01-01'),
  ('artist',       500,  10, '2024-01-01'),
  ('caterer',      1000, 8,  '2024-01-01'),
  ('photographer', 1000, 12, '2024-01-01'),
  ('decorator',    1000, 10, '2024-01-01'),
  ('other',        500,  10, '2024-01-01'),
  ('venue',        2000, 15, '2024-01-01')
ON CONFLICT DO NOTHING;

-- ────────────────────────────────────────────────────────────
-- 5. SERVICE LISTINGS
-- ────────────────────────────────────────────────────────────
INSERT INTO public.service_listings (
  vendor_id, sector, title, description,
  base_price, price_unit, tags, is_active, rating, total_reviews
)
VALUES
  -- Florists
  ('a1000000-0000-0000-0000-000000000001', 'florist',
   'Luxury Bridal Floral Package',
   'Full bridal flower setup: bridal bouquet, bridesmaid posies, mandap floral arch, centrepieces for 20 tables, car decoration, and stage backdrop.',
   85000, 'per_event', ARRAY['bridal','arch','centrepieces','rose','luxury'], true, 4.8, 42),

  ('a1000000-0000-0000-0000-000000000001', 'florist',
   'Reception Stage Floral Backdrop',
   'Lush floral wall backdrop (12×8 ft) with premium roses, orchids, and greens. Perfect for reception and photo ops.',
   35000, 'per_event', ARRAY['backdrop','reception','roses','orchids','photo booth'], true, 4.7, 28),

  ('a1000000-0000-0000-0000-000000000002', 'florist',
   'Budget Wedding Flower Package',
   'Simple and elegant floral arrangement: bridal bouquet, 10 table centrepieces, and entrance decoration. Seasonal flowers.',
   28000, 'per_event', ARRAY['budget','wedding','centrepieces','seasonal','simple'], true, 4.5, 61),

  ('a1000000-0000-0000-0000-000000000002', 'florist',
   'Birthday Party Flower Decoration',
   'Colourful balloon and floral mix for birthday parties. Includes photo corner, table arrangements, and cake table decor.',
   8500, 'per_event', ARRAY['birthday','balloon','colourful','party','fun'], true, 4.6, 35),

  -- Musicians / DJs
  ('a2000000-0000-0000-0000-000000000001', 'musician',
   'Live Bollywood & Sufi Performance',
   'Arjun Mehta performs live Bollywood, Sufi, and ghazal sets for 2–3 hours. Includes PA system, mic, and light backing.',
   55000, 'per_event', ARRAY['bollywood','sufi','ghazal','live','sangeet','mehndi'], true, 4.9, 54),

  ('a2000000-0000-0000-0000-000000000001', 'musician',
   'Acoustic Baarat Dhol + Guitar Combo',
   'High-energy baarat performance with traditional dhol and acoustic guitar fusion. 90-minute set.',
   30000, 'per_event', ARRAY['baarat','dhol','acoustic','energetic','procession'], true, 4.8, 31),

  ('a2000000-0000-0000-0000-000000000002', 'musician',
   'Classical Instrumental Ambience Set',
   'Sitar, tabla, and flute trio for 3 hours. Ideal for cocktail hour, pheras background, or corporate gala.',
   45000, 'per_event', ARRAY['classical','sitar','tabla','flute','instrumental','phera'], true, 4.9, 22),

  ('a2000000-0000-0000-0000-000000000003', 'musician',
   'DJ Night — Full Wedding Package',
   'Professional DJ for 5 hours: Bollywood, EDM, Bhangra, and Top 40. Includes JBL speaker array, lighting rig, and fog machine.',
   70000, 'per_event', ARRAY['dj','bollywood','edm','bhangra','lighting','fog','night'], true, 4.7, 89),

  ('a2000000-0000-0000-0000-000000000003', 'musician',
   'DJ Set — 3-Hour Birthday / Corporate',
   'Energetic 3-hour DJ set tailored to the crowd. Includes speakers and basic lighting.',
   35000, 'per_event', ARRAY['dj','birthday','corporate','3hour','speakers'], true, 4.6, 47),

  -- Caterers
  ('a3000000-0000-0000-0000-000000000001', 'caterer',
   'North & South Indian Wedding Menu',
   'Full wedding catering: live counters (North Indian, South Indian, Chinese), dessert station, and pan counter. Includes service staff.',
   850, 'per_plate', ARRAY['north indian','south indian','chinese','wedding','live counters','dessert'], true, 4.8, 112),

  ('a3000000-0000-0000-0000-000000000001', 'caterer',
   'Corporate Lunch Buffet',
   'Professional buffet: 2 veg + 2 non-veg mains, salad bar, breads, dessert, and beverages. Min 50 guests.',
   450, 'per_plate', ARRAY['corporate','buffet','lunch','professional','veg','non-veg'], true, 4.6, 78),

  ('a3000000-0000-0000-0000-000000000002', 'caterer',
   'Royal Rajasthani & Mughlai Feast',
   'Authentic Mughlai and Rajasthani royal wedding menu. Dal Baati Churma, Laal Maas, Biryani, kebab counter, and live tawa.',
   1200, 'per_plate', ARRAY['mughlai','rajasthani','biryani','kebab','royal','wedding','authentic'], true, 4.9, 67),

  ('a3000000-0000-0000-0000-000000000002', 'caterer',
   'Pan-Asian Fusion Menu',
   'Modern pan-Asian catering with Thai, Japanese, and Chinese stations. Ideal for corporate galas and upscale parties.',
   950, 'per_plate', ARRAY['asian','thai','japanese','chinese','fusion','corporate','upscale'], true, 4.7, 41),

  -- Photographers
  ('a4000000-0000-0000-0000-000000000001', 'photographer',
   'Full Wedding Photography & Video',
   'Complete wedding coverage (mehndi to reception). 2 photographers + 1 videographer. 1000+ edited photos and 20-min cinematic film.',
   120000, 'per_event', ARRAY['wedding','photography','video','cinematic','full coverage','edited'], true, 4.9, 88),

  ('a4000000-0000-0000-0000-000000000001', 'photographer',
   'Pre-Wedding Shoot',
   'Themed pre-wedding shoot at outdoor or studio location. 4-hour session, 2 outfits, 200 edited photos.',
   35000, 'per_event', ARRAY['pre-wedding','outdoor','studio','romantic','portrait','edited'], true, 4.8, 55),

  ('a4000000-0000-0000-0000-000000000002', 'photographer',
   'Candid Wedding Photography',
   'Candid and documentary-style wedding photography. Full-day coverage, 500 edited photos + Instagram reel.',
   65000, 'per_event', ARRAY['candid','documentary','wedding','reel','instagram','creative'], true, 4.7, 72),

  ('a4000000-0000-0000-0000-000000000002', 'photographer',
   'Drone Aerial Coverage Add-on',
   'Cinematic drone coverage. 2-hour session, 50 aerial shots + 5-min aerial reel. Subject to local airspace clearance.',
   18000, 'per_event', ARRAY['drone','aerial','cinematic','add-on','reel','bird-eye'], true, 4.6, 29),

  -- Decorators
  ('a5000000-0000-0000-0000-000000000001', 'decorator',
   'Royal Mandap & Stage Decoration',
   'Premium mandap with flower canopy, pillar draping, marigold strings, stage backdrop, couple seating, and entrance rangoli.',
   95000, 'per_event', ARRAY['mandap','stage','floral','marigold','rangoli','royal','wedding'], true, 4.9, 63),

  ('a5000000-0000-0000-0000-000000000001', 'decorator',
   'Balloon & Floral Birthday Setup',
   'Colourful birthday decoration: organic balloon garland, floral backdrop for cake table, banner, and table centrepieces.',
   12000, 'per_event', ARRAY['birthday','balloon','garland','colourful','cake table','fun'], true, 4.7, 48),

  ('a5000000-0000-0000-0000-000000000002', 'decorator',
   'Luxury Fabric & Lighting Decoration',
   'Ceiling fabric draping, crystal chandelier rentals, fairy light curtains, and ambient uplighting.',
   75000, 'per_event', ARRAY['fabric','draping','chandelier','fairy lights','uplighting','luxury','elegant'], true, 4.8, 51),

  ('a5000000-0000-0000-0000-000000000002', 'decorator',
   'Corporate Event Décor Package',
   'Professional décor: branded backdrop, podium floral, table centrepieces, and entrance archway. Clean, modern aesthetic.',
   40000, 'per_event', ARRAY['corporate','branded','modern','clean','professional','archway'], true, 4.6, 34),

  -- Artists
  ('a6000000-0000-0000-0000-000000000001', 'artist',
   'Bridal Mehndi — Full Bridal Package',
   'Intricate bridal mehndi on both hands and feet. Arabic, Rajasthani, and fusion designs. Artist and assistant for up to 6 hours.',
   15000, 'per_event', ARRAY['bridal','mehndi','arabic','rajasthani','hands','feet','intricate'], true, 4.9, 134),

  ('a6000000-0000-0000-0000-000000000001', 'artist',
   'Party Mehndi for Guests',
   'Quick, beautiful mehndi for wedding guests. Small to medium designs on hands. Min 20 guests.',
   300, 'per_plate', ARRAY['party','mehndi','guests','quick','hands','small design'], true, 4.7, 91),

  ('a6000000-0000-0000-0000-000000000002', 'artist',
   'Bridal Makeup & Hair Styling',
   'Full bridal makeup (airbrush + HD) and hair styling. Includes trial session 1 week before. 8–10 hours on wedding day.',
   25000, 'per_event', ARRAY['bridal','makeup','airbrush','HD','hair','trial','wedding day'], true, 4.8, 76),

  ('a6000000-0000-0000-0000-000000000002', 'artist',
   'Party Makeup — Family & Guests',
   'Professional party makeup for bridesmaids, family, and guests. Min 5 persons. Includes lashes and setting spray.',
   2500, 'per_plate', ARRAY['party makeup','guests','bridesmaids','family','lashes','professional'], true, 4.6, 58),

  -- Other
  ('a7000000-0000-0000-0000-000000000001', 'other',
   'Full Wedding Planning & Coordination',
   'End-to-end wedding planning: vendor sourcing, budget management, event-day coordination, and décor oversight.',
   200000, 'per_event', ARRAY['wedding planning','coordination','full service','budget','vendor management'], true, 4.9, 45),

  ('a7000000-0000-0000-0000-000000000001', 'other',
   'Day-of Coordination Package',
   'On-site coordinator for the wedding day. Manages timeline, vendors, and guests. Includes 4 weeks of pre-event planning calls.',
   45000, 'per_event', ARRAY['day-of','coordinator','on-site','timeline','wedding day'], true, 4.7, 38),

  ('a7000000-0000-0000-0000-000000000002', 'other',
   'Premium Tent & Furniture Rental',
   'Luxury shamiyana / party tent (40×60 ft), 200 banquet chairs, 20 round tables, and stage platform. Setup and pickup included.',
   55000, 'per_event', ARRAY['tent','shamiyana','furniture','chairs','tables','stage','rental'], true, 4.6, 27),

  ('a7000000-0000-0000-0000-000000000002', 'other',
   'Audio-Visual Equipment Rental',
   'Professional PA system (line array), projector + screen, wireless mics (×4), and LED stage lighting rig. Includes 1 operator.',
   30000, 'per_event', ARRAY['audio','visual','PA system','projector','mic','lighting','rental','AV'], true, 4.5, 33)

ON CONFLICT DO NOTHING;
