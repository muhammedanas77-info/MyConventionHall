import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(__dirname, '../.env') });

// Force direct URL for scripting
const supabaseUrl = 'http://127.0.0.1:4000';
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

const supabase = createClient(supabaseUrl, supabaseKey);

async function setupStorage() {
    const { data, error } = await supabase.storage.listBuckets();
    if (error) {
        console.error('Error listing buckets:', error);
        return;
    }
    console.log('Existing buckets:', data.map(b => b.name));

    const venueBucket = data.find(b => b.name === 'venue-images');
    if (!venueBucket) {
        console.log('Trying to create venue-images bucket...');
        const { data: newBucket, error: createError } = await supabase.storage.createBucket('venue-images', {
            public: true,
            fileSizeLimit: 10485760, // 10MB
        });
        if (createError) {
            console.error('Error creating bucket (Might need Admin/Dashboard access depending on RLS):', createError);
        } else {
            console.log('Successfully created bucket:', newBucket);
        }
    } else {
        console.log('Bucket already exists!');
    }
}

setupStorage();
