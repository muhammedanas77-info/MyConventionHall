import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(__dirname, '../.env') });

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

const supabase = createClient(supabaseUrl, supabaseKey);

async function purgeFakes() {
    console.log('Purging fake venues...');
    const idsToDelete = ['hall-001', 'hall-002', 'hall-003', 'hall-004', 'hall-005', 'hall-006', 'hall-007', 'hall-008', 'hall-009', 'hall-010'];

    const { error } = await supabase.from('halls').delete().in('id', idsToDelete);
    if (error) {
        console.error('Failed to delete fake venues:', error);
    } else {
        console.log('Fake venues purged successfully!');
    }
}

purgeFakes();
