-- ============================================================
-- ConventionHub — Fix bookings schema column constraints
-- Run this in Supabase SQL Editor if you see:
--   "null value in column 'date' violates not-null constraint"
-- ============================================================

-- The original schema had a 'date' column with NOT NULL.
-- Phase 1 migration added 'event_date' as the canonical column.
-- This script makes the old columns nullable so both schemas work.

-- 1. Make old 'date' column nullable (if it exists)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'bookings'
      AND column_name = 'date'
  ) THEN
    EXECUTE 'ALTER TABLE public.bookings ALTER COLUMN "date" DROP NOT NULL';
    RAISE NOTICE 'Dropped NOT NULL on bookings.date';
  ELSE
    RAISE NOTICE 'bookings.date column does not exist — nothing to do';
  END IF;
END $$;

-- 2. Make old 'slot' column nullable (if it exists)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'bookings'
      AND column_name = 'slot'
  ) THEN
    EXECUTE 'ALTER TABLE public.bookings ALTER COLUMN slot DROP NOT NULL';
    RAISE NOTICE 'Dropped NOT NULL on bookings.slot';
  END IF;
END $$;

-- 3. Backfill event_date from date for any existing rows
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'bookings'
      AND column_name = 'date'
  ) THEN
    EXECUTE 'UPDATE public.bookings SET event_date = date::date WHERE event_date IS NULL AND date IS NOT NULL';
    RAISE NOTICE 'Backfilled event_date from date';
  END IF;
END $$;

-- 4. Backfill slot_type from slot for any existing rows
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'bookings'
      AND column_name = 'slot'
  ) THEN
    EXECUTE 'UPDATE public.bookings SET slot_type = slot WHERE slot_type IS NULL AND slot IS NOT NULL';
    RAISE NOTICE 'Backfilled slot_type from slot';
  END IF;
END $$;

-- Done. The app now writes to both column names so it works
-- regardless of which migration state your DB is in.
