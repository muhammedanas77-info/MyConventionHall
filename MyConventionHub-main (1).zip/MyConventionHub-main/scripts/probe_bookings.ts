import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(__dirname, '../.env') });

const supabaseUrl = 'http://127.0.0.1:4000';
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

const supabase = createClient(supabaseUrl, supabaseKey);

async function probeBookings() {
    console.log('Probing bookings table...');
    const testColumns = ['hall_id', 'customer_id', 'date', 'slot', 'guest_count', 'total_amount', 'advance_amount', 'status'];

    for (const col of testColumns) {
        const { error } = await supabase.from('bookings').select(col).limit(1);
        if (error) {
            console.log(`❌ Column [${col}] is MISSING in bookings: ${error.message}`);
        } else {
            console.log(`✅ Column [${col}] exists in bookings!`);
        }
    }
}

probeBookings();
