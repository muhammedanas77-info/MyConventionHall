-- ============================================================
-- ConventionHub — Phase 2: Multi-Vendor Service Marketplace
-- Idempotent migration. Run AFTER phase1_migration.sql.
-- Requirements: 1.7, 2.10, 4.1, 4.6, 4.8, 6.5, 6.6, 6.7,
--               6.8, 6.9, 7.1, 7.7, 8.9, 9.1, 9.3, 9.6,
--               9.7, 10.9
-- ============================================================

-- ============================================================
-- 1. EXTEND profiles_role_check TO INCLUDE 'vendor'
-- ============================================================
ALTER TABLE public.profiles
DROP CONSTRAINT IF EXISTS profiles_role_check;

ALTER TABLE public.profiles
ADD CONSTRAINT profiles_role_check
CHECK (role IN ('customer', 'owner', 'admin', 'vendor'));

-- ============================================================
-- 2. VENDOR_PROFILES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.vendor_profiles (
  id                        uuid PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  vendor_sector             text NOT NULL CHECK (vendor_sector IN (
                              'venue', 'florist', 'musician', 'artist', 'caterer',
                              'photographer', 'decorator', 'other'
                            )),
  business_name             text,
  phone                     text,
  is_approved               boolean NOT NULL DEFAULT false,
  profile_completion_status text NOT NULL DEFAULT 'incomplete'
                            CHECK (profile_completion_status IN ('incomplete', 'complete')),
  rejection_reason          text,
  sector_data               jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at                timestamptz NOT NULL DEFAULT now(),
  updated_at                timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_vendor_profiles_sector
  ON public.vendor_profiles(vendor_sector);

CREATE INDEX IF NOT EXISTS idx_vendor_profiles_is_approved
  ON public.vendor_profiles(is_approved);

CREATE INDEX IF NOT EXISTS idx_vendor_profiles_sector_data_gin
  ON public.vendor_profiles USING gin (sector_data);

-- ============================================================
-- 3. SERVICE_LISTINGS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.service_listings (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id     uuid NOT NULL REFERENCES public.vendor_profiles(id) ON DELETE CASCADE,
  sector        text NOT NULL CHECK (sector IN (
                  'venue', 'florist', 'musician', 'artist', 'caterer',
                  'photographer', 'decorator', 'other'
                )),
  title         text NOT NULL CHECK (char_length(title) <= 200),
  description   text CHECK (char_length(description) <= 2000),
  base_price    numeric NOT NULL CHECK (base_price >= 0 AND base_price <= 999999.99),
  price_unit    text NOT NULL DEFAULT 'per_event'
                CHECK (price_unit IN ('per_event', 'per_plate', 'per_hour', 'per_day')),
  photos        text[] NOT NULL DEFAULT '{}',
  tags          text[] NOT NULL DEFAULT '{}',
  packages      jsonb,
  is_active     boolean NOT NULL DEFAULT true,
  rating        numeric,
  total_reviews integer NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_service_listings_vendor
  ON public.service_listings(vendor_id);

CREATE INDEX IF NOT EXISTS idx_service_listings_sector_active
  ON public.service_listings(sector, is_active);

CREATE INDEX IF NOT EXISTS idx_service_listings_tags_gin
  ON public.service_listings USING gin (tags);

-- ============================================================
-- 4. SERVICE_BOOKINGS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.service_bookings (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id       uuid NOT NULL REFERENCES public.service_listings(id) ON DELETE RESTRICT,
  vendor_id        uuid NOT NULL REFERENCES public.vendor_profiles(id) ON DELETE RESTRICT,
  customer_id      uuid NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
  sector           text NOT NULL CHECK (sector IN (
                     'venue', 'florist', 'musician', 'artist', 'caterer',
                     'photographer', 'decorator', 'other'
                   )),
  event_date       date NOT NULL,
  event_type       text NOT NULL CHECK (event_type IN ('wedding', 'birthday', 'corporate', 'other')),
  guest_count      integer,
  total_amount     numeric NOT NULL CHECK (total_amount >= 0),
  advance_amount   numeric NOT NULL CHECK (advance_amount >= 0),
  status           text NOT NULL DEFAULT 'pending'
                   CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
  special_requests text CHECK (char_length(special_requests) <= 500),
  rejection_reason text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

-- Double-booking prevention: only one non-cancelled booking per (listing, date)
DROP INDEX IF EXISTS service_bookings_unique_active_slot;
CREATE UNIQUE INDEX IF NOT EXISTS service_bookings_unique_active_slot
  ON public.service_bookings (listing_id, event_date)
  WHERE status <> 'cancelled';

CREATE INDEX IF NOT EXISTS idx_service_bookings_vendor_status
  ON public.service_bookings(vendor_id, status);

CREATE INDEX IF NOT EXISTS idx_service_bookings_customer
  ON public.service_bookings(customer_id);

CREATE INDEX IF NOT EXISTS idx_service_bookings_event_date
  ON public.service_bookings(event_date);

-- ============================================================
-- 5. SERVICE_BOOKING_STATUS_HISTORY TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.service_booking_status_history (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id  uuid NOT NULL REFERENCES public.service_bookings(id) ON DELETE CASCADE,
  old_status  text,
  new_status  text NOT NULL,
  changed_by  uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  changed_at  timestamptz NOT NULL DEFAULT now()
);

-- ============================================================
-- 6. SECTOR_COMMISSION_RATES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.sector_commission_rates (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sector          text NOT NULL CHECK (sector IN (
                    'venue', 'florist', 'musician', 'artist', 'caterer',
                    'photographer', 'decorator', 'other'
                  )),
  fixed_fee       numeric NOT NULL DEFAULT 0 CHECK (fixed_fee >= 0),
  percentage_rate numeric NOT NULL DEFAULT 0
                  CHECK (percentage_rate >= 0 AND percentage_rate <= 100),
  effective_from  date NOT NULL,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sector_commission_rates_lookup
  ON public.sector_commission_rates(sector, effective_from DESC);

-- ============================================================
-- 7. SERVICE_COMMISSIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.service_commissions (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id        uuid NOT NULL UNIQUE REFERENCES public.service_bookings(id) ON DELETE CASCADE,
  vendor_id         uuid NOT NULL REFERENCES public.vendor_profiles(id) ON DELETE RESTRICT,
  sector            text NOT NULL,
  total_amount      numeric NOT NULL,
  commission_amount numeric NOT NULL,
  vendor_payout     numeric NOT NULL,
  is_capped         boolean NOT NULL DEFAULT false,
  status            text NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending', 'paid')),
  paid_at           timestamptz,
  created_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_service_commissions_vendor_status
  ON public.service_commissions(vendor_id, status);

-- ============================================================
-- 8. SERVICE_FAVOURITES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.service_favourites (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  listing_id  uuid NOT NULL REFERENCES public.service_listings(id) ON DELETE CASCADE,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (customer_id, listing_id)
);

-- ============================================================
-- 9. NOTIFICATION TABLES
-- ============================================================

-- 9a. notification_failures — permanent log of exhausted retries
CREATE TABLE IF NOT EXISTS public.notification_failures (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_email   text NOT NULL,
  notification_type text NOT NULL,
  booking_id        uuid,
  vendor_id         uuid,
  error_message     text,
  attempts          integer NOT NULL DEFAULT 1,
  failed_at         timestamptz NOT NULL DEFAULT now()
);

-- 9b. notification_retry_queue — transient retry rows consumed by
--     the send-vendor-notification edge function on each invocation.
--     Rows are deleted once processed (success or final failure).
CREATE TABLE IF NOT EXISTS public.notification_retry_queue (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payload       jsonb NOT NULL,
  attempt       integer NOT NULL DEFAULT 1,
  next_retry_at timestamptz NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_notification_retry_queue_due
  ON public.notification_retry_queue (next_retry_at)
  WHERE next_retry_at IS NOT NULL;

-- ============================================================
-- 10. TRIGGERS
-- ============================================================

-- 10a. fn_set_booking_amounts — BEFORE INSERT on service_bookings
--      Derives total_amount from listing.base_price and
--      advance_amount = CEIL(total * 0.30 * 100) / 100
--      Requirements: 6.8, 6.9
CREATE OR REPLACE FUNCTION public.fn_set_booking_amounts()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  v_base numeric;
BEGIN
  SELECT base_price
    INTO v_base
    FROM public.service_listings
   WHERE id = NEW.listing_id;

  IF v_base IS NULL OR v_base = 0 THEN
    RAISE EXCEPTION 'Listing has no base price; cannot create booking'
      USING ERRCODE = 'P0001';
  END IF;

  NEW.total_amount   := v_base;
  NEW.advance_amount := CEIL(v_base * 0.30 * 100) / 100;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS service_bookings_set_amounts ON public.service_bookings;
CREATE TRIGGER service_bookings_set_amounts
  BEFORE INSERT ON public.service_bookings
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_booking_amounts();

-- 10b. fn_create_service_commission — AFTER INSERT on service_bookings
--      Applies fixed_fee + percentage_rate, caps at 50%, sets is_capped
--      Requirements: 9.2, 9.3, 9.6, 9.7
CREATE OR REPLACE FUNCTION public.fn_create_service_commission()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_rate       record;
  v_commission numeric;
  v_capped     boolean := false;
BEGIN
  SELECT fixed_fee, percentage_rate
    INTO v_rate
    FROM public.sector_commission_rates
   WHERE sector = NEW.sector
     AND effective_from <= NEW.event_date
   ORDER BY effective_from DESC
   LIMIT 1;

  IF v_rate IS NULL THEN
    RAISE EXCEPTION 'No active commission rate for sector %', NEW.sector
      USING ERRCODE = 'P0001';
  END IF;

  v_commission := v_rate.fixed_fee + (v_rate.percentage_rate / 100.0) * NEW.total_amount;

  IF v_commission > NEW.total_amount * 0.5 THEN
    v_commission := NEW.total_amount * 0.5;
    v_capped     := true;
  END IF;

  INSERT INTO public.service_commissions (
    booking_id, vendor_id, sector,
    total_amount, commission_amount, vendor_payout, is_capped
  ) VALUES (
    NEW.id, NEW.vendor_id, NEW.sector,
    NEW.total_amount, v_commission,
    NEW.total_amount - v_commission, v_capped
  );

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS service_bookings_create_commission ON public.service_bookings;
CREATE TRIGGER service_bookings_create_commission
  AFTER INSERT ON public.service_bookings
  FOR EACH ROW EXECUTE FUNCTION public.fn_create_service_commission();

-- 10c. fn_log_service_booking_status — AFTER UPDATE on service_bookings
--      Writes a row to service_booking_status_history on status change
--      Requirements: 6.7, 7.2, 7.3, 7.4
CREATE OR REPLACE FUNCTION public.fn_log_service_booking_status()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    INSERT INTO public.service_booking_status_history
      (booking_id, old_status, new_status, changed_by)
    VALUES
      (NEW.id, OLD.status, NEW.status, auth.uid());
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS service_bookings_log_status ON public.service_bookings;
CREATE TRIGGER service_bookings_log_status
  AFTER UPDATE ON public.service_bookings
  FOR EACH ROW EXECUTE FUNCTION public.fn_log_service_booking_status();

-- ============================================================
-- 11. ROW LEVEL SECURITY
-- ============================================================

-- vendor_profiles
ALTER TABLE public.vendor_profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "vp_select_own" ON public.vendor_profiles;
CREATE POLICY "vp_select_own"
  ON public.vendor_profiles FOR SELECT
  USING (auth.uid() = id);

DROP POLICY IF EXISTS "vp_select_approved_public" ON public.vendor_profiles;
CREATE POLICY "vp_select_approved_public"
  ON public.vendor_profiles FOR SELECT
  USING (is_approved = true);

DROP POLICY IF EXISTS "vp_update_own" ON public.vendor_profiles;
CREATE POLICY "vp_update_own"
  ON public.vendor_profiles FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (
    auth.uid() = id
    AND vendor_sector = (SELECT vendor_sector FROM public.vendor_profiles WHERE id = auth.uid())
    AND is_approved   = (SELECT is_approved   FROM public.vendor_profiles WHERE id = auth.uid())
  );

DROP POLICY IF EXISTS "vp_insert_own" ON public.vendor_profiles;
CREATE POLICY "vp_insert_own"
  ON public.vendor_profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "vp_admin_all" ON public.vendor_profiles;
CREATE POLICY "vp_admin_all"
  ON public.vendor_profiles FOR ALL
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- service_listings
ALTER TABLE public.service_listings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "sl_select_active" ON public.service_listings;
CREATE POLICY "sl_select_active"
  ON public.service_listings FOR SELECT
  USING (
    is_active = true
    AND EXISTS (
      SELECT 1 FROM public.vendor_profiles
       WHERE id = vendor_id AND is_approved = true
    )
  );

DROP POLICY IF EXISTS "sl_select_own" ON public.service_listings;
CREATE POLICY "sl_select_own"
  ON public.service_listings FOR SELECT
  USING (auth.uid() = vendor_id);

DROP POLICY IF EXISTS "sl_manage_own" ON public.service_listings;
CREATE POLICY "sl_manage_own"
  ON public.service_listings FOR ALL
  USING (auth.uid() = vendor_id)
  WITH CHECK (auth.uid() = vendor_id);

DROP POLICY IF EXISTS "sl_admin_all" ON public.service_listings;
CREATE POLICY "sl_admin_all"
  ON public.service_listings FOR ALL
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- service_bookings
ALTER TABLE public.service_bookings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "sb_select_customer" ON public.service_bookings;
CREATE POLICY "sb_select_customer"
  ON public.service_bookings FOR SELECT
  USING (auth.uid() = customer_id);

DROP POLICY IF EXISTS "sb_select_vendor" ON public.service_bookings;
CREATE POLICY "sb_select_vendor"
  ON public.service_bookings FOR SELECT
  USING (auth.uid() = vendor_id);

DROP POLICY IF EXISTS "sb_insert_customer" ON public.service_bookings;
CREATE POLICY "sb_insert_customer"
  ON public.service_bookings FOR INSERT
  WITH CHECK (auth.uid() = customer_id);

DROP POLICY IF EXISTS "sb_update_vendor" ON public.service_bookings;
CREATE POLICY "sb_update_vendor"
  ON public.service_bookings FOR UPDATE
  USING (auth.uid() = vendor_id)
  WITH CHECK (auth.uid() = vendor_id);

DROP POLICY IF EXISTS "sb_update_customer_cancel" ON public.service_bookings;
CREATE POLICY "sb_update_customer_cancel"
  ON public.service_bookings FOR UPDATE
  USING (auth.uid() = customer_id AND status = 'pending')
  WITH CHECK (auth.uid() = customer_id AND status IN ('pending', 'cancelled'));

DROP POLICY IF EXISTS "sb_admin_all" ON public.service_bookings;
CREATE POLICY "sb_admin_all"
  ON public.service_bookings FOR ALL
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- service_commissions
ALTER TABLE public.service_commissions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "sc_select_vendor" ON public.service_commissions;
CREATE POLICY "sc_select_vendor"
  ON public.service_commissions FOR SELECT
  USING (auth.uid() = vendor_id);

DROP POLICY IF EXISTS "sc_admin_all" ON public.service_commissions;
CREATE POLICY "sc_admin_all"
  ON public.service_commissions FOR ALL
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- service_favourites
ALTER TABLE public.service_favourites ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "sf_manage_own" ON public.service_favourites;
CREATE POLICY "sf_manage_own"
  ON public.service_favourites FOR ALL
  USING (auth.uid() = customer_id)
  WITH CHECK (auth.uid() = customer_id);

-- notification_failures (admin-only)
ALTER TABLE public.notification_failures ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "nf_admin_all" ON public.notification_failures;
CREATE POLICY "nf_admin_all"
  ON public.notification_failures FOR ALL
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- notification_retry_queue (service-role only — edge function uses service key)
ALTER TABLE public.notification_retry_queue ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "nrq_service_role_all" ON public.notification_retry_queue;
-- No user-facing policy; the edge function accesses this table via the
-- service-role key which bypasses RLS. Deny all other access.

-- sector_commission_rates (readable by all authenticated, writable by admin only)
ALTER TABLE public.sector_commission_rates ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "scr_select_all" ON public.sector_commission_rates;
CREATE POLICY "scr_select_all"
  ON public.sector_commission_rates FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "scr_admin_write" ON public.sector_commission_rates;
CREATE POLICY "scr_admin_write"
  ON public.sector_commission_rates FOR ALL
  USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

-- service_booking_status_history (readable by booking participants, admin)
ALTER TABLE public.service_booking_status_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "sbsh_select_participant" ON public.service_booking_status_history;
CREATE POLICY "sbsh_select_participant"
  ON public.service_booking_status_history FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.service_bookings
       WHERE id = booking_id
         AND (customer_id = auth.uid() OR vendor_id = auth.uid())
    )
    OR EXISTS (
      SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- ============================================================
-- 12. REALTIME PUBLICATION
-- ============================================================
DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.service_bookings;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.service_listings;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.vendor_profiles;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- ============================================================
-- 13. STORAGE BUCKETS
-- ============================================================
INSERT INTO storage.buckets (id, name, public)
VALUES
  ('service-listings', 'service-listings', true),
  ('vendor-portfolio',  'vendor-portfolio',  true)
ON CONFLICT (id) DO NOTHING;

-- ============================================================
-- 14. STORAGE POLICIES
-- ============================================================

-- service-listings bucket
DROP POLICY IF EXISTS "service_listings_public_read" ON storage.objects;
CREATE POLICY "service_listings_public_read"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'service-listings');

DROP POLICY IF EXISTS "service_listings_owner_insert" ON storage.objects;
CREATE POLICY "service_listings_owner_insert"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'service-listings'
    AND auth.role() = 'authenticated'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

DROP POLICY IF EXISTS "service_listings_owner_update" ON storage.objects;
CREATE POLICY "service_listings_owner_update"
  ON storage.objects FOR UPDATE
  USING (
    bucket_id = 'service-listings'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

DROP POLICY IF EXISTS "service_listings_owner_delete" ON storage.objects;
CREATE POLICY "service_listings_owner_delete"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'service-listings'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- vendor-portfolio bucket
DROP POLICY IF EXISTS "vendor_portfolio_public_read" ON storage.objects;
CREATE POLICY "vendor_portfolio_public_read"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'vendor-portfolio');

DROP POLICY IF EXISTS "vendor_portfolio_owner_insert" ON storage.objects;
CREATE POLICY "vendor_portfolio_owner_insert"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'vendor-portfolio'
    AND auth.role() = 'authenticated'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

DROP POLICY IF EXISTS "vendor_portfolio_owner_update" ON storage.objects;
CREATE POLICY "vendor_portfolio_owner_update"
  ON storage.objects FOR UPDATE
  USING (
    bucket_id = 'vendor-portfolio'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

DROP POLICY IF EXISTS "vendor_portfolio_owner_delete" ON storage.objects;
CREATE POLICY "vendor_portfolio_owner_delete"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'vendor-portfolio'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- Migration complete
