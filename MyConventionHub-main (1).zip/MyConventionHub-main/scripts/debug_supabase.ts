import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(__dirname, '../.env') });

const supabaseUrl = 'http://127.0.0.1:4000';
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

const supabase = createClient(supabaseUrl, supabaseKey);

async function debug() {
    console.log('Testing connection to Supabase via Proxy...');

    // 1. Test basic auth/health
    const { data: profileData, error: profileError } = await supabase.from('profiles').select('*').limit(1);
    console.log('Profiles table check:', profileError ? 'Error: ' + profileError.message : 'OK (' + (profileData?.length || 0) + ' rows)');

    // 2. Test halls table
    const { data: hallData, error: hallError } = await supabase.from('halls').select('*');
    if (hallError) {
        console.error('Halls table error:', hallError);
    } else {
        console.log('Halls table OK, row count:', hallData?.length || 0);
        if (hallData && hallData.length > 0) {
            console.log('First Hall Name:', hallData[0].name);
        }
    }
}

debug();
