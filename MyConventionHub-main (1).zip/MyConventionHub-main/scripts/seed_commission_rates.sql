-- ============================================================
-- Seed: Default sector commission rates
-- Requirements: 9.1, 9.7
--
-- Inserts one default commission rate row per sector using
-- effective_from = CURRENT_DATE.
--
-- Idempotent: each INSERT is guarded by a DO block that checks
-- whether a rate already exists for the sector before inserting.
-- Re-running this script is safe — existing rows are never
-- modified or duplicated.
-- ============================================================

DO $$
BEGIN
  -- venue: fixed_fee=2000, percentage_rate=8
  IF NOT EXISTS (
    SELECT 1 FROM public.sector_commission_rates WHERE sector = 'venue'
  ) THEN
    INSERT INTO public.sector_commission_rates (sector, fixed_fee, percentage_rate, effective_from)
    VALUES ('venue', 2000, 8, CURRENT_DATE);
  END IF;

  -- florist: fixed_fee=500, percentage_rate=10
  IF NOT EXISTS (
    SELECT 1 FROM public.sector_commission_rates WHERE sector = 'florist'
  ) THEN
    INSERT INTO public.sector_commission_rates (sector, fixed_fee, percentage_rate, effective_from)
    VALUES ('florist', 500, 10, CURRENT_DATE);
  END IF;

  -- musician: fixed_fee=1000, percentage_rate=10
  IF NOT EXISTS (
    SELECT 1 FROM public.sector_commission_rates WHERE sector = 'musician'
  ) THEN
    INSERT INTO public.sector_commission_rates (sector, fixed_fee, percentage_rate, effective_from)
    VALUES ('musician', 1000, 10, CURRENT_DATE);
  END IF;

  -- artist: fixed_fee=500, percentage_rate=10
  IF NOT EXISTS (
    SELECT 1 FROM public.sector_commission_rates WHERE sector = 'artist'
  ) THEN
    INSERT INTO public.sector_commission_rates (sector, fixed_fee, percentage_rate, effective_from)
    VALUES ('artist', 500, 10, CURRENT_DATE);
  END IF;

  -- caterer: fixed_fee=1000, percentage_rate=8
  IF NOT EXISTS (
    SELECT 1 FROM public.sector_commission_rates WHERE sector = 'caterer'
  ) THEN
    INSERT INTO public.sector_commission_rates (sector, fixed_fee, percentage_rate, effective_from)
    VALUES ('caterer', 1000, 8, CURRENT_DATE);
  END IF;

  -- photographer: fixed_fee=1500, percentage_rate=10
  IF NOT EXISTS (
    SELECT 1 FROM public.sector_commission_rates WHERE sector = 'photographer'
  ) THEN
    INSERT INTO public.sector_commission_rates (sector, fixed_fee, percentage_rate, effective_from)
    VALUES ('photographer', 1500, 10, CURRENT_DATE);
  END IF;

  -- decorator: fixed_fee=1000, percentage_rate=10
  IF NOT EXISTS (
    SELECT 1 FROM public.sector_commission_rates WHERE sector = 'decorator'
  ) THEN
    INSERT INTO public.sector_commission_rates (sector, fixed_fee, percentage_rate, effective_from)
    VALUES ('decorator', 1000, 10, CURRENT_DATE);
  END IF;

  -- other: fixed_fee=500, percentage_rate=10
  IF NOT EXISTS (
    SELECT 1 FROM public.sector_commission_rates WHERE sector = 'other'
  ) THEN
    INSERT INTO public.sector_commission_rates (sector, fixed_fee, percentage_rate, effective_from)
    VALUES ('other', 500, 10, CURRENT_DATE);
  END IF;
END $$;
