-- ============================================================
-- ConventionHub — Add dummy photos to seeded service listings
-- Uses picsum.photos (reliable, no API key, no auth needed)
-- Run AFTER seed_vendors.sql in Supabase SQL Editor
-- ============================================================

-- ── Florists ─────────────────────────────────────────────────
UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/152/800/600',
  'https://picsum.photos/id/306/800/600',
  'https://picsum.photos/id/488/800/600'
] WHERE title = 'Luxury Bridal Floral Package';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/488/800/600',
  'https://picsum.photos/id/152/800/600'
] WHERE title = 'Reception Stage Floral Backdrop';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/306/800/600',
  'https://picsum.photos/id/583/800/600'
] WHERE title = 'Budget Wedding Flower Package';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/445/800/600',
  'https://picsum.photos/id/152/800/600'
] WHERE title = 'Birthday Party Flower Decoration';

-- ── Musicians / DJs ───────────────────────────────────────────
UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/164/800/600',
  'https://picsum.photos/id/392/800/600',
  'https://picsum.photos/id/1011/800/600'
] WHERE title = 'Live Bollywood & Sufi Performance';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/164/800/600',
  'https://picsum.photos/id/1025/800/600'
] WHERE title = 'Acoustic Baarat Dhol + Guitar Combo';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/1060/800/600',
  'https://picsum.photos/id/392/800/600'
] WHERE title = 'Classical Instrumental Ambience Set';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/1015/800/600',
  'https://picsum.photos/id/325/800/600',
  'https://picsum.photos/id/455/800/600'
] WHERE title = 'DJ Night — Full Wedding Package';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/325/800/600',
  'https://picsum.photos/id/1015/800/600'
] WHERE title = 'DJ Set — 3-Hour Birthday / Corporate';

-- ── Caterers ──────────────────────────────────────────────────
UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/292/800/600',
  'https://picsum.photos/id/431/800/600',
  'https://picsum.photos/id/999/800/600'
] WHERE title = 'North & South Indian Wedding Menu';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/431/800/600',
  'https://picsum.photos/id/292/800/600'
] WHERE title = 'Corporate Lunch Buffet';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/999/800/600',
  'https://picsum.photos/id/292/800/600',
  'https://picsum.photos/id/431/800/600'
] WHERE title = 'Royal Rajasthani & Mughlai Feast';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/493/800/600',
  'https://picsum.photos/id/431/800/600'
] WHERE title = 'Pan-Asian Fusion Menu';

-- ── Photographers ─────────────────────────────────────────────
UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/1002/800/600',
  'https://picsum.photos/id/659/800/600',
  'https://picsum.photos/id/826/800/600'
] WHERE title = 'Full Wedding Photography & Video';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/826/800/600',
  'https://picsum.photos/id/659/800/600'
] WHERE title = 'Pre-Wedding Shoot';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/1002/800/600',
  'https://picsum.photos/id/318/800/600'
] WHERE title = 'Candid Wedding Photography';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/250/800/600',
  'https://picsum.photos/id/960/800/600'
] WHERE title = 'Drone Aerial Coverage Add-on';

-- ── Decorators ────────────────────────────────────────────────
UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/174/800/600',
  'https://picsum.photos/id/445/800/600',
  'https://picsum.photos/id/152/800/600'
] WHERE title = 'Royal Mandap & Stage Decoration';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/445/800/600',
  'https://picsum.photos/id/488/800/600'
] WHERE title = 'Balloon & Floral Birthday Setup';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/1015/800/600',
  'https://picsum.photos/id/455/800/600',
  'https://picsum.photos/id/174/800/600'
] WHERE title = 'Luxury Fabric & Lighting Decoration';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/3/800/600',
  'https://picsum.photos/id/180/800/600'
] WHERE title = 'Corporate Event Décor Package';

-- ── Artists (Mehndi / Makeup) ─────────────────────────────────
UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/839/800/600',
  'https://picsum.photos/id/1084/800/600',
  'https://picsum.photos/id/883/800/600'
] WHERE title = 'Bridal Mehndi — Full Bridal Package';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/839/800/600',
  'https://picsum.photos/id/883/800/600'
] WHERE title = 'Party Mehndi for Guests';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/1068/800/600',
  'https://picsum.photos/id/338/800/600',
  'https://picsum.photos/id/883/800/600'
] WHERE title = 'Bridal Makeup & Hair Styling';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/338/800/600',
  'https://picsum.photos/id/1068/800/600'
] WHERE title = 'Party Makeup — Family & Guests';

-- ── Other (Event Planners / Rentals) ─────────────────────────
UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/260/800/600',
  'https://picsum.photos/id/174/800/600',
  'https://picsum.photos/id/3/800/600'
] WHERE title = 'Full Wedding Planning & Coordination';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/180/800/600',
  'https://picsum.photos/id/260/800/600'
] WHERE title = 'Day-of Coordination Package';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/376/800/600',
  'https://picsum.photos/id/174/800/600'
] WHERE title = 'Premium Tent & Furniture Rental';

UPDATE public.service_listings SET photos = ARRAY[
  'https://picsum.photos/id/3/800/600',
  'https://picsum.photos/id/455/800/600'
] WHERE title = 'Audio-Visual Equipment Rental';
