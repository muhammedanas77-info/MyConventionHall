const { createClient } = require('@supabase/supabase-js');
const dotenv = require('dotenv');
const fs = require('fs');
const path = require('path');

dotenv.config({ path: path.resolve(__dirname, '../.env') });

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const qrPath = process.env.UPI_QR_LOCAL_PATH;

if (!supabaseUrl || !serviceRoleKey) {
  throw new Error('EXPO_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are required.');
}

const supabase = createClient(supabaseUrl, serviceRoleKey, {
  auth: { persistSession: false, autoRefreshToken: false },
});

async function ensureBucket(name, isPublic) {
  const { data: buckets, error: listError } = await supabase.storage.listBuckets();
  if (listError) throw listError;

  if (buckets && buckets.some((bucket) => bucket.name === name)) {
    console.log(`Bucket exists: ${name}`);
    return;
  }

  const { error } = await supabase.storage.createBucket(name, {
    public: isPublic,
    fileSizeLimit: 10 * 1024 * 1024,
  });
  if (error) throw error;
  console.log(`Created bucket: ${name}`);
}

async function uploadQrCode() {
  if (!qrPath) {
    console.log('UPI_QR_LOCAL_PATH not set. Skipping QR upload.');
    return;
  }

  const absoluteQrPath = path.resolve(qrPath);
  if (!fs.existsSync(absoluteQrPath)) {
    throw new Error(`QR file not found: ${absoluteQrPath}`);
  }

  const extension = path.extname(absoluteQrPath).replace('.', '') || 'png';
  const filePath = `upi-qr.${extension}`;
  const fileBuffer = fs.readFileSync(absoluteQrPath);
  const contentType = extension === 'jpg' || extension === 'jpeg' ? 'image/jpeg' : 'image/png';

  const { error } = await supabase.storage.from('payment-assets').upload(filePath, fileBuffer, { contentType, upsert: true });
  if (error) throw error;

  const { data } = supabase.storage.from('payment-assets').getPublicUrl(filePath);
  console.log(`UPI QR public URL: ${data.publicUrl}`);
}

async function main() {
  await ensureBucket('payment-proofs', false);
  await ensureBucket('payment-assets', true);
  await uploadQrCode();
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
