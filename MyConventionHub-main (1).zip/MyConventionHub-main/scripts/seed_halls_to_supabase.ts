import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(__dirname, '../.env') });

// Point to local proxy to avoid ISP block
const supabaseUrl = 'http://127.0.0.1:4000';
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

const supabase = createClient(supabaseUrl, supabaseKey);

const SEED_HALLS = [
    {
        name: 'Palace Grounds — Nalpad Pavilion',
        description: 'The crown jewel of Bangalore\'s wedding venues, featuring a grand pavilion and sprawling lawns.',
        address: 'Palace Road, Near TV Tower',
        area: 'Palace Grounds',
        city: 'Bangalore',
        capacity_min: 1000,
        capacity_max: 5000,
        price_per_day: 740000,
        photos: ['https://images.unsplash.com/photo-1519167758481-83f550bb49b3?q=80&w=2074&auto=format&fit=crop'],
        amenities: ['AC', 'Parking', 'Catering Info', 'Decoration', 'Rooms available', 'Valet'],
        is_featured: true,
        rating: 4.8,
        total_reviews: 215,
        created_at: new Date().toISOString()
    },
    {
        name: 'Royal Garden Banquet Hall',
        description: 'Elegant boutique banquet hall perfect for intimate weddings and receptions.',
        address: '12th Main Road, Jayanagar 4th Block',
        area: 'Jayanagar',
        city: 'Bangalore',
        capacity_min: 200,
        capacity_max: 800,
        price_per_day: 370000,
        photos: ['https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=2070&auto=format&fit=crop'],
        amenities: ['AC', 'Parking', 'Decoration', 'DJ Allowed'],
        is_featured: true,
        rating: 4.6,
        total_reviews: 128,
        created_at: new Date().toISOString()
    },
    {
        name: 'Palace Grounds — Tripura Vasini',
        description: 'Large scale venue with massive capacity and premium facilities for grand celebrations.',
        address: 'Gate No. 2, Palace Grounds',
        area: 'Palace Grounds',
        city: 'Bangalore',
        capacity_min: 1500,
        capacity_max: 8000,
        price_per_day: 940000,
        photos: ['https://images.unsplash.com/photo-1469334031218-e382a71b716b?q=80&w=2070&auto=format&fit=crop'],
        amenities: ['AC', 'Parking', 'Power Backup', 'Valet', 'Rooms available'],
        is_featured: false,
        rating: 4.5,
        total_reviews: 95,
        created_at: new Date().toISOString()
    },
    {
        name: 'Koramangala Club Banquet',
        description: 'Sophisticated club venue with a modern touch and excellent catering options.',
        address: '6th Block, Koramangala',
        area: 'Koramangala',
        city: 'Bangalore',
        capacity_min: 300,
        capacity_max: 1200,
        price_per_day: 690000,
        photos: ['https://images.unsplash.com/photo-1544145945-f904253db0ad?q=80&w=1974&auto=format&fit=crop'],
        amenities: ['AC', 'Parking', 'Catering Info', 'Alcohol Allowed'],
        is_featured: false,
        rating: 4.7,
        total_reviews: 142,
        created_at: new Date().toISOString()
    }
];

async function seedData() {
    console.log('Starting seed...');

    const placeholderOwnerId = '00000000-0000-0000-0000-000000000000';

    const { error } = await supabase.from('halls').insert(
        SEED_HALLS.map(hall => ({
            ...hall,
            owner_id: placeholderOwnerId
        }))
    );

    if (error) {
        console.error('Error seeding data:', error);
    } else {
        console.log('Seeded halls successfully!');
    }
}

seedData();
