const http = require('http');
const https = require('https');

const TARGET_HOST = 'nmwqzozezbmshwjsgxhx.supabase.co';
// Known good Cloudflare IP for Supabase, bypassing the Jio DNS block entirely.
const TARGET_IP = '104.18.38.10';
const PORT = 4000;

const server = http.createServer((req, res) => {
    console.log(`\n🔔 INCOMING: ${req.method} ${req.url}`);
    // We dynamically reconstruct the path based on whatever Supabase tries to fetch
    const options = {
        hostname: TARGET_IP,
        port: 443,
        path: req.url,
        method: req.method,
        headers: {
            ...req.headers,
            host: TARGET_HOST, // Spoof host header so Cloudflare routes perfectly
        },
        servername: TARGET_HOST, // Set SNI to the real host for the SSL certificate
        rejectUnauthorized: true,
    };

    const proxyReq = https.request(options, (proxyRes) => {
        console.log(`✅ RESPONSE: ${proxyRes.statusCode}`);
        // Carry over everything to the React Native app perfectly
        res.writeHead(proxyRes.statusCode, proxyRes.headers);
        proxyRes.pipe(res, { end: true });
    });

    proxyReq.on('error', (err) => {
        console.error('Proxy Request Error:', err);
        res.writeHead(500);
        res.end('Proxy Error');
    });

    // Pipe the React Native request body into the Supabase Proxy request
    req.pipe(proxyReq, { end: true });
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`===============================================`);
    console.log(`🚀 Supabase Unblocker Proxy active on Port ${PORT}`);
    console.log(`===============================================`);
    console.log(`Listening for app traffic...`);
});
