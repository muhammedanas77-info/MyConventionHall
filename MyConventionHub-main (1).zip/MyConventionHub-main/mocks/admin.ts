import type { Hall } from '@/types';
import { SEED_HALLS } from '@/mocks/halls';

export const ADMIN_STATS = {
    totalHalls: 10,
    activeBookings: 28,
    todayRevenue: 84000,
    pendingApprovals: 2,
    totalCommission: 1245000,
    totalDiscounts: 280000,
    netRevenue: 965000,
};

export const ADMIN_MONTHLY_REVENUE = [
    { month: 'Sep', commission: 85000, discounts: 18000 },
    { month: 'Oct', commission: 112000, discounts: 24000 },
    { month: 'Nov', commission: 178000, discounts: 38000 },
    { month: 'Dec', commission: 245000, discounts: 52000 },
    { month: 'Jan', commission: 310000, discounts: 68000 },
    { month: 'Feb', commission: 315000, discounts: 80000 },
];

export const PENDING_HALLS: Hall[] = [
    {
        id: 'pending-001',
        owner_id: 'owner-new-001',
        name: 'Golden Lotus Convention',
        description: 'A new luxurious venue in HSR Layout with modern amenities and elegant décor.',
        address: 'HSR Layout, Sector 3',
        area: 'HSR Layout',
        city: 'Bangalore',
        latitude: 12.9116,
        longitude: 77.6389,
        capacity_min: 300,
        capacity_max: 1200,
        price_per_day: 185000,
        photos: ['https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=800&q=80'],
        amenities: ['AC', 'Parking', 'Generator', 'Catering Kitchen', 'Bridal Suite', 'Stage', 'LED Walls'],
        is_approved: false,
        is_featured: false,
        is_verified: false,
        rating: 0,
        total_reviews: 0,
        created_at: '2026-02-18T10:00:00Z',
    },
    {
        id: 'pending-002',
        owner_id: 'owner-new-002',
        name: 'Orchid Garden Banquet',
        description: 'Beautiful garden venue in JP Nagar perfect for outdoor weddings.',
        address: 'JP Nagar, 6th Phase',
        area: 'JP Nagar',
        city: 'Bangalore',
        latitude: 12.8920,
        longitude: 77.5850,
        capacity_min: 200,
        capacity_max: 800,
        price_per_day: 120000,
        photos: ['https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=800&q=80'],
        amenities: ['Parking', 'Generator', 'Catering Kitchen', 'Lawn Area', 'Stage', 'Sound System'],
        is_approved: false,
        is_featured: false,
        is_verified: false,
        rating: 0,
        total_reviews: 0,
        created_at: '2026-02-20T14:30:00Z',
    },
];

export const TOP_HALLS = SEED_HALLS.slice(0, 5).map((hall, index) => ({
    ...hall,
    monthlyBookings: [18, 15, 12, 10, 9][index],
    monthlyRevenue: [2800000, 2100000, 1650000, 1400000, 1200000][index],
}));

export const RECENT_ACTIVITY = [
    { id: 'act-1', type: 'booking', text: 'New booking at Palace Grounds by Priya Sharma', time: '2026-02-22T09:30:00Z' },
    { id: 'act-2', type: 'hall', text: 'New hall submitted: Golden Lotus Convention', time: '2026-02-22T08:15:00Z' },
    { id: 'act-3', type: 'cancel', text: 'Booking cancelled at Koramangala Club Banquet', time: '2026-02-21T18:45:00Z' },
    { id: 'act-4', type: 'review', text: 'New 5★ review on CMA Palace Hebbal', time: '2026-02-21T16:20:00Z' },
    { id: 'act-5', type: 'booking', text: 'New booking at Indiranagar Grand by Vikram Singh', time: '2026-02-21T14:00:00Z' },
    { id: 'act-6', type: 'hall', text: 'New hall submitted: Orchid Garden Banquet', time: '2026-02-20T14:30:00Z' },
    { id: 'act-7', type: 'booking', text: 'New booking at Hebbal Lake View by Deepa Iyer', time: '2026-02-20T11:00:00Z' },
];
