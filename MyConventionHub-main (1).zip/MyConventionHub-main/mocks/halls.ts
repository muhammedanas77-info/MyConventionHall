import type { Hall, HallPricing, Review, Booking } from '@/types';
import { SEASON_SLOT_MULTIPLIERS } from '@/constants/pricing';
import type { SeasonType, SlotType } from '@/types';

const PHOTOS = [
    'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=800&q=80',
    'https://images.unsplash.com/photo-1522413452208-996ff3f3e740?w=800&q=80',
    'https://images.unsplash.com/photo-1520854221256-17451cc331bf?w=800&q=80',
    'https://images.unsplash.com/photo-1544986581-efac024faf62?w=800&q=80',
    'https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?w=800&q=80',
];

export const SEED_HALLS: Hall[] = [
    {
        id: 'hall-001', owner_id: 'owner-001', name: 'Palace Grounds — Nalpad Pavilion',
        description: 'The crown jewel of Bangalore\'s wedding venues with sprawling lawns and world-class facilities.',
        address: 'Palace Grounds, Jayamahal Road', area: 'Palace Grounds', city: 'Bangalore',
        latitude: 13.0032, longitude: 77.5640, capacity_min: 1000, capacity_max: 5000, price_per_day: 500000,
        photos: [PHOTOS[0], PHOTOS[1], PHOTOS[2]],
        amenities: ['AC', 'Parking', 'Generator', 'Catering Kitchen', 'Bridal Suite', 'Valet Parking', 'Lawn Area', 'CCTV', 'VIP Lounge'],
        is_approved: true, is_featured: true, is_verified: true, rating: 4.9, total_reviews: 128, created_at: '2024-01-01T00:00:00Z',
    },
    {
        id: 'hall-002', owner_id: 'owner-002', name: 'CMA Palace Hebbal',
        description: 'A breathtaking lakeside venue combining natural beauty with modern elegance.',
        address: 'Hebbal, Outer Ring Road', area: 'Hebbal', city: 'Bangalore',
        latitude: 13.0389, longitude: 77.5956, capacity_min: 500, capacity_max: 2000, price_per_day: 300000,
        photos: [PHOTOS[1], PHOTOS[2], PHOTOS[3]],
        amenities: ['AC', 'Parking', 'Generator', 'Catering Kitchen', 'Bridal Suite', 'Stage', 'Lake View', 'Valet Parking'],
        is_approved: true, is_featured: true, is_verified: true, rating: 4.8, total_reviews: 96, created_at: '2024-01-15T00:00:00Z',
    },
    {
        id: 'hall-003', owner_id: 'owner-003', name: 'Frazer Town Palace Banquet',
        description: 'A cultural gem blending traditional charm with modern amenities.',
        address: 'Frazer Town, Coles Road', area: 'Frazer Town', city: 'Bangalore',
        latitude: 12.9823, longitude: 77.6089, capacity_min: 500, capacity_max: 2000, price_per_day: 200000,
        photos: [PHOTOS[2], PHOTOS[3], PHOTOS[4]],
        amenities: ['AC', 'Parking', 'Generator', 'Halal Catering', 'Bridal Suite', 'Stage', 'Prayer Room', 'CCTV'],
        is_approved: true, is_featured: true, is_verified: true, rating: 4.7, total_reviews: 84, created_at: '2024-02-01T00:00:00Z',
    },
    {
        id: 'hall-004', owner_id: 'owner-004', name: 'Koramangala Club Banquet',
        description: 'An exclusive rooftop venue with premium bar setup and stunning city views.',
        address: 'Koramangala, 4th Block', area: 'Koramangala', city: 'Bangalore',
        latitude: 12.9352, longitude: 77.6245, capacity_min: 200, capacity_max: 600, price_per_day: 250000,
        photos: [PHOTOS[3], PHOTOS[4], PHOTOS[0]],
        amenities: ['AC', 'Valet Parking', 'Generator', 'Premium Catering', 'Bridal Suite', 'Rooftop', 'Bar Setup', 'VIP Lounge'],
        is_approved: true, is_featured: true, is_verified: true, rating: 4.9, total_reviews: 72, created_at: '2024-02-15T00:00:00Z',
    },
    {
        id: 'hall-005', owner_id: 'owner-005', name: 'The Grand Pavilion Whitefield',
        description: 'A modern convention center in the IT hub with LED walls and sprawling lawns.',
        address: 'Whitefield, ITPL Main Road', area: 'Whitefield', city: 'Bangalore',
        latitude: 12.9698, longitude: 77.7499, capacity_min: 300, capacity_max: 1000, price_per_day: 220000,
        photos: [PHOTOS[4], PHOTOS[0], PHOTOS[1]],
        amenities: ['AC', 'Parking', 'Generator', 'Catering Kitchen', 'Bridal Suite', 'LED Walls', 'Valet Parking', 'Lawn Area'],
        is_approved: true, is_featured: true, is_verified: true, rating: 4.8, total_reviews: 65, created_at: '2024-03-01T00:00:00Z',
    },
    {
        id: 'hall-006', owner_id: 'owner-006', name: 'MSR Grand Kalyan Nagar',
        description: 'A versatile venue with excellent value, modern LED lighting and professional sound.',
        address: 'Kalyan Nagar, HRBR Layout', area: 'Kalyan Nagar', city: 'Bangalore',
        latitude: 13.0235, longitude: 77.6401, capacity_min: 300, capacity_max: 1000, price_per_day: 150000,
        photos: [PHOTOS[0], PHOTOS[2], PHOTOS[4]],
        amenities: ['AC', 'Parking', 'Generator', 'Catering Kitchen', 'Stage', 'Sound System', 'LED Lighting', 'Valet Parking'],
        is_approved: true, is_featured: true, is_verified: true, rating: 4.5, total_reviews: 58, created_at: '2024-03-15T00:00:00Z',
    },
    {
        id: 'hall-007', owner_id: 'owner-007', name: 'Royal Garden Banquet Jayanagar',
        description: 'Lush greenery with elegant interiors, perfect for traditional South Indian weddings.',
        address: 'Jayanagar, 4th T Block', area: 'Jayanagar', city: 'Bangalore',
        latitude: 12.9252, longitude: 77.5938, capacity_min: 500, capacity_max: 1500, price_per_day: 200000,
        photos: [PHOTOS[1], PHOTOS[3], PHOTOS[0]],
        amenities: ['AC', 'Parking', 'Generator', 'Catering Kitchen', 'Stage', 'Sound System', 'Lawn Area', 'Valet Parking'],
        is_approved: true, is_featured: true, is_verified: false, rating: 4.7, total_reviews: 45, created_at: '2024-04-01T00:00:00Z',
    },
    {
        id: 'hall-008', owner_id: 'owner-008', name: 'Indiranagar Grand Banquet',
        description: 'The most sought-after venue in Indiranagar with stunning rooftop city views.',
        address: 'Indiranagar, 100 Feet Road', area: 'Indiranagar', city: 'Bangalore',
        latitude: 12.9784, longitude: 77.6408, capacity_min: 200, capacity_max: 600, price_per_day: 275000,
        photos: [PHOTOS[3], PHOTOS[0], PHOTOS[2]],
        amenities: ['AC', 'Valet Parking', 'Generator', 'Premium Catering', 'Bridal Suite', 'Rooftop', 'Bar Setup', 'VIP Lounge'],
        is_approved: true, is_featured: true, is_verified: true, rating: 4.8, total_reviews: 88, created_at: '2024-05-01T00:00:00Z',
    },
    {
        id: 'hall-009', owner_id: 'owner-009', name: 'AMC Convention Bannerghatta',
        description: 'Surrounded by nature with sprawling gardens and modern amenities.',
        address: 'Bannerghatta Road', area: 'Bannerghatta Road', city: 'Bangalore',
        latitude: 12.8934, longitude: 77.5934, capacity_min: 400, capacity_max: 1500, price_per_day: 180000,
        photos: [PHOTOS[4], PHOTOS[1], PHOTOS[3]],
        amenities: ['AC', 'Parking', 'Generator', 'Catering Kitchen', 'Bridal Suite', 'Stage', 'Garden Area', 'Valet Parking'],
        is_approved: true, is_featured: false, is_verified: true, rating: 4.5, total_reviews: 52, created_at: '2024-05-15T00:00:00Z',
    },
    {
        id: 'hall-010', owner_id: 'owner-010', name: 'Malleshwaram Heritage Mahal',
        description: 'A heritage-style venue in the cultural heart of Malleshwaram.',
        address: 'Malleshwaram, Sampige Road', area: 'Malleshwaram', city: 'Bangalore',
        latitude: 13.0034, longitude: 77.5673, capacity_min: 300, capacity_max: 1000, price_per_day: 140000,
        photos: [PHOTOS[2], PHOTOS[4], PHOTOS[0]],
        amenities: ['AC', 'Parking', 'Generator', 'Catering Kitchen', 'Stage', 'Sound System', 'Valet Parking'],
        is_approved: true, is_featured: false, is_verified: true, rating: 4.6, total_reviews: 42, created_at: '2024-07-01T00:00:00Z',
    },
];

const REVIEWER_NAMES = [
    'Priya Sharma', 'Rajesh Kumar', 'Anjali Patel', 'Vikram Singh', 'Meera Reddy',
    'Arjun Nair', 'Deepa Iyer', 'Suresh Rao', 'Kavitha Menon', 'Rahul Gupta',
];

const REVIEW_COMMENTS = [
    'Absolutely stunning venue! Our wedding was magical here.',
    'Beautiful hall with excellent amenities. Highly recommended!',
    'The venue exceeded our expectations. Spacious and well-maintained.',
    'Perfect location for our reception. Professional management.',
    'Wonderful experience from start to finish. Great value for money.',
];

function generatePricing(hall: Hall): HallPricing[] {
    const seasons: SeasonType[] = ['off_season', 'shoulder', 'peak'];
    const slots: SlotType[] = ['morning', 'evening', 'full_day'];
    const pricing: HallPricing[] = [];
    for (const season of seasons) {
        for (const slot of slots) {
            pricing.push({
                id: `pricing-${hall.id}-${season}-${slot}`,
                hall_id: hall.id, slot, season,
                price: Math.round(hall.price_per_day * SEASON_SLOT_MULTIPLIERS[season][slot]),
            });
        }
    }
    return pricing;
}

function generateReviews(hall: Hall): Review[] {
    const reviews: Review[] = [];
    const idx = parseInt(hall.id.replace('hall-', '')) - 1;
    for (let i = 0; i < 3; i++) {
        const nIdx = (idx * 3 + i) % REVIEWER_NAMES.length;
        const cIdx = (idx * 3 + i) % REVIEW_COMMENTS.length;
        reviews.push({
            id: `review-${hall.id}-${i}`, hall_id: hall.id,
            customer_id: `customer-${nIdx}`, booking_id: `booking-review-${hall.id}-${i}`,
            rating: Math.max(3, Math.min(5, Math.floor(hall.rating) + (i === 0 ? 0 : (i % 2 === 0 ? -1 : 0)))),
            comment: REVIEW_COMMENTS[cIdx],
            created_at: new Date(2025, 6 + i, 10 + i * 5).toISOString(),
            profile: { full_name: REVIEWER_NAMES[nIdx] },
        });
    }
    return reviews;
}

export const SEED_HALL_PRICING: HallPricing[] = SEED_HALLS.flatMap(generatePricing);
export const SEED_REVIEWS: Review[] = SEED_HALLS.flatMap(generateReviews);

export const AREAS = [
    'All', 'HBR Layout', 'Nagavara', 'Frazer Town', 'Shivaji Nagar', 'Thanisandra',
    'Palace Grounds', 'Hegde Nagar', 'Hebbal', 'Indiranagar', 'Koramangala',
    'Whitefield', 'Jayanagar', 'Kalyan Nagar', 'Bannerghatta Road', 'Malleshwaram',
];

export const SEED_BOOKINGS: Booking[] = [
    {
        id: 'booking-001', hall_id: 'hall-001', customer_id: 'guest-user',
        date: '2026-03-15', slot: 'evening', guest_count: 2000,
        total_amount: 940000, advance_amount: 282000, commission_amount: 76000, discount_amount: 10000,
        status: 'confirmed', payment_id: 'pay_mock_001', refund_id: null, refund_status: null,
        special_requests: 'Need extra parking arrangements', created_at: '2026-01-10T10:30:00Z',
        hall: SEED_HALLS[0],
    },
    {
        id: 'booking-002', hall_id: 'hall-004', customer_id: 'guest-user',
        date: '2026-04-20', slot: 'full_day', guest_count: 400,
        total_amount: 690000, advance_amount: 207000, commission_amount: 56000, discount_amount: 10000,
        status: 'pending', payment_id: null, refund_id: null, refund_status: null,
        special_requests: 'Rooftop setup preferred', created_at: '2026-02-01T14:00:00Z',
        hall: SEED_HALLS[3],
    },
    {
        id: 'booking-003', hall_id: 'hall-008', customer_id: 'guest-user',
        date: '2025-12-10', slot: 'evening', guest_count: 300,
        total_amount: 517500, advance_amount: 155250, commission_amount: 41800, discount_amount: 10000,
        status: 'completed', payment_id: 'pay_mock_003', refund_id: null, refund_status: null,
        special_requests: null, created_at: '2025-10-05T09:00:00Z',
        hall: SEED_HALLS[7],
    },
];
