import React, { useRef, useEffect } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { Image } from 'expo-image';
import { MapPin, BadgeCheck, Star } from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { formatCurrency } from '@/utils/currency';
import { LinearGradient } from 'expo-linear-gradient';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import type { Hall } from '@/types';

interface FeaturedHallCardProps {
    hall: Hall;
    onPress: () => void;
    index?: number;
}

export default React.memo(function FeaturedHallCard({ hall, onPress, index = 0 }: FeaturedHallCardProps) {
    const entryAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        Animated.spring(entryAnim, {
            toValue: 1,
            delay: index * 100,
            useNativeDriver: true,
            speed: 14,
            bounciness: 4,
        }).start();
    }, [entryAnim, index]);

    return (
        <Animated.View style={[
            styles.wrapper,
            {
                opacity: entryAnim,
                transform: [{
                    translateX: entryAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [40, 0],
                    }),
                }],
            },
        ]}>
            <AnimatedPressable onPress={onPress} testID={`featured-hall-${hall.id}`}>
                <View style={styles.card}>
                    <Image
                        source={{ uri: hall.photos[0] }}
                        style={styles.image}
                        contentFit="cover"
                        placeholder={{ blurhash: 'LKO2?U%2Tw=w]~RBVZRi};RPxuwH' }}
                        transition={300}
                    />
                    <LinearGradient
                        colors={['transparent', 'rgba(0,0,0,0.8)']}
                        style={styles.gradient}
                        locations={[0.4, 1]}
                    />

                    <View style={styles.overlay}>
                        <View style={styles.ratingBadge}>
                            <Star size={11} color={Colors.gold} fill={Colors.gold} />
                            <Text style={styles.ratingText}>{hall.rating}</Text>
                        </View>

                        <View style={styles.bottomInfo}>
                            <View style={styles.nameRow}>
                                <Text style={styles.name} numberOfLines={1}>{hall.name}</Text>
                                {hall.is_verified && (
                                    <BadgeCheck size={14} color={Colors.gold} fill={Colors.gold} />
                                )}
                            </View>
                            <View style={styles.locationRow}>
                                <MapPin size={11} color="rgba(255,255,255,0.7)" />
                                <Text style={styles.area}>{hall.area}</Text>
                            </View>
                            <Text style={styles.price}>{formatCurrency(hall.price_per_day)}</Text>
                        </View>
                    </View>
                </View>
            </AnimatedPressable>
        </Animated.View>
    );
});

const styles = StyleSheet.create({
    wrapper: {
        marginRight: Spacing.md,
    },
    card: {
        width: 220,
        height: 280,
        borderRadius: Radius.xl,
        overflow: 'hidden',
        ...Shadow.lg,
    },
    image: {
        width: '100%',
        height: '100%',
    },
    gradient: {
        ...StyleSheet.absoluteFill,
        borderRadius: Radius.xl,
    },
    overlay: {
        ...StyleSheet.absoluteFill,
        justifyContent: 'space-between',
        padding: Spacing.md,
    },
    ratingBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-end',
        backgroundColor: 'rgba(0,0,0,0.5)',
        paddingHorizontal: Spacing.sm,
        paddingVertical: Spacing.xxs,
        borderRadius: Radius.full,
        gap: 3,
    },
    ratingText: {
        color: '#FFFFFF',
        fontSize: FontSize.xs,
        fontWeight: FontWeight.bold,
    },
    bottomInfo: {
        gap: Spacing.xxs,
    },
    nameRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xs,
    },
    name: {
        color: '#FFFFFF',
        fontSize: FontSize.md,
        fontWeight: FontWeight.bold,
        flex: 1,
    },
    locationRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 3,
    },
    area: {
        color: 'rgba(255,255,255,0.7)',
        fontSize: FontSize.xs,
    },
    price: {
        color: Colors.goldLight,
        fontSize: FontSize.lg,
        fontWeight: FontWeight.bold,
        marginTop: 2,
    },
});
