import React, { useRef, useCallback } from 'react';
import { ScrollView, Text, StyleSheet, Platform, type ScrollViewInstance } from 'react-native';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

interface AreaChipsProps {
    areas: string[];
    selectedArea: string;
    onSelect: (area: string) => void;
}

export default React.memo(function AreaChips({ areas, selectedArea, onSelect }: AreaChipsProps) {
    const scrollRef = useRef<ScrollViewInstance>(null);

    const handleSelect = useCallback((area: string) => {
        if (Platform.OS !== 'web') {
            Haptics.selectionAsync();
        }
        onSelect(area);
    }, [onSelect]);

    return (
        <ScrollView
            ref={scrollRef}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.container}
            decelerationRate="fast"
            snapToAlignment="start"
        >
            {areas.map((area) => {
                const isSelected = area === selectedArea;
                return (
                    <AnimatedPressable
                        key={area}
                        onPress={() => handleSelect(area)}
                        scaleValue={0.93}
                    >
                        <Text style={[
                            styles.chip,
                            isSelected ? styles.chipSelected : styles.chipDefault,
                        ]}>
                            {area}
                        </Text>
                    </AnimatedPressable>
                );
            })}
        </ScrollView>
    );
});

const styles = StyleSheet.create({
    container: {
        paddingHorizontal: Spacing.lg,
        paddingVertical: Spacing.sm,
        gap: Spacing.sm,
    },
    chip: {
        paddingHorizontal: Spacing.lg,
        paddingVertical: Spacing.sm,
        borderRadius: Radius.full,
        fontSize: FontSize.sm,
        fontWeight: FontWeight.medium,
        overflow: 'hidden',
    },
    chipSelected: {
        backgroundColor: Colors.primary,
        color: Colors.textOnPrimary,
        fontWeight: FontWeight.semibold,
    },
    chipDefault: {
        backgroundColor: Colors.surface,
        color: Colors.textSecondary,
        borderWidth: 1,
        borderColor: Colors.border,
    },
});
