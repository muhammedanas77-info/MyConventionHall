import React, { useState, useCallback } from 'react';
import {
    View, Text, StyleSheet, Modal, ScrollView,
    TouchableOpacity, Pressable, Platform, Dimensions
} from 'react-native';
import { X, Check } from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { SafeAreaView } from 'react-native-safe-area-context';
import AnimatedPressable from '@/components/ui/AnimatedPressable';

const { height } = Dimensions.get('window');
const SERIF_FONT = Platform.select({ ios: 'Georgia', android: 'serif', web: 'Georgia, serif', default: 'serif' });

const CAPACITIES = ['100+', '200+', '500+', '1000+', '2000+'];
const AMENITIES = ['AC', 'Parking', 'Catering', 'Decor', 'Rooms', 'Music'];

interface FilterModalProps {
    visible: boolean;
    onClose: () => void;
    onApply: (filters: FilterState) => void;
    initialFilters: FilterState;
}

export interface FilterState {
    maxPrice: number | null;
    capacity: string | null;
    amenities: string[];
}

export default function FilterModal({ visible, onClose, onApply, initialFilters }: FilterModalProps) {
    const [maxPrice, setMaxPrice] = useState<number | null>(initialFilters.maxPrice);
    const [capacity, setCapacity] = useState<string | null>(initialFilters.capacity);
    const [amenities, setAmenities] = useState<string[]>(initialFilters.amenities);

    const toggleAmenity = useCallback((amenity: string) => {
        setAmenities(prev =>
            prev.includes(amenity)
                ? prev.filter(a => a !== amenity)
                : [...prev, amenity]
        );
    }, []);

    const handleClear = () => {
        setMaxPrice(null);
        setCapacity(null);
        setAmenities([]);
    };

    const handleApply = () => {
        onApply({ maxPrice, capacity, amenities });
        onClose();
    };

    const priceRanges = [
        { label: 'Any', value: null },
        { label: 'Under ₹50k', value: 50000 },
        { label: 'Under ₹1L', value: 100000 },
        { label: 'Under ₹2L', value: 200000 },
        { label: 'Under ₹5L', value: 500000 },
    ];

    return (
        <Modal
            visible={visible}
            animationType="slide"
            transparent={true}
            onRequestClose={onClose}
        >
            <View style={styles.overlay}>
                <Pressable style={styles.dismiss} onPress={onClose} />
                <View style={styles.sheet}>
                    <View style={styles.grabHandle} />
                    <View style={styles.header}>
                        <TouchableOpacity onPress={onClose} style={styles.iconButton}>
                            <X size={20} color={Colors.textSecondary} />
                        </TouchableOpacity>
                        <Text style={styles.title}>Filters</Text>
                        <TouchableOpacity onPress={handleClear}>
                            <Text style={styles.clearText}>Clear All</Text>
                        </TouchableOpacity>
                    </View>

                    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>Budget</Text>
                            <Text style={styles.sectionSubtitle}>Max price per day</Text>
                            <View style={styles.chipRow}>
                                {priceRanges.map((range) => (
                                    <TouchableOpacity
                                        key={range.label}
                                        onPress={() => setMaxPrice(range.value)}
                                        style={[
                                            styles.chip,
                                            maxPrice === range.value && styles.chipActive
                                        ]}
                                    >
                                        <Text style={[
                                            styles.chipText,
                                            maxPrice === range.value && styles.chipTextActive
                                        ]}>
                                            {range.label}
                                        </Text>
                                    </TouchableOpacity>
                                ))}
                            </View>
                        </View>

                        <View style={styles.divider} />

                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>Capacity</Text>
                            <Text style={styles.sectionSubtitle}>Select minimum guest count</Text>
                            <View style={styles.chipRow}>
                                {CAPACITIES.map((cap) => (
                                    <TouchableOpacity
                                        key={cap}
                                        onPress={() => setCapacity(capacity === cap ? null : cap)}
                                        style={[
                                            styles.chip,
                                            capacity === cap && styles.chipActive
                                        ]}
                                    >
                                        <Text style={[
                                            styles.chipText,
                                            capacity === cap && styles.chipTextActive
                                        ]}>
                                            {cap}
                                        </Text>
                                    </TouchableOpacity>
                                ))}
                            </View>
                        </View>

                        <View style={styles.divider} />

                        <View style={styles.section}>
                            <Text style={styles.sectionTitle}>Amenities</Text>
                            <Text style={styles.sectionSubtitle}>Choose essential facilities</Text>
                            <View style={styles.chipRow}>
                                {AMENITIES.map((amenity) => {
                                    const isActive = amenities.includes(amenity);
                                    return (
                                        <TouchableOpacity
                                            key={amenity}
                                            onPress={() => toggleAmenity(amenity)}
                                            style={[
                                                styles.chip,
                                                isActive && styles.chipActive
                                            ]}
                                        >
                                            {isActive && <Check size={12} color="#FFFFFF" style={{ marginRight: 6 }} />}
                                            <Text style={[
                                                styles.chipText,
                                                isActive && styles.chipTextActive
                                            ]}>
                                                {amenity}
                                            </Text>
                                        </TouchableOpacity>
                                    );
                                })}
                            </View>
                        </View>
                    </ScrollView>

                    <SafeAreaView edges={['bottom']} style={styles.footer}>
                        <AnimatedPressable onPress={handleApply} style={styles.applyButton} scaleValue={0.98}>
                            <Text style={styles.applyButtonText}>Apply Filters</Text>
                        </AnimatedPressable>
                    </SafeAreaView>
                </View>
            </View>
        </Modal>
    );
}

const styles = StyleSheet.create({
    overlay: {
        flex: 1,
        backgroundColor: 'rgba(26, 14, 14, 0.4)',
        justifyContent: 'flex-end',
    },
    dismiss: {
        flex: 1,
    },
    sheet: {
        backgroundColor: '#FFFFFF',
        borderTopLeftRadius: 32,
        borderTopRightRadius: 32,
        maxHeight: height * 0.8,
        ...Shadow.lg,
    },
    grabHandle: {
        width: 36,
        height: 4,
        backgroundColor: Colors.border,
        borderRadius: 2,
        alignSelf: 'center',
        marginTop: 12,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: Spacing.xl,
        paddingTop: Spacing.md,
        paddingBottom: Spacing.lg,
        borderBottomWidth: 1,
        borderBottomColor: Colors.borderLight,
    },
    iconButton: {
        width: 32,
    },
    title: {
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.text,
        fontFamily: SERIF_FONT,
    },
    clearText: {
        fontSize: FontSize.sm,
        color: Colors.primary,
        fontWeight: FontWeight.bold,
    },
    scrollContent: {
        padding: Spacing.xl,
    },
    section: {
        marginBottom: Spacing.lg,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: Colors.text,
        fontFamily: SERIF_FONT,
        marginBottom: 2,
    },
    sectionSubtitle: {
        fontSize: FontSize.xs,
        color: Colors.textTertiary,
        marginBottom: Spacing.lg,
    },
    divider: {
        height: 1,
        backgroundColor: Colors.borderLight,
        marginBottom: Spacing.xl,
    },
    chipRow: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: 10,
    },
    chip: {
        paddingHorizontal: 18,
        paddingVertical: 10,
        borderRadius: Radius.full,
        backgroundColor: Colors.ivory,
        borderWidth: 1,
        borderColor: Colors.borderLight,
        flexDirection: 'row',
        alignItems: 'center',
    },
    chipActive: {
        backgroundColor: Colors.primary,
        borderColor: Colors.primary,
        ...Shadow.sm,
    },
    chipText: {
        fontSize: 14,
        color: Colors.textSecondary,
        fontWeight: FontWeight.semibold,
    },
    chipTextActive: {
        color: '#FFFFFF',
    },
    footer: {
        padding: Spacing.xl,
        backgroundColor: '#FFFFFF',
        ...Shadow.lg,
        shadowOpacity: 0.1,
    },
    applyButton: {
        backgroundColor: Colors.primary,
        height: 56,
        borderRadius: 16,
        justifyContent: 'center',
        alignItems: 'center',
    },
    applyButtonText: {
        color: '#FFFFFF',
        fontSize: 16,
        fontWeight: FontWeight.bold,
        textAlign: 'center',
    },
});
