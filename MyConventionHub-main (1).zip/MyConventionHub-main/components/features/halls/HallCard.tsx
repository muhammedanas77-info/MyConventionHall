import React, { useRef, useEffect } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { Image } from 'expo-image';
import { MapPin, Users, Heart } from 'lucide-react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight, Shadow } from '@/constants/theme';
import { formatCurrency } from '@/utils/currency';
import RatingStars from '@/components/ui/RatingStars';
import Badge from '@/components/ui/Badge';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import type { Hall } from '@/types';

interface HallCardProps {
    hall: Hall;
    onPress: () => void;
    onSave?: () => void;
    isSaved?: boolean;
    index?: number;
}

export default React.memo(function HallCard({ hall, onPress, onSave, isSaved = false, index = 0 }: HallCardProps) {
    const entryAnim = useRef(new Animated.Value(0)).current;
    const heartScale = useRef(new Animated.Value(1)).current;

    useEffect(() => {
        Animated.spring(entryAnim, {
            toValue: 1, delay: index * 80, useNativeDriver: true, speed: 12, bounciness: 6,
        }).start();
    }, [entryAnim, index]);

    const handleSave = () => {
        Animated.sequence([
            Animated.spring(heartScale, { toValue: 1.4, useNativeDriver: true, speed: 50 }),
            Animated.spring(heartScale, { toValue: 1, useNativeDriver: true, speed: 30, bounciness: 10 }),
        ]).start();
        onSave?.();
    };

    return (
        <Animated.View style={[styles.wrapper, {
            opacity: entryAnim,
            transform: [{ translateY: entryAnim.interpolate({ inputRange: [0, 1], outputRange: [60, 0] }) }],
        }]}>
            <AnimatedPressable onPress={onPress} onLongPress={handleSave} testID={`hall-card-${hall.id}`}>
                <View style={styles.card}>
                    <View style={styles.imageContainer}>
                        <Image source={{ uri: hall.photos[0] }} style={styles.image} contentFit="cover" transition={300} />
                        {hall.is_featured && (
                            <View style={styles.featuredBadge}><Text style={styles.featuredText}>Featured</Text></View>
                        )}
                        {onSave && (
                            <AnimatedPressable onPress={handleSave} style={styles.heartButton} scaleValue={0.85}>
                                <Animated.View style={{ transform: [{ scale: heartScale }] }}>
                                    <Heart size={20} color={isSaved ? Colors.primary : '#FFFFFF'} fill={isSaved ? Colors.primary : 'transparent'} />
                                </Animated.View>
                            </AnimatedPressable>
                        )}
                        <View style={styles.priceOverlay}>
                            <Text style={styles.priceText}>{formatCurrency(hall.price_per_day)}</Text>
                            <Text style={styles.priceLabel}>per day</Text>
                        </View>
                    </View>
                    <View style={styles.content}>
                        <Text style={styles.name} numberOfLines={1}>{hall.name}</Text>
                        <View style={styles.locationRow}>
                            <MapPin size={13} color={Colors.textTertiary} />
                            <Text style={styles.area}>{hall.area}, {hall.city}</Text>
                        </View>
                        <View style={styles.bottomRow}>
                            <View style={styles.capacityRow}>
                                <Users size={13} color={Colors.textTertiary} />
                                <Text style={styles.capacity}>{hall.capacity_min.toLocaleString()}-{hall.capacity_max.toLocaleString()}</Text>
                            </View>
                            <RatingStars rating={hall.rating} totalReviews={hall.total_reviews} size={13} />
                        </View>
                        {hall.amenities.length > 0 && (
                            <View style={styles.amenities}>
                                {hall.amenities.slice(0, 3).map((amenity) => (
                                    <Badge key={amenity} text={amenity} variant="neutral" size="sm" />
                                ))}
                                {hall.amenities.length > 3 && <Badge text={`+${hall.amenities.length - 3}`} variant="primary" size="sm" />}
                            </View>
                        )}
                    </View>
                </View>
            </AnimatedPressable>
        </Animated.View>
    );
});

const styles = StyleSheet.create({
    wrapper: { marginHorizontal: Spacing.lg, marginBottom: Spacing.lg },
    card: { backgroundColor: Colors.surface, borderRadius: Radius.xl, overflow: 'hidden', ...Shadow.md },
    imageContainer: { height: 190, position: 'relative' },
    image: { width: '100%', height: '100%' },
    featuredBadge: { position: 'absolute', top: Spacing.md, left: Spacing.md, backgroundColor: Colors.gold, paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: Radius.full },
    featuredText: { color: '#1A0E0E', fontSize: FontSize.xs, fontWeight: FontWeight.bold, letterSpacing: 0.5 },
    heartButton: { position: 'absolute', top: Spacing.md, right: Spacing.md, width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(0,0,0,0.3)', justifyContent: 'center', alignItems: 'center' },
    priceOverlay: { position: 'absolute', bottom: Spacing.md, right: Spacing.md, backgroundColor: 'rgba(0,0,0,0.7)', paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: Radius.md, flexDirection: 'row', alignItems: 'baseline', gap: Spacing.xxs },
    priceText: { color: '#FFFFFF', fontSize: FontSize.md, fontWeight: FontWeight.bold },
    priceLabel: { color: 'rgba(255,255,255,0.7)', fontSize: FontSize.xs },
    content: { padding: Spacing.lg, gap: Spacing.sm },
    name: { fontSize: FontSize.lg, fontWeight: FontWeight.bold, color: Colors.text },
    locationRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
    area: { fontSize: FontSize.sm, color: Colors.textTertiary },
    bottomRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    capacityRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
    capacity: { fontSize: FontSize.sm, color: Colors.textSecondary },
    amenities: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xs, marginTop: Spacing.xxs },
});
