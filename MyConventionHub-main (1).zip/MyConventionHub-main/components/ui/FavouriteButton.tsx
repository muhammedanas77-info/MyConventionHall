import React from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { Heart } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '@/providers/AuthProvider';
import { useFavourites } from '@/hooks/useFavourites';
import AnimatedPressable from '@/components/ui/AnimatedPressable';
import { Colors } from '@/constants/theme';

interface FavouriteButtonProps {
    listingId: string;
    size?: number;
}

export default function FavouriteButton({ listingId, size = 24 }: FavouriteButtonProps) {
    const router = useRouter();
    const { user } = useAuth();
    const { isFavourited, toggleFavourite, togglingId } = useFavourites();

    const favourited = isFavourited(listingId);
    const isToggling = togglingId === listingId;

    const handlePress = () => {
        if (!user) {
            router.push('/customer-login');
            return;
        }
        toggleFavourite(listingId);
    };

    return (
        <AnimatedPressable
            onPress={handlePress}
            style={styles.container}
            scaleValue={0.85}
            disabled={isToggling}
        >
            <View style={styles.inner}>
                {isToggling ? (
                    <ActivityIndicator
                        size="small"
                        color={Colors.error}
                        style={{ width: size, height: size }}
                    />
                ) : (
                    <Heart
                        size={size}
                        color={favourited ? Colors.error : Colors.textSecondary}
                        fill={favourited ? Colors.error : 'transparent'}
                    />
                )}
            </View>
        </AnimatedPressable>
    );
}

const styles = StyleSheet.create({
    container: {
        alignSelf: 'flex-start',
    },
    inner: {
        alignItems: 'center',
        justifyContent: 'center',
    },
});
