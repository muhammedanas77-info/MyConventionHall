import React, { useCallback, useRef } from 'react';
import { Animated, Pressable, StyleSheet, Platform } from 'react-native';
import * as Haptics from 'expo-haptics';

interface AnimatedPressableProps {
    onPress?: () => void;
    onLongPress?: () => void;
    style?: object;
    children: React.ReactNode;
    scaleValue?: number;
    disabled?: boolean;
    testID?: string;
}

export default function AnimatedPressable({
    onPress,
    onLongPress,
    style,
    children,
    scaleValue = 0.97,
    disabled = false,
    testID,
}: AnimatedPressableProps) {
    const scaleAnim = useRef(new Animated.Value(1)).current;

    const handlePressIn = useCallback(() => {
        Animated.spring(scaleAnim, {
            toValue: scaleValue,
            useNativeDriver: true,
            speed: 50,
            bounciness: 4,
        }).start();
    }, [scaleAnim, scaleValue]);

    const handlePressOut = useCallback(() => {
        Animated.spring(scaleAnim, {
            toValue: 1,
            useNativeDriver: true,
            speed: 40,
            bounciness: 6,
        }).start();
    }, [scaleAnim]);

    const handlePress = useCallback(() => {
        if (Platform.OS !== 'web') {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        }
        onPress?.();
    }, [onPress]);

    const handleLongPress = useCallback(() => {
        if (Platform.OS !== 'web') {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        }
        onLongPress?.();
    }, [onLongPress]);

    return (
        <Animated.View style={[{ transform: [{ scale: scaleAnim }] }, style]}>
            <Pressable
                onPress={handlePress}
                onLongPress={onLongPress ? handleLongPress : undefined}
                onPressIn={handlePressIn}
                onPressOut={handlePressOut}
                disabled={disabled}
                testID={testID}
                style={styles.pressable}
            >
                {children}
            </Pressable>
        </Animated.View>
    );
}

const styles = StyleSheet.create({
    pressable: {
        width: '100%',
    },
});
