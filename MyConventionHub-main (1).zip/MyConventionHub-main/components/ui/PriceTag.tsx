import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors, FontSize, FontWeight, Spacing } from '@/constants/theme';
import { formatCurrency } from '@/utils/currency';

interface PriceTagProps {
    price: number;
    label?: string;
    size?: 'sm' | 'md' | 'lg';
}

export default function PriceTag({ price, label = 'per day', size = 'md' }: PriceTagProps) {
    const priceSize = size === 'lg' ? FontSize.xxl : size === 'md' ? FontSize.lg : FontSize.md;
    const labelSize = size === 'lg' ? FontSize.sm : FontSize.xs;

    return (
        <View style={styles.container}>
            <Text style={[styles.price, { fontSize: priceSize }]}>
                {formatCurrency(price)}
            </Text>
            {label && (
                <Text style={[styles.label, { fontSize: labelSize }]}>
                    {label}
                </Text>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        alignItems: 'baseline',
        gap: Spacing.xxs,
    },
    price: {
        color: Colors.text,
        fontWeight: FontWeight.bold,
    },
    label: {
        color: Colors.textTertiary,
        fontWeight: FontWeight.regular,
    },
});
