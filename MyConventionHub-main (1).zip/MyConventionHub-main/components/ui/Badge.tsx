import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors, Spacing, Radius, FontSize, FontWeight } from '@/constants/theme';

type BadgeVariant = 'primary' | 'gold' | 'success' | 'warning' | 'error' | 'neutral';

interface BadgeProps {
    text: string;
    variant?: BadgeVariant;
    size?: 'sm' | 'md';
    icon?: React.ReactNode;
}

const VARIANT_STYLES: Record<BadgeVariant, { bg: string; text: string }> = {
    primary: { bg: Colors.primaryFaded2, text: Colors.primary },
    gold: { bg: Colors.goldFaded, text: Colors.goldDark },
    success: { bg: Colors.successLight, text: Colors.success },
    warning: { bg: Colors.warningLight, text: Colors.warning },
    error: { bg: Colors.errorLight, text: Colors.error },
    neutral: { bg: Colors.cream, text: Colors.textSecondary },
};

export default function Badge({ text, variant = 'primary', size = 'sm', icon }: BadgeProps) {
    const colors = VARIANT_STYLES[variant];
    const isSmall = size === 'sm';

    return (
        <View style={[
            styles.container,
            { backgroundColor: colors.bg },
            isSmall ? styles.smallPadding : styles.mdPadding,
        ]}>
            {icon && <View style={styles.icon}>{icon}</View>}
            <Text style={[
                styles.text,
                { color: colors.text },
                isSmall ? styles.smallText : styles.mdText,
            ]}>
                {text}
            </Text>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        alignItems: 'center',
        borderRadius: Radius.full,
        alignSelf: 'flex-start',
    },
    smallPadding: {
        paddingHorizontal: Spacing.sm,
        paddingVertical: Spacing.xxs,
    },
    mdPadding: {
        paddingHorizontal: Spacing.md,
        paddingVertical: Spacing.xs,
    },
    icon: {
        marginRight: Spacing.xs,
    },
    text: {
        fontWeight: FontWeight.semibold,
    },
    smallText: {
        fontSize: FontSize.xs,
    },
    mdText: {
        fontSize: FontSize.sm,
    },
});
