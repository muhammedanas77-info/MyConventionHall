import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Star } from 'lucide-react-native';
import { Colors, Spacing, FontSize, FontWeight } from '@/constants/theme';

interface RatingStarsProps {
    rating: number;
    totalReviews?: number;
    size?: number;
    showCount?: boolean;
}

export default function RatingStars({
    rating,
    totalReviews,
    size = 14,
    showCount = true,
}: RatingStarsProps) {
    return (
        <View style={styles.container}>
            <Star size={size} color={Colors.gold} fill={Colors.gold} />
            <Text style={[styles.rating, { fontSize: size - 1 }]}>
                {rating.toFixed(1)}
            </Text>
            {showCount && totalReviews !== undefined && (
                <Text style={[styles.count, { fontSize: size - 2 }]}>
                    ({totalReviews})
                </Text>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: Spacing.xxs,
    },
    rating: {
        color: Colors.text,
        fontWeight: FontWeight.semibold,
        marginLeft: 2,
    },
    count: {
        color: Colors.textTertiary,
        fontWeight: FontWeight.regular,
    },
});
