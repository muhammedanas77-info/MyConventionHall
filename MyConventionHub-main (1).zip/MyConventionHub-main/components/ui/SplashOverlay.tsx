import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated, Dimensions, Platform } from 'react-native';
import { Colors } from '@/constants/theme';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const SERIF_FONT = Platform.select({
    ios: 'Georgia',
    android: 'serif',
    web: 'Georgia, serif',
    default: 'serif',
});

interface SplashOverlayProps {
    onAnimationComplete: () => void;
}

export default function SplashOverlay({ onAnimationComplete }: SplashOverlayProps) {
    const lineScale = useRef(new Animated.Value(0)).current;
    const titleOpacity = useRef(new Animated.Value(0)).current;
    const titleScale = useRef(new Animated.Value(0.95)).current;
    const taglineOpacity = useRef(new Animated.Value(0)).current;
    const dotsOpacity = useRef(new Animated.Value(0)).current;
    const dot1 = useRef(new Animated.Value(0.3)).current;
    const dot2 = useRef(new Animated.Value(0.3)).current;
    const dot3 = useRef(new Animated.Value(0.3)).current;
    const fadeOut = useRef(new Animated.Value(1)).current;

    useEffect(() => {
        Animated.sequence([
            Animated.timing(lineScale, {
                toValue: 1,
                duration: 400,
                useNativeDriver: true,
            }),
            Animated.parallel([
                Animated.timing(titleOpacity, {
                    toValue: 1,
                    duration: 600,
                    useNativeDriver: true,
                }),
                Animated.spring(titleScale, {
                    toValue: 1,
                    useNativeDriver: true,
                    speed: 14,
                    bounciness: 3,
                }),
            ]),
            Animated.timing(taglineOpacity, {
                toValue: 1,
                duration: 400,
                useNativeDriver: true,
            }),
            Animated.timing(dotsOpacity, {
                toValue: 1,
                duration: 200,
                useNativeDriver: true,
            }),
        ]).start(() => {
            const pulse = (dot: Animated.Value, delay: number) => {
                Animated.loop(
                    Animated.sequence([
                        Animated.timing(dot, { toValue: 1, duration: 400, delay, useNativeDriver: true }),
                        Animated.timing(dot, { toValue: 0.3, duration: 400, useNativeDriver: true }),
                    ])
                ).start();
            };
            pulse(dot1, 0);
            pulse(dot2, 150);
            pulse(dot3, 300);

            setTimeout(() => {
                Animated.timing(fadeOut, {
                    toValue: 0,
                    duration: 400,
                    useNativeDriver: true,
                }).start(() => {
                    onAnimationComplete();
                });
            }, 800);
        });
    }, []);

    return (
        <Animated.View style={[styles.container, { opacity: fadeOut }]}>
            <View style={styles.content}>
                <Animated.Text
                    style={[
                        styles.title,
                        {
                            opacity: titleOpacity,
                            transform: [{ scale: titleScale }],
                        },
                    ]}
                >
                    ConventionHub
                </Animated.Text>

                <Animated.View style={[styles.line, { transform: [{ scaleX: lineScale }] }]} />

                <Animated.Text style={[styles.tagline, { opacity: taglineOpacity }]}>
                    INDIA'S PREMIER CONVENTION PORTAL
                </Animated.Text>

                <Animated.View style={[styles.dotsRow, { opacity: dotsOpacity }]}>
                    <Animated.View style={[styles.dot, { opacity: dot1 }]} />
                    <Animated.View style={[styles.dot, { opacity: dot2 }]} />
                    <Animated.View style={[styles.dot, { opacity: dot3 }]} />
                </Animated.View>
            </View>
        </Animated.View>
    );
}

const styles = StyleSheet.create({
    container: {
        ...StyleSheet.absoluteFill,
        backgroundColor: '#FFFFFF',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 9999,
    },
    content: {
        alignItems: 'center',
    },
    title: {
        fontSize: 40,
        fontWeight: '300' as const,
        color: Colors.primary,
        letterSpacing: 2,
        fontFamily: SERIF_FONT,
        marginBottom: 20,
    },
    line: {
        width: SCREEN_WIDTH * 0.3,
        height: 1.5,
        backgroundColor: Colors.primary,
        marginBottom: 20,
    },
    tagline: {
        fontSize: 12,
        color: Colors.textTertiary,
        letterSpacing: 2.5,
        fontWeight: '400' as const,
        marginBottom: 40,
    },
    dotsRow: {
        flexDirection: 'row',
        gap: 8,
    },
    dot: {
        width: 6,
        height: 6,
        borderRadius: 3,
        backgroundColor: Colors.primary,
    },
});
