export type UserRole = 'customer' | 'owner' | 'admin' | 'vendor';

export type SlotType = 'morning' | 'evening' | 'full_day';

export type SeasonType = 'peak' | 'shoulder' | 'off_season';

export type BookingStatus = 'pending' | 'confirmed' | 'cancelled' | 'completed';

export type AvailabilityStatus = 'available' | 'booked' | 'blocked';

export interface Profile {
    id: string;
    full_name: string;
    phone: string;
    role: UserRole;
    fcm_token: string | null;
    created_at: string;
}

export interface Hall {
    id: string;
    owner_id: string;
    name: string;
    description: string;
    address: string;
    area: string;
    city: string;
    latitude: number;
    longitude: number;
    capacity_min: number;
    capacity_max: number;
    price_per_day: number;
    photos: string[];
    amenities: string[];
    is_approved: boolean;
    is_featured: boolean;
    is_verified: boolean;
    rating: number;
    total_reviews: number;
    created_at: string;
}

export interface HallPricing {
    id: string;
    hall_id: string;
    slot: SlotType;
    season: SeasonType;
    price: number;
}

export interface Availability {
    id: string;
    hall_id: string;
    date: string;
    slot: SlotType;
    status: AvailabilityStatus;
}

export interface Booking {
    id: string;
    hall_id: string;
    customer_id: string;
    date: string;
    slot: SlotType;
    guest_count: number;
    total_amount: number;
    advance_amount: number;
    commission_amount: number;
    discount_amount: number;
    status: BookingStatus;
    payment_id: string | null;
    refund_id: string | null;
    refund_status: string | null;
    special_requests: string | null;
    created_at: string;
    hall?: Hall;
}

export interface Review {
    id: string;
    hall_id: string;
    customer_id: string;
    booking_id: string;
    rating: number;
    comment: string;
    created_at: string;
    profile?: Pick<Profile, 'full_name'>;
}

export interface SavedHall {
    id: string;
    customer_id: string;
    hall_id: string;
}

export interface AppNotification {
    id: string;
    user_id: string;
    title: string;
    body: string;
    type: string;
    is_read: boolean;
    related_id: string | null;
    created_at: string;
}

export interface PriceBreakdown {
    basePrice: number;
    season: SeasonType;
    slot: SlotType;
    slotPrice: number;
    commission: number;
    discount: number;
    totalAmount: number;
    advanceAmount: number;
    ownerGets: number;
}

// ─── Multi-vendor service marketplace types ───────────────────────────────────

export type VendorSector =
  | 'venue'
  | 'florist'
  | 'musician'
  | 'artist'
  | 'caterer'
  | 'photographer'
  | 'decorator'
  | 'other';

export type ServiceBookingStatus = 'pending' | 'confirmed' | 'cancelled' | 'completed';

export type EventType = 'wedding' | 'birthday' | 'corporate' | 'other';

export type PriceUnit = 'per_event' | 'per_plate' | 'per_hour' | 'per_day';

export type ProfileCompletionStatus = 'incomplete' | 'complete';

// Sector-specific data shapes (stored in vendor_profiles.sector_data JSONB)

export interface BlockedDateRange {
    start_date: string; // ISO date
    end_date: string;   // ISO date
}

export interface VenueSectorData {
    business_name: string;
    address: string;
    city: string;
    capacity_min: number;
    capacity_max: number;
    price_per_day: number;
    photos: string[];
    amenities: string[];
    blocked_dates: BlockedDateRange[];
}

export interface FloristSectorData {
    business_name: string;
    city: string;
    service_area: string;
    specialty_styles: string[];
    price_range_min: number;
    price_range_max: number;
    portfolio_photos: string[];
    blocked_dates: BlockedDateRange[];
}

export interface MusicianSectorData {
    artist_name: string;
    city: string;
    genre_tags: string[];
    performance_durations_min: number[];
    price_per_event: number;
    demo_links: string[];
    blocked_dates: BlockedDateRange[];
}

export interface PhotographerPackage {
    name: string;
    price: number;
}

export interface PhotographerSectorData {
    studio_name: string;
    city: string;
    photography_styles: string[];
    packages: PhotographerPackage[];
    portfolio_media: string[];
    blocked_dates: BlockedDateRange[];
}

export interface CatererSectorData {
    business_name: string;
    city: string;
    cuisine_types: string[];
    service_capacity_min: number;
    service_capacity_max: number;
    price_per_plate_min: number;
    price_per_plate_max: number;
    menu_highlights: string;
    blocked_dates: BlockedDateRange[];
}

export interface DecoratorSectorData {
    business_name: string;
    city: string;
    decoration_themes: string[];
    price_range_min: number;
    price_range_max: number;
    portfolio_photos: string[];
    blocked_dates: BlockedDateRange[];
}

export interface ArtistSectorData {
    artist_name: string;
    city: string;
    art_types: string[];
    price_per_event: number;
    portfolio_photos: string[];
    blocked_dates: BlockedDateRange[];
}

export interface OtherSectorData {
    business_name: string;
    city: string;
    service_description: string;
    price_range_min: number;
    price_range_max: number;
    blocked_dates: BlockedDateRange[];
}

export type SectorData =
    | VenueSectorData
    | FloristSectorData
    | MusicianSectorData
    | PhotographerSectorData
    | CatererSectorData
    | DecoratorSectorData
    | ArtistSectorData
    | OtherSectorData;

export interface VendorProfile {
    id: string;                 // = auth.users.id
    vendor_sector: VendorSector;
    business_name: string | null;
    email: string;
    phone: string | null;
    is_approved: boolean;
    profile_completion_status: ProfileCompletionStatus;
    rejection_reason: string | null;
    sector_data: SectorData | Partial<SectorData>;
    created_at: string;
    updated_at: string;
}

export interface ServiceListing {
    id: string;
    vendor_id: string;
    sector: VendorSector;
    title: string;
    description: string | null;
    base_price: number;
    price_unit: PriceUnit;
    photos: string[];
    tags: string[];
    packages: PhotographerPackage[] | null;
    is_active: boolean;
    rating: number | null;
    total_reviews: number;
    created_at: string;
}

export interface ServiceBooking {
    id: string;
    listing_id: string;
    vendor_id: string;
    customer_id: string;
    sector: VendorSector;
    event_date: string;
    event_type: EventType;
    guest_count: number | null;
    total_amount: number;
    advance_amount: number;
    status: ServiceBookingStatus;
    special_requests: string | null;
    rejection_reason: string | null;
    created_at: string;
    listing?: ServiceListing;
    customer?: Pick<Profile, 'id' | 'full_name' | 'phone'>;
}

export interface SectorCommissionRate {
    id: string;
    sector: VendorSector;
    fixed_fee: number;
    percentage_rate: number;
    effective_from: string;
    created_at: string;
}

export interface ServiceCommission {
    id: string;
    booking_id: string;
    vendor_id: string;
    sector: VendorSector;
    total_amount: number;
    commission_amount: number;
    vendor_payout: number;
    is_capped: boolean;
    status: 'pending' | 'paid';
    paid_at: string | null;
    created_at: string;
}

export interface ServiceFavourite {
    id: string;
    customer_id: string;
    listing_id: string;
    created_at: string;
}

export interface NotificationFailure {
    id: string;
    recipient_email: string;
    notification_type: string;
    booking_id: string | null;
    vendor_id: string | null;
    error_message: string;
    attempts: number;
    failed_at: string;
}
