export const Colors = {
    primary: '#8B1A2B',
    primaryLight: '#A8344A',
    primaryDark: '#6B0F1E',
    primaryFaded: 'rgba(139, 26, 43, 0.08)',
    primaryFaded2: 'rgba(139, 26, 43, 0.15)',

    gold: '#C8A24D',
    goldLight: '#E8C96A',
    goldDark: '#9A7B2F',
    goldFaded: 'rgba(200, 162, 77, 0.12)',

    saffron: '#E87D3E',
    saffronLight: '#F5A06A',

    ivory: '#FBF7F0',
    cream: '#F5EDE0',
    warmGray: '#E8DFD3',

    surface: '#FFFFFF',
    surfaceElevated: '#FFFFFF',
    background: '#FBF7F0',

    text: '#1A0E0E',
    textSecondary: '#6B5A52',
    textTertiary: '#9B8E86',
    textOnPrimary: '#FFFFFF',
    textOnGold: '#1A0E0E',

    success: '#1B7A40',
    successLight: '#E6F5EC',
    error: '#C53030',
    errorLight: '#FDE8E8',
    warning: '#D97706',
    warningLight: '#FEF3CD',
    info: '#2563EB',

    border: '#E8DFD3',
    borderLight: '#F0EBE3',
    divider: '#F0EBE3',

    shadow: 'rgba(26, 14, 14, 0.08)',
    shadowDark: 'rgba(26, 14, 14, 0.15)',
    overlay: 'rgba(26, 14, 14, 0.5)',

    skeleton: '#E8DFD3',
    skeletonHighlight: '#F5EDE0',

    verified: '#1B7A40',
    featured: '#C8A24D',
} as const;

export const Spacing = {
    xxs: 2,
    xs: 4,
    sm: 8,
    md: 12,
    lg: 16,
    xl: 20,
    xxl: 24,
    xxxl: 32,
    huge: 40,
    massive: 48,
} as const;

export const Radius = {
    xs: 4,
    sm: 8,
    md: 12,
    lg: 16,
    xl: 20,
    xxl: 24,
    full: 9999,
} as const;

export const FontSize = {
    xs: 11,
    sm: 13,
    md: 15,
    lg: 17,
    xl: 20,
    xxl: 24,
    xxxl: 30,
    display: 36,
} as const;

export const FontWeight = {
    regular: '400' as const,
    medium: '500' as const,
    semibold: '600' as const,
    bold: '700' as const,
    heavy: '800' as const,
};

export const Shadow = {
    sm: {
        shadowColor: Colors.shadow,
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 1,
        shadowRadius: 3,
        elevation: 2,
    },
    md: {
        shadowColor: Colors.shadow,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 1,
        shadowRadius: 8,
        elevation: 4,
    },
    lg: {
        shadowColor: Colors.shadowDark,
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 1,
        shadowRadius: 16,
        elevation: 8,
    },
} as const;
