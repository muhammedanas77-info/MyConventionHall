export default {
    light: {
        text: '#1A0E0E',
        background: '#FBF7F0',
        tint: '#8B1A2B',
        tabIconDefault: '#9B8E86',
        tabIconSelected: '#8B1A2B',
    },
};
