import type { SeasonType } from '@/types';

export const MONTH_SEASONS: Record<number, SeasonType> = {
    0: 'peak',       // Jan
    1: 'peak',       // Feb
    2: 'shoulder',   // Mar
    3: 'peak',       // Apr
    4: 'peak',       // May
    5: 'off_season', // Jun
    6: 'off_season', // Jul
    7: 'off_season', // Aug
    8: 'off_season', // Sep
    9: 'shoulder',   // Oct
    10: 'peak',      // Nov
    11: 'peak',      // Dec
};

export function getSeasonForDate(date: Date): SeasonType {
    return MONTH_SEASONS[date.getMonth()];
}

export function getSeasonForMonth(month: number): SeasonType {
    return MONTH_SEASONS[month];
}
