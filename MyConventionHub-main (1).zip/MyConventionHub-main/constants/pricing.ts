import type { SeasonType, SlotType } from '@/types';

export const SEASON_SLOT_MULTIPLIERS: Record<SeasonType, Record<SlotType, number>> = {
    off_season: {
        morning: 1.0,
        evening: 1.2,
        full_day: 1.7,
    },
    shoulder: {
        morning: 1.3,
        evening: 1.5,
        full_day: 2.1,
    },
    peak: {
        morning: 1.6,
        evening: 1.9,
        full_day: 2.8,
    },
};

export const COMMISSION_RATE = 0.08;
export const ADVANCE_RATE = 0.30;

export const DISCOUNT_TIERS = [
    { maxPrice: 100000, discount: 2000 },
    { maxPrice: 200000, discount: 5000 },
    { maxPrice: Infinity, discount: 10000 },
] as const;

export const SLOT_LABELS: Record<SlotType, string> = {
    morning: 'Morning',
    evening: 'Evening',
    full_day: 'Full Day',
};

export const SEASON_LABELS: Record<SeasonType, string> = {
    peak: 'Peak Season',
    shoulder: 'Shoulder Season',
    off_season: 'Off Season',
};
