import type { VendorSector, PriceUnit } from '@/types';

// ─── SectorConfig interface ───────────────────────────────────────────────────

export interface SectorConfig {
  id: VendorSector;
  displayName: string;
  iconName: string;          // lucide-react-native icon name
  badgeColor: string;        // hex colour used for sector badge / tile
  description: string;
  defaultPriceUnit: PriceUnit;
}

// ─── Ordered list of all sectors ─────────────────────────────────────────────

export const SECTOR_LIST: VendorSector[] = [
  'venue',
  'florist',
  'musician',
  'photographer',
  'caterer',
  'decorator',
  'artist',
  'other',
];

// ─── Per-sector configuration ─────────────────────────────────────────────────

export const SECTOR_CONFIGS: Record<VendorSector, SectorConfig> = {
  venue: {
    id: 'venue',
    displayName: 'Venue',
    iconName: 'Building2',
    badgeColor: '#6366F1',
    description: 'Banquet halls, gardens, and event spaces for every occasion.',
    defaultPriceUnit: 'per_day',
  },
  florist: {
    id: 'florist',
    displayName: 'Florist',
    iconName: 'Flower2',
    badgeColor: '#EC4899',
    description: 'Fresh floral arrangements, bouquets, and décor for your event.',
    defaultPriceUnit: 'per_event',
  },
  musician: {
    id: 'musician',
    displayName: 'Musician',
    iconName: 'Music',
    badgeColor: '#F59E0B',
    description: 'Live bands, solo artists, and DJs to set the perfect mood.',
    defaultPriceUnit: 'per_event',
  },
  photographer: {
    id: 'photographer',
    displayName: 'Photographer',
    iconName: 'Camera',
    badgeColor: '#0EA5E9',
    description: 'Professional photography and videography to capture every moment.',
    defaultPriceUnit: 'per_event',
  },
  caterer: {
    id: 'caterer',
    displayName: 'Caterer',
    iconName: 'UtensilsCrossed',
    badgeColor: '#10B981',
    description: 'Catering services with diverse cuisines for any event size.',
    defaultPriceUnit: 'per_plate',
  },
  decorator: {
    id: 'decorator',
    displayName: 'Decorator',
    iconName: 'Sparkles',
    badgeColor: '#8B5CF6',
    description: 'Creative decoration and styling to transform your event space.',
    defaultPriceUnit: 'per_event',
  },
  artist: {
    id: 'artist',
    displayName: 'Artist',
    iconName: 'Palette',
    badgeColor: '#F97316',
    description: 'Performers, painters, and entertainers to delight your guests.',
    defaultPriceUnit: 'per_event',
  },
  other: {
    id: 'other',
    displayName: 'Other',
    iconName: 'MoreHorizontal',
    badgeColor: '#6B7280',
    description: 'Specialised event services that don\'t fit a standard category.',
    defaultPriceUnit: 'per_event',
  },
};

// ─── Helper ───────────────────────────────────────────────────────────────────

export function getSectorConfig(sector: VendorSector): SectorConfig {
  return SECTOR_CONFIGS[sector];
}
