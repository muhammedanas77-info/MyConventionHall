# Phase 1 Quick Reference

## TL;DR: What Changed?

| What | Before | After |
|------|--------|-------|
| **Login OTP** | Hardcoded `123456` | Real email from Supabase |
| **Auth Provider** | AppProvider mock login | Supabase AuthProvider |
| **Booking Status** | Auto-confirmed | Pending (wait for payment) |
| **Double-Booking** | No prevention | Database constraint + UI check |
| **Session** | Lost on reload | Persists via Supabase |

---

## Key Files to Know

### Core Authentication
```
app/customer-login.tsx       Real OTP email sent to customers
app/owner-login.tsx          Real OTP for venue partners
app/admin-login.tsx          Real OTP for admins
```

### Core Booking
```
app/booking/[id].tsx         Check availability → pending booking → payment
utils/booking.ts             Availability logic + booking creation
```

### Database
```
scripts/phase1_migration.sql  RUN THIS FIRST! Creates tables + constraints
```

---

## Testing 1-2-3

### 1. Run Migration
```bash
→ Go to Supabase Console
→ SQL Editor → New Query
→ Paste phase1_migration.sql
→ RUN
→ Check: New tables exist (payments, commissions, etc.)
```

### 2. Test Auth
```bash
→ Open app
→ Customer Login → Enter email → Check email for OTP
→ Enter OTP → Should redirect to Discover
→ Reload app → Should still be logged in
```

### 3. Test Double-Booking
```bash
→ Book venue X, May 20, Evening slot
→ Try to book same venue, date, slot again
→ Should show error or unavailable
```

---

## Common Questions

**Q: Did you break existing bookings?**  
A: No! New columns have defaults. Old bookings still work.

**Q: Do I need SendGrid?**  
A: Not for Phase 1. Supabase sends OTP emails. We add SendGrid later.

**Q: What if OTP doesn't arrive?**  
A: Check Supabase Auth settings, spam folder, or see troubleshooting in guide.

**Q: Can I rollback?**  
A: Yes! See PHASE1_MIGRATION_GUIDE.md for SQL to undo.

**Q: How long until Phase 2?**  
A: May 15 (payment system) after verification.

---

## Code Flow

### Login Flow (NEW)
```
Email input → Supabase OTP → Email received → Enter OTP
→ Supabase verifies → Profile created (if new)
→ AuthProvider notified → Redirect to dashboard
```

### Booking Flow (UPDATED)
```
Date/Slot selection → Check availability from DB
→ Slot available? Yes: proceed | No: show unavailable
→ Details + Payment button
→ Create booking (status='pending')
→ Create payment record
→ Redirect to payment page (Phase 2)
```

### Database (NEW TABLES)
```
payments          - Track payment transactions
commissions       - Track platform earnings
booking_status_history - Audit trail
partner_analytics - Monthly revenue by owner
```

---

## Checklist Before Deploy

- [ ] Run migration → no errors
- [ ] New tables exist in Supabase
- [ ] Customer login → OTP arrives → works
- [ ] Owner login → OTP arrives → works
- [ ] Admin login → OTP arrives → works
- [ ] Double-booking prevented
- [ ] Session persists after reload
- [ ] No console errors

---

## If Something Breaks

1. **Migration Error** → Check SQL syntax, see guide
2. **OTP Not Arriving** → Check Supabase email settings
3. **Double Booking Still Works** → Constraint may not exist, re-run migration
4. **Session Lost** → Clear app cache, verify AuthProvider mounted
5. **RLS Denies Access** → Verify profile exists with correct role

See full troubleshooting in `PHASE1_MIGRATION_GUIDE.md`

---

## Files You Need

To deploy Phase 1:
```
✅ scripts/phase1_migration.sql        (database)
✅ app/customer-login.tsx               (auth)
✅ app/owner-login.tsx                  (auth)
✅ app/admin-login.tsx                  (auth)
✅ app/booking/[id].tsx                 (booking)
✅ utils/booking.ts                     (logic)
```

---

## Files You Need to Verify

After deployment, check:
```
✅ PHASE1_MIGRATION_GUIDE.md           (test procedures)
✅ PHASE1_COMPLETE.md                  (what was done)
✅ PHASE1_READY_TO_DEPLOY.md           (deploy checklist)
```

---

## Next Phase Preview (Phase 2)

When Phase 1 is verified:
- [ ] UPI payment page
- [ ] Payment verification admin UI
- [ ] Email notifications
- [ ] Booking confirmation

**Target**: May 15-20

---

## Useful SQL Queries

```sql
-- Check migration worked
SELECT * FROM information_schema.tables WHERE table_schema='public';

-- Check double-booking constraint
SELECT * FROM information_schema.table_constraints 
WHERE table_name='bookings' AND constraint_type='UNIQUE';

-- See recent bookings
SELECT * FROM bookings ORDER BY created_at DESC LIMIT 10;

-- See pending payments
SELECT * FROM payments WHERE status='pending';

-- Check your profile
SELECT * FROM profiles WHERE id=auth.uid();
```

---

**Last Updated**: May 5, 2026  
**Phase**: 1 of 6  
**Status**: Ready ✅
