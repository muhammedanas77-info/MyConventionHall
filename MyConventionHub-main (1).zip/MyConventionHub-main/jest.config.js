/** @type {import('jest').Config} */
module.exports = {
  testEnvironment: 'node',
  testMatch: ['**/__tests__/**/*.test.ts', '**/__tests__/**/*.test.tsx'],
  transform: {
    '^.+\\.tsx?$': ['ts-jest', {
      tsconfig: {
        jsx: 'react',
        esModuleInterop: true,
        allowSyntheticDefaultImports: true,
        types: ['jest', 'node'],
      },
    }],
  },
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/$1',
    // Stub out native modules that don't run in Node
    '^react-native$': '<rootDir>/__mocks__/react-native.js',
    '^expo-.*$': '<rootDir>/__mocks__/expo.js',
    '^@expo/.*$': '<rootDir>/__mocks__/expo.js',
    '^react-native-url-polyfill/auto$': '<rootDir>/__mocks__/empty.js',
    '^@react-native-async-storage/async-storage$': '<rootDir>/__mocks__/async-storage.js',
  },
  collectCoverageFrom: [
    'utils/pricing.ts',
    'utils/currency.ts',
    'utils/date.ts',
    'utils/booking.ts',
    'utils/payments.ts',
    'utils/sectorValidation.ts',
    'utils/commissionCalculator.ts',
    'utils/availabilityChecker.ts',
  ],
};
